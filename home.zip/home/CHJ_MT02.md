# CHJ_MT02 静态分析记录（法院 · 判决被起诉者 / Sentence the Prosecuted）

关卡：`CourthouseJudicial / CHJ_LD_MT02_B00`。
产物：`release/home/chj_mt02.py`（分析器）＋ 本文件。

## 1. 新样本 seed=135135（`release/home/test.txt`）

```
Trial ID: CHJ_MT02, Program difficulty: Easy, Stage: CourthouseJudicial, Seed: 135135
三角=408
螺旋=067=RBRoom_West_Blueprints=CHJ_MT02_ProjectionSymbol_BP_A19
骷髅=820=RBRoom_West_ConstructionGore=CHJ_MT02_ProjectionSymbol_BP_A2
五角星=219=RBRoom_EastCorridor_1_Slave_2=CHJ_MT02_ProjectionSymbol_BP_B4
太阳=874=RBRoom_East_Museum=CHJ_MT02_ProjectionSymbol_BP_B14
```

这是本关第一组**同时记录到 actor 与密码**的样本（前几组只有密码、或只有房间），
因此它把「密码链」和「房间」两件事一次性钉住了。

## 2. 密码主链：已验证 19/19

`python release\home\chj_mt02.py --regress` → **19/19**（原 14/14，新增 135135 的 5 个）。

```
三角 408  螺旋 067  骷髅 820  五角星 219  太阳 874      # 135135
```

链路由两个已反编译的函数确定：

| 地址 | 作用 |
|---|---|
| `0x1436E95F0` | 主随机化（开头调用 `0x1436E7F70` 做前置） |
| `0x1436EA3D0` | 三位密码生成 |
| `0x1437056A0` | 数字池交换删除 |
| `0x1402D29E0` | `RandSeeded` |
| `0x140503B80` | `GetSeed` |

```text
coordSeed = GetSeed(协调器)
# 协调器内 2 个线索组的抽取顺序：同一池上 RemoveAtSwap
for i in 0 .. 组数-1:
    gi    = RandSeeded(i + 46541, 剩余组数)
    group = 剩余组[gi]
    base  = GetSeed(该组真实投影器) + coordSeed + i
    code  = Draw3(base)              # 0-9 池，末尾交换删除，三位互不重复
Draw3 内部：RandSeeded(base + 38541 + k, len(pool))，k = 0,1,2
```

注意 `base` 里的 `i` 是**循环序号**，不是符号序号；线索组被抽走的顺序会改变密码，
所以「骷髅在第几位」本身就是随机结果，不能按符号名固定。

## 3. 前置 Actor Randomization：本次新确认的事实

`0x1436E7F70` 是个小函数（0x2ca），结构非常干净：

```text
if (bUseContainerActorsRandomization) {
    if (SpecificContainerActors.Num() > 0)       // a1+4216 / a1+4224
        sub_1402AF490(..., 候选表, "Projection Containers")   // 显式列表分支
    else
        sub_140A61C30(..., "Objective Actors")               // 回退分支
}
if (bUseCodeProjectorsRandomization) {
    if (显式投影器表.Num() > 0)                  // a1+4240 / a1+4248
        sub_1402AF490(..., 候选表, "Projection Actors")      // 显式列表分支
    else
        sub_140A61C30(..., "Objective Actors")               // 回退分支
}
```

三个盐是**硬编码宽字符串**，本次逐一按 RVA 从 exe 里读出（IDA 的 `read_bytes`
在本环境不可用，改为直接解析 PE 节表读文件字节）：

| 地址 | 字符串 | 用在哪条分支 |
|---|---|---|
| `0x1466657A0` | `Projection Containers` | 容器 · 显式候选列表非空 |
| `0x14665E230` | `Projection Actors` | 投影器 · 显式候选列表非空 |
| `0x14665E254` | `Objective Actors` | 候选表为空时的回退 |

**这修正了旧记录的说法。** 旧记录把 `crc4("Objective Actors") + GetSeed(coordinator)`
直接写成「前置核心」的种子基；实际它只是**回退分支**的盐。真正用哪条分支取决于
关卡有没有给显式候选表：

- `MHS_MT01` 用的是 `Projection Actors`（它给了显式候选表，见
  `release/seed/seed.py` 的 `MHS_PICK_SALT`）—— 两个关卡的盐不同，别混用。
- `CHJ_MT02` 的协调器**只有 `SpecificContainerActors`（容器那两路），没有任何显式
  投影器候选表**，所以 `a1+4248 == 0` → 走 `sub_140A61C30` + `Objective Actors`。

`sub_140A61C30` 本身（0x358）确认了候选来源：

```text
v11 = a2->GetWorld()                       // 取世界
TActorIterator(v30, v11, CodeProjectorActorClass)
while (!iter_done) {
    actor = *iter
    if (actor && !(actor->Flags & 0x10)) 追加到 v28    // 去重 + 过滤
    ++iter
}
sub_1402B05C0(输出, 协调器, &v28, 盐字符串)
```

**即候选是运行时用 `TActorIterator` 按 `CodeProjectorActorClass` 现场收集的，
不是关卡 JSON 里那份显式列表。** 这解释了旧记录里
「`sub_1436E8B40` 读的是 `a1+18912` 的前置输出列表，不是 `TActorIterator` 的 21 个 actor」：
21 个只是入库顺序，经过 `sub_1402B05C0` 之后才成为真正的池。

两个 wing 各 21 个点位，教学翼 1 个（`C_4`，池恒为 1 → 恒选 `C_4`，与四批
seed 全部一致，这条已经可以当确定性结论用）。

## 4. 尚未闭环的部分

密码链上游的**真实投影器**仍不能只靠脚本算出。当前卡在 `sub_1402B05C0`
（与 `sub_1402B4CA0`/`sub_1402B3C30` 配合）里的这几件事：

1. `TActorIterator` 收集后的**候选顺序**与「按名字整理」的具体排序键；
2. 距离校验阈值（`DistanceBetween*Objectives`）在本关是否真的生效；
3. `CodeProjectorsRandomizationSetup.DesiredCount = 2` 的**补位/回退路径**——
   旧记录已指出「拒绝后输出计数与候选池要分别处理」，本次仍未拆开。

已排除（扫描过，均不成立）：

- 盐 `Objective Actors` / `Projection Actors` / `Projection Containers`，
  偏移 0..3000 及 3156 / 38541 / 39135 / 46541 / 61390 / 94922；
- 候选池 21 个，顺序取「全名字典序 / JSON 导出序 / 数值序」；
- 两次抽取共享同一 base、或独立不删除、或用 `base + i` 配 `RemoveAtSwap`。

换句话说：**不是偏移没扫到，而是池本身在 `sub_1402B05C0` 里被改过**
（排序 + 过滤 + 补位），直接拿 21 个入库 actor 当池算不出来。

## 5. 已验证的反例：图案不是绑定在 actor 上的

同一 actor 在不同 seed 里属于不同图案：

| actor | 135135 | 713713 | 620620 | 20020 |
|---|---|---|---|---|
| `A2` | 骷髅 | 螺旋 | — | — |
| `A3` | — | — | 骷髅 | 螺旋 |

所以「先定点位、再定图案」是错的；**先抽 actor，图案由协调器的线索组抽取
（`i + 46541`）另行指派**。建模时不要把候选池按图案切开。

## 6. 建议的下一步

1. 反编译 `sub_1402B05C0`，重点看它对传入池做的排序、过滤和补位，
   拿到真正的池与 `DesiredCount` 循环 → 这一步做完本关就闭环。
2. 比对 `MHS_MT01`：它走的是 `Projection Actors` 那条显式列表分支，
   池只有 10（TrainDepot 去重后 8）；把两条分支的入参差异列出来可以直接互证。
3. 取样时优先记**房间 + actor + 密码三件套**（135135 这种做法），
   只有密码的样本无法反推 actor。

## 7. 复用经验

- 别把三个盐混用：`Objective Actors` 是回退盐，`Projection Actors` /
  `Projection Containers` 是显式候选表分支的盐，关卡有没有给表决定用哪个。
- 候选是运行时按 `CodeProjectorActorClass` 收集的，关卡 JSON 里没有这份表，
  JSON 的 21 个 actor 只是入库顺序，不是抽取池。
- 不要按图案切分候选池；图案是抽完 actor 之后才指派的。
- 教学翼池恒为 1，`C_4` 可以直接当常量。
- 密码三位互不重复，且删的是**末尾交换**不是保序删除。

## 8. 补记：`sub_1402B05C0` 反编译后确认的抽取公式（本次突破）

`sub_1402B05C0` 共 0x22f2 字节。真正干活的循环在 `0x1402B17B1` 起：

```text
v240 = crc4(盐字符串) + GetSeed(协调器)      # 0x1402B161C / 0x1402B163E
                                             # 盐 = 'Objective Actors'
for 每个线索组 g（24 字节：{Pool TArray, DesiredCount}，按 PossibleClueGroups 原序）:
    for i in 0 .. g.DesiredCount - 1:
        n = g.Pool.Num()
        if n > 0 and levelSeed != 0:
            idx  = RandSeeded(v240 + 已选总数, n)   # ★ 种子基 + 全局已选计数
            actor = g.Pool[idx]
            RemoveAtSwap(g.Pool, idx)
            RemoveAtSwap(全局 Src, actor)
            已选总数 += 1
```

与旧模型不同的三点：

1. **种子是「种子基 + 已选总数」，不是「+ 组号」也不是「+ i」**；计数器跨线索组共享、单调递增。
2. **每个线索组有独立池**，由 `sub_1402B4CA0` 用 `TActorIterator` 来的候选 + 距离阈值
   + 常量 `200.0f`（`0x43480000`，以 float 传入）建出，不是共用 21 项池。
3. 抽中的 actor 会同时从组的池和全局 `Src` 里删掉。

### 实测吻合度

用「池 = 21 个 A/B 翼候选（全名字典序）」算第一槽（`base + 0`）：

| 翼 | 20020 | 135135 | 620620 | 713713 |
|---|---|---|---|---|
| A | A6 ✓ | A2 ✓ | A3 ✓ | A2（实测 A18/A2） |
| B | B24 ✓ | B4 ✓ | B19 ✓ | B16（实测 B23/B16） |

**第一槽 6/8 精确命中**（随机期望 1/21）。这同时钉住了三件事：盐是
`Objective Actors`、池序是全名字典序、种子基是「+ 已选总数」（第一槽即 `+0`）。

713713 两例的 A2 / B16 确实落在实测的两个 actor 里，只是被指派给了
Spiral / Sun —— 说明**线索组的处理顺序也是随机的**，与密码链里
`i + 46541` 那次抽取是同一件事的两面。

### 剩下的最后一步

第二槽目前 8/8 全错。

## 9. 补记：`sub_1402B4CA0` 是候选过滤器，不是组构建器

`sub_1402B4CA0(a1, a2, a3, a4, a5, a6, a7, a8)`（0x921 字节）反编译结果：

- `a1` = 输出，一个 TSet，元素 24 字节 `{Actor(8), Flag(8), NextIdx(4), Hash(4)}`；
- `a5` = 候选 TArray（即 `Src`）；
- `a6` = 距离阈值（`v74` 六个 float 全部填成 a6，`v74[0] = 1`）；
- `a7` = `200.0f`（`0x43480000`）。

主循环 `0x1402B4ED0` 起：

```text
v22 = Src.Num()
do {
    v23 = v22--;                            # ★ 从数组尾部往前遍历
    v24 = Src[v23 - 1];
    if (!*(QWORD*)(v24 + 16)) { RemoveAtSwap(Src, v22); continue; }   # 无 Room → 丢弃
    v26 = sub_1402A53F0(v24);               # 取组件
    ...取该 actor 的一个或多个世界坐标 → v69（每项 12 字节）
    for 每个坐标 loc in v69:
        if (!sub_141D1E3B0(世界, RBPushCartSpawner 列表, loc, v40, v74, &v70))
            continue;                        # 未通过可达性校验
        flag = (a6 <= a7 || a7 <= v70) ? 0 : 1
        把 v24 加进 a1（TSet），带 flag
        RemoveAtSwap(Src, v22)               # ★ 通过者从 Src 移除
} while (v23 > 1);
```

要点：

1. **遍历方向是从尾到头**，不是从头到尾；每轮 `RemoveAtSwap(Src, v22)` 用的是
   递减后的下标。这直接决定了「哪些候选留下、以及留下的顺序」。
2. `a6 <= a7 || a7 <= v70` 在本关恒为真（a6 是 0 量级、a7 = 200），
   所以 flag 恒为 0，距离分支实际上不产生分化。
3. 通过者进 TSet 并从 `Src` 移除；**未通过者留在 `Src`**，随后在
   `0x1402B1BA9` 被统一 `sub_1402B2930(x, 0, 协调器)` 关闭。

### 组到底是谁建的

`sub_1402B05C0` 里 `v261`（线索组数组）不是 `sub_1402B4CA0` 的产物，而是
`0x1402B1683` 处的分支：

```text
if (*(BYTE*)(a1 + 1000) && v127 >= 2 && v247 > 0)
    sub_1402C30C0(a1, &Src, v127, &v261, &v240);      # 多组路径
else
    # 单组回退：一个组装下整个 Src，DesiredCount = v127（本关 = 2）
```

也就是说：**若走单组回退，就是「一个 21 项池 + DesiredCount 2 + 末尾交换」**
—— 这正是当前脚本试的模型，第一槽 6/8 命中、第二槽全错，说明本关更可能
走的是 `sub_1402C30C0` 多组路径（两组各自的池不同）。

## 10. `sub_1402C30C0`：分组 + 随机排序 + 分配 DesiredCount（链路闭合）

签名 `sub_1402C30C0(协调器, &候选, 需要数, &输出组, &base)`，`a5 = &v240`
是**种子基的指针**（会被就地递增）。依次做四件事：

**① 按「客观类型」把候选分桶**（`0x1402C31CC` 起）

```text
if (*(BYTE*)(协调器 + 1001) == 1)
    # 用 RBRoomAssociationComponent：取 actor 所属房间，在关卡房间表里查索引
    v22 = 房间索引
else
    # 用 RBObjectiveRandomizable 接口的 GetObjectiveType()
    v22 = 客观类型
把该 actor 加进 组[v22].Pool
```

**即：同一房间（或同一客观类型）的候选归为一组。** 组的元素 24 字节
`{Pool Data(8), Count(4), Max(4), DesiredCount(4), pad}`。

**② 随机打乱组的输出顺序**（`0x1402C40E6` 起）

```text
while (组非空) {
    i = RandSeeded(*a5, 剩余组数);      # ★ 用种子基本身
    *a5 += 1;                           # ★ 种子基就地 +1
    把 组[i] 追加到输出;
    RemoveAtSwap(组, i);                # 24 字节步长
}
```

**这是最关键的一点：分组阶段会推进种子基。** 设共有 N 个组，则回到
`sub_1402B05C0` 时种子基已经变成 `原base + N`，抽取循环的第一发
用的是 `原base + N`，**不是 `原base + 0`**。

**③ 分配 DesiredCount**（`0x1402C42E7` 起）

```text
需要数 = v179（本关 = 2）
第一遍：给前 min(需要数, 组数) 个组各 +1
有余数：v151 = (float)(组.Pool.Num() / 候选总数) * (float)需要数
        v152 = (int)((v151 - 1) * 2 + 0.5) >> 1; 按需数截断后追加
```

本关需要数 = 2、组数 ≥ 2 → **前两组各得 1，其余为 0**，正好抽两次。

**④ 回到 `sub_1402B05C0` 的抽取**

```text
for g in 输出组（已被打乱的顺序）:
    for k in 0 .. g.DesiredCount - 1:
        idx = RandSeeded(base + 已选总数, g.Pool.Num())   # base 已 +N
```

### 完整链路

```text
候选 = TActorIterator(CodeProjectorActorClass)          # 21 个/翼
候选 = sub_1402B4CA0 过滤（从尾到头，RBPushCartSpawner 可达性）
base = crc4('Objective Actors') + GetSeed(协调器)
组   = sub_1402C30C0：按房间分桶 → 随机排序（base 递增 N 次）→ 前 2 组各 DesiredCount 1
抽   = 每组 RandSeeded(base + 已选总数, 该组池大小)，末尾交换删除
密码 = Draw3(GetSeed(投影器) + GetSeed(协调器) + 线索组循环号)
```

### 为什么之前第一槽能撞对 6/8

之前用的是「单一 21 项池 + `base + 0`」。真实是**按房间切的小池**、
且起始种子是 `base + 组数`。两者只在个别 seed 上偶然重合，所以才出现
「第一槽 6/8、第二槽 0/8」这种半对不对的结果。

### 下一步（工程量已很小）

1. 取每个 `CHJ_MT02_ProjectionSymbol_BP_A*/B*` 的**房间**
   （`RBRoomAssociationComponent`，32 个房名见 wiki §3.3/3.4）；
2. 按房间分桶 → 得到 N 个组与每组池；
3. 按上面的公式复算；用 135135（房间+actor+密码三件套齐全）做校验。

房间数据到位后本关即闭环，随后可把 1000 个 d 整表导出。
