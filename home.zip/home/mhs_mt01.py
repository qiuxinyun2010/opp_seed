# -*- coding: utf-8 -*-
"""MHS_MT01「黑帮据点 · 找到 3 个投影房间并输入 3 位密码」种子模型（第三轮 · 已闭环）。

第三轮（2026-10-29）补上最后一块：**TrainDepot 的候选池要从 10 个剔到 8 个**。

    pool    = 该区 10 个投影符号，按【关卡 actor 顺序】= 全名字典序 _1,_10,_2,_3…_9
    ★ 若该区 CodeProjectorsRandomizationSetup.bLimitOneObjectivePerRoom = true
      （本关只有 TrainDepot）：池内「与前面任一候选共房间」的候选被 RemoveAt，
      保留靠前的那个。TrainDepot 因此 10 → 8（_8、_9 被剔）。
    base    = crc32_fname("Projection Actors") + GetSeed(协调器)   # 引擎 sub_1402B05C0
    idx     = RandSeeded(base + 0, len(pool))                      # DesiredCount=1
    图案     = RandSeeded(46541, |PossibleClueGroups|)              # DrugLab/Shipyard 恒骷髅/三角
    密码     = Draw( GetSeed(symbol) + GetSeed(coordinator) )
    RandSeeded 内部掺关卡种子 salt = S % 1000

实测 4 个 seed（759759 / 884884 / 771771 / 707707）：
    密码主链 11/11，抽取 12/12，图案 4/4，房间 8/10。

用法：
    python mhs_mt01.py 707707              # ★ 3 行：图案 / 房间 / 密码 / actor / 坐标
    python mhs_mt01.py 707707 --json
    python mhs_mt01.py --pool              # 三个区的抽取池（含剔除标记）
    python mhs_mt01.py --list              # 30 个候选
    python mhs_mt01.py --codes 884884      # 该 seed 下 30 个候选各自的 3 位密码
    python mhs_mt01.py --find 884884 806   # 密码 → 房间（反向查）
    python mhs_mt01.py --selftest
"""
import json
import sys

M32 = 0xFFFFFFFF
M64 = 0xFFFFFFFFFFFFFFFF

# ---------------------------------------------------------------------------
# 盐名（从 .rdata 读出，非猜）
# ---------------------------------------------------------------------------
SALT_PROJECTORS = 'Projection Actors'      # 宽串 @0x14665E230
LEVEL_OBJECT = 'PersistentLevel'
SYMBOL_PREFIX = 'MT01_ProjectionSymbol_BP_'

# 协调器 Projections_Coordinator_BP_C（SuperStruct = RBProjectionCodeCoordinator）
# limit_one_per_room 来自各协调器自己的 CodeProjectorsRandomizationSetup：
#   DrugLab / Shipyard = false（池保持 10），TrainDepot_1 = true（10 → 8）
ZONES = [
    {
        'key': 'DrugLab',
        'coord': 'MT01_Projections_Coordinator_BP_DrugLab',
        'container': 'MT01_PasscodeTriggerable_Base_BP_DrugLab',
        'clues': [['Skull1', 'Skull2', 'Skull3']],
        'patterns': ['Skull 骷髅'],
        'limit_one_per_room': False,
    },
    {
        'key': 'Shipyard',
        'coord': 'MT01_Projections_Coordinator_BP_Shipyard',
        'container': 'MT01_PasscodeTriggerable_Base_BP_Shipyard',
        'clues': [['TriangleCircle1', 'TriangleCircle2', 'TriangleCircle3']],
        'patterns': ['TriangleCircle 三角'],
        'limit_one_per_room': False,
    },
    {
        'key': 'TrainDepot',
        'coord': 'MT01_Projections_Coordinator_BP_TrainDepot_1',
        'container': 'MT01_PasscodeTriggerable_Base_BP_TrainDepot_1',
        'clues': [['Spiral1', 'Spiral2', 'Spiral3'],
                  ['Pentagram1', 'Pentagram2', 'Pentagram3'],
                  ['Sun1', 'Sun2', 'Sun3']],
        'patterns': ['Spiral 螺旋', 'Pentagram 五角星', 'Sun 太阳'],
        'limit_one_per_room': True,
    },
]
ZONE_BY_KEY = {z['key']: z for z in ZONES}

# ---------------------------------------------------------------------------
# 静态表：(zone, short, texture, actor_loc, [候选房间, ...])
# 房间元组 = (raw_name, zmin, zmax, cx, cy)；来自
# paks/MAP/Maps/MobsterHideoutSyndicate/MHS_LD_MT01_B00.json +
# release/map/out/MobsterHideoutSyndicate/plan.json，已固化，运行时不再依赖。
# 顺序 = 关卡 actor 顺序（全名字典序 _1,_10,_2…_9），**就是抽取池顺序**。
# ---------------------------------------------------------------------------
STATIC = [
    # DrugLab
    ('DrugLab', '1', 'MHS_MT01_Projection_02', (868.1, -2164.2, 450.0), [('RBRoom_DrugLab_2F_Lab_03', 445, 800, 690, -2608)]),
    ('DrugLab', '10', 'MHS_MT01_Projection_25', (2215.2, -726.0, 450.0), [('RBRoom_DrugLab_2F_WalkwayRoom', 445, 865, 1522, -735)]),
    ('DrugLab', '2', 'MHS_MT01_Projection_01', (1678.6, -671.2, 0.5), [('RBRoom_DrugLab_1F_ChemicalStorage', 0, 435, 1259, -519), ('RBRoom_DrugLab_2F_WalkwayRoom', 445, 865, 1522, -735)]),
    ('DrugLab', '3', 'MHS_MT01_Projection_06', (1141.7, -1663.1, 450.0), [('RBRoom_DrugLab_2F_Kitchen', 220, 805, 826, -1475)]),
    ('DrugLab', '4', 'MHS_MT01_Projection_07', (1578.3, -849.9, 450.0), [('RBRoom_DrugLab_1F_ChemicalStorage', 0, 435, 1259, -519), ('RBRoom_DrugLab_2F_WalkwayRoom', 445, 865, 1522, -735)]),
    ('DrugLab', '5', 'MHS_MT01_Projection_16', (2815.4, -1670.8, 0.5), [('RBRoom_Casino_2F_Roof_13', 449, 864, 2683, -2114), ('RBRoom_DrugLab_1F_Corridor', -5, 435, 2472, -1279)]),
    ('DrugLab', '6', 'MHS_MT01_Projection_17', (2189.5, -1796.2, 0.5), [('RBRoom_DrugLab_1F_Corridor', -5, 435, 2472, -1279), ('RBRoom_DrugLub_2F_Hallway_Master', 445, 875, 1877, -1828)]),
    ('DrugLab', '7', 'MHS_MT01_Projection_22', (799.5, -618.6, 0.5), [('RBRoom_DrugLab_1F_ChemicalStorage', 0, 435, 1259, -519), ('RBRoom_DrugLab_2F_WalkwayRoom', 445, 865, 1522, -735)]),
    ('DrugLab', '8', 'MHS_MT01_Projection_23', (720.9, -426.1, 0.5), [('RBRoom_DrugLab_1F_ChemicalStorage', 0, 435, 1259, -519)]),
    ('DrugLab', '9', 'MHS_MT01_Projection_24', (1245.9, -2159.0, 450.0), [('RBRoom_DrugLub_2F_Hallway_Master', 445, 875, 1877, -1828)]),
    # Shipyard
    ('Shipyard', '1', 'MHS_MT01_Projection_03', (4084.0, 1313.2, 250.5), [('RBRoom_Shipyard_Stairs', -10, 925, 3721, 939)]),
    ('Shipyard', '10', 'MHS_MT01_Projection_21', (3554.1, 3567.7, 452.7), [('RBRoom_Shipyard_01', -4, 695, 3382, 2781), ('RBRoom_Shipyard_Tower_Balcony', 452, 865, 4016, 2337)]),
    ('Shipyard', '2', 'MHS_MT01_Projection_04', (2407.0, 2623.5, 0.5), [('RBRoom_Shipyard_01', -4, 695, 3382, 2781)]),
    ('Shipyard', '3', 'MHS_MT01_Projection_05', (1896.7, 3894.6, 0.5), [('RBRoom_Shipyard_01', -4, 695, 3382, 2781)]),
    ('Shipyard', '4', 'MHS_MT01_Projection_08', (4258.4, 2215.5, 100.5), [('RBRoom_Shipyard_01', -4, 695, 3382, 2781), ('RBRoom_Shipyard_Tower_Balcony', 452, 865, 4016, 2337)]),
    ('Shipyard', '5', 'MHS_MT01_Projection_09', (3306.4, 1451.1, 0.5), [('RBRoom_Shipyard_02', 0, 751, 2623, 1269)]),
    ('Shipyard', '6', 'MHS_MT01_Projection_15', (4624.5, 766.7, 452.6), [('RBRoom_Casino_Ext_Dock_Corner_Slave', 5, 415, 4492, 778), ('RBRoom_Casino_Ext_Stairs_2F_Bridge', 440, 1221, 4436, 788)]),
    ('Shipyard', '7', 'MHS_MT01_Projection_18', (3514.0, 2328.6, 452.7), [('RBRoom_Shipyard_01', -4, 695, 3382, 2781), ('RBRoom_Shipyard_Tower_Balcony', 452, 865, 4016, 2337)]),
    ('Shipyard', '8', 'MHS_MT01_Projection_19', (3116.0, 1701.6, 387.0), [('RBRoom_Shipyard_Train_Car_01_2', 90, 380, 2845, 1694), ('RBRoom_Shipyard_TrainCar_Roof', 357, 698, 3232, 1672)]),
    ('Shipyard', '9', 'MHS_MT01_Projection_20', (4152.9, 3379.2, 95.5), [('RBRoom_Shipyard_Tower_FrancoRoom', 447, 722, 3928, 3215), ('RBRoom_Shipyard_Tower_1F_Master', 96, 442, 3936, 2915)]),
    # TrainDepot
    ('TrainDepot', '1', 'MHS_MT01_Projection_10', (592.9, 2723.3, 6.2), [('RBRoom_Train_Bridge_02', -355, 783, 648, 2668)]),
    ('TrainDepot', '10', 'MHS_MT01_Projection_30', (-2215.6, 1703.5, 450.0), [('RBRoom_Train_2ndFloor_Room09', 448, 1023, -2404, 1688), ('RBRoom_Train_Car_03', 90, 380, -2461, 1700)]),
    ('TrainDepot', '2', 'MHS_MT01_Projection_11', (638.7, 2153.9, 250.0), [('RBRoom_TrainDepot2_StairBridge_Master', 245, 695, 602, 2170)]),
    ('TrainDepot', '3', 'MHS_MT01_Projection_12', (-1863.2, 2147.0, 448.4), [('RBRoom_Train_2ndFloor_Lookout', 440, 1461, -1140, 2406), ('RBRoom_Trainyard_1F_Hub', -7, 415, -1537, 2125)]),
    ('TrainDepot', '4', 'MHS_MT01_Projection_13', (999.8, 2571.2, 451.4), [('RBRoom_Train_2ndFloor_Room02', 450, 1090, 1440, 2750), ('RBRoom_Train_Corridor_03', -5, 435, 1280, 2622)]),
    ('TrainDepot', '5', 'MHS_MT01_Projection_14', (624.6, 1458.3, 450.0), [('RBRoom_Train_2ndFloor_Cooridor_05', 451, 941, 138, 1368)]),
    ('TrainDepot', '6', 'MHS_MT01_Projection_26', (-2366.1, 905.3, 450.0), [('RBRoom_Train_2ndFloor_Cooridor_08', 450, 980, -2465, 912), ('RBRoom_Train_Entrance', 100, 430, -1905, 1259)]),
    ('TrainDepot', '7', 'MHS_MT01_Projection_27', (-2313.7, 2899.4, 450.0), [('RBRoom_Train_2ndFloor_Cooridor_01', 450, 1130, -2426, 3061), ('RBRoom_Train_Room_03', 95, 425, -2650, 3126)]),
    ('TrainDepot', '8', 'MHS_MT01_Projection_28', (-1907.5, 3055.2, 450.0), [('RBRoom_Train_2ndFloor_Room01', 450, 810, -1730, 3035), ('RBRoom_Train_Room_03', 95, 425, -2650, 3126)]),
    ('TrainDepot', '9', 'MHS_MT01_Projection_29', (344.4, 2599.6, 4.2), [('RBRoom_Train_Bridge_02', -355, 783, 648, 2668)]),
]


def _primary_room(cells, x, y, z):
    """点 → 主房间：同类候选里优先「z 落在 zmin..zmax 内」，避免串楼层。"""
    if not cells:
        return '', True
    def key(c):
        zdist = max(0.0, c[1] - z, z - c[2])
        return (zdist, (c[3] - x) ** 2 + (c[4] - y) ** 2)
    best = min(cells, key=key)
    return best[0], max(0.0, best[1] - z, z - best[2]) > 150.0


SYMBOLS = {}
for _z, _s, _tex, _loc, _cells in STATIC:
    SYMBOLS.setdefault(_z, []).append({
        'zone': _z,
        'short': _s,
        'name': SYMBOL_PREFIX + _z + '_' + _s,
        'texture': _tex,
        'loc': _loc,
        'rooms': [c[0] for c in _cells],
        'room': _primary_room(_cells, *_loc)[0],
        'room_approx': _primary_room(_cells, *_loc)[1],
    })

# ---------------------------------------------------------------------------
# 随机原语（与 release/seed/seedcore.py 同源）
# ---------------------------------------------------------------------------
_T = []
for _i in range(256):
    _c = _i
    for _ in range(8):
        _c = ((_c >> 1) ^ 0xEDB88320) if (_c & 1) else (_c >> 1)
    _T.append(_c & M32)


def crc32_fname(text):
    """sub_141CBDC30：每个 UTF-16 字符按 [lo, hi, 0, 0] 走 4 步标准 CRC32。"""
    crc = M32
    for ch in text:
        u = ord(ch) & 0xFFFF
        crc = _T[(crc ^ (u & 0xFF)) & 0xFF] ^ (crc >> 8)
        crc = _T[(crc ^ (u >> 8)) & 0xFF] ^ (crc >> 8)
        crc = _T[crc & 0xFF] ^ (crc >> 8)
        crc = _T[crc & 0xFF] ^ (crc >> 8)
    return (~crc) & M32


def seed_of_object(name, outer_seed=None):
    """sub_140503B80 的名字兜底分支：|crc(name) + seed(Outer)|。"""
    if outer_seed is None:
        outer_seed = crc32_fname(LEVEL_OBJECT)
    value = (crc32_fname(name) + outer_seed) & M32
    return value if value < 0x80000000 else (0x100000000 - value) & M32


def _mix64(seed, salt):
    a = (0xBF58476D1CE4E5B9 * ((seed ^ (seed >> 30)) & M64)) & M64
    a ^= a >> 27
    b = (0xBF58476D1CE4E5B9 * (salt % 1000)) & M64
    b ^= b >> 27
    v = (((0x94D049BB133111EB * a) & M64) ^ ((0x94D049BB133111EB * b) & M64)) & M64
    t = (v ^ (v >> 31)) & M64
    w = (0xBF58476D1CE4E5B9 * (t ^ (t >> 30))) & M64
    u = (w ^ (w >> 27)) & M64
    r = (((321982955 * u) & M64) ^ (((0x94D049BB133111EB * u) & M64) >> 31)) & M64
    return r & M32


def rand_seeded(seed, n, level_seed):
    """sub_1402D29E0(seed, N)：内部掺 dword_146E2E5C4 % 1000，取 (uint16)hash % N。"""
    if not n or not level_seed or not seed:
        return 0
    return (_mix64(seed & M32, level_seed) & 0xFFFF) % n


def draw_code(base, level_seed, digits=3):
    """sub_1436EA3D0：池 0..9，逐位抽取，**交换删除**（末尾元素填洞）。"""
    pool = list(range(10))
    out = []
    for k in range(digits):
        idx = rand_seeded((base + 38541 + k) & M32, len(pool), level_seed)
        out.append(str(pool[idx]))
        pool[idx] = pool[-1]
        pool.pop()
    return ''.join(out)


# ---------------------------------------------------------------------------
# 密码主链
# ---------------------------------------------------------------------------
def code_of(symbol, zone_key, level_seed, slot=0):
    """真实投影器：base = GetSeed(symbol) + GetSeed(coordinator) + slot。"""
    base = (seed_of_object(symbol)
            + seed_of_object(ZONE_BY_KEY[zone_key]['coord']) + slot) & M32
    return draw_code(base, level_seed)


def fake_code_of(symbol, zone_key, level_seed, k, slot=0):
    """假投影器（同区其余 actor）：base = GetSeed(symbol) + k + GetSeed(coord) + 1 + slot。"""
    base = (seed_of_object(symbol) + k
            + seed_of_object(ZONE_BY_KEY[zone_key]['coord']) + 1 + slot) & M32
    return draw_code(base, level_seed)


# ---------------------------------------------------------------------------
# 图案家族（clue 组）
# ---------------------------------------------------------------------------
def pattern_of(zone_key, level_seed, slot=0):
    """0x1436E95F0：RandSeeded(slot + 46541, |PossibleClueGroups|)。"""
    groups = ZONE_BY_KEY[zone_key]['patterns']
    if len(groups) == 1:
        return groups[0]
    return groups[rand_seeded(46541 + slot, len(groups), level_seed)]


# ---------------------------------------------------------------------------
# 抽取：10 选 1（+ TrainDepot 的「每房间至多一个」剔除）
# ---------------------------------------------------------------------------
def raw_pool(zone_key):
    """关卡 actor 顺序的 10 个候选。"""
    return list(SYMBOLS[zone_key])


def pool_of(zone_key):
    """**抽取池**：bLimitOneObjectivePerRoom 时先按房间去重（保留靠前的）。

    引擎侧是 sub_1402B3C30：距离阈值 v5 <= 0 时跳过距离分支，落到
    `sub_140B3BE80(coord, candidate)` → `RemoveAt(pool, i, 1)` 的那个循环，
    把「和已保留候选共房间」的候选从池里删掉（从尾往前扫，保序）。
    """
    pool = raw_pool(zone_key)
    if not ZONE_BY_KEY[zone_key]['limit_one_per_room']:
        return pool, []
    kept, rooms_seen, dropped = [], set(), []
    for row in pool:
        if rooms_seen & set(row['rooms']):
            dropped.append(row)
            continue
        rooms_seen |= set(row['rooms'])
        kept.append(row)
    return kept, dropped


def pick_base(zone_key):
    """sub_1402B05C0: crc32_fname("Projection Actors") + GetSeed(协调器)。"""
    return (crc32_fname(SALT_PROJECTORS)
            + seed_of_object(ZONE_BY_KEY[zone_key]['coord'])) & M32


def pick_of(zone_key, level_seed, slot=0):
    """本区被点亮的那个投影符号 → (idx, row, pool)。"""
    pool, _ = pool_of(zone_key)
    idx = rand_seeded((pick_base(zone_key) + slot) & M32, len(pool), level_seed)
    return idx, pool[idx], pool


def predict(level_seed, slot=0):
    out = {'level': 'MHS_MT01', 'seed': level_seed, 'salt': level_seed % 1000,
           'zones': []}
    for zone in ZONES:
        key = zone['key']
        idx, row, pool = pick_of(key, level_seed, slot)
        out['zones'].append({
            'zone': key,
            'coordinator': zone['coord'],
            'pattern': pattern_of(key, level_seed, slot),
            'symbol': row['name'],
            'short': row['short'],
            'texture': row['texture'],
            'room': row['room'],
            'room_approx': row['room_approx'],
            'code': code_of(row['name'], key, level_seed, slot),
            'loc': row['loc'],
            'pool_size': len(pool),
            'pool_index': idx,
        })
    return out


# ---------------------------------------------------------------------------
# 实测样本
#   CODE : 玩家记的 3 位密码（→ 反推唯一生效符号）
#   PICK : 生效符号编号（759759/TrainDepot 只有房间记忆，也列进来）
#   ROOM : 玩家记的房间
# ---------------------------------------------------------------------------
SAMPLES = [
    (759759, 'DrugLab', '2', '854'),
    (759759, 'Shipyard', '2', '460'),
    (759759, 'TrainDepot', '2', None),
    (884884, 'DrugLab', '4', '806'),
    (884884, 'Shipyard', '2', '869'),
    (884884, 'TrainDepot', '7', '245'),
    (771771, 'DrugLab', '5', '342'),
    (771771, 'Shipyard', '1', '123'),
    (771771, 'TrainDepot', '5', '015'),
    (707707, 'DrugLab', '9', '384'),
    (707707, 'Shipyard', '6', '102'),
    (707707, 'TrainDepot', '2', '863'),
]
OBSERVED_ROOMS = {
    759759: {'DrugLab': 'RBRoom_DrugLab_1F_ChemicalStorage',
             'Shipyard': 'RBRoom_Shipyard_01',
             'TrainDepot': 'RBRoom_TrainDepot2_StairBridge_Master'},
    884884: {'DrugLab': 'RBRoom_DrugLab_2F_WalkwayRoom',
             'Shipyard': 'RBRoom_Shipyard_01',
             'TrainDepot': 'RBRoom_Train_2ndFloor_Room01'},
    771771: {'DrugLab': 'RBRoom_DrugLab_1F_Corridor',
             'Shipyard': 'RBRoom_Shipyard_02',
             'TrainDepot': 'RBRoom_Train_2ndFloor_Cooridor_05'},
    707707: {'TrainDepot': 'RBRoom_TrainDepot2_StairBridge_Master'},
}
OBSERVED_PATTERN = {759759: 'Spiral 螺旋', 884884: 'Pentagram 五角星',
                    771771: 'Sun 太阳', 707707: 'Spiral 螺旋'}


def selftest(verbose=True):
    res = {'code': [0, 0], 'pick': [0, 0], 'room': [0, 0], 'pattern': [0, 0]}
    for level_seed, zone, short, want in SAMPLES:
        if want is None:
            continue
        got = code_of(SYMBOL_PREFIX + zone + '_' + short, zone, level_seed)
        res['code'][1] += 1
        res['code'][0] += (got == want)
        if verbose:
            print('code    %-7d %-11s #%-3s %-5s %-5s %s'
                  % (level_seed, zone, short, got, want, 'OK' if got == want else 'FAIL'))

    print()
    for level_seed, zone, short, _ in SAMPLES:
        idx, row, pool = pick_of(zone, level_seed)
        ok = row['short'] == short
        res['pick'][1] += 1
        res['pick'][0] += ok
        if verbose:
            print('pick    %-7d %-11s idx=%d/%-2d -> #%-3s want #%-3s %s'
                  % (level_seed, zone, idx, len(pool), row['short'], short,
                     'OK' if ok else 'FAIL'))

    print()
    for level_seed, rooms in sorted(OBSERVED_ROOMS.items()):
        for zone, room in rooms.items():
            _, row, _ = pick_of(zone, level_seed)
            ok = row['room'] == room
            res['room'][1] += 1
            res['room'][0] += ok
            if verbose:
                print('room    %-7d %-11s %-36s %-36s %s'
                      % (level_seed, zone, row['room'], room, 'OK' if ok else 'FAIL'))

    print()
    for level_seed, want in sorted(OBSERVED_PATTERN.items()):
        got = pattern_of('TrainDepot', level_seed)
        res['pattern'][1] += 1
        res['pattern'][0] += (got == want)
        if verbose:
            print('pattern %-7d TrainDepot   %-20s %-20s %s'
                  % (level_seed, got, want, 'OK' if got == want else 'FAIL'))

    print()
    print('selftest: code %d/%d   pick %d/%d   room %d/%d   pattern %d/%d'
          % (res['code'][0], res['code'][1], res['pick'][0], res['pick'][1],
             res['room'][0], res['room'][1], res['pattern'][0], res['pattern'][1]))
    return res


def print_predict(level_seed, as_json=False):
    r = predict(level_seed)
    if as_json:
        print(json.dumps(r, ensure_ascii=False, indent=1))
        return
    print('MHS_MT01  seed=%d  salt=%d' % (r['seed'], r['salt']))
    print('%-18s %-36s %-6s %-40s %s'
          % ('图案', '房间', '密码', '投影符号 actor', '坐标'))
    for z in r['zones']:
        print('%-18s %-36s %-6s %-40s %.0f,%.0f,%.0f'
              % (z['pattern'], z['room'] + ('?' if z['room_approx'] else ''),
                 z['code'], z['symbol'], *z['loc']))


def print_pool():
    for zone in ZONES:
        key = zone['key']
        pool, dropped = pool_of(key)
        print('== %-11s base=0x%08X  bLimitOneObjectivePerRoom=%s  池 %d/%d'
              % (key, pick_base(key), zone['limit_one_per_room'],
                 len(pool), len(raw_pool(key))))
        for i, row in enumerate(pool):
            print('   %2d  %-42s %-34s %s'
                  % (i, row['name'], row['room'], row['texture']))
        for row in dropped:
            print('   xx  %-42s %-34s %s   <- 与前面候选共房间，被剔除'
                  % (row['name'], row['room'], row['texture']))
        print()


def print_list():
    for zone in ZONES:
        print('== %-11s coord=%s' % (zone['key'], zone['coord']))
        print('   %-4s %-24s %-22s %s' % ('#', 'texture', 'actor (X,Y,Z)', 'room'))
        for row in SYMBOLS[zone['key']]:
            print('   %-4s %-24s %-22s %s'
                  % (row['short'], row['texture'],
                     '%.0f,%.0f,%.0f' % row['loc'],
                     row['room'] + ('?' if row['room_approx'] else '')))
        print()


def print_codes(level_seed):
    print('seed=%d  salt=%d   code = Draw(GetSeed(symbol) + GetSeed(coord))'
          % (level_seed, level_seed % 1000))
    for zone in ZONES:
        observed = None
        for s, z, short, code in SAMPLES:
            if s == level_seed and z == zone['key']:
                observed = (short, code)
        print('== %-11s %s' % (zone['key'], pattern_of(zone['key'], level_seed)))
        for row in SYMBOLS[zone['key']]:
            code = code_of(row['name'], zone['key'], level_seed)
            mark = '   <== 实测' if observed and observed[0] == row['short'] else ''
            print('   %-4s %-24s %s  %-36s%s'
                  % (row['short'], row['texture'], code, row['room'], mark))
        print()


def find_by_code(level_seed, code):
    hits = []
    for zone in ZONES:
        for row in SYMBOLS[zone['key']]:
            if code_of(row['name'], zone['key'], level_seed) == code:
                hits.append((zone['key'], row['short'], row['room']))
    return hits


def main():
    argv = sys.argv[1:]
    if not argv or '--help' in argv:
        print(__doc__)
        return
    if '--selftest' in argv:
        selftest()
        return
    if '--pool' in argv:
        print_pool()
        return
    if '--list' in argv:
        print_list()
        return
    if '--codes' in argv:
        print_codes(int(argv[argv.index('--codes') + 1]))
        return
    if '--find' in argv:
        i = argv.index('--find')
        level_seed, code = int(argv[i + 1]), argv[i + 2]
        hits = find_by_code(level_seed, code)
        if not hits:
            print('没有候选投影器的密码等于 %s' % code)
        for zone, short, room in hits:
            print('%-11s #%-3s %s' % (zone, short, room))
        return
    if argv[0].isdigit():
        print_predict(int(argv[0]), '--json' in argv)
        return
    print(__doc__)


if __name__ == '__main__':
    sys.stdout.reconfigure(encoding='utf-8')
    main()
