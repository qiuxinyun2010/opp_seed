# -*- coding: utf-8 -*-
"""SRR_MT02 拟合器：用 test.txt 的 6 条实测（2 seed x 3 区）检验抽取假设。

事实输入（不依赖旧结论）：
  - srr02_pool.json   三个 OrderedClueFrequency 协调器的 PossibleClueNames /
                      OrderedClueActors / ObjectiveActors 顺序（关卡对象树原序）
  - test.txt          seed 417417 / 737737 的逐轮「屏幕 3 图案 + 调频器↔图案」

假设（来自已闭环关卡的逆向结论，见 MHS_MT01.md / opp_seed/seed.py）：
  图案抽取  : CHJ_MT02/MHS 同款 RandSeeded(slot + 46541, |pool|)，交换删除或保序删除，
              base 可含 GetSeed(协调器)
  调频器抽取: 通用引擎 sub_1402B05C0，base = crc32_fname(盐名) + GetSeed(协调器)，
              RandSeeded(base + k, len(pool)) 逐次抽
用法：
  python srr02_fit.py            # 全组合扫描 + 报告
"""
import io
import json
import os
import sys

_HERE = os.path.dirname(os.path.abspath(__file__))
sys.path.insert(0, os.path.join(os.path.dirname(_HERE)))
sys.path.insert(0, r'd:/workspace/outlast/opp_seed')

from seedcore import (crc32_fname, seed_of_object, rand_seeded, M32)

LEVEL_CRC = crc32_fname('PersistentLevel')

POOL = json.load(io.open(os.path.join(_HERE, 'srr02_pool.json'), encoding='utf-8'))
COORDS = POOL['coordinators']

COORD_NAME = {
    'RichDistrict': 'SRR_MT02_OrderedClueFrequency_RichDistrict',
    'School': 'SRR_MT02_OrderedClueFrequency_School',
    'SasExit': 'SRR_MT02_OrderedClueFrequency_SasExit',
}
COORD_SEED = {z: seed_of_object(n, LEVEL_CRC) for z, n in COORD_NAME.items()}

# test.txt 实测：seed -> zone -> {'display': [...], 'map': {调频器: 图案}}
ZH = {'Bunny': '兔子', 'Heart': '红心', 'Moon': '月亮', 'Spade': '黑桃',
      'Club': '梅花', 'Diamond': '方块'}
SAMPLES = {
    417417: {
        'RichDistrict': {
            'display': ['Moon', 'Bunny', 'Club'],
            'map': {'FrequencyMatchBlacklit_BP': 'Moon',
                    'FrequencyMatchBlacklit_BP2': 'Bunny',
                    'FrequencyMatchBlacklit_BP3': 'Club',
                    'FrequencyMatchBlacklit_BP49': 'Heart'}},
        'School': {
            'display': ['Diamond', 'Heart', 'Bunny'],
            'map': {'FrequencyMatchBlacklit_BP24': 'Diamond',
                    'FrequencyMatchBlacklit_BP26': 'Heart',
                    'FrequencyMatchBlacklit_BP5': 'Bunny',
                    'FrequencyMatchBlacklit_BP19': 'Moon',
                    'FrequencyMatchBlacklit_BP6': 'Club',
                    'FrequencyMatchBlacklit_BP29': 'Spade'}},
        'SasExit': {
            'display': ['Diamond', 'Moon', 'Bunny'],
            'map': {'FrequencyMatchBlacklit_BP43': 'Diamond',
                    'FrequencyMatchBlacklit_BP45': 'Moon',
                    'FrequencyMatchBlacklit_BP36': 'Bunny',
                    'FrequencyMatchBlacklit_BP31': 'Heart',
                    'FrequencyMatchBlacklit_BP38': 'Club',
                    'FrequencyMatchBlacklit_BP47': 'Spade'}},
    },
    737737: {
        'RichDistrict': {
            'display': ['Moon', 'Spade', 'Club'],
            'map': {'FrequencyMatchBlacklit_BP': 'Heart',
                    'FrequencyMatchBlacklit_BP2': 'Moon',
                    'FrequencyMatchBlacklit_BP3': 'Spade',
                    'FrequencyMatchBlacklit_BP49': 'Club'}},
        'School': {
            'display': ['Club', 'Moon', 'Heart'],
            'map': {'FrequencyMatchBlacklit_BP21': 'Club',
                    'FrequencyMatchBlacklit_BP25': 'Moon',
                    'FrequencyMatchBlacklit_BP11': 'Heart',
                    'FrequencyMatchBlacklit_BP8': 'Diamond',
                    'FrequencyMatchBlacklit_BP5': 'Spade',
                    'FrequencyMatchBlacklit_BP27_3': 'Bunny'}},
        'SasExit': {
            'display': ['Moon', 'Heart', 'Diamond'],
            'map': {'FrequencyMatchBlacklit_BP40': 'Moon',
                    'FrequencyMatchBlacklit_BP45': 'Heart',
                    'FrequencyMatchBlacklit_BP30': 'Diamond',
                    'FrequencyMatchBlacklit_BP33': 'Spade',
                    'FrequencyMatchBlacklit_BP37': 'Club',
                    'FrequencyMatchBlacklit_BP47': 'Bunny'}},
    },
}
SALT = {417417: 417, 737737: 737}


def draw_swap(pool, seed_base, salt, count, step=1):
    """交换删除抽 count 个，返回 (抽取序列, 每步用的 seed)。"""
    p = list(pool)
    out = []
    for k in range(count):
        idx = rand_seeded((seed_base + k * step) & M32, len(p), salt)
        out.append(p[idx])
        p[idx] = p[-1]
        p.pop()
    return out


def draw_ordered(pool, seed_base, salt, count, step=1):
    p = list(pool)
    out = []
    for k in range(count):
        idx = rand_seeded((seed_base + k * step) & M32, len(p), salt)
        out.append(p.pop(idx))
    return out


def zone_names(zone):
    return COORDS[zone]['PossibleClueNames']


def zone_tuners(zone):
    return COORDS[zone]['ObjectiveActors']


def eval_combo(name_base_mode, name_delete, tune_salt, tune_delete,
               tune_offset=0, step=1, verbose=False):
    """name_base_mode: 'plain'(46541+k) | 'coord'(coord+46541+k)
       tune_salt: 盐名字符串或 None(不用盐，base=coord_seed)"""
    name_ok = disp_ok = tune_ok = map_ok = 0
    total_name = total_tune = 0
    for seed, zones in SAMPLES.items():
        salt = SALT[seed]
        for zone, fact in zones.items():
            cseed = COORD_SEED[zone]
            if name_base_mode == 'plain':
                nb = 46541
            else:
                nb = (cseed + 46541) & M32
            fn = draw_swap if name_delete == 'swap' else draw_ordered
            names = fn(zone_names(zone), nb, salt, len(zone_names(zone)), step)
            got_display = names[:3]
            total_name += 1
            if got_display == fact['display']:
                disp_ok += 1
            # 调频器抽取
            base = cseed if not tune_salt else \
                (crc32_fname(tune_salt) + cseed) & M32
            base = (base + tune_offset) & M32
            ft = draw_swap if tune_delete == 'swap' else draw_ordered
            n = len(fact['map'])
            tuners = ft(zone_tuners(zone), base, salt, n, step)
            total_tune += 1
            if set(tuners) == set(fact['map']):
                tune_ok += 1
            if tuners[:3] and all(
                    tuners[i] for i in range(min(3, n))):
                pass
            # 名字↔调频器配对（名字抽取序列前 n 个 ↔ 调频器抽取序列前 n 个）
            pairs = dict(zip(tuners, names[:n]))
            if pairs == fact['map']:
                map_ok += 1
            if verbose:
                print('  seed=%d %-12s display=%s (want %s) %s' % (
                    seed, zone,
                    [ZH[x] for x in got_display],
                    [ZH[x] for x in fact['display']],
                    'OK' if got_display == fact['display'] else 'X'))
                print('      tuners=%s' % (tuners,))
    return dict(display=disp_ok, total=total_name, tune=tune_ok, pair=map_ok)


def main():
    salt_names = [None, 'Objective Actors', 'Projection Actors',
                  'Frequency Actors', 'Clue Actors', 'Ordered Clue Actors',
                  'Blacklight Actors', 'Match Actors', 'Radio Actors']
    best = []
    for nmode in ('plain', 'coord'):
        for ndel in ('swap', 'ordered'):
            for tsalt in salt_names:
                for tdel in ('swap', 'ordered'):
                    r = eval_combo(nmode, ndel, tsalt, tdel)
                    tag = 'name=%s/%s tune=%s/%s' % (nmode, ndel,
                                                     tsalt, tdel)
                    best.append((r['pair'], r['tune'], r['display'], tag))
    best.sort(reverse=True)
    print('== 组合排名（pair/tune/display 命中数 /6）==')
    for pair, tune, disp, tag in best[:12]:
        print('  pair=%d tune=%d display=%d  %s' % (pair, tune, disp, tag))

    print('\n== 两个先验组合的明细 ==')
    for tag, args in [
        ('MHS 同款: name=plain/swap tune=Objective Actors/swap',
         ('plain', 'swap', 'Objective Actors', 'swap')),
        ('name=coord/swap tune=Objective Actors/swap',
         ('coord', 'swap', 'Objective Actors', 'swap')),
    ]:
        print('--', tag)
        eval_combo(*args, verbose=True)


if __name__ == '__main__':
    main()
