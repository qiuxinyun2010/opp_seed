# -*- coding: utf-8 -*-
"""RES_MT02「焚毁莉莉娅的遗物 / Purchase Liliya's Relic」种子推理。

给定关卡种子，输出**真宝石挂在哪些莉莉娅人偶身上、是什么宝石、坐标在哪**。

本关卡有两段（两个协调器，都在 RES_MT02_B00 里，共用同一个关卡种子）：

  1. MT02_CollectingJewels_Tuto  —— 教学段（Crypt / FinalKill 一带），6 颗，只有蓝/绿
  2. MT02_CollectingJewels_MainAuction —— 主轴段（度假村主体），2 固定 + 25 分区 = 最多 27 颗，红/蓝/绿

**第 2 段已闭环**：seed=176176 的 2 条实测（人偶 + 宝石类别）全部命中。
**第 1 段未闭环**：见 RES_MT02.md §5。

算法来源（IDA / REA，TOTClient-Win64-Shipping.exe，base 0x140000000）
  ------------------------------------------------------------------------
  0x1433B49B0  RBBlacklightDetectableQuestItemCoordinator 房间/分区随机化主循环
  0x1433B58F0  在给定房间里挑一个人偶  pick_spawner(room, seed)
  0x1433B5BC0  spawner 随机化分支（教学段走这条）
  0x1402D29E0  RandSeeded(seed, N)          -> rand_seeded
  0x1401A0F00  RandRangeInt(seed, lo, hi)   -> rand_seeded_range
  0x1413F02F0  RandFractionSeeded(seed)     -> rand_fraction
  0x140503B80  GetSeed(obj)                 -> seed_of
  0x1404FF400  IntByDifficulty              -> int_by_difficulty
  0x141C9CE10  TArray::RemoveAll            （0x1433B5BC0 里用来剔 nullptr）
  0x14018C680  Algo::Introsort，比较器 0x1402C6910 = **按 actor 名字比较**

用法
  python res_mt02.py 176176              # 全部真宝石点位
  python res_mt02.py 176176 --trace      # 附带房间排序键与逐个抽取过程
  python res_mt02.py 176176 --json       # 机器可读
  python res_mt02.py 176176 --out r.json
  python res_mt02.py --rooms 176176      # 只看 4 个区的房间排序与命中房间
  python res_mt02.py --pool              # 打印主轴人偶池
  python res_mt02.py --selftest          # 原语 + 配额 + 实测样本自检
"""
import argparse
import json
import math
import os
import sys

M32 = 0xFFFFFFFF
M64 = 0xFFFFFFFFFFFFFFFF

HERE = os.path.dirname(os.path.abspath(__file__))
POOL_JSON = os.path.join(HERE, 'res_mt02_pool.json')
LEVEL_JSON = os.path.join(HERE, 'res_mt02_leveldata.json')

LEVEL_OBJECT = 'PersistentLevel'    # GetSeed 的兜底外层（与 MHS_MT01 / CHJ_MT01 一致）

# ---------------------------------------------------------------- 随机原语
_CRC_TAB = []
for _i in range(256):
    _c = _i
    for _ in range(8):
        _c = ((_c >> 1) ^ 0xEDB88320) if (_c & 1) else (_c >> 1)
    _CRC_TAB.append(_c & M32)


def crc32_fname(name):
    """FName 的 CRC32：每个 16 位字符按 4 字节喂进标准 CRC32。

    校验：crc32_fname('PersistentLevel') == 0x4C09CC22
    """
    crc = M32
    for ch in name:
        u = ord(ch) & 0xFFFF
        crc = _CRC_TAB[(crc ^ (u & 0xFF)) & 0xFF] ^ (crc >> 8)
        crc = _CRC_TAB[(crc ^ (u >> 8)) & 0xFF] ^ (crc >> 8)
        crc = _CRC_TAB[crc & 0xFF] ^ (crc >> 8)
        crc = _CRC_TAB[crc & 0xFF] ^ (crc >> 8)
    return (~crc) & M32


def seed_of(name, outer=None):
    """sub_140503B80 的名字兜底分支：|crc(name) + seed(Outer)|。"""
    if outer is None:
        outer = crc32_fname(LEVEL_OBJECT)
    v = (crc32_fname(name) + outer) & M32
    return v if v < 0x80000000 else (0x100000000 - v) & M32


def _mix64(seed, salt):
    """sub_1402D29E0 / sub_1413F02F0 / sub_1401A0F00 共用的 64 位混合。"""
    a = (0xBF58476D1CE4E5B9 * ((seed ^ (seed >> 30)) & M64)) & M64
    a ^= a >> 27
    g = (salt % 1000) & M64
    b = (0xBF58476D1CE4E5B9 * g) & M64
    b ^= b >> 27
    v5 = (((0x94D049BB133111EB * a) & M64) ^ ((0x94D049BB133111EB * b) & M64)) & M64
    t = (v5 ^ (v5 >> 31)) & M64
    v6 = (0xBF58476D1CE4E5B9 * (t ^ (t >> 30))) & M64
    u = (v6 ^ (v6 >> 27)) & M64
    v7 = (((321982955 * u) & M64) ^ (((0x94D049BB133111EB * u) & M64) >> 31)) & M64
    return v7 & M32


def rand_seeded(seed, n, salt):
    """sub_1402D29E0(seed, N) -> [0, N)。"""
    if not n or not seed:
        return 0
    return (_mix64(seed & M32, salt) & 0xFFFF) % n


def rand_seeded_range(seed, lo, hi, salt):
    """sub_1401A0F00(seed, lo, hi) -> [lo, hi]。"""
    if hi - lo < 0:
        return lo
    span = (hi - lo + 1) & 0xFFFF
    if span == 0:
        return lo
    return lo + (rand_seeded(seed, span, salt) % span)


def rand_fraction(seed, salt):
    """sub_1413F02F0(seed) -> [0,1) 的 float，房间排序键。"""
    if not seed:
        return 0.0
    return (_mix64(seed & M32, salt) & 0xFFFF) / 65536.0


def int_by_difficulty(block, difficulty='easy'):
    """sub_1404FF400：看 Override 标志，缺档时向下一档回落（easy -> normal）。"""
    if not block:
        return 0
    order = [('easy', 'EasyLocalValue'), ('normal', 'NormalLocalValue'),
             ('hard', 'HardLocalValue'), ('insane', 'InsaneLocalValue')]
    want = {'easy': 0, 'normal': 1, 'hard': 2, 'insane': 3}.get(difficulty, 1)
    for i, (tag, key) in enumerate(order):
        if i < want:
            continue
        if block.get('bOverride%sLocalValue' % tag.capitalize()):
            return block.get(key)
    for tag, key in reversed(order):
        if key in block:
            return block.get(key)
    return 0


# ---------------------------------------------------------------- 关卡静态数据
def _load_level():
    with open(LEVEL_JSON, encoding='utf-8') as f:
        return json.load(f)['coordinators']['MT02_CollectingJewels_MainAuction']


_LV = None


def level_data():
    global _LV
    if _LV is None:
        _LV = _load_level()
    return _LV


def mandatory_rooms():
    return [(m['room'], m['count']['default']) for m in level_data()['mandatory_rooms']]


def sections():
    out = []
    for s in level_data()['sections']:
        out.append({'count': s['count']['default'], 'rooms': list(s['rooms'])})
    return out


def distribution():
    """ItemClassesDistributionDataOrderedByPrice，顺序 = 数组顺序（别排序）。

    关卡里写的是 RE_Ruby_BP_C / RE_Sapphire_BP_C / RE_Emerald_BP_C。
    """
    return [(d['class'].replace('_BP_C', '').replace('RE_', ''), d['value'])
            for d in level_data()['distributions']]


PRICE_GOAL = 260.0

# seed 常量（硬编码在 0x1433B49B0 里）
SEED_MANDATORY = 820351        # 0x1433B4B81  pick_spawner(counter + 820351)
SEED_SECTION_SPAWNER = 279412  # 0x1433B506C  pick_spawner(counter + 279412)
SEED_ROOM_ORDER = 479582       # 0x1433B4F6D  RandFraction(GetSeed(room) + 479582)
SEED_CLASS_PICK = 823203       # 0x1433B50BF  RandRangeInt(counter + 823203, 0, len-1)

# ---------------------------------------------------------------- 人偶池
_POOL = None


def pool(classes=('main',)):
    global _POOL
    if _POOL is None:
        with open(POOL_JSON, encoding='utf-8') as f:
            _POOL = json.load(f)['pool']
    return [m for m in _POOL if m['pool'] in classes]


def uid(m):
    """不同子关卡里可能有同名 actor，必须带 level。"""
    return '%s:%s' % (m['level'], m['name'])


# ------------------------------------------------------------ 教学段类别图
TUTO_COORD = 'MT02_CollectingJewels_Tuto'


def tuto_ok():
    """`0x1433B5BC0` 是否走「交替价格」分支的条件（ctor 里 +92 bit0 = 1）。"""
    return True


def tuto_conf():
    """教学段协调器的关卡配置（DesiredCount / distributions / 距离约束）。"""
    with open(LEVEL_JSON, encoding='utf-8') as f:
        return json.load(f)['coordinators'][TUTO_COORD]


def tuto_order():
    """教学段人偶数组的排序（比较器 0x1402C6910 = actor 名字大小写折叠升序）。"""
    return sorted((m for m in pool(('tutorial',))), key=lambda m: (m['name'].upper(), m['name']))


def tuto_class_map(seed):
    """教学段 51 个人偶各自的类别（颜色）。

    `0x1433B5BC0` 给**整个**数组逐个分配类别：
        v4 = GetSeed(协调器) = seed_of(TUTO_COORD)          # 与关卡种子无关
        for k in 0..Num-1:
            i   = RandSeeded(v4 + k, Num_remaining)          # 逐次抽签
            cls = k % Num(classes)                           # bAlternatePricesUniformly
            类别表顺序 = ItemClassesDistributionDataOrderedByPrice
    返回 {name: (序号, 'Sapphire'|'Emerald')}。
    """
    v4 = seed_of(TUTO_COORD)
    salt = seed % 1000
    dist = [d['class'].replace('_BP_C', '').replace('RE_', '')
            for d in tuto_conf()['distributions']]
    pl = list(tuto_order())
    out = {}
    for k in range(len(pl)):
        i = rand_seeded((v4 + k) & 0xFFFFFFFF, len(pl), salt)
        out[pl.pop(i)['name']] = (k, dist[k % len(dist)])
    return out


def gem_point(m):
    """宝石挂点 = 人偶根 + ItemSpawnLocation（按 yaw 绕 Z 旋转）。"""
    if not m.get('spawn_offset'):
        return (m['x'], m['y'], m['z'])
    ox, oy, oz = m['spawn_offset']
    th = math.radians(m.get('yaw') or 0.0)
    c, s = math.cos(th), math.sin(th)
    return (round(m['x'] + ox * c - oy * s, 1),
            round(m['y'] + ox * s + oy * c, 1),
            round(m['z'] + oz, 1))


def candidates(room, classes=('main',), used=()):
    """房间里还没被占用的人偶，顺序 = (level, name)（近似关卡 actor 顺序）。"""
    out = [m for m in pool(classes) if m.get('room') == room and uid(m) not in used]
    out.sort(key=lambda m: (m['level'], m['name']))
    return out


# ---------------------------------------------------------------- 主模型
def class_slots(dist, total):
    """0x1433B4D72..0x1433B4D88:
        n_i = (int)(2 * d_i * total + 0.5) >> 1   —— cvtss2si 四舍五入到偶数
    """
    slots = []
    for i, (_n, d) in enumerate(dist):
        n = int(round(2.0 * float(d) * total + 0.5)) >> 1
        slots.extend([i] * max(0, n))
    return slots


def room_order(rooms, salt):
    """每个房间算 RandFraction(GetSeed(room)+479582)，按 float 升序排。"""
    keyed = [(rand_fraction((seed_of(r) + SEED_ROOM_ORDER) & M32, salt), r) for r in rooms]
    keyed.sort(key=lambda t: t[0])
    return [r for _k, r in keyed], keyed


def predict(seed, difficulty='easy', trace=False):
    salt = seed % 1000
    dist = distribution()
    items = []
    tr = []

    # ---- 1) 固定房（MandatoryRoomsSpawnData）：类别恒为 dist[0]
    #   它们用自己的 counter（0,1），不影响分区的 counter
    used = set()
    counter = 0
    for room, cfg in mandatory_rooms():
        n = int_by_difficulty(cfg, difficulty)
        for _ in range(n):
            cands = candidates(room, used=used)
            pick = cands[rand_seeded((counter + SEED_MANDATORY) & M32, len(cands), salt)] \
                if cands else None
            tr.append('mandatory %-34s seed=%d n=%d -> %s' %
                      (room, (counter + SEED_MANDATORY) & M32, len(cands),
                       pick['name'] if pick else 'NONE'))
            if pick is None:
                continue
            items.append(_mk('mandatory', room, dist[0][0], pick, counter, len(cands)))
            used.add(uid(pick))
            counter += 1

    # ---- 2) 类别桶：把 Distribution 按总需求整数化，再抽签 + swap-remove
    secs = sections()
    total = sum(int_by_difficulty(s['count'], difficulty) for s in secs)
    slots = class_slots(dist, total)
    tr.append('sections total=%d  class slots=%s (len=%d)' % (total, dist, len(slots)))
    if len(slots) < total:
        tr.append('!! len(slots) < total -> 游戏会打 "Random rooms distributions error" 并放弃')

    # ---- 3) 分区：counter 从 0 起（0x1433B4F12: v42=0; v135=v42），固定房不占用它
    counter = 0
    for si, sec in enumerate(secs, 1):
        n = int_by_difficulty(sec['count'], difficulty)
        if n <= 0:
            continue
        order, keyed = room_order(sec['rooms'], salt)
        tr.append('section %d: want=%d rooms=%d' % (si, n, len(order)))
        if trace:
            for k, r in keyed:
                tr.append('    key=%.6f %s' % (k, r))
        k = 0
        while k < n:
            room = order[k % len(order)]          # 轮流，不是随机（0x1433B505C）
            cands = candidates(room, used=used)
            if not cands:
                tr.append('    [%s] 没有空余人偶，跳过（counter 不前进）' % room)
                k += 1
                continue
            pick = cands[rand_seeded((counter + SEED_SECTION_SPAWNER) & M32, len(cands), salt)]
            r = rand_seeded_range((counter + SEED_CLASS_PICK) & M32, 0, len(slots) - 1, salt)
            ci = slots.pop(r)
            items.append(_mk('section%d' % si, room, dist[ci][0], pick, counter, len(cands)))
            used.add(uid(pick))
            tr.append('    [%s] #%d spawner_seed=%d n=%d -> %s  gem=%s' %
                      (room, counter, (counter + SEED_SECTION_SPAWNER) & M32,
                       len(cands), pick['name'], dist[ci][0]))
            counter += 1
            k += 1

    return {
        'level': 'RES_MT02',
        'stage': 'ResortSpa',
        'seed': seed,
        'salt': salt,
        'difficulty': difficulty,
        'price_goal': PRICE_GOAL,
        'section_total': total,
        'class_slot_counts': _slot_counts(dist, total),
        'items': items,
        'trace': tr,
    }


def _mk(source, room, gem, pick, counter, ncand):
    gx, gy, gz = gem_point(pick)
    return {
        'source': source,
        'room': room,
        'gem': gem,
        'spawner': pick['name'],
        'spawner_level': pick['level'],
        'counter': counter,
        'n_candidates': ncand,
        'root': [pick['x'], pick['y'], pick['z']],
        'coordinates': [gx, gy, gz],
        'coordinate_type': 'actor',
    }


def _slot_counts(dist, total):
    slots = class_slots(dist, total)
    return {name: slots.count(i) for i, (name, _d) in enumerate(dist)}


# ---------------------------------------------------------------- 渲染
CN = {'Ruby': '红宝石', 'Sapphire': '蓝宝石', 'Emerald': '绿宝石'}


def render(r):
    L = []
    L.append('RES_MT02  水疗度假村 · 焚毁莉莉娅的遗物  (ResortSpa)')
    L.append('seed = %d   salt = %d   %s   price goal = %.0f'
             % (r['seed'], r['salt'], r['difficulty'], r['price_goal']))
    L.append('类别配额（分区 %d 颗展开）: %s'
             % (r['section_total'],
                ', '.join('%s=%d' % (CN.get(k, k), v) for k, v in r['class_slot_counts'].items())))
    L.append('')
    L.append('=== 主轴段 MT02_CollectingJewels_MainAuction（已验证）===')
    cur = None
    for it in r['items']:
        if it['source'] != cur:
            cur = it['source']
            L.append('[%s]' % cur)
        L.append('  %-34s %-6s %-32s (%s, %s, %s)'
                 % (it['room'], '%s/%s' % (it['gem'], CN.get(it['gem'], '')),
                    it['spawner'], it['coordinates'][0], it['coordinates'][1],
                    it['coordinates'][2]))
    L.append('')
    L.append('共 %d 颗真宝石' % len(r['items']))
    L.append('')
    L.append('=== 教学段 MT02_CollectingJewels_Tuto（类别已解，见 RES_MT02.md §5）===')
    L.append('  6 颗：3 蓝宝石 + 3 绿宝石')
    L.append('  类别 = 该人偶在 51 人偶「排序后逐次抽取」排列里的奇偶（偶=蓝 奇=绿）')
    L.append('  用 --tuto 打印整张 51 人偶类别图，现场对着人名查颜色即可')
    L.append('  「哪 6 个人偶」由上游 spawner 随机化决定，仍未反解出来')
    return '\n'.join(L)


# ---------------------------------------------------------------- 实测样本
SAMPLES = [
    ('RE_MannequinTrap_Setup_BP160', 'Ruby'),
    ('RE_MannequinTrap_Setup_BP_295', 'Sapphire'),
]
SAMPLE_SEED = 176176

# 教学段实测（seed, 人偶, 颜色）。仅收「确定无歧义」的记录：
#   BP_139 在两局里都与模型相反（见 RES_MT02.md §5），单独列出不计分。
TUTO_SAMPLES = [
    (176176, 'RE_MannequinTrap_Tutorial_BP_96', 'Emerald'),
    (176176, 'RE_MannequinTrap_Tutorial_BP_106', 'Sapphire'),
    (176176, 'RE_MannequinTrap_Tutorial_BP_111', 'Sapphire'),
    (69069, 'RE_MannequinTrap_Tutorial_BP_106', 'Sapphire'),
    (69069, 'RE_MannequinTrap_Tutorial_BP_115', 'Sapphire'),
    (69069, 'RE_MannequinTrap_Tutorial_BP_84', 'Emerald'),
    (69069, 'RE_MannequinTrap_Tutorial_BP_117', 'Emerald'),
    (69069, 'RE_MannequinTrap_Tutorial_BP_109', 'Emerald'),
]


def selftest():
    ok = True
    if crc32_fname('PersistentLevel') != 0x4C09CC22:
        print('FAIL crc32_fname'); ok = False
    dist = distribution()
    for diff in ('easy', 'normal', 'hard', 'insane'):
        secs = sections()
        total = sum(int_by_difficulty(s['count'], diff) for s in secs)
        slots = class_slots(dist, total)
        cnt = _slot_counts(dist, total)
        print('   %-7s total=%2d slots=%2d %s' % (diff, total, len(slots), cnt))
        if len(slots) < total:
            print('   FAIL 类别桶少于总需求'); ok = False
    r = predict(SAMPLE_SEED)
    if len(r['items']) < 20:
        print('FAIL 条目数异常', len(r['items'])); ok = False
    got = {it['spawner']: it['gem'] for it in r['items']}
    for name, gem in SAMPLES:
        hit = got.get(name)
        print('   实测 %-32s %-9s -> 预测 %s  %s'
              % (name, gem, hit, 'OK' if hit == gem else 'MISMATCH'))
        if hit != gem:
            ok = False
    a, b = predict(SAMPLE_SEED), predict(SAMPLE_SEED)
    if [i['spawner'] for i in a['items']] != [i['spawner'] for i in b['items']]:
        print('FAIL 非确定性'); ok = False
    print('   seed=%s -> %d 颗' % (SAMPLE_SEED, len(r['items'])))
    # ---- 教学段类别图 ----
    cache = {}
    for seed, name, gem in TUTO_SAMPLES:
        cm = cache.setdefault(seed, tuto_class_map(seed))
        hit = cm[name][1]
        print('   教学 %6d %-6s %-9s -> %s  %s'
              % (seed, name.rsplit('_', 1)[-1], gem, hit, 'OK' if hit == gem else 'MISMATCH'))
        if hit != gem:
            ok = False
    print('SELFTEST', 'OK' if ok else 'FAILED')
    return 0 if ok else 1


def main(argv=None):
    ap = argparse.ArgumentParser(description='RES_MT02 种子推理')
    ap.add_argument('seed', nargs='?', type=int)
    ap.add_argument('--difficulty', default='easy',
                    choices=['easy', 'normal', 'hard', 'insane'])
    ap.add_argument('--trace', action='store_true')
    ap.add_argument('--json', action='store_true')
    ap.add_argument('--out')
    ap.add_argument('--rooms', action='store_true', help='只打印 4 个区的房间排序与前 N 个')
    ap.add_argument('--pool', action='store_true', help='打印主轴人偶池')
    ap.add_argument('--tuto', action='store_true',
                    help='打印教学段 51 个人偶的类别图（需 seed）')
    ap.add_argument('--selftest', action='store_true')
    args = ap.parse_args(argv)

    if args.selftest:
        return selftest()

    if args.pool:
        for m in pool(('main', 'tutorial', 'base')):
            print('%-9s %-44s %-38s %9.1f %9.1f %8.1f'
                  % (m['pool'], m['name'], m.get('room') or '-', m['x'], m['y'], m['z']))
        return 0

    if args.seed is None:
        ap.error('需要 seed')

    if args.tuto:
        cm = tuto_class_map(args.seed)
        print('seed = %d   教学段类别图（v4 = seed_of(%s) = %d）'
              % (args.seed, TUTO_COORD, seed_of(TUTO_COORD)))
        for m in tuto_order():
            k, c = cm[m['name']]
            print('  %-4s %2d  %-44s %-38s %8.1f %8.1f %7.1f'
                  % ('蓝' if c == 'Sapphire' else '绿', k, m['name'],
                     m.get('room') or '-', m['x'], m['y'], m['z']))
        return 0

    if args.rooms:
        salt = args.seed % 1000
        print('seed = %d   salt = %d' % (args.seed, salt))
        for si, sec in enumerate(sections(), 1):
            n = int_by_difficulty(sec['count'], args.difficulty)
            order, keyed = room_order(sec['rooms'], salt)
            print('[section %d] want=%d rooms=%d' % (si, n, len(order)))
            for i, (k, r) in enumerate(keyed):
                print('  %s %2d  %.6f  %-40s cand=%d'
                      % ('*' if i < n else ' ', i, k, r, len(candidates(r))))
        return 0

    r = predict(args.seed, difficulty=args.difficulty, trace=args.trace)
    if args.json or args.out:
        txt = json.dumps(r, ensure_ascii=False, indent=1)
        if args.out:
            with open(args.out, 'w', encoding='utf-8') as f:
                f.write(txt)
            print('wrote', args.out)
        else:
            print(txt)
    else:
        print(render(r))
        if args.trace:
            print('')
            print('\n'.join('  ' + t for t in r['trace']))
    return 0


if __name__ == '__main__':
    sys.exit(main())
