# -*- coding: utf-8 -*-
"""CHJ_MT02（法院 · 判决被起诉者 / Sentence the Prosecuted）seed 分析器。

本关分两步，本脚本把已验证的部分和未闭环的部分严格分开：

步骤 1（已验证，19/19）
    真实投影器 → 线索组 → 三位密码。
    三个协调器各自持有 2/2/1 个线索组，共 5 组 = 5 个三位密码。

步骤 2（尚未闭环）
    候选池 → 真实投影器（前置 Actor Randomization）。
    这条链路走 `0x1436E7F70` → `0x140A61C30` → `0x1402B05C0`，
    候选由 TActorIterator 按 `CodeProjectorActorClass` 现场收集，
    不在关卡 JSON 的显式列表里，因此当前只对已实测过的 seed 给出房间。

用法
----
    python release/home/chj_mt02.py 135135          # 新样本，5 个密码
    python release/home/chj_mt02.py 20020 --rooms
    python release/home/chj_mt02.py --regress       # 四批 seed 的密码回归
    python release/home/chj_mt02.py 135135 --json

给新样本定房间时，用 --actors 直接喂实测 actor，不必改数据：
    python release/home/chj_mt02.py 999999 --actors A2,A19,B4,B14,C_4
"""
import argparse
import json

M32 = 0xFFFFFFFF
M64 = 0xFFFFFFFFFFFFFFFF

# 三个协调器 + 各自的线索组顺序（= 关卡 PossibleClueGroups 的原始顺序）
COORDS = [
    ('MT02_Projections_Coordinator_BP_YellowSide', ['Skull', 'Spiral'], 'A'),
    ('MT02_Projections_Coordinator_BP_BlueSIde', ['Pentagram', 'Sun'], 'B'),
    ('MT02_Projections_Coordinator_BP_Tuto', ['TriangleCircle'], 'C'),
]

SYMBOL_NAMES = {
    'Skull': '骷髅', 'Spiral': '螺旋', 'Pentagram': '五角星',
    'Sun': '太阳', 'TriangleCircle': '三角',
}

# 已由实测确定的真实投影器（key = seed）
ACTORS = {
    713713: {'Skull': 'A18', 'Spiral': 'A2', 'Pentagram': 'B23', 'Sun': 'B16',
             'TriangleCircle': 'C_4'},
    620620: {'Skull': 'A3', 'Spiral': 'A13', 'Pentagram': 'B19', 'Sun': 'B2',
             'TriangleCircle': 'C_4'},
    20020: {'Skull': 'A6', 'Spiral': 'A3', 'Pentagram': 'B24', 'Sun': 'B16',
            'TriangleCircle': 'C_4'},
    135135: {'Skull': 'A2', 'Spiral': 'A19', 'Pentagram': 'B4', 'Sun': 'B14',
             'TriangleCircle': 'C_4'},
}

ROOMS = {
    20020: {'Spiral': 'West_ConstructionGore', 'Skull': 'RBRoom_West_PrivateOffice',
            'Pentagram': 'Main_CourtRoom_Balcony',
            'Sun': 'East_BathRoom_Crawlspace',
            'TriangleCircle': 'RBRoom_BackEntrance_Stairs'},
    135135: {'Spiral': 'RBRoom_West_Blueprints',
             'Skull': 'RBRoom_West_ConstructionGore',
             'Pentagram': 'RBRoom_EastCorridor_1_Slave_2',
             'Sun': 'RBRoom_East_Museum',
             'TriangleCircle': 'RBRoom_BackEntrance_Stairs'},
}

OBSERVED = {
    713713: {'TriangleCircle': '139', 'Skull': '736', 'Spiral': '486',
             'Sun': '470', 'Pentagram': '861'},
    620620: {'Skull': '067', 'Spiral': '704', 'Pentagram': '429', 'Sun': '398'},
    20020: {'TriangleCircle': '973', 'Spiral': '752', 'Pentagram': '037',
            'Sun': '136', 'Skull': '017'},
    135135: {'TriangleCircle': '408', 'Spiral': '067', 'Skull': '820',
             'Pentagram': '219', 'Sun': '874'},
}

_CRC_TAB = []
for _i in range(256):
    _c = _i
    for _ in range(8):
        _c = ((_c >> 1) ^ 0xEDB88320) if _c & 1 else _c >> 1
    _CRC_TAB.append(_c & M32)


def crc32_fname(name):
    crc = M32
    for ch in name:
        u = ord(ch) & 0xFFFF
        crc = _CRC_TAB[(crc ^ (u & 0xFF)) & 0xFF] ^ (crc >> 8)
        crc = _CRC_TAB[(crc ^ (u >> 8)) & 0xFF] ^ (crc >> 8)
        crc = _CRC_TAB[crc & 0xFF] ^ (crc >> 8)
        crc = _CRC_TAB[crc & 0xFF] ^ (crc >> 8)
    return (~crc) & M32


def seed_of_object(name, outer_seed=0):
    value = (crc32_fname(name) + outer_seed) & M32
    return value if value < 0x80000000 else (0x100000000 - value) & M32


def _mix64(seed, level_seed):
    a = (0xBF58476D1CE4E5B9 * ((seed ^ (seed >> 30)) & M64)) & M64
    a ^= a >> 27
    b = (0xBF58476D1CE4E5B9 * (level_seed % 1000)) & M64
    b ^= b >> 27
    value = (((0x94D049BB133111EB * a) & M64) ^
             ((0x94D049BB133111EB * b) & M64)) & M64
    value = (value ^ (value >> 31)) & M64
    value = (0xBF58476D1CE4E5B9 * (value ^ (value >> 30))) & M64
    value = (value ^ (value >> 27)) & M64
    return (((321982955 * value) & M64) ^
            (((0x94D049BB133111EB * value) & M64) >> 31)) & M32


def rand_seeded(seed, count, level_seed):
    if not count or not seed or not level_seed:
        return 0
    return (_mix64(seed & M32, level_seed) & 0xFFFF) % count


# 0x1436EA3D0 的三位密码
CODE_OFFSET = 38541
# 0x1436E95F0 里线索组的抽取
GROUP_OFFSET = 46541


def draw_code(base, level_seed):
    """sub_1436EA3D0：0-9 数字池，末尾交换删除，三位互不重复。"""
    pool = list(range(10))
    digits = []
    for k in range(3):
        index = rand_seeded((base + CODE_OFFSET + k) & M32, len(pool), level_seed)
        digits.append(str(pool[index]))
        pool[index] = pool[-1]
        pool.pop()
    return ''.join(digits)


def actor_full(short):
    return 'CHJ_MT02_ProjectionSymbol_BP_' + short


def predict(level_seed, table=None):
    """返回 5 组（线索组 / 真实投影器 / 房间 / 三位密码）。"""
    if table is None:
        table = ACTORS.get(level_seed)
    if table is None:
        return None
    level_crc = crc32_fname('PersistentLevel')
    rooms = ROOMS.get(level_seed, {})
    out = []
    for coord_name, groups, wing in COORDS:
        coord_seed = seed_of_object(coord_name, level_crc)
        clues = list(groups)
        for i in range(len(groups)):
            # 线索组的抽取顺序：同一协调器内 RemoveAtSwap
            group_index = rand_seeded(i + GROUP_OFFSET, len(clues), level_seed)
            group = clues[group_index]
            actor = actor_full(table[group])
            base = (seed_of_object(actor, level_crc) + coord_seed + i) & M32
            out.append({
                'coordinator': coord_name,
                'wing': wing,
                'slot': i,
                'symbol': group,
                'symbol_name': SYMBOL_NAMES[group],
                'actor': actor,
                'room': rooms.get(group),
                'code': draw_code(base, level_seed),
            })
            clues[group_index] = clues[-1]
            clues.pop()
    return out


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('seed', nargs='?', type=int, default=135135)
    parser.add_argument('--regress', action='store_true')
    parser.add_argument('--rooms', action='store_true', help='输出房间列')
    parser.add_argument('--actors', default=None,
                        help='逗号分隔的 A 翼两个,B 翼两个,教学一个，'
                             '例如 A2,A19,B4,B14,C_4')
    parser.add_argument('--json', action='store_true', dest='as_json')
    args = parser.parse_args()

    if args.regress:
        total = ok = 0
        for seed in sorted(OBSERVED):
            rows = predict(seed)
            for row in rows:
                want = OBSERVED[seed].get(row['symbol'])
                if want is None:
                    continue
                total += 1
                good = row['code'] == want
                ok += good
                print('  %-7d %-15s %-34s 预测=%s 实测=%s %s'
                      % (seed, row['symbol'], row['actor'], row['code'], want,
                         'OK' if good else 'MISMATCH'))
        print()
        print('密码主链 %d/%d' % (ok, total))
        return

    table = None
    note = None
    if args.actors:
        parts = [p.strip() for p in args.actors.split(',') if p.strip()]
        if len(parts) != 5:
            raise SystemExit('--actors 需要 5 个：A翼2个, B翼2个, 教学1个')
        table = {'Skull': parts[0], 'Spiral': parts[1], 'Pentagram': parts[2],
                 'Sun': parts[3], 'TriangleCircle': parts[4]}
        note = '房间未随 --actors 给出，需再补实测'
    rows = predict(args.seed, table)
    if rows is None:
        print('seed=%d 没有已验证的投影器，无法给出密码。' % args.seed)
        print('补到实测 actor 后用：--actors A? ,A? ,B? ,B? ,C_?')
        return

    if args.as_json:
        print(json.dumps({'level': 'CHJ_MT02', 'seed': args.seed,
                          'salt': args.seed % 1000, 'projections': rows},
                         ensure_ascii=False, indent=2))
        return

    print('CHJ_MT02 seed=%d salt=%d' % (args.seed, args.seed % 1000))
    for row in rows:
        line = '  %s %-4s %-34s %s' % (
            row['symbol_name'], row['code'], row['actor'],
            row['room'] if (row['room'] and args.rooms) else '')
        print(line)
    if note:
        print('  (%s)' % note)


if __name__ == '__main__':
    main()
