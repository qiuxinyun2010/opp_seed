# -*- coding: utf-8 -*-
"""PSO_MT01 多样本拟合器：比较候选池顺序 / 重排 / 分组 / seed 偏移假设。

    python pso_fit.py            # 扫描偏移 ±64（宽松，会有假命中）
    python pso_fit.py --strict   # 只允许调用点已知常量（extra = 243551）
    python pso_fit.py --diag     # 只打印每条样本的目标下标，不做扫描
"""
import re
import sys

import pso_mt01 as p

TARGETS = [
    (519519, 'C', 'PoliceStation_Office_QuestItemSpawner_BP_Child_105'),
    (329329, 'A', 'PoliceStation_Office_QuestItemSpawner_BP_Child_40'),
    (876876, 'B', 'PoliceStation_Office_QuestItemSpawner_BP_Child_27'),
    (235235, 'A', 'PoliceStation_Office_QuestItemSpawner_BP_Child_40'),
]

SORT_MODES = ('intro', 'intro-reversed', 'raw', 'raw-reversed',
              'bool-high', 'bool-low', 'frac-high', 'frac-low')
SEED_MODES = ('chain', 'absolute', 'crc')


def suffix(name):
    match = re.search(r'_([0-9]+)$', name)
    return int(match.group(1)) if match else -1


def orders(letter):
    explicit = list(p.POOLS[letter])
    names = set(explicit)
    export_order = [row.get('Name') for row in p._EXPORTS
                    if row.get('Name') in names]
    point_order = [row['actor'] for row in p._MAP['points']
                   if row.get('actor') in names]
    return {
        'explicit': explicit,
        'numeric': sorted(explicit, key=suffix),
        'lexical': sorted(explicit),
        'exports': export_order,
        'points': point_order,
    }


def sorted_pool(model, raw, mode):
    if mode == 'intro':
        return model.shuffled(raw)
    if mode == 'intro-reversed':
        return list(reversed(model.shuffled(raw)))
    if mode == 'raw':
        return list(raw)
    if mode == 'raw-reversed':
        return list(reversed(raw))
    if mode == 'bool-high':
        return sorted(raw, key=lambda a: model.frac(a) < 0.5)
    if mode == 'bool-low':
        return sorted(raw, key=lambda a: model.frac(a) >= 0.5)
    if mode == 'frac-high':
        return sorted(raw, key=model.frac, reverse=True)
    if mode == 'frac-low':
        return sorted(raw, key=model.frac)
    raise ValueError(mode)


def predict(seed, letter, order_name, sort_mode, seed_mode, extra,
            group_mode, group_extra=0, group_order='first', additive=False):
    """返回 (actor, idx, chosen_key, pool_size)。

    group_mode: none / group(房间组) / room(单个房间)
    group_order: first(按首次出现) / rev(反转组顺序，模拟 TMap 另一种遍历序)
    additive: 组内抽取的 seed 再加上「组下标 i」
    """
    model = p.SectionModel(seed, seed_mode=seed_mode)
    raw = orders(letter)[order_name]
    if len(raw) != len(p.POOLS[letter]):
        return None
    arranged = sorted_pool(model, raw, sort_mode)
    base = p.get_seed(p.SECTION_PREFIX + letter)

    def key_of(actor):
        if group_mode == 'room':
            return p.ROOMS[p.INFO[actor]['room']]
        return p.group_of(actor)

    if group_mode == 'none':
        pool = arranged
        item_seed = (base + extra) & p.sc.M32
        chosen_group = '<all>'
        first = 0
    else:
        groups = []
        for actor in arranged:
            group = key_of(actor)
            if group not in groups:
                groups.append(group)
        if group_order == 'rev':
            groups.reverse()
        first = p.sc.rand_seeded((base + group_extra) & p.sc.M32,
                                 len(groups), seed)
        chosen_group = groups[first]
        pool = [a for a in arranged if key_of(a) == chosen_group]
        item_seed = (base + len(groups) + extra) & p.sc.M32
    if additive:
        item_seed = (item_seed + first) & p.sc.M32
    index = p.sc.rand_seeded(item_seed, len(pool), seed)
    return pool[index], index, chosen_group, len(pool)


def diag():
    for seed, letter, target in TARGETS:
        for order_name, pool in orders(letter).items():
            print('%d %s %-8s target_idx=%s' % (
                seed, letter, order_name,
                pool.index(target) if target in pool else 'ABSENT'))
        print('   group=%s size=%d' % (
            p.group_of(target),
            sum(1 for a in p.POOLS[letter] if p.group_of(a) == p.group_of(target))))


def main():
    strict = '--strict' in sys.argv
    if '--diag' in sys.argv:
        diag()
        return
    offsets = (p.ITEM_SEED_STEP,) if strict else tuple(range(-64, 65))
    hits = []
    partial = []
    for order_name in orders('A'):
        for sort_mode in SORT_MODES:
            for seed_mode in SEED_MODES:
                for group_mode in ('none', 'group', 'room'):
                    for group_extra in (0, 1):
                        for group_order in ('first', 'rev'):
                            for additive in (False, True):
                                for extra in offsets:
                                    score = 0
                                    rows = []
                                    for seed, letter, target in TARGETS:
                                        result = predict(
                                            seed, letter, order_name,
                                            sort_mode, seed_mode, extra,
                                            group_mode, group_extra,
                                            group_order, additive)
                                        if result is None:
                                            score = -1
                                            break
                                        rows.append((letter, result[1],
                                                     result[2], result[3]))
                                        if result[0] == target:
                                            score += 1
                                    if score == len(TARGETS):
                                        hits.append((order_name, sort_mode,
                                                     seed_mode, group_mode,
                                                     group_extra, group_order,
                                                     additive, extra, rows))
                                    elif score > 1:
                                        partial.append((score, order_name,
                                                        sort_mode, seed_mode,
                                                        group_mode, group_extra,
                                                        group_order, additive,
                                                        extra))
    for hit in hits:
        print('HIT order=%s sort=%s actor-seed=%s group=%s gextra=%d '
              'gorder=%s add=%s extra=%+d rows=%r' % hit)
    print('samples=%d hits=%d strict=%s' % (len(TARGETS), len(hits), strict))
    partial.sort(reverse=True)
    print('partial(score>1)=%d' % len(partial))
    for row in partial[:30]:
        print('  %d/%d %s %s %s %s gextra=%d gorder=%s add=%s extra=%+d'
              % (row[0], len(TARGETS), row[1], row[2], row[3], row[4],
                 row[5], row[6], row[7], row[8]))


if __name__ == '__main__':
    main()
