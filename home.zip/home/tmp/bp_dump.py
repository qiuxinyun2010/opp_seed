# -*- coding: utf-8 -*-
"""解析提取出的 BP 包：函数列表 + 每个函数引用的函数 import（调用点）。"""
import struct, sys, os

def parse_package(umap_path, uexp_path):
    d = open(umap_path, 'rb').read()
    uexp = open(uexp_path, 'rb').read()
    tag, legacy = struct.unpack_from('<Ii', d, 0)
    pos = 8
    pos += 4  # legacy ue3
    pos += 8  # fv/fvl
    cnt, = struct.unpack_from('<i', d, pos); pos += 4
    pos += cnt * 20
    total_header, = struct.unpack_from('<i', d, pos); pos += 4
    n, = struct.unpack_from('<i', d, pos); pos += 4
    pos += max(n, 0)
    pos += 4  # flags
    name_cnt, name_off = struct.unpack_from('<ii', d, pos); pos += 8
    pos += 8  # gatherable
    exp_cnt, exp_off = struct.unpack_from('<ii', d, pos); pos += 8
    imp_cnt, imp_off = struct.unpack_from('<ii', d, pos); pos += 8

    names = []
    p = name_off
    for i in range(name_cnt):
        ln, = struct.unpack_from('<i', d, p); p += 4
        if ln < 0:
            s = d[p:p - 2 * ln].decode('utf-16-le', 'replace')[:-1]; p += -2 * ln
        else:
            s = d[p:p + ln].decode('utf-8', 'replace')[:-1]; p += ln
        p += 4
        names.append(s)

    imports = []
    p = imp_off
    for i in range(imp_cnt):
        p += 16
        outer, = struct.unpack_from('<i', d, p); p += 4
        on_i, on_n = struct.unpack_from('<ii', d, p); p += 8
        imports.append(names[on_i] if on_i < len(names) else '?%d' % on_i)

    exports = []
    for i in range(exp_cnt):
        q = exp_off + i * 104
        cls, sup, tmpl, outer = struct.unpack_from('<iiii', d, q)
        on_i, on_n = struct.unpack_from('<ii', d, q + 16)
        size, off = struct.unpack_from('<qq', d, q + 28)
        exports.append({
            'cls': cls, 'outer': outer,
            'name': names[on_i] if on_i < len(names) else '?%d' % on_i,
            'size': size, 'off': off - total_header,
        })
    return names, imports, exports, uexp, total_header

def main():
    base = sys.argv[1]
    umap = base + '.uasset'
    uexp_p = base + '.uexp'
    names, imports, exports, uexp, th = parse_package(umap, uexp_p)
    print('== %s names=%d imports=%d exports=%d hdr=0x%X' % (
        os.path.basename(base), len(names), len(imports), len(exports), th))
    print('imports:')
    for i, nm in enumerate(imports):
        if any(k in nm for k in ('Random', 'Clue', 'Room', 'Weapon', 'Body', 'Seed', 'Pick',
                                 'Shuffle', 'Select', 'Letter', 'Number', 'Text', 'Array',
                                 'Int', 'Sort', 'Swap', 'Handler', 'Trap', 'Mannequin')):
            print('  I-%-4d %s' % (i + 1, nm))
    print('functions & call sites:')
    for e in exports:
        if e['cls'] != -len(imports) + 150 and e['cls'] != -151:
            pass
        nm = e['name']
        if not any(k in nm for k in ('UberGraph', 'BndEvt', 'Execute', 'Clue', 'Random',
                                     'Room', 'Weapon', 'Body', 'Set', 'Get', 'On', 'Update')):
            continue
        if e['size'] <= 0 or e['off'] < 0 or e['off'] + e['size'] > len(uexp):
            continue
        blob = uexp[e['off']:e['off'] + e['size']]
        hits = []
        for i in range(0, len(blob) - 3):
            v, = struct.unpack_from('<i', blob, i)
            if -len(imports) <= v < 0:
                inm = imports[-v - 1]
                hits.append((i, inm))
        print('  %-58s size=%-6d' % (nm[:58], e['size']))
        seen = {}
        for i, inm in hits:
            seen.setdefault(inm, []).append(i)
        for inm, offs in seen.items():
            print('       %-36s x%d @%s' % (inm, len(offs), [hex(o) for o in offs[:6]]))

if __name__ == '__main__':
    main()
