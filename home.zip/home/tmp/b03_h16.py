import numpy as np
import sys

C1 = np.uint64(0xBF58476D1CE4E5B9)
C2 = np.uint64(0x94D049BB133111EB)
M32 = np.uint64(0xFFFFFFFF)

np.seterr(over='ignore', invalid='ignore')


def H(x):
    t = x ^ (x >> np.uint64(30))
    a = C1 * t
    return C2 * (a ^ (a >> np.uint64(27)))


def h16(x, salt):
    """sub_1401A0F00 真实收尾"""
    s = np.uint64(salt % 1000)
    Hs = H(np.array([s], dtype=np.uint64))[0]
    v5 = H(x) ^ Hs
    t = v5 ^ (v5 >> np.uint64(31))
    t = t ^ (t >> np.uint64(30))
    v6 = C1 * t
    X = v6 ^ (v6 >> np.uint64(27))
    v7 = ((np.uint64(321982955) * X) & M32) ^ ((C2 * X) >> np.uint64(31))
    return v7 & np.uint64(0xFFFF)


# (剩余组数, 被选下标) —— 弹出顺序 + swap-remove
RICH_POP = [(6, 2), (5, 2), (4, 1), (3, 2), (2, 0)]
RICH_PICK = [(3, 2), (4, 3), (3, 1), (2, 0), (4, 0), (2, 0)]

POOR_POP = [(6, 2), (5, 2), (4, 0), (3, 0), (2, 0)]
POOR_PICK = [(2, 1), (2, 0), (2, 0), (3, 0), (2, 0), (2, 0)]


def _scan(salt, pop, pick, variant='k', chunk=1 << 22):
    hits = []
    for start in range(0, 1 << 32, chunk):
        v = np.arange(start, start + chunk, dtype=np.uint64)
        for k, (rem, j) in enumerate(pop):
            if v.size == 0:
                break
            x = (v + np.uint64(k)) & M32
            v = v[(h16(x, salt) % np.uint64(rem)) == np.uint64(j)]
        for k, (sz, idx) in enumerate(pick):
            if v.size == 0:
                break
            off = 6 + (k if variant == 'k' else 0)
            x = (v + np.uint64(off)) & M32
            v = v[(h16(x, salt) % np.uint64(sz)) == np.uint64(idx)]
        if v.size:
            hits.extend(int(t) for t in v)
    return hits


def scan_rich(salt, variant='k'):
    return _scan(salt, RICH_POP, RICH_PICK, variant)


def scan_poor(salt, variant='k'):
    return _scan(salt, POOR_POP, POOR_PICK, variant)


if __name__ == '__main__':
    salt = int(sys.argv[1]) if len(sys.argv) > 1 else 485
    R = scan_rich(salt)
    P = scan_poor(salt)
    print('salt=%d  Rich hits=%d  Poor hits=%d' % (salt, len(R), len(P)))
    np.save('hits_rich.npy', np.array(R, dtype=np.uint64))
    np.save('hits_poor.npy', np.array(P, dtype=np.uint64))

    # v240_Poor - v240_Rich = seed_Poor - seed_Rich (mod 2^32)
    # 由宽字符 CRC 反解：seed = |~level + ~coord|
    d = 360816895
    for name, dd in (('+d', d), ('-d', (-d) & 0xFFFFFFFF)):
        Ps = set(P)
        inter = [r for r in R if ((r + dd) & 0xFFFFFFFF) in Ps]
        print('  shift %-3s = %10d  -> 交集 %d  %s' % (name, dd, len(inter), inter[:5]))
