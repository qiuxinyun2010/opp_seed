# -*- coding: utf-8 -*-
"""扫 .text 的 lea reg,[rip+rel32]，统计指向 vtable 段内的目标地址频次 → vtable 基址候选。
用法: python lea_vtable.py <seg_lo_va> <seg_hi_va> <anchor_va>"""
import struct, sys
from collections import Counter

exe = r'd:/workspace/outlast/TOTClient-Win64-Shipping.exe'
data = open(exe, 'rb').read()

pe = data.find(b'PE\x00\x00')
nsec, = struct.unpack_from('<H', data, pe + 6)
optsz, = struct.unpack_from('<H', data, pe + 20)
img_base, = struct.unpack_from('<Q', data, pe + 24 + 24)
sec = pe + 24 + optsz
secs = []
for i in range(nsec):
    off = sec + i * 40
    name = data[off:off + 8].rstrip(b'\x00').decode()
    vsize, va, rawsz, raw = struct.unpack_from('<IIII', data, off + 8)
    secs.append((name, va, rawsz, raw))

seg_lo = int(sys.argv[1], 0)
seg_hi = int(sys.argv[2], 0)
anchor = int(sys.argv[3], 0)

name, tva, trawsz, traw = next(s for s in secs if s[0] == '.text')
tseg = data[traw:traw + trawsz]

def o2v(o):
    return img_base + tva + o

cnt = Counter()
# lea r64,[rip+rel32] : 48/4C 8D 05/0D/15/1D/25/2D/35/3D  rel32
for modrm in (0x05, 0x0D, 0x15, 0x1D, 0x25, 0x2D, 0x35, 0x3D):
    for rex in (0x48, 0x4C):
        pat = bytes([rex, 0x8D, modrm])
        q = 0
        while True:
            j = tseg.find(pat, q)
            if j < 0:
                break
            q = j + 1
            rel, = struct.unpack_from('<i', tseg, j + 3)
            tgt = o2v(j + 7) + rel
            if seg_lo <= tgt < seg_hi and tgt % 8 == 0:
                cnt[tgt] += 1

print('候选（频次 top25）：')
for tgt, c in cnt.most_common(25):
    k = (anchor - tgt) // 8
    mark = ' <= anchor-k=%d' % k if tgt <= anchor else ''
    print('  %s  x%-4d%s' % (hex(tgt), c, mark))
