import numpy as np
from b03_h16 import h16, RICH_POP, RICH_PICK, POOR_POP, POOR_PICK

M = 0xFFFFFFFF
CASES = (
    ('Rich', 562885957, RICH_POP, RICH_PICK),
    ('Poor', 923702852, POOR_POP, POOR_PICK),
)


def score(V, salt, pop, pick):
    ok = 0
    for k, (rem, j) in enumerate(pop):
        if int(h16(np.array([(V + k) & M], dtype=np.uint64), salt)[0]) % rem == j:
            ok += 1
    for k, (sz, idx) in enumerate(pick):
        if int(h16(np.array([(V + 6 + k) & M], dtype=np.uint64), salt)[0]) % sz == idx:
            ok += 1
    return ok


res = []
for salt in range(0, 1000):
    a = score(CASES[0][1], salt, CASES[0][2], CASES[0][3])
    b = score(CASES[1][1], salt, CASES[1][2], CASES[1][3])
    res.append((a + b, a, b, salt))
res.sort(reverse=True)
print('top 10 by joint score (满分 22):')
for t, a, b, s in res[:10]:
    print('   total=%2d  Rich=%2d Poor=%2d  salt=%d' % (t, a, b, s))
