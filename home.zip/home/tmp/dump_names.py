# -*- coding: utf-8 -*-
"""dump exe 名字表锚点附近的 ASCII 串。"""
import re, sys

exe = r'd:/workspace/outlast/TOTClient-Win64-Shipping.exe'
data = open(exe, 'rb').read()

anchor = int(sys.argv[1], 0) if len(sys.argv) > 1 else 0x65BAEF0
half = int(sys.argv[2], 0) if len(sys.argv) > 2 else 0x1800
lo, hi = anchor - half, anchor + half
seg = data[lo:hi]

for m in re.finditer(rb'[\x20-\x7e]{5,}', seg):
    print('0x%X  %s' % (lo + m.start(), m.group().decode('ascii')))
