# -*- coding: utf-8 -*-
"""看 [rsp+0xcc] 的初值（v240）如何算出：0x1402B163E 与 0x1402B1FCB 附近。"""
import pefile
from capstone import Cs, CS_ARCH_X86, CS_MODE_64

EXE = r'd:\workspace\outlast\TOTClient-Win64-Shipping.exe'
pe = pefile.PE(EXE, fast_load=True)
data = open(EXE, 'rb').read()
IB = pe.OPTIONAL_HEADER.ImageBase


def rva_to_off(rva):
    for s in pe.sections:
        if s.VirtualAddress <= rva < s.VirtualAddress + s.Misc_VirtualSize:
            return s.PointerToRawData + (rva - s.VirtualAddress)
    return None


START, SIZE = 0x1402b05c0, 0x22f2
md = Cs(CS_ARCH_X86, CS_MODE_64)
insns = list(md.disasm(data[rva_to_off(START - IB):rva_to_off(START - IB) + SIZE], START))

for anchor, before, after in ((0x1402B163E, 40, 6), (0x1402B1FCB, 30, 6)):
    i = next(j for j, x in enumerate(insns) if x.address == anchor)
    print('==== context of 0x%X ====' % anchor)
    for j in range(i - before, i + after):
        x = insns[j]
        print('%s 0x%X  %-8s %s' % ('>>' if j == i else '  ', x.address, x.mnemonic, x.op_str))
    print()
