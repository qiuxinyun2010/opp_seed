import numpy as np
import zlib
from b03_h16 import h16

M = 0xFFFFFFFF


def crcw(s):
    return zlib.crc32(s.encode('utf-16-le')) & M


a4 = crcw('Large Objects')
lv = crcw('SuburbRiot_T08_B03')
cR = crcw('SR_B02_ObjCoord_OrderedClueFrequency_Rich')
cP = crcw('SR_B02_ObjCoord_OrderedClueFrequency_Poor')
sR = (((~lv) & M) + ((~cR) & M)) & M

PICK = [(3, 2), (4, 3), (3, 1), (2, 0), (4, 0), (2, 0)]

bases = {
    '~cR-1': ((~cR) & M) - 1,
    '~cR': (~cR) & M,
    'a4+sR': (a4 + sR) & M,
    'lv+sR': (lv + sR) & M,
}

best = []
for bn, B in bases.items():
    for off in range(0, 128):
        for rev in (0, 1):
            ok = 0
            for k, (sz, idx) in enumerate(PICK):
                want = (sz - 1 - idx) if rev else idx
                got = int(h16(np.array([(B + off + k) & M], dtype=np.uint64), 485)[0]) % sz
                if got == want:
                    ok += 1
            if ok >= 5:
                best.append((ok, bn, off, rev))
best.sort(reverse=True)
for b in best[:15]:
    print('  ok=%d  base=%-6s off=%d rev=%d' % b)
print('total candidates >=5:', len(best))
