# -*- coding: utf-8 -*-
"""sub_140503B80：打印调用目标与每个 ret 前的收尾计算。"""
import pefile
from capstone import Cs, CS_ARCH_X86, CS_MODE_64

EXE = r'd:\workspace\outlast\TOTClient-Win64-Shipping.exe'
pe = pefile.PE(EXE, fast_load=True)
data = open(EXE, 'rb').read()
IB = pe.OPTIONAL_HEADER.ImageBase


def off_of(va):
    rva = va - IB
    for s in pe.sections:
        if s.VirtualAddress <= rva < s.VirtualAddress + s.Misc_VirtualSize:
            return s.PointerToRawData + (rva - s.VirtualAddress)
    return None


START, SIZE = 0x140503b80, 0xa21
md = Cs(CS_ARCH_X86, CS_MODE_64)
insns = list(md.disasm(data[off_of(START):off_of(START) + SIZE], START))
print('insns', len(insns))

print('---- calls ----')
seen = {}
for x in insns:
    if x.mnemonic == 'call':
        seen[x.op_str] = seen.get(x.op_str, 0) + 1
for k, v in sorted(seen.items(), key=lambda t: -t[1]):
    print('   %-14s x%d' % (k, v))

print('---- ret sites ----')
for i, x in enumerate(insns):
    if x.mnemonic == 'ret':
        print('  ret @0x%X' % x.address)
        for j in range(max(0, i - 14), i + 1):
            y = insns[j]
            print('      0x%X  %-8s %s' % (y.address, y.mnemonic, y.op_str))
        print()
