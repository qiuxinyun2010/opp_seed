# -*- coding: utf-8 -*-
"""反查：对每个 (seed, section) 真值，找出满足 rand_seeded(cs+X, n, seed)==truth 的 X，
再求 12 个点的交集。也试 reversed 顺序与 n-1 计数。"""
import sys, os
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
from tfs_fit90090 import (rand_seeded, cs_of, SECTIONS, ORDER, TRUTH, seed_chain)

def search(order_mode='orig', count_mode='n', seed_expr='cs+X', xmax=250000):
    per_point = []
    for seed in (14014, 90090):
        for sec in ORDER:
            n = len(SECTIONS[sec])
            cs = cs_of(sec)
            cnt = n if count_mode == 'n' else n - 1
            if cnt <= 0:
                continue
            truth = TRUTH[seed][sec]
            xs = set()
            for X in range(xmax):
                if seed_expr == 'cs+X':
                    s = cs + X
                elif seed_expr == 'X':
                    s = X
                else:
                    s = cs ^ X
                idx = rand_seeded(s, cnt, seed)
                if order_mode == 'rev':
                    idx = cnt - 1 - idx
                if order_mode == 'orig':
                    hit = idx in truth
                else:
                    hit = idx in truth
                if hit:
                    xs.add(X)
            per_point.append((seed, sec, truth, xs))
    inter = per_point[0][3]
    for _, _, _, xs in per_point[1:]:
        inter &= xs
    return per_point, inter


for om in ('orig', 'rev'):
    for cm in ('n', 'n-1'):
        for se in ('cs+X',):
            pts, inter = search(om, cm, se, 120000)
            print('mode=%s count=%s expr=%s -> common X (0..120000): %s'
                  % (om, cm, se, sorted(inter)[:20] if inter else 'NONE'))
            if not inter:
                # 显示各区可行 X 的数量
                print('   per-point X counts:', [(s, sec, len(xs)) for s, sec, _, xs in pts])
