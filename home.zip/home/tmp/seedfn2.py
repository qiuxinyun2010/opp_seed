# -*- coding: utf-8 -*-
"""sub_140503B80 返回前的计算段。"""
import pefile
from capstone import Cs, CS_ARCH_X86, CS_MODE_64

EXE = r'd:\workspace\outlast\TOTClient-Win64-Shipping.exe'
pe = pefile.PE(EXE, fast_load=True)
data = open(EXE, 'rb').read()
IB = pe.OPTIONAL_HEADER.ImageBase


def off_of(va):
    rva = va - IB
    for s in pe.sections:
        if s.VirtualAddress <= rva < s.VirtualAddress + s.Misc_VirtualSize:
            return s.PointerToRawData + (rva - s.VirtualAddress)
    return None


START, SIZE = 0x140503b80, 0xa21
md = Cs(CS_ARCH_X86, CS_MODE_64)
insns = list(md.disasm(data[off_of(START):off_of(START) + SIZE], START))
for x in insns:
    if 0x140503D40 <= x.address <= 0x140503EA8:
        print('  0x%X  %-8s %s' % (x.address, x.mnemonic, x.op_str))
