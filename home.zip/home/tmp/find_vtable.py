# -*- coding: utf-8 -*-
"""通过静态指针引用定位类 vtable：搜已知函数地址的 8 字节出现，识别 vtable 连续段，
打印段头/各槽位（重点 slot 223/230/256/295/297/268/281/323）。
用法: python find_vtable.py <addr> [<addr2> ...]"""
import struct, sys

exe = r'd:/workspace/outlast/TOTClient-Win64-Shipping.exe'
data = open(exe, 'rb').read()

pe = data.find(b'PE\x00\x00')
nsec, = struct.unpack_from('<H', data, pe + 6)
optsz, = struct.unpack_from('<H', data, pe + 20)
img_base, = struct.unpack_from('<Q', data, pe + 24 + 24)
sec = pe + 24 + optsz
secs = []
for i in range(nsec):
    off = sec + i * 40
    name = data[off:off + 8].rstrip(b'\x00').decode()
    vsize, va, rawsz, raw = struct.unpack_from('<IIII', data, off + 8)
    secs.append((name, va, rawsz, raw))

def off2va(o):
    for name, sva, rawsz, raw in secs:
        if raw <= o < raw + rawsz:
            return img_base + sva + (o - raw)
    return None

def va2off(v):
    rva = v - img_base
    for name, sva, rawsz, raw in secs:
        if sva <= rva < sva + rawsz:
            return raw + (rva - sva)
    return None

def is_code(v):
    return 0x140001000 <= v < 0x147625000

addrs = [int(a, 0) for a in sys.argv[1:]]
for target in addrs:
    pat = struct.pack('<Q', target)
    q = 0
    print('== xrefs to %s' % hex(target))
    while True:
        j = data.find(pat, q)
        if j < 0:
            break
        q = j + 1
        if j % 8:
            continue
        va = off2va(j)
        if va is None:
            continue
        secname = next((n for n, s, r, w in secs if w <= j < w + r), '?')
        print('   ref @%s (%s)' % (hex(va), secname))

print()
print('=== vtable 连续段探测（.data/.rdata 中 >=300 个连续代码指针）===')
for name, sva, rawsz, raw in secs:
    if name not in ('.rdata', '.data'):
        continue
    seg = data[raw:raw + rawsz]
    run_start = None
    for i in range(0, rawsz - 8, 8):
        v, = struct.unpack_from('<Q', seg, i)
        if is_code(v):
            if run_start is None:
                run_start = i
        else:
            if run_start is not None and (i - run_start) // 8 >= 300:
                print('  %s run @%s len=%d slots' % (name, hex(off2va(raw + run_start)), (i - run_start) // 8))
            run_start = None
