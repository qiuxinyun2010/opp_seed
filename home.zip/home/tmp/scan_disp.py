# -*- coding: utf-8 -*-
"""在 .text 扫 [reg+disp32] 指令中 disp=0xD88（RemainingObjectives 数组）的引用。
用法: python scan_disp.py [disp]"""
import struct, sys

exe = r'd:/workspace/outlast/TOTClient-Win64-Shipping.exe'
data = open(exe, 'rb').read()

pe = data.find(b'PE\x00\x00')
nsec, = struct.unpack_from('<H', data, pe + 6)
optsz, = struct.unpack_from('<H', data, pe + 20)
img_base, = struct.unpack_from('<Q', data, pe + 24 + 24)
sec = pe + 24 + optsz
text = None
for i in range(nsec):
    off = sec + i * 40
    name = data[off:off + 8].rstrip(b'\x00').decode()
    vsize, va, rawsz, raw = struct.unpack_from('<IIII', data, off + 8)
    if name == '.text':
        text = (va, rawsz, raw)

disp = int(sys.argv[1], 0) if len(sys.argv) > 1 else 0xD88
pat = struct.pack('<I', disp)

va, rawsz, raw = text
seg = data[raw:raw + rawsz]
hits = []
q = 0
while True:
    j = seg.find(pat, q)
    if j < 0:
        break
    q = j + 1
    if j < 4:
        continue
    modrm = seg[j - 1]
    op = seg[j - 2]
    rex = seg[j - 3]
    # REX + (mov r/m | lea | cmp | test | movzx) + ModRM(mod=2) + disp32
    if (modrm & 0xC0) == 0x80 and (0x40 <= rex <= 0x4F) and op in (0x8B, 0x89, 0x8D, 0x87, 0x63, 0xFF, 0x3B, 0x39, 0x0F):
        a = img_base + va + j - 3
        hits.append((a, seg[j - 3:j + 4].hex(' ')))
print('disp=0x%X  hits=%d' % (disp, len(hits)))
RANGES = [(0x14384C000, 0x143852000), (0x1437B4000, 0x1437BA000), (0x1433A6000, 0x1433AC000),
          (0x143582000, 0x143590000), (0x1402AE000, 0x1402C6000)]
for a, hx in hits:
    inr = any(lo <= a < hi for lo, hi in RANGES)
    if inr or len(hits) < 40:
        print('  %s  %s %s' % (hex(a), hx, '<<' if inr else ''))
