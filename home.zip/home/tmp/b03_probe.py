import numpy as np
import zlib
from b03_h16 import h16

M = 0xFFFFFFFF


def crcw(s):
    return zlib.crc32(s.encode('utf-16-le')) & M


a4 = crcw('Large Objects')
lv = crcw('SuburbRiot_T08_B03')
cR = crcw('SR_B02_ObjCoord_OrderedClueFrequency_Rich')
cP = crcw('SR_B02_ObjCoord_OrderedClueFrequency_Poor')
sR = (((~lv) & M) + ((~cR) & M)) & M
sP = (((~lv) & M) + ((~cP) & M)) & M

PICK = [(3, 2), (4, 3), (3, 1), (2, 0), (4, 0), (2, 0)]

cands = {
    'a4+sR': (a4 + sR) & M,
    'a4-sR': (a4 - sR) & M,
    '~a4+sR': (((~a4) & M) + sR) & M,
    'lv+sR': (lv + sR) & M,
    '~lv+sR': (((~lv) & M) + sR) & M,
    'sR': sR,
    'a4': a4,
}

print('a4=%d lv=%d sR=%d sP=%d' % (a4, lv, sR, sP))
for name, V in cands.items():
    out = []
    for k, (sz, idx) in enumerate(PICK):
        got = int(h16(np.array([(V + 6 + k) & M], dtype=np.uint64), 485)[0]) % sz
        out.append('%d%s' % (got, '=' if got == idx else '/%d' % idx))
    print('  %-8s %10d  %s' % (name, V, ' '.join(out)))
