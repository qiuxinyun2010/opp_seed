# -*- coding: utf-8 -*-
"""扩大窗口 + 追踪 [rsp+0xcc] / [rsp+0xb8] / [rsp+0x80] 的所有访存。"""
import pefile
from capstone import Cs, CS_ARCH_X86, CS_MODE_64

EXE = r'd:\workspace\outlast\TOTClient-Win64-Shipping.exe'
pe = pefile.PE(EXE, fast_load=True)
data = open(EXE, 'rb').read()
IB = pe.OPTIONAL_HEADER.ImageBase


def rva_to_off(rva):
    for s in pe.sections:
        if s.VirtualAddress <= rva < s.VirtualAddress + s.Misc_VirtualSize:
            return s.PointerToRawData + (rva - s.VirtualAddress)
    return None


START, SIZE = 0x1402b05c0, 0x22f2
off = rva_to_off(START - IB)
md = Cs(CS_ARCH_X86, CS_MODE_64)
insns = list(md.disasm(data[off:off + SIZE], START))

idx = next(i for i, x in enumerate(insns) if x.address == 0x1402B2217)
print('---- window around call ----')
for j in range(idx - 45, idx + 22):
    x = insns[j]
    print('%s 0x%X  %-8s %s' % ('>>' if j == idx else '  ', x.address, x.mnemonic, x.op_str))

print('\n---- refs to [rsp + 0xcc] ----')
for x in insns:
    if 'rsp + 0xcc]' in x.op_str:
        print('  0x%X  %-8s %s' % (x.address, x.mnemonic, x.op_str))

print('\n---- writes to [rsp + 0xb8] ----')
for x in insns:
    if 'rsp + 0xb8]' in x.op_str and x.mnemonic in ('mov', 'add', 'sub', 'inc', 'dec', 'lea'):
        print('  0x%X  %-8s %s' % (x.address, x.mnemonic, x.op_str))

print('\n---- refs to [rsp + 0x80] ----')
for x in insns:
    if 'rsp + 0x80]' in x.op_str:
        print('  0x%X  %-8s %s' % (x.address, x.mnemonic, x.op_str))
