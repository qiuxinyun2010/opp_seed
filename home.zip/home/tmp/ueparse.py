# -*- coding: utf-8 -*-
"""极简 UE4 包解析：summary → name/import/export 表。打印 import 与 export 名单。"""
import struct, sys

def parse(path):
    d = open(path, 'rb').read()
    tag, legacy = struct.unpack_from('<Ii', d, 0)
    assert tag == 0x9E2A83C1, hex(tag)
    pos = 8
    legacy_ue3, = struct.unpack_from('<i', d, pos); pos += 4
    fv, fvl = struct.unpack_from('<ii', d, pos); pos += 8
    # CustomVersionContainer
    cnt, = struct.unpack_from('<i', d, pos); pos += 4
    assert 0 <= cnt < 64, cnt
    pos += cnt * 20
    total_header, = struct.unpack_from('<i', d, pos); pos += 4
    # FolderName FString
    n, = struct.unpack_from('<i', d, pos); pos += 4
    folder = d[pos:pos + max(n, 0)].decode('utf-8', 'replace'); pos += max(n, 0)
    pkg_flags, = struct.unpack_from('<I', d, pos); pos += 4
    name_cnt, name_off = struct.unpack_from('<ii', d, pos); pos += 8
    # GatherableText（UE4.13+）
    gt_cnt, gt_off = struct.unpack_from('<ii', d, pos); pos += 8
    exp_cnt, exp_off = struct.unpack_from('<ii', d, pos); pos += 8
    imp_cnt, imp_off = struct.unpack_from('<ii', d, pos); pos += 8
    dep_off, = struct.unpack_from('<i', d, pos); pos += 4
    print('legacy=%d ue3=%d fv=%d/%d hdr=%d folder=%r flags=0x%X' % (legacy, legacy_ue3, fv, fvl, total_header, folder, pkg_flags))
    print('names=%d@0x%X  exports=%d@0x%X  imports=%d@0x%X  depends@0x%X' % (name_cnt, name_off, exp_cnt, exp_off, imp_cnt, imp_off, dep_off))

    # name 表
    names = []
    p = name_off
    for i in range(name_cnt):
        ln, = struct.unpack_from('<i', d, p); p += 4
        if ln < 0:
            s = d[p:p - 2 * ln].decode('utf-16-le', 'replace')[:-1]; p += -2 * ln
        else:
            s = d[p:p + ln].decode('utf-8', 'replace')[:-1]; p += ln
        # 两个 u16 hash
        h1, h2 = struct.unpack_from('<HH', d, p); p += 4
        names.append(s)

    def fname(idx, num):
        try:
            s = names[idx]
        except IndexError:
            return '?%d' % idx
        return s if num == 0 else '%s_%d' % (s, num - 1)

    # import 表
    imports = []
    p = imp_off
    for i in range(imp_cnt):
        cp_i, cp_n = struct.unpack_from('<ii', d, p); p += 8
        cn_i, cn_n = struct.unpack_from('<ii', d, p); p += 8
        outer, = struct.unpack_from('<i', d, p); p += 4
        on_i, on_n = struct.unpack_from('<ii', d, p); p += 8
        imports.append((fname(cp_i, cp_n), fname(cn_i, cn_n), outer, fname(on_i, on_n)))

    # export 表
    exports = []
    p = exp_off
    for i in range(exp_cnt):
        cls, sup, tmpl, outer = struct.unpack_from('<iiii', d, p); p += 16
        on_i, on_n = struct.unpack_from('<ii', d, p); p += 8
        flags, = struct.unpack_from('<I', d, p); p += 4
        size, off = struct.unpack_from('<qq', d, p); p += 16
        exports.append((cls, outer, fname(on_i, on_n), size, off))
    return names, imports, exports

if __name__ == '__main__':
    umap, uexp = sys.argv[1], sys.argv[2]
    names, imports, exports = parse(umap)
    print()
    print('=== imports (%d) ===' % len(imports))
    for i, (cp, cn, outer, on) in enumerate(imports):
        print('  I%-5d %-28s %-30s %s' % (-i - 1, cn, on, cp))
    print()
    print('=== exports (%d) ===' % len(exports))
    for i, (cls, outer, on, size, off) in enumerate(exports):
        print('  E%-5d %-52s size=%-8d off=0x%X' % (i + 1, on, size, off))
