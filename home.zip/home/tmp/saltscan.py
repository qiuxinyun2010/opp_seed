# -*- coding: utf-8 -*-
"""固定 v240=seed 候选，反扫 salt 0..999 与微小偏移，看能否同时满足 Rich/Poor 约束。"""
import numpy as np
import zlib
from b03_h16 import h16, RICH_POP, RICH_PICK, POOR_POP, POOR_PICK

M = 0xFFFFFFFF


def crcw(s):
    return zlib.crc32(s.encode('utf-16-le')) & M


lv = crcw('SuburbRiot_T08_B03')
cR = crcw('SR_B02_ObjCoord_OrderedClueFrequency_Rich')
cP = crcw('SR_B02_ObjCoord_OrderedClueFrequency_Poor')
sR = (((~lv) & M) + ((~cR) & M)) & M
sP = (((~lv) & M) + ((~cP) & M)) & M


def score(V, salt, pop, pick):
    ok = 0
    for k, (rem, j) in enumerate(pop):
        if int(h16(np.array([(V + k) & M], dtype=np.uint64), salt)[0]) % rem == j:
            ok += 1
    for k, (sz, idx) in enumerate(pick):
        if int(h16(np.array([(V + 6 + k) & M], dtype=np.uint64), salt)[0]) % sz == idx:
            ok += 1
    return ok


print('seedR=%d seedP=%d' % (sR, sP))
for name, base, pop, pick in (('Rich', sR, RICH_POP, RICH_PICK), ('Poor', sP, POOR_POP, POOR_PICK)):
    best = []
    for salt in range(0, 1000):
        for dv in range(-8, 9):
            V = (base + dv) & M
            sc = score(V, salt, pop, pick)
            if sc >= 10:
                best.append((sc, salt, dv))
    best.sort(reverse=True)
    print('%s: 满分%d 条约束，>=10 的组合 %d 个' % (name, len(pop) + len(pick), len(best)))
    for b in best[:8]:
        print('   ok=%d salt=%d dv=%+d' % b)
