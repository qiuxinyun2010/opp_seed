# -*- coding: utf-8 -*-
"""注册表反查：字符串 → VA → .data 中 {ptr,ptr} 对 → 实现函数。
用法: python reg_lookup.py <字符串> [窗口项数]"""
import struct, sys
sys.stdout.reconfigure(encoding='utf-8', errors='replace')

exe = r'd:/workspace/outlast/TOTClient-Win64-Shipping.exe'
data = open(exe, 'rb').read()

pe = data.find(b'PE\x00\x00')
nsec, = struct.unpack_from('<H', data, pe + 6)
optsz, = struct.unpack_from('<H', data, pe + 20)
img_base, = struct.unpack_from('<Q', data, pe + 24 + 24)
sec = pe + 24 + optsz
secs = []
for i in range(nsec):
    off = sec + i * 40
    vsize, va, rawsz, raw = struct.unpack_from('<IIII', data, off + 8)
    secs.append((va, rawsz, raw))

def va2off(va):
    rva = va - img_base
    for sva, rawsz, raw in secs:
        if sva <= rva < sva + rawsz:
            return raw + (rva - sva)
    return None

def off2va(off):
    for sva, rawsz, raw in secs:
        if raw <= off < raw + rawsz:
            return img_base + sva + (off - raw)
    return None

def rd(va, n):
    o = va2off(va)
    return None if o is None else data[o:o + n]

needle = sys.argv[1].encode()
win = int(sys.argv[2]) if len(sys.argv) > 2 else 6

# 找所有出现（精确串，后跟 \x00）
hits = []
p = 0
while True:
    i = data.find(needle, p)
    if i < 0:
        break
    if data[i + len(needle)] == 0:
        hits.append(i)
    p = i + 1
print('字符串命中 %d 处: %s' % (len(hits), [hex(off2va(h) or 0) for h in hits]))

for h in hits:
    va = off2va(h)
    if va is None:
        continue
    # 全文件扫 {va, func} 对（8 字节对齐）
    pat = struct.pack('<Q', va)
    q = 0
    while True:
        j = data.find(pat, q)
        if j < 0:
            break
        q = j + 8
        if j % 8:
            continue
        ent_va = off2va(j)
        if ent_va is None:
            continue
        print('  xref @%s' % hex(ent_va))
        for k in range(-win, win + 1):
            b = rd(ent_va + k * 16, 16)
            if not b or len(b) < 16:
                continue
            nptr, fptr = struct.unpack('<QQ', b)
            s = (rd(nptr, 80) or b'').split(b'\x00')[0].decode('ascii', 'replace')
            mark = ' <==' if nptr == va else ''
            if s.isprintable() and len(s) > 2:
                print('    %+3d %-55s -> %s%s' % (k, s, hex(fptr), mark))
