# -*- coding: utf-8 -*-
"""展开 vtable 段并打印关键槽位。用法: python read_vslot.py <任一槽位地址>"""
import struct, sys

exe = r'd:/workspace/outlast/TOTClient-Win64-Shipping.exe'
data = open(exe, 'rb').read()

pe = data.find(b'PE\x00\x00')
nsec, = struct.unpack_from('<H', data, pe + 6)
optsz, = struct.unpack_from('<H', data, pe + 20)
img_base, = struct.unpack_from('<Q', data, pe + 24 + 24)
sec = pe + 24 + optsz
secs = []
for i in range(nsec):
    off = sec + i * 40
    name = data[off:off + 8].rstrip(b'\x00').decode()
    vsize, va, rawsz, raw = struct.unpack_from('<IIII', data, off + 8)
    secs.append((name, va, rawsz, raw))

def va2off(v):
    rva = v - img_base
    for name, sva, rawsz, raw in secs:
        if sva <= rva < sva + rawsz:
            return raw + (rva - sva)
    return None

def is_code(v):
    return 0x140001000 <= v < 0x147625000

anchor = int(sys.argv[1], 0)
o = va2off(anchor)
assert o is not None and o % 8 == 0

def q(off):
    return struct.unpack_from('<Q', data, off)[0]

# 向两侧展开：允许少量非代码槽（0 或纯 call thunk）
lo = o
while True:
    v = q(lo - 8)
    if is_code(v) or v == 0:
        lo -= 8
    else:
        break
hi = o
while True:
    v = q(hi + 8)
    if is_code(v) or v == 0:
        hi += 8
    else:
        break

def o2v(off):
    for name, sva, rawsz, raw in secs:
        if raw <= off < raw + rawsz:
            return img_base + sva + (off - raw)
    return 0

base = lo
nslots = (hi - lo) // 8 + 1
print('vtable run: base=%s end=%s slots=%d' % (hex(o2v(base)), hex(o2v(hi)), nslots))
print('anchor %s = slot %d' % (hex(anchor), (o - base) // 8))
for s in (223, 230, 247, 256, 267, 268, 280, 281, 294, 295, 296, 297, 298, 323):
    if 0 <= s < nslots:
        print('  slot %-4d -> %s' % (s, hex(q(base + s * 8))))
