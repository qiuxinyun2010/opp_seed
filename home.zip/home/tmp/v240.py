# -*- coding: utf-8 -*-
"""读 0x1402B1599 处 lea 引用的宽字符串，算 ~CRC32w，验证 v240 是否落在候选集。"""
import pefile
import zlib
import numpy as np
from capstone import Cs, CS_ARCH_X86, CS_MODE_64

EXE = r'd:\workspace\outlast\TOTClient-Win64-Shipping.exe'
pe = pefile.PE(EXE, fast_load=True)
data = open(EXE, 'rb').read()
IB = pe.OPTIONAL_HEADER.ImageBase
M = 0xFFFFFFFF


def off_of(va):
    rva = va - IB
    for s in pe.sections:
        if s.VirtualAddress <= rva < s.VirtualAddress + s.Misc_VirtualSize:
            return s.PointerToRawData + (rva - s.VirtualAddress)
    return None


# lea rax, [rip + 0x6733ca0]
p = off_of(0x1402B1599)
md = Cs(CS_ARCH_X86, CS_MODE_64)
md.detail = True
ins = next(md.disasm(data[p:p + 15], 0x1402B1599))
disp = ins.operands[1].mem.disp
tgt = ins.address + ins.size + disp
print('lea -> 0x%X   (%s %s)' % (tgt, ins.mnemonic, ins.op_str))

q = off_of(tgt)
raw = data[q:q + 256]
s = raw.decode('utf-16-le', errors='replace').split('\x00')[0]
print('wide string = %r' % s)

crcw = zlib.crc32(s.encode('utf-16-le')) & M
def crcwc(x):
    return zlib.crc32(x.encode('utf-16-le')) & M

lv = crcw('SuburbRiot_T08_B03')
cR = crcw('SR_B02_ObjCoord_OrderedClueFrequency_Rich')
cP = crcw('SR_B02_ObjCoord_OrderedClueFrequency_Poor')
sR = (((~lv) & M) + ((~cR) & M)) & M
sP = (((~lv) & M) + ((~cP) & M)) & M
print('CRCw(str)=%d  ~CRCw=%d' % (crcw, (~crcw) & M))
print('seedR=%d seedP=%d' % (sR, sP))

R = set(int(x) for x in np.load('hits_rich.npy'))
P = set(int(x) for x in np.load('hits_poor.npy'))

for name, v in (('~S+sR', ((~crcw) & M) + sR), ('~S+sP', ((~crcw) & M) + sP),
                ('S+sR', crcw + sR), ('S+sP', crcw + sP)):
    v &= M
    print('  %-7s v240=%10d  Rich:%s  Poor:%s' % (name, v, v in R, v in P))
