import numpy as np
from b03_h16 import h16

M = 0xFFFFFFFF
CASES = (
    ('Rich', 562885957, [(3, 2), (4, 3), (3, 1), (2, 0), (4, 0), (2, 0)]),
    ('Poor', 923702852, [(2, 1), (2, 0), (2, 0), (3, 0), (2, 0), (2, 0)]),
)

for name, V, PICK in CASES:
    out = []
    for k, (sz, idx) in enumerate(PICK):
        g = int(h16(np.array([(V + 6 + k) & M], dtype=np.uint64), 485)[0]) % sz
        out.append('%d%s' % (g, '=' if g == idx else '/%d' % idx))
    print('%-5s V=%10d  %s' % (name, V, '  '.join(out)))
