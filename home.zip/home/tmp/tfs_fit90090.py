# -*- coding: utf-8 -*-
"""TFS_MT03 模型判定：14014(房间级) + 90090(actor级) 双样本联合拟合。

候选模型（k 由 ValvePerSectionRandomSettings=[1,1] -> k=1）：
  A first          : 答案 = 61390 段 k=1 抽出的那只（include，valid=[drawn]）
  B orig-complement: 答案 = 39135 段在「原序补集」上抽（exclude）
  C swap-complement: 旧 opp_seed 的 second（RemoveAtSwap 余池序）
另附通用 (k, mode) 网格。
"""
import sys, os
sys.path.insert(0, os.path.join(os.path.dirname(os.path.abspath(__file__)), '..'))

M32 = 0xFFFFFFFF
M64 = 0xFFFFFFFFFFFFFFFF

_CRC_TAB = []
for _i in range(256):
    _c = _i
    for _ in range(8):
        _c = ((_c >> 1) ^ 0xEDB88320) if _c & 1 else _c >> 1
    _CRC_TAB.append(_c & M32)


def crc32_fname(name):
    crc = M32
    for ch in name:
        u = ord(ch) & 0xFFFF
        crc = _CRC_TAB[(crc ^ (u & 0xFF)) & 0xFF] ^ (crc >> 8)
        crc = _CRC_TAB[(crc ^ (u >> 8)) & 0xFF] ^ (crc >> 8)
        crc = _CRC_TAB[crc & 0xFF] ^ (crc >> 8)
        crc = _CRC_TAB[crc & 0xFF] ^ (crc >> 8)
    return (~crc) & M32


def seed_of_object(name, outer_seed=0):
    value = (crc32_fname(name) + outer_seed) & M32
    return value if value < 0x80000000 else (0x100000000 - value) & M32


def seed_chain(names):
    value = 0
    for name in names:
        value = seed_of_object(name, value)
    return value


def _mix64(seed, salt):
    a = (0xBF58476D1CE4E5B9 * ((seed ^ (seed >> 30)) & M64)) & M64
    a ^= a >> 27
    g = (salt % 1000) & M64
    b = (0xBF58476D1CE4E5B9 * g) & M64
    b ^= b >> 27
    v5 = (((0x94D049BB133111EB * a) & M64) ^ ((0x94D049BB133111EB * b) & M64)) & M64
    t = (v5 ^ (v5 >> 31)) & M64
    v6 = (0xBF58476D1CE4E5B9 * (t ^ (t >> 30))) & M64
    u = (v6 ^ (v6 >> 27)) & M64
    v7 = (((321982955 * u) & M64) ^ (((0x94D049BB133111EB * u) & M64) >> 31)) & M64
    return v7 & M32


def rand_seeded(seed, n, salt=0):
    if not n or not seed:
        return 0
    return (_mix64(seed & M32, salt) & 0xFFFF) % n


SECTIONS = {
    'A1': ['01', '02', '03', '04', '05', '06'],
    'A2': ['01', '02', '03', '04', '05', '06'],
    'A3': ['1', '2', '3', '5', '6', '7'],
    'B1': ['02', '03', '04', '08'],
    'B2': ['07', '01', '02', '03', '04', '5', '05', '06'],
    'B3': ['1', '2', '3', '4', '6', '5'],
}
ORDER = ['B3', 'B2', 'B1', 'A3', 'A1', 'A2']

# 真值：允许的候选下标集合（房间级可能含 2 个）
TRUTH = {
    14014: {  # 房间级
        'B3': {0, 1},   # OfficeTrailer -> B3_1/B3_2
        'B2': {0, 7},   # East_Laundry  -> B2_07/B2_06
        'B1': {2},      # East_Construction -> B1_04
        'A3': {3, 4},   # ReceivingDocks_OfficeBuilding -> A3_5/A3_6
        'A1': {3, 4},   # East_Painting -> A1_04/A1_05
        'A2': {0, 1},   # West_Processing -> A2_01/A2_02
    },
    90090: {  # actor 级（A1/A2 仅房间级）
        'B3': {1},      # B3_2
        'B1': {1},      # B1_03
        'B2': {2},      # B2_02
        'A3': {4},      # A3_6
        'A1': {0, 2},   # West_Storage -> A1_01/A1_03
        'A2': {0, 1},   # West_Processing -> A2_01/A2_02
    },
}


def cs_of(section):
    return seed_chain(['PersistentLevel',
                       'MT03_FirePump_ObjCoord_BP_Section' + section])


def preselect(cs, n, k, level_seed):
    pool = list(range(n))
    drawn = []
    for i in range(k):
        if not pool:
            break
        j = rand_seeded(i + cs + 61390, len(pool), level_seed)
        drawn.append(pool[j])
        pool[j] = pool[-1]
        pool.pop()
    return drawn, pool


def model_first(cs, n, level_seed):
    return rand_seeded(cs + 61390, n, level_seed)


def model_orig_compl(cs, n, level_seed):
    drawn, _ = preselect(cs, n, 1, level_seed)
    valid = [i for i in range(n) if i not in drawn]
    return valid[rand_seeded(cs + 39135, len(valid), level_seed)]


def model_swap_compl(cs, n, level_seed):
    drawn, rest = preselect(cs, n, 1, level_seed)
    return rest[rand_seeded(cs + 39135, len(rest), level_seed)]


MODELS = [('A:first', model_first),
          ('B:orig-compl', model_orig_compl),
          ('C:swap-compl', model_swap_compl)]


def eval_models():
    print('== 三模型 vs 两局真值 ==')
    for name, fn in MODELS:
        hit = 0
        total = 0
        detail = []
        for seed in (14014, 90090):
            for sec in ORDER:
                n = len(SECTIONS[sec])
                idx = fn(cs_of(sec), n, seed)
                ok = idx in TRUTH[seed][sec]
                hit += ok
                total += 1
                detail.append('%d/%s->%s%s' % (seed, sec, SECTIONS[sec][idx], '' if ok else ' X'))
        print('%-14s %d/%d' % (name, hit, total))
        print('   ' + '  '.join(detail))


def eval_grid():
    print('\n== (k, mode) 网格：同时命中 14014+90090 全部 12 点的组合 ==')
    found = []
    for k in range(0, 9):
        for mode in ('include', 'exclude'):
            hit = 0
            total = 0
            ok_secs = []
            for seed in (14014, 90090):
                for sec in ORDER:
                    n = len(SECTIONS[sec])
                    cs = cs_of(sec)
                    drawn, rest = preselect(cs, n, k, seed)
                    if mode == 'include':
                        valid = sorted(drawn)
                    else:
                        valid = [i for i in range(n) if i not in drawn]
                    if not valid:
                        continue
                    idx = valid[rand_seeded(cs + 39135, len(valid), seed)]
                    ok = idx in TRUTH[seed][sec]
                    hit += ok
                    total += 1
                    ok_secs.append(ok)
            if total and hit == total:
                found.append((k, mode))
                print('  k=%d %-7s -> 12/12 FULL' % (k, mode))
    if not found:
        print('  (无 12/12 组合)')
        # 逐样本最佳
        for seed in (14014, 90090):
            print('  -- seed %d 各区命中情况 --' % seed)
            for sec in ORDER:
                n = len(SECTIONS[sec])
                cs = cs_of(sec)
                line = []
                for k in range(0, n + 1):
                    for mode in ('include', 'exclude'):
                        drawn, rest = preselect(cs, n, k, seed)
                        valid = sorted(drawn) if mode == 'include' else [i for i in range(n) if i not in drawn]
                        if not valid:
                            continue
                        idx = valid[rand_seeded(cs + 39135, len(valid), seed)]
                        if idx in TRUTH[seed][sec]:
                            line.append('k=%d %s' % (k, mode[:3]))
                print('  %-3s %s' % (sec, ', '.join(line) or '(无)'))


def dump(seed):
    print('\n== 明细 seed=%d ==' % seed)
    for sec in ORDER:
        n = len(SECTIONS[sec])
        cs = cs_of(sec)
        f = model_first(cs, n, seed)
        o = model_orig_compl(cs, n, seed)
        s = model_swap_compl(cs, n, seed)
        print('%-3s cs=%-11d first=%s orig=%s swap=%s truth=%s'
              % (sec, cs, SECTIONS[sec][f], SECTIONS[sec][o], SECTIONS[sec][s],
                 sorted(SECTIONS[sec][i] for i in TRUTH[seed][sec])))


if __name__ == '__main__':
    eval_models()
    eval_grid()
    dump(14014)
    dump(90090)
