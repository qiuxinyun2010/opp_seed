# -*- coding: utf-8 -*-
"""追 0x1402B2464（空串跳转目标）与 0x1402B1F91（另一 v240 分支）。"""
import pefile
from capstone import Cs, CS_ARCH_X86, CS_MODE_64

EXE = r'd:\workspace\outlast\TOTClient-Win64-Shipping.exe'
pe = pefile.PE(EXE, fast_load=True)
data = open(EXE, 'rb').read()
IB = pe.OPTIONAL_HEADER.ImageBase


def off_of(va):
    rva = va - IB
    for s in pe.sections:
        if s.VirtualAddress <= rva < s.VirtualAddress + s.Misc_VirtualSize:
            return s.PointerToRawData + (rva - s.VirtualAddress)
    return None


START, SIZE = 0x1402b05c0, 0x22f2
md = Cs(CS_ARCH_X86, CS_MODE_64)
insns = list(md.disasm(data[off_of(START):off_of(START) + SIZE], START))

for anchor, n in ((0x1402B2464, 26), (0x1402B1F91, 26)):
    try:
        i = next(j for j, x in enumerate(insns) if x.address == anchor)
    except StopIteration:
        print('!! 0x%X 不在函数内' % anchor)
        continue
    print('==== 0x%X ====' % anchor)
    for j in range(i, min(len(insns), i + n)):
        x = insns[j]
        print('  0x%X  %-8s %s' % (x.address, x.mnemonic, x.op_str))
    print()
