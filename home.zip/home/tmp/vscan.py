# -*- coding: utf-8 -*-
"""打印 vtable 锚点附近槽位的实现地址，识别本类 vtable 起止。
用法: python vscan.py <anchor_va> [span_slots]"""
import struct, sys

exe = r'd:/workspace/outlast/TOTClient-Win64-Shipping.exe'
data = open(exe, 'rb').read()

pe = data.find(b'PE\x00\x00')
nsec, = struct.unpack_from('<H', data, pe + 6)
optsz, = struct.unpack_from('<H', data, pe + 20)
img_base, = struct.unpack_from('<Q', data, pe + 24 + 24)
sec = pe + 24 + optsz
secs = []
for i in range(nsec):
    off = sec + i * 40
    name = data[off:off + 8].rstrip(b'\x00').decode()
    vsize, va, rawsz, raw = struct.unpack_from('<IIII', data, off + 8)
    secs.append((name, va, rawsz, raw))

def va2off(v):
    rva = v - img_base
    for name, sva, rawsz, raw in secs:
        if sva <= rva < sva + rawsz:
            return raw + (rva - sva)
    return None

anchor = int(sys.argv[1], 0)
span = int(sys.argv[2]) if len(sys.argv) > 2 else 420
o = va2off(anchor)

def q(off):
    return struct.unpack_from('<Q', data, off)[0]

# 打印相对槽位 → 实现地址；同前缀连续段压缩
prev_prefix = None
run_start = None
for k in range(-span, 41):
    v = q(o + k * 8)
    if 0x140001000 <= v < 0x147625000:
        pref = v >> 12           # 4KB 页前缀
    else:
        pref = -1
    if pref != prev_prefix:
        if prev_prefix is not None and run_start is not None:
            print('  slots %+4d..%+4d  ~%s' % (run_start, k - 1, hex(prev_prefix << 12)))
        run_start = k
        prev_prefix = pref
if prev_prefix is not None:
    print('  slots %+4d..%+4d  ~%s' % (run_start, 40, hex(prev_prefix << 12)))
print()
print('anchor slot 值 =', hex(q(o)))
