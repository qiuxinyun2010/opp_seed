# -*- coding: utf-8 -*-
"""离线反汇编 sub_1402B05C0，定位对 sub_1401A0F00 的调用点及其实参建立过程。"""
import sys
import pefile
from capstone import Cs, CS_ARCH_X86, CS_MODE_64

EXE = r'd:\workspace\outlast\TOTClient-Win64-Shipping.exe'
TARGETS = [0x1401a0f00, 0x1402c30c0]

pe = pefile.PE(EXE, fast_load=True)
data = open(EXE, 'rb').read()
image_base = pe.OPTIONAL_HEADER.ImageBase


def rva_to_off(rva):
    for s in pe.sections:
        if s.VirtualAddress <= rva < s.VirtualAddress + s.Misc_VirtualSize:
            return s.PointerToRawData + (rva - s.VirtualAddress)
    return None


def disasm(start, size):
    off = rva_to_off(start - image_base)
    blob = data[off:off + size]
    md = Cs(CS_ARCH_X86, CS_MODE_64)
    return list(md.disasm(blob, start)), blob


def show_func(start, size, targets, ctx=26):
    insns, _ = disasm(start, size)
    for i, ins in enumerate(insns):
        if ins.mnemonic == 'call' and ins.op_str.startswith('0x'):
            tgt = int(ins.op_str, 16)
            if tgt in targets:
                print('=== call 0x%X at 0x%X (func 0x%X) ===' % (tgt, ins.address, start))
                for j in range(max(0, i - ctx), min(len(insns), i + 3)):
                    mark = '>>' if j == i else '  '
                    print('%s 0x%X  %-8s %s' % (mark, insns[j].address,
                                                insns[j].mnemonic, insns[j].op_str))
                print()


if __name__ == '__main__':
    show_func(0x1402b05c0, 0x22f2, TARGETS)
