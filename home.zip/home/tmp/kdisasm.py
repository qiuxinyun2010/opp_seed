# -*- coding: utf-8 -*-
"""Kismet 字节码反汇编器（常用 opcode 子集）。用法: kdisasm.py <包基名> <函数名片段>"""
import struct, sys
sys.path.insert(0, '.')
from bp_dump import parse_package

# UE4 EExprToken（常用子集）
OPS = {
    0x00: ('LocalVariable', 'prop'), 0x01: ('InstanceVariable', 'prop'),
    0x02: ('DefaultVariable', 'prop'), 0x03: ('LocalOutVariable', 'prop'),
    0x04: ('Return', 'term'), 0x05: ('FinalFunction', 'call'),
    0x06: ('Jump', 'i32'), 0x07: ('JumpIfNot', 'term'),
    0x08: ('ComputedJump', 'term'), 0x09: ('PopExecutionFlow', ''),
    0x0A: ('PopExecutionFlowIfNot', 'term'), 0x0B: ('EndOfScript', ''),
    0x0F: ('Let', 'term'), 0x11: ('MetaCast', 'cls'),
    0x12: ('LetBool', 'term'), 0x14: ('EndOfStruct', ''),
    0x15: ('InterfaceContext', 'term'), 0x16: ('EndOfFunctionParams', ''),
    0x17: ('Cast', 'i32'), 0x18: ('DynamicCast', 'cls'),
    0x19: ('ObjectConst', 'obj'), 0x1B: ('IntConst', 'i32'),
    0x1C: ('FloatConst', 'f32'), 0x1D: ('StringConst', 'str'),
    0x1E: ('ObjectConst2', 'obj'), 0x1F: ('NameConst', 'fname'),
    0x21: ('IntZero', ''), 0x22: ('IntOne', ''), 0x23: ('True', ''),
    0x24: ('False', ''), 0x25: ('TextConst', 'text'), 0x26: ('NoObject', ''),
    0x28: ('IntConstByte', 'byte'), 0x29: ('FloatConst2', 'f32'),
    0x2C: ('Context', 'term'), 0x2D: ('CallMath', 'call'),
    0x2E: ('FinalFunction2', 'call'), 0x2F: ('VirtualFunction', 'name'),
    0x30: ('Let', 'term'), 0x31: ('LetObj', 'term'), 0x32: ('LetBool2', 'term'),
    0x34: ('LetDelegate', 'term'), 0x38: ('ArrayGet', ''),
    0x3F: ('Cast2', 'i32'), 0x40: ('InterfaceContext', 'term'),
    0x42: ('DelegateFunction', 'name'), 0x46: ('ArrayConst', 'i32'),
    0x4C: ('SoftObjectConst', 'soft'), 0x4D: ('CallMath2', 'call'),
    0x4E: ('SwitchValue', 'term'), 0x4F: ('FieldPathConst', ''),
}

def disasm(blob, imports, names, limit=400):
    i = 0
    out = []
    while i < len(blob) and len(out) < limit:
        op = blob[i]
        name, kind = OPS.get(op, ('UNK_%02X' % op, ''))
        line = '%04X  %-18s' % (i, name)
        i += 1
        try:
            if kind == 'prop':
                v, = struct.unpack_from('<i', blob, i); i += 4
                line += ' prop=%d' % v
            elif kind == 'call':
                v, = struct.unpack_from('<i', blob, i); i += 4
                nm = imports[-v - 1] if -len(imports) <= v < 0 else 'E%d' % v
                line += ' -> %s' % nm
            elif kind == 'i32':
                v, = struct.unpack_from('<i', blob, i); i += 4
                line += ' %d' % v
            elif kind == 'byte':
                line += ' %d' % blob[i]; i += 1
            elif kind == 'f32':
                v, = struct.unpack_from('<f', blob, i); i += 4
                line += ' %g' % v
            elif kind == 'str':
                n, = struct.unpack_from('<i', blob, i); i += 4
                if n < 0:
                    s = blob[i:i - 2 * n].decode('utf-16-le', 'replace'); i += -2 * n
                else:
                    s = blob[i:i + n].decode('utf-8', 'replace'); i += n
                line += ' %r' % s
            elif kind == 'obj':
                v, = struct.unpack_from('<i', blob, i); i += 4
                nm = imports[-v - 1] if -len(imports) <= v < 0 else 'E%d' % v
                line += ' obj=%s' % nm
            elif kind == 'cls':
                v, = struct.unpack_from('<i', blob, i); i += 4
                line += ' cls=%d' % v
            elif kind == 'name':
                a, b = struct.unpack_from('<ii', blob, i); i += 8
                line += ' name=%d/%d' % (a, b)
            elif kind == 'soft':
                i += 24
                line += ' (soft)'
            elif kind == 'text':
                i += 32
                line += ' (text)'
        except struct.error:
            line += ' <truncated>'
            break
        out.append(line)
        if name in ('EndOfScript',):
            break
    return out

if __name__ == '__main__':
    base = sys.argv[1]
    filt = sys.argv[2] if len(sys.argv) > 2 else 'UberGraph'
    names, imports, exports, uexp, th = parse_package(base + '.uasset', base + '.uexp')
    for e in exports:
        if filt.lower() not in e['name'].lower():
            continue
        if e['size'] <= 0 or e['off'] < 0:
            continue
        blob = uexp[e['off']:e['off'] + e['size']]
        print('== %s (size=%d)' % (e['name'], e['size']))
        for ln in disasm(blob, imports, names):
            print(' ', ln)
