# home/ — AI 生成的分析产物

本目录**全部由 AI 分析生成**，可以整目录打包给另一个会话；`release/` 根下的
`seedcore.py`、`puzzleroom.md`、`LEVELS.md`、`test.txt` 是原有的，不在这里。

```
home/
  README.md            本文件
  RE_METHOD.md         ★ 可复用的逆向方法论：五步定位链 / 随机原语 / 坑表 / 关键函数速查
  CHJ_MT01.md          ★ 关卡分析：法院「让正义天平倾斜」（已完全解出，6/6 验证）
  PSO_MT01.md          ★ 关卡分析：警察局办公区「四区钥匙」（4 样本未闭环，含已证伪记录）
  FPI_MT02.md          ★ 关卡分析：游乐场「Survive the Game Show」（结构已解，seed→答案 待解）
  DTS_MT01.md          ★ 关卡分析：闹市区「调频器 + 线索 + 搬回正确人体模型」（面板已解，线索/目标模型 待解）
  dts_mt01.py          ★ DTS_MT01 专用 CLI（候选池 / 房间 / 人体模型池 / seed → 3 个面板）
  MHS_MT01.md          ★ 关卡分析：黑帮据点「3 个投影房间 + 3 位密码」（已闭环，pick 12/12 / code 11/11）
  mhs_mt01.py          ★ MHS_MT01 专用 CLI（抽取池 / 房间去重 / seed → 3 个图案+房间+密码）
  SRR_MT02.md          ★ 关卡分析：郊区住宅区「有序调频」（第一轮闭环，6/6 未闭环；§11 是「3 图案 / 点位」的最终答复）
  srr_mt02.py          ★ SRR_MT02 专用 CLI（协调器参数 / 候选池 / 房间分组 / 坐标 / 实测）
  srr_answer.py        ★ SRR_MT02 直接答 Q1（每轮 3 图案）/ Q2（图案→调频器房间坐标）
  PSB_MT01.md          ★ 关卡分析：警察局地下室「3 区 3 把图案钥匙」（结构全解 13/13；seed→图案未闭环，§5 写清墙）
  psb_mt01.py          ★ PSB_MT01 专用 CLI（3 扇区 / 41 尸体 / 10 图案 / 候选尸体）
  psb_mt01_static.py   PSB_MT01 固化静态表（41 尸体 / 53 房间），由 tools/psb_gen.py 生成
  test.txt             实测样本
  res_mt02.py           ★ RES_MT02 专用 CLI（主轴段 26 颗真宝石：房间 / 人偶 / 类别 / 坐标）
  RES_MT02.md           ★ 关卡分析：水疗度假村「焚毁莉莉娅的遗物」（主轴段已闭环，教学段类别已解）
  res_mt02_pool.json    318 个莉莉娅人偶容器（房间 + 坐标 + 宝石挂点偏移）
  res_mt02_leveldata.json   RES_MT02 两个协调器的静态配置
  res_mt02_tuto_fit.py  教学段类别模型的一致性检查（两局 10 条实测，8/10）
  PSA_MT01.md         ★ 关卡分析：警察局阁楼「图案钥匙 + 录像盘」（7 节点钥匙树已闭环，26/26）
  psa_mt01.py         ★ PSA_MT01 专用 CLI（7 把钥匙点位 / 7 个房间 / 录像盘 / 最短链）
  TFS_MT03.md         ★ 关卡分析：玩具工厂「六阀门」（结构已从 IDA 读出，静态数据全核对；61390/39135 的包含-排除未闭环）
  tfs_mt03.py         ★ TFS_MT03 专用 CLI（按真实结构实现，--k/--mode 可切，--fit 出拟合表）
  tools/
    srr_scan.py          SRR_MT02 关卡 JSON 探查器（kinds / find / props / pool / tuners）
    srr_fit.py           拟合探查器 v2（8 种抽取算法 × 正/倒序 × 种子基扫描）
    srr_fit2.py          拟合探查器 v3（只验「前 D 组的 key 集合」，可扫 30 万，带交集检验）
    srr_fit3.py          交叉验证器（用第一轮的机器↔图案配对反推算法）
    gen_table.py       从 paks/ + release/map/plan.json 重新生成 MHS_MT01 的固化静态表
    probe_rooms.py     MHS_MT01 符号 → 房间探针（含「落在哪些 hull 里」）
    scan_x.c           2³² 全扫器（OpenMP），抓到 CHJ_MT01 的 X=0x4C09CC22
    pe_read.py         PE 节表 VA→文件偏移（读 CRC 表 / 查常量）
    pe_scan.py         离线 PE 查询：find（串/4 字节）/ disp（[reg+disp]）/ str / ptrs / props
    pe_str_at.py       按 VA 读 ASCII / UTF-16 串（配合 pe_scan.py find 的命中地址）
    ida_query.py       IDA headless 批处理：decompile / callers / xrefs / callees / vtdiff / qwords
    dis_va.py          capstone+pefile 裸反汇编（IDA 掉线兜底，`--raw` 看十六进制）
    srr_engine.py      SRR_MT02 抽取引擎模拟器（按 §23 重建）+ 全自由度扫描
    srr_diag.py        SRR_MT02 Phase D 首抽下标随池大小 N 的诊断表
    scan_disp.py       偏移指纹定位：扫 [reg+disp32] -> .pdata 归到函数入口（SRR_MT02 §12）
    callsites.py       函数内对某被调的 E8 调用点 + 调用前字节（读种子基/计数）
    vt_slot.py         目标 vtable 基址 + 槽偏移 -> 虚函数地址
    vt_class.py        同表邻槽判定：哪些函数与某成员同属一个类
    srr_strva.py       ASCII/UTF-16 串 -> VA（喂给 REA 的 xrefs）
    vaq.py             离线读 qword/dword/宽串 / 回溯 vtable（替代不可用的 read_bytes）
    room_actors.py     从 FModel 导出的关卡 JSON 扒 actor / 组件名
    dump_props.py      打印 JSON 里某个对象的 Properties
    dump_gameshow.py   打印 GameShow 协调器的分区/图案/回合配置
    samples.py / fit_*.py / probe_fpi.py   FPI_MT02 的样本解析与拟合（见 FPI_MT02.md）
    psb_gen.py         PSB_MT01 静态表生成器（pak + opp_seed/ui 地图数据 → psb_mt01_static.py）
    psb_scan.py        PSB_MT01 关卡 JSON 探查器（kinds / find / props / corpses / coord）
    psb_fit2.py        PSB_MT01「顺序抽 3」形态扫描（证伪用）
    psb_fit3.py        PSB_MT01 分支 A 全模拟（d × 组序 × 分配；0 命中）
    psb_fit4.py        PSB_MT01 用「尸体↔图案」四条事实反解（0 命中）
    psb_fit5.py        PSB_MT01 分支 B（每区独立抽 1）模板扫描（0 命中）
    psb_callscan.py    离线找 `RandSeeded(x,10)` 调用点（全 exe 仅 1 处，非本关）
    decomp/            反编译存档（dec_<VA>.c，按地址命名，供后续关卡查证）
```

临时文件（`_fit*.py` / `_dis.py` / `_probe.py` / `tmp/`）已清理；一次性脚本的结论
都写进了对应 `<关卡>.md` 的「已证伪」表，需要复现时按表重写，不要留半成品脚本。

## 用法

```powershell
cd d:\workspace\outlast\release\home

# 交付入口在 opp_seed/（不在本目录）
python ..\..\opp_seed\seed.py --list                 # 已支持 / 待做的关卡
python ..\..\opp_seed\seed.py CHJ_MT01 592592        # 3 个密码房 + 每间 4 位密码
python ..\..\opp_seed\seed.py RES_MT02 176176        # 水疗度假村：26 颗宝石（人偶 / 类别 / 坐标）
python ..\..\opp_seed\seed.py RES_MT02 69069 --tuto  # 再加教学段 51 人偶的类别图
python ..\..\opp_seed\seed.py --selftest             # 82/82

# 关卡专用分析脚本（留在 home，结果已同步进 opp_seed）
python res_mt02.py 176176                # RES_MT02 的全量点位（含 trace/pool）
python res_mt02_tuto_fit.py              # 教学段类别模型对 10 条实测的一致性检查

python dts_mt01.py 252252                # DTS_MT01：固定面板 + 3 个随机面板（含房间）
python dts_mt01.py 252252 --out r.json   # UTF-8 JSON（PowerShell 的 > 重定向是 UTF-16）
python dts_mt01.py --panels              # 20 个调频面板全表
python dts_mt01.py --mannequins          # 84 个人体模型出生点（6 种武器）
python dts_mt01.py --selftest            # 14 项自洽检查

python mhs_mt01.py 707707             # MHS_MT01：3 个区 → 图案 / 房间 / 密码 / 坐标
python mhs_mt01.py 707707 --json
python mhs_mt01.py --pool             # 抽取池（TrainDepot 因「每房间至多一个」10 → 8）
python mhs_mt01.py --find 884884 806  # 密码 → 房间（反向查）
python mhs_mt01.py --selftest         # code 11/11  pick 12/12  pattern 4/4  room 8/10

python srr_mt02.py --coords           # SRR_MT02：三个协调器 / 种子基 / 图案表
python srr_mt02.py --pool             # 三个候选池 + 房间 + 坐标
python srr_mt02.py --sample 417417    # 该 seed 的实测
python srr_mt02.py --selftest         # 50 项静态自洽检查

python srr_answer.py 417417           # SRR_MT02：逐轮回答「3 个图案 / 调频器点位」
python srr_answer.py 417417 --json
python srr_answer.py --sample 417417  # 已知 seed 的实测（3 个目标 → 调频器房间）
python srr_answer.py --pattern 月亮 --round r2
python srr_answer.py --selftest

python psb_mt01.py --sectors          # PSB_MT01：3 扇区 / 锁位 / 线索电视 / 区域
python psb_mt01.py --corpses C        # 41 具尸体（扇区 / 房间 / 坐标），可加 A|B|C
python psb_mt01.py --pool             # 10 个图案（QuestItemClasses 池顺序 + 贴图）
python psb_mt01.py 565565             # ★ 3 个区的钥匙图案 + 每区刷出的图案清单
python psb_mt01.py --known            # 两条实测样本回放
python psb_mt01.py --selftest         # 13/13（含 test.txt 的 4 条房间核对）

python pso_mt01.py 252252             # PSO_MT01：选区顺序 + 钥匙候选点（区内点位未闭环）
python pso_mt01.py 252252 --variants  # 几种未验证变体的对照结果
python pso_mt01.py 252252 --all-sections --json
python pso_mt01.py --selftest         # 选区 2/2 命中，点位 0/2（模型未闭环）
python pso_fit.py --strict            # 双样本拟合：只允许调用点已知常量

python res_mt02.py 176176             # RES_MT02：主轴段 26 颗真宝石（房间 / 人偶 / 类别 / 坐标）
python res_mt02.py 176176 --trace     # 附带房间排序键与逐个抽取过程
python res_mt02.py --rooms 176176     # 4 个区的房间排序与命中的前 N 个
python res_mt02.py --selftest         # 实测 2/2（BP160=红宝石 / BP_295=蓝宝石）
python res_mt02.py 69069 --tuto       # 教学段 51 个人偶的类别图（蓝/绿 + 序号 + 坐标）

python psa_mt01.py 958958             # PSA_MT01：最短链 + 7 把钥匙点位 + 录像盘
python psa_mt01.py 958958 --tree      # 完整 7 节点钥匙树
python psa_mt01.py 958958 --trace     # 房间抽取的重抽过程（距离过滤）
python psa_mt01.py --spawners         # 15 个钥匙房 × 2 个生成点全表
python psa_mt01.py --selftest         # 26/26（219219 15 项 + 958958 11 项）

python tfs_mt03.py 14014              # TFS_MT03：六区阀门（「预选被排除/被选中」两路都打）
python tfs_mt03.py 14014 --k 0        # k=0：39135 直接在全池抽
python tfs_mt03.py --fit              # 14014 实测房间 vs 各 (k, mode) 组合
```

交付版 `opp_seed\seed.py` 自带 `seedcore.py` / `seeddata.py` / `data\*.json`，在 `opp_seed/`
目录下直接 `python seed.py ...` 即可；它不依赖 `release/home`。`release/home` 里只保留
**分析过程**用的脚本（`res_mt02.py`、`dts_mt01.py`、`mhs_mt01.py` 等），
所有关卡数据都是从 `paks` / `pak` 的关卡 JSON 里提出来后同步进 `opp_seed\data\`。
`dts_mt01.py` 只读 `pak/` 下的关卡 JSON，自带随机原语；`mhs_mt01.py` 把静态表固化在文件里。

## 现状

| 关卡 | 说明 | 状态 |
|---|---|---|
| `CHJ_MT01` | 法院 · 让正义天平倾斜 | ✅ 房间 + 4 位密码，6/6 实测命中 |
| `FPI_MT02` | 游乐场 · 在真人秀中幸存 | 🟡 房间池/图案池/回合结构已解 |
| `DTS_MT01` | 闹市区 · 调频器 + 线索 + 人体模型 | 🟡 1 固定 + 3 随机面板已可算（分组假设待样本）；4 条线索/目标模型未解 |
| `MHS_MT01` | 黑帮据点 · 3 个投影房间 + 3 位密码 | ✅ 图案 + 房间 + 密码，pick 12/12、code 11/11、pattern 4/4 |
| `SRR_MT02` | 郊区住宅区 · 有序调频 | 🟡 第 1 轮位置+图案已闭环（seed 417417/737737 双验证）；第 2/3 轮 6/6 未闭环。§23–§24 已读完全部候选筛选谓词，卡点是「路径过滤 + 等价性过滤」两道运行期世界查询（§24.5）；实战不需要反推是哪 6 台（§24.6） |
| `PSO_MT01` | 警察局办公区 · 四区钥匙 | 🔴 4 条样本下「选哪个区」2/4、「区内哪个生成器」0/4；前一轮的选区模型已被新样本证伪，见 `PSO_MT01.md` |
| `PSB_MT01` | 警察局地下室 · 3 区图案钥匙 | ✅ **seed → 3 区钥匙图案已闭环**（12/12 实测，全 2³² 唯一解 `B=0xCD055621`；一局共 10 具，A3/C4/B3，每组第 1 具是钥匙）。🟡 图案落在哪具尸体仍差「候选组初始顺序」（来自一段随 seed 变化的洗牌），7 条约束已推出且 0 冲突，见 `PSB_MT01.md` §6 |
| `PSA_MT01` | 警察局阁楼 · 图案钥匙 + 录像盘 | ✅ 7 节点钥匙树 / 图案 / 房间 / 生成点 / 录像盘全解，26/26 实测（219219 + 958958）。旧脚本漏了 `PSA_LD_Items` 子关卡里的 `KeySpawner_Morgue_2`，已在 `psa_mt01.py` 补上；`opp_seed` 侧静态表待同步 |
| `CHJ_MT02/MT03` | 法院其它 Mini Trial | ⬜ 只有占位，缺 `Sections` 数据 |
| `RES_MT02` | 水疗度假村 · 焚毁莉莉娅的遗物 | 🟡 主轴段 26 颗全解（房间+人偶+类别+坐标，176176 实测 2/2；入口 `python ..\..\opp_seed\seed.py RES_MT02 <seed>`）；教学段**颜色已解**（`--tuto` 打印 51 人偶类别图，两局 8/10 实测，`BP_139` 单点异常），**点位（51 选 6）未解**，见 `RES_MT02.md` §6 |

新增关卡：写一份 `<关卡>.md`（照 `CHJ_MT01.md` / `DTS_MT01.md` 的结构）+ 一个 `<关卡>.py`；
随机原语优先复用 `release/seed/seedcore.py` 或 `dts_mt01.py` 里的实现。

## 逆向方法论（新关卡从这里入手）

**`RE_METHOD.md`** 是从 RES_MT02 / PSB_MT01 / SRR_MT02 提炼的可复用流程：

* **五步定位链**：关卡 JSON → 协调器类 → ctor 读成员偏移 → 虚表槽 → 目标函数；
* **随机原语唯一实现**：`RandSeeded / RandRangeInt / RandFraction / GetSeed`，盐 = `关卡种子 % 1000`；
* **三种抽取形态**（长度递减 / 长度不变 / 区间抽配额桶）先判形态再拟合；
* **坑表 8 条**：循环上界不递减、计数器复位、`RemoveAt` 条件化、比较器语义、
  `GetSeed` 与关卡种子无关、幻数归属、单局调参过拟合、把记录歧义当误差；
* **拟合套路**：模型层剪枝 + numpy 全 2³² 扫描 + 双样本 join 取唯一解 + 证伪留档；
* **关键函数速查表**（VA → 语义）。

## 逆向取代码的三个入口

1. `release/coop/tools/`、`release/coop/GUIDE.md` —— 原有流程（REA MCP / ida_rpc.py），需要 IDA 开着 MCP 插件。
2. `home/tools/ida_query.py` —— **不开 IDA GUI**，headless `idat` 批处理（实测快且稳）：
   ```powershell
   $env:IDA_Q='decompile'; $env:IDA_ARGS='0x14361A4E0'
   $env:IDA_OUT='d:\workspace\outlast\release\home\_ida_out.txt'
   & "C:\Program Files\IDA Professional 9.3\idat.exe" -A `
       -S"d:\workspace\outlast\release\home\tools\ida_query.py" `
       "d:\workspace\outlast\TOTClient-Win64-Shipping.exe.i64"
   ```
   ⚠️ headless `idat` 打开数据库后会**回写 `.i64`**（时间戳/元数据变化），这是一次性副作用，
   分析结论不受影响；介意的话先把 `.i64` 复制一份再跑。
3. `home/tools/pe_scan.py` / `pe_str_at.py` —— 纯离线读 exe（找字符串、找 `[reg+disp]`），不占 IDA。


## 12.1 2026-10-31 复核（PSB_MT01）

* **REA**：server 可用，但 `ida` provider 掉线（`Not connected`，上游 `ida_pro_mcp` 的 stdio 进程已退出）。
  IDA 侧 MCP 插件端口 `127.0.0.1:13337` 正常 -> 新增 `tools/ida_http.py` 直连插件继续反编译。
  恢复办法：IDA 里 `Ctrl+Alt+M` 重开插件 / 重启 IDE 的 rea MCP server。
* **Q1 复核**：`python tools/psb_model.py 378378` -> A=月亮 C=黑桃 B=火焰，与实测一致；
  结论不变（v143=0xCD055621，图案偏移 223551，池 `QuestItemClasses` 递减移除）。
* **Q2**：用汇编核实了洗牌比较器（`0x14361C3B5 GetSeed -> 0x14361C3C1 f() -> ucomiss 0.5f`，
  后向扫描比的是枢轴 `[rsi]`）。`tools/psb_sort_scan.exe` 扫 L 全 32 位仍最高 7/9 ->
  还差「v144 的来源/顺序」或「crc32 变体」一处。明细见 `PSB_MT01_Q2.md`，
  点位表用 `python tools/mt01_q2_table.py` 生成。
