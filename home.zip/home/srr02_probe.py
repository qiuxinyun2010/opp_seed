# -*- coding: utf-8 -*-
"""读取 TOTClient-Win64-Shipping.exe 中指定 VA 的字符串（UTF-16LE / ASCII），
用于确认 sub_1402B05C0 的盐名等常量。只读 exe，不修改任何文件。"""
import struct, sys

EXE = r"D:\workspace\outlast\TOTClient-Win64-Shipping.exe"
IMAGE_BASE = 0x140000000


def sections():
    with open(EXE, "rb") as f:
        f.seek(0x3C)
        e_lfanew = struct.unpack("<I", f.read(4))[0]
        f.seek(e_lfanew + 4)
        machine, nsect, _ts, _ps, _cs, opt_size, _chars = struct.unpack(
            "<HHIIIHH", f.read(20))
        opt_off = f.tell()
        magic = struct.unpack("<H", f.read(2))[0]
        # section table offset = opt_off + opt_size
        sect_off = opt_off + opt_size
        f.seek(sect_off)
        secs = []
        for i in range(nsect):
            name, vsize, va, rsize, raw = struct.unpack("<8sIIII", f.read(24))
            f.read(16)  # relocs/linenums/characteristics
            secs.append((name.rstrip(b"\x00").decode("latin1"),
                         va, vsize, raw, rsize))
        return secs


def rva_to_off(rva, secs):
    for name, va, vsize, raw, rsize in secs:
        if va <= rva < va + max(vsize, rsize):
            return raw + (rva - va)
    return None


def dump(va, n=64):
    secs = sections()
    rva = va - IMAGE_BASE
    off = rva_to_off(rva, secs)
    if off is None:
        print("VA %#x -> no section" % va)
        return
    with open(EXE, "rb") as f:
        f.seek(off)
        data = f.read(n)
    # UTF-16LE
    try:
        s16 = data.decode("utf-16-le")
        s16 = s16.split("\x00")[0]
    except Exception as e:
        s16 = "<err %s>" % e
    asc = "".join(chr(b) if 32 <= b < 127 else "." for b in data)
    print("VA %#x (off %#x) UTF16=%r ASCII=%r" % (va, off, s16, asc))


if __name__ == "__main__":
    vas = [int(x, 0) for x in sys.argv[1:]]
    if not vas:
        vas = [0x14665E254, 0x14665E264]
    for va in vas:
        dump(va)
