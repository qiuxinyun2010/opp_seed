# -*- coding: utf-8 -*-
"""由「屏幕 3 个 = 抽序前 3 台」反推出第一轮的完整抽序，再去找抽取算法。

  417417: 屏幕 [Moon, Bunny, Club] → BP/BP2/BP3  → 抽序 = [BP, BP2, BP3, BP49]
  737737: 屏幕 [Moon, Spade, Club] → BP2/BP3/BP49 → 抽序 = [BP2, BP3, BP49, BP]

两个 seed 各 1/24，联合 1/576 —— 只要 base 是确定的（不扫偏移），命中即可信。
"""
import sys
from itertools import product

M32 = 0xFFFFFFFF
M64 = 0xFFFFFFFFFFFFFFFF

_T = []
for _i in range(256):
    _c = _i
    for _ in range(8):
        _c = ((_c >> 1) ^ 0xEDB88320) if (_c & 1) else (_c >> 1)
    _T.append(_c & M32)


def crc32_fname(text):
    crc = M32
    for ch in text:
        u = ord(ch) & 0xFFFF
        crc = _T[(crc ^ (u & 0xFF)) & 0xFF] ^ (crc >> 8)
        crc = _T[(crc ^ (u >> 8)) & 0xFF] ^ (crc >> 8)
        crc = _T[crc & 0xFF] ^ (crc >> 8)
        crc = _T[crc & 0xFF] ^ (crc >> 8)
    return (~crc) & M32


def seed_of_object(name):
    value = (crc32_fname(name) + crc32_fname('PersistentLevel')) & M32
    return value if value < 0x80000000 else (0x100000000 - value) & M32


def mix1(x):
    z = (0xBF58476D1CE4E5B9 * (x ^ (x >> 30))) & M64
    return z ^ (z >> 27)


def rs(seed, n, salt):
    if not n or not seed:
        return 0
    B = (0x94D049BB133111EB * mix1(salt % 1000)) & M64
    v = ((0x94D049BB133111EB * mix1(seed)) & M64) ^ B
    t = (v ^ (v >> 31)) & M64
    w = (0xBF58476D1CE4E5B9 * (t ^ (t >> 30))) & M64
    u = (w ^ (w >> 27)) & M64
    r = (((321982955 * u) & M64) ^ (((0x94D049BB133111EB * u) & M64) >> 31)) & M64
    return (r & 0xFFFF) % n


POOL = ['BP', 'BP2', 'BP3', 'BP49']
COORD = 'SRR_MT02_OrderedClueFrequency_RichDistrict'
SEED = seed_of_object(COORD)
SALT_CRC = crc32_fname('Objective Actors')
WANT = {417417: ['BP', 'BP2', 'BP3'], 737737: ['BP2', 'BP3', 'BP49']}


def draw(base, mode, salt, n=3):
    if mode == 'plain':
        mem = list(POOL)
        out = []
        for i in range(n):
            k = rs((base + i) & M32, len(mem), salt)
            out.append(mem[k])
            mem[k] = mem[-1]
            mem.pop()
        return out
    if mode == 'rm':
        mem = list(POOL)
        out = []
        for i in range(n):
            k = rs((base + i) & M32, len(mem), salt)
            out.append(mem[k])
            del mem[k]
        return out
    if mode == 'fy':
        mem = list(POOL)
        for i in range(len(mem), 1, -1):
            j = rs((base + (len(mem) - i)) & M32, i, salt)
            mem[i - 1], mem[j] = mem[j], mem[i - 1]
        return mem[:n]
    raise ValueError(mode)


def main():
    cands = [('GetSeed', SEED), ('GetSeed+saltCrc', (SEED + SALT_CRC) & M32),
             ('GetSeed+503', (SEED + 503) & M32),
             ('GetSeed+507', (SEED + 507) & M32)]
    print('目标 417417 = %s' % WANT[417417])
    print('目标 737737 = %s' % WANT[737737])
    for btag, base in cands:
        for mode in ('plain', 'rm', 'fy'):
            a = draw(base, mode, 417417)
            b = draw(base, mode, 737737)
            mark = '★' if (a == WANT[417417] and b == WANT[737737]) else ' '
            print('%s %-16s %-6s  417=%-28s 737=%s' % (mark, btag, mode, a, b))


if __name__ == '__main__':
    main()
