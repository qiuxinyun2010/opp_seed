"""FPI_MT02：检验「seed -> 房间」是否复用 CHJ_MT01 的分区排序算法。

18 个分区（SectionDefinitions 顺序），每区只有 1 间房；
假设：两回合各取排序后的第 (2k, 2k+1) 个分区（NumActiveConsoles=2）。
"""
import sys

sys.path.insert(0, r"d:\workspace\outlast\release")
import seedcore as sc

ROOMS = [
    'RBRoom_RabbitTortur', 'RBRoom_RabbitHole_CarrotsStorage',
    'RBRoom_RabbitHole_Bedroom_Master', 'RBRoom_RabbitHole_DinnerTable',
    'RBRoom15_9', 'RBRoom_QueenTrone', 'RBRoom_CreepyHands', 'RBRoom_Library',
    'RBRoom_Storm', 'RBRoom_UpsideDownStorm', 'RBRoom_UpsideDown_Church',
    'RBRoom_SpaceConsoleStation', 'RBRoom_UpsideUp_Church',
    'RBRoom_ShowRoom_Master', 'RBRoom_Eyes', 'RBRoom_Tesseract',
    'RBRoom_DinningIllusion', 'RBRoom_DarkMannequin',
]

SAMPLES = {
    189189: [('RBRoom_SpaceConsoleStation', 'RBRoom_Eyes'),
             ('RBRoom_RabbitHole_CarrotsStorage', 'RBRoom_DarkMannequin')],
    346346: [('RBRoom_RabbitHole_DinnerTable', 'RBRoom_CreepyHands'),
             ('RBRoom_UpsideDownStorm', 'RBRoom_DinningIllusion')],
}


def order_for(seed, base=0):
    salt = (seed % 1000)
    keys = sc._section_keys(len(ROOMS), salt)
    return sc._sort_sections(keys, salt)


for seed, rounds in SAMPLES.items():
    order = order_for(seed)
    names = [ROOMS[i] for i in order]
    print('seed %d (salt %d)' % (seed, seed % 1000))
    print('  order[:6] =', [n.replace('RBRoom_', '') for n in names[:6]])
    for k, want in enumerate(rounds):
        got = tuple(names[2 * k:2 * k + 2])
        print('  round%d want=%s got=%s %s' % (
            k + 1,
            [w.replace('RBRoom_', '') for w in want],
            [g.replace('RBRoom_', '') for g in got],
            'OK' if set(got) == set(want) else '--'))
