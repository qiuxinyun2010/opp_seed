"""解析 home/test.txt 里手抄的样本，输出结构化列表（供拟合脚本用）。

支持的行格式（尽量宽松）：
    Trial ID: FPI_MT02, ... Seed: 189189, EffectiveNumberOfPlayers: 1
    1 bear=9                                  # 教学关（房间固定 = RBRoom_Circus）
    2 space-station-Dumbbells=4+1=5 ；wall of eyes-sharing=1+3+1=5
    3 carrots_storage-apple=1+2+1=4 ; child dorm-book=4+2=6

用法：
    python samples.py [test.txt]        # 打印解析结果
"""
import json
import re
import sys

# 玩家写法 / 游戏显示名 / actor 名 → 统一 actor
ALIASES = {
    'space-station': 'RBRoom_SpaceConsoleStation',
    'spacestation': 'RBRoom_SpaceConsoleStation',
    'space station': 'RBRoom_SpaceConsoleStation',
    'wall of eye': 'RBRoom_Eyes',
    'wall of eyes': 'RBRoom_Eyes',
    'eyes': 'RBRoom_Eyes',
    'carrots_storage': 'RBRoom_RabbitHole_CarrotsStorage',
    'carrots storage': 'RBRoom_RabbitHole_CarrotsStorage',
    'child dorm': 'RBRoom_DarkMannequin',
    'darkmannequin': 'RBRoom_DarkMannequin',
    'rabbit_dinner': 'RBRoom_RabbitHole_DinnerTable',
    'rabbit dinner': 'RBRoom_RabbitHole_DinnerTable',
    'wall of hands': 'RBRoom_CreepyHands',
    'creepyhands': 'RBRoom_CreepyHands',
    'upside_storm': 'RBRoom_UpsideDownStorm',
    'upside storm': 'RBRoom_UpsideDownStorm',
    'illusion_dinner': 'RBRoom_DinningIllusion',
    'illusion dinner': 'RBRoom_DinningIllusion',
    'hourglass': 'RBRoom_Circus',
    'circus': 'RBRoom_Circus',
    'rabbit torture': 'RBRoom_RabbitTortur',
    'rabbit bedroom': 'RBRoom_RabbitHole_Bedroom_Master',
    'kitchen storage': 'RBRoom15_9',
    'queen throne': 'RBRoom_QueenTrone',
    'library': 'RBRoom_Library',
    'storm': 'RBRoom_Storm',
    'upside church': 'RBRoom_UpsideDown_Church',
    'church': 'RBRoom_UpsideUp_Church',
    'showroom': 'RBRoom_ShowRoom_Master',
    'illusion cube': 'RBRoom_Tesseract',
}

SYMBOLS = ['apple', 'book', 'brushteeth', 'cleaning', 'dumbbells',
           'sharing', 'sleep', 'washhands', 'water', 'blank']
SYMBOL_ALIAS = {'bear': 'sharing', 'teddy': 'sharing', 'teeth': 'brushteeth',
                'hands': 'washhands'}


def _norm(s):
    return re.sub(r'[\s_]+', ' ', s.strip().lower())


def room_of(name):
    n = _norm(name)
    if n in ALIASES:
        return ALIASES[n]
    key = n.replace(' ', '-')
    if key in ALIASES:
        return ALIASES[key]
    k = n.replace(' ', '')
    if k in ALIASES:
        return ALIASES[k]
    for alias, actor in ALIASES.items():
        if alias.replace(' ', '') == k:
            return actor
    return None


def symbol_of(name):
    n = _norm(name)
    n = SYMBOL_ALIAS.get(n, n)
    n = n.replace(' ', '')
    for s in SYMBOLS:
        if s == n:
            return SYMBOLS.index(s)
    return None


def parse(path):
    """-> [{'seed':int,'players':int,'stages':{1:[...],2:[...],3:[...]}}]"""
    out = []
    cur = None
    for raw in open(path, encoding='utf-8', errors='replace'):
        line = raw.strip()
        if not line:
            continue
        m = re.search(r'Seed:\s*(\d+)', line, re.I)
        if m:
            cur = {'seed': int(m.group(1)), 'players': 1, 'stages': {}}
            mp = re.search(r'Players:\s*(\d+)', line, re.I)
            if mp:
                cur['players'] = int(mp.group(1))
            out.append(cur)
            continue
        m = re.match(r'^([123])\s+(.*)$', line)
        if not m or cur is None:
            continue
        stage = int(m.group(1))
        body = m.group(2)
        for part in re.split(r'[；;]', body):
            part = part.strip()
            if not part:
                continue
            mm = re.match(r'^([^=]+?)\s*=\s*(.+)$', part)
            if not mm:
                continue
            head, tail = mm.group(1).strip(), mm.group(2).strip()
            # head 可能是 "space-station-Dumbbells"
            if '-' in head:
                room_s, sym_s = head.rsplit('-', 1)
            elif ' ' in head:
                room_s, sym_s = head.rsplit(' ', 1)
            else:
                room_s, sym_s = '', head
            digits = [int(x) for x in re.findall(r'\d+', tail)]
            total = digits[-1] if digits else None
            panels = digits[:-1] if len(digits) > 1 else digits
            if len(panels) == 1 and total is not None and panels[0] == total:
                panels = []
            cur['stages'].setdefault(stage, []).append({
                'room': room_of(room_s) if room_s else 'RBRoom_Circus',
                'room_raw': room_s,
                'symbol': symbol_of(sym_s),
                'symbol_raw': sym_s,
                'panels': panels,
                'total': total,
            })
    return out


if __name__ == '__main__':
    path = sys.argv[1] if len(sys.argv) > 1 else 'test.txt'
    data = parse(path)
    print(json.dumps(data, ensure_ascii=False, indent=2))
    bad = [(s['seed'], e) for s in data for st in s['stages'].values() for e in st
           if not e['room'] or e['symbol'] is None]
    if bad:
        print('!! 未能解析的条目：', bad)
