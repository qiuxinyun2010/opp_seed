# -*- coding: utf-8 -*-
"""对候选类表基址做判别：看 +0x888/+0x898 槽和 4 个已知成员函数的槽号。

    python vt_pick.py 0x145A061C8 0x145A04C50 0x145A05440 ...
"""
import struct
import sys
import os

_HERE = os.path.dirname(os.path.abspath(__file__))
sys.path.insert(0, _HERE)
import scan_disp as sd
import vaq

KNOWN = {
    0x14358EA00: 'collect',
    0x14358EF70: 'getactors',
    0x14358ED80: 'endplay',
    0x14358E4A0: 'sync',
}


def q(va):
    off = vaq.va2off(va)
    if off is None:
        return 0
    return struct.unpack_from('<Q', vaq.d, off)[0]


def main():
    slot = int(sys.argv[1], 16)
    for a in sys.argv[2:]:
        base = int(a, 16)
        print('== base=0x%X' % base)
        first = [q(base + 8 * i) for i in range(4)]
        print('   slot0..3: %s' % ' '.join('%X' % x for x in first))
        for off in (0x880, 0x888, 0x890, 0x898, 0x8A0):
            t = q(base + off)
            c = sd.containing(t) if t else None
            tag = ''
            if t:
                if c:
                    tag = 'func size 0x%X' % (c[1] - c[0])
                else:
                    tag = 'thunk/non-pdata'
            print('   +0x%03X -> %-12X %s' % (off, t, tag))
        idxs = {}
        for i in range(0, 760):
            v = q(base + 8 * i)
            if v in KNOWN:
                idxs[KNOWN[v]] = i
        print('   已知成员槽号: %s' % (idxs if idxs else 'none'))
        if idxs.get('collect') is not None:
            print('   collect 槽 %d，+6 槽(0x%X) -> %X'
                  % (idxs['collect'], 8 * (idxs['collect'] + 6),
                     q(base + 8 * (idxs['collect'] + 6))))


if __name__ == '__main__':
    main()
