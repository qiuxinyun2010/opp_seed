# -*- coding: utf-8 -*-
"""在二进制里找包含 sub_14361C230 的 vtable，并打印该表 +0x800 槽的虚函数。

用法:
    python tools/psb_find_vt.py 14361C230        # 找含该函数指针的 vtable
    python tools/psb_find_vt.py 14361C230 800    # 顺便看 +0x800 槽
"""
import struct
import sys
import os

_HERE = os.path.dirname(os.path.abspath(__file__))
sys.path.insert(0, _HERE)
import vaq

PATH = r"d:\workspace\outlast\TOTClient-Win64-Shipping.exe"
d = open(PATH, "rb").read()

image_base = vaq.image_base
SECS = vaq.SECS


def main():
    target = int(sys.argv[1], 16)
    slot_off = int(sys.argv[2], 16) if len(sys.argv) > 2 else None

    needle = struct.pack("<Q", target)
    hits = []
    # 只在 .rdata / .data 里找（vtable 在只读数据段）
    for name, sva, vsize, rawptr, rawsize in SECS:
        if name not in (".rdata", ".data"):
            continue
        seg = d[rawptr:rawptr + max(vsize, rawsize)]
        i = 0
        while True:
            j = seg.find(needle, i)
            if j < 0:
                break
            va = image_base + sva + j
            hits.append(va)
            i = j + 1

    print("目标函数 %X 作为 qword 出现 %d 次：" % (target, len(hits)))
    for va in hits:
        print("  qword @ 0x%X  (rva 0x%X)" % (va, va - image_base))

    # 对每个命中，回溯到 vtable 表头（向上找一段连续的 code 指针，直到非 code 或空）
    print("\n=== 回退定位 vtable ===")
    for va in hits:
        start = va
        while True:
            q = struct.unpack_from("<Q", d, vaq.va2off(start - 8))[0]
            if vaq.is_code(q) or q == 0:
                start -= 8
                if va - start > 0x4000 or start < image_base + 0x5066000:
                    break
            else:
                break
        # start 附近应是表头（slot0 通常是析构/首函数）
        # 找表的第一个非零槽
        head = start
        while head - 8 >= image_base:
            q = struct.unpack_from("<Q", d, vaq.va2off(head - 8))[0]
            if q == 0 and head - start < 0x200:
                head -= 8
            else:
                break
        idx = (va - start) // 8
        print("  %X 在 vtable(起始~%X) 的槽 idx=%d (off=0x%X)"
              % (va, start, idx, idx * 8))
        if slot_off is not None:
            sva2 = start + slot_off
            q = struct.unpack_from("<Q", d, vaq.va2off(sva2))[0]
            print("      +0x%X [idx %d] -> %X%s"
                  % (slot_off, slot_off // 8, q, '  ; code' if vaq.is_code(q) else ''))
        # 打印前 16 个槽，帮助确认表头
        print("      前 16 槽:", ' '.join(
            '%X' % struct.unpack_from("<Q", d, vaq.va2off(start + 8 * k))[0]
            for k in range(16)))


if __name__ == '__main__':
    main()
