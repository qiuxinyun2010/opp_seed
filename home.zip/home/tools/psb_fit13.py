# -*- coding: utf-8 -*-
"""PSB_MT01 第十三轮：把 base 当自由 24 位量，尸体集双样本联合反解。

约束
  seed 378378（完整）：A {0,4,6}  B {1,5,9}  C {8,9,14}   （组内下标）
  seed 565565（部分）：A ∋ 1     B ∋ 0      C ∋ {0,3}
模型
  for group(顺序待定) : for k in 0..2:
      idx = RandSeeded(base + 243551 + k + v70, |组内候选|)   （保序 / swap 删除）
  v70 跨组累加（+3）

随机命中概率 ≈ 1/(455·120·560) × 0.0015 ≈ 5×10⁻¹¹，2²⁴ 次扫描期望 0.001 次巧合。
"""
import os
import sys

sys.path.insert(0, os.path.abspath(os.path.join(os.path.dirname(__file__), '..', '..', 'seed')))
import seedcore as sc  # noqa: E402

A_LIST = [0, 1, 2, 4, 8, 15, 16, 17, 18, 19, 22, 33, 34, 35, 40]
B_LIST = [9, 10, 21, 23, 24, 25, 26, 32, 36, 37]
C_LIST = [3, 5, 6, 7, 11, 12, 13, 14, 20, 27, 28, 29, 30, 31, 38, 39]
LISTS = {'A': A_LIST, 'B': B_LIST, 'C': C_LIST}
WANT378 = {'A': {0, 4, 6}, 'B': {1, 5, 9}, 'C': {8, 9, 14}}
WANT565 = {'A': {1}, 'B': {0}, 'C': {0, 3}}
COORD = 'PSB_MT01_B01_CorpseSearch_3'

r = sc.rand_seeded
OFF = 243551


def group_set(base, sec, swap, salt, v70=0):
    g = list(range(len(LISTS[sec])))
    out = set()
    for k in range(3):
        i = r((base + OFF + k + v70) & 0xFFFFFFFF, len(g), salt)
        out.add(g[i])
        if swap:
            g[i] = g[-1]
        g.pop(i)
    return out


def full(base, order, swap, salt):
    return {sec: group_set(base, sec, swap, salt, 3 * idx)
            for idx, sec in enumerate(order)}


def main():
    try:
        sys.stdout.reconfigure(encoding='utf-8')
    except Exception:
        pass
    scan = int(sys.argv[1]) if len(sys.argv) > 1 else (1 << 24)
    lvl = sc.crc32_fname('PersistentLevel')
    coord = sc.seed_of_object(COORD, lvl)
    s378 = 378378 % 1000
    s565 = 565565 % 1000
    orders = [('A', 'B', 'C'), ('A', 'C', 'B'), ('B', 'A', 'C'),
              ('B', 'C', 'A'), ('C', 'A', 'B'), ('C', 'B', 'A')]
    print('扫 base = 0..%d（GetSeed(coord)=0x%08X）' % (scan - 1, coord))
    hits = 0
    for pure in (True, False):
        for d in range(scan):
            base = d if pure else (coord + d) & 0xFFFFFFFF
            # 每区「首组」的第 1 抽（两种删除语义相同）
            first = {}
            for sec in 'ABC':
                first[sec] = r((base + OFF) & 0xFFFFFFFF, len(LISTS[sec]), s378)
            cand = [sec for sec in 'ABC'
                    if first[sec] in WANT378[sec]]
            if not cand:
                continue
            for swap in (True, False):
                for order in orders:
                    if order[0] not in cand:
                        continue
                    got = full(base, order, swap, s378)
                    if any(got[s] != WANT378[s] for s in 'ABC'):
                        continue
                    got565 = full(base, order, swap, s565)
                    if any(not (WANT565[s] <= got565[s]) for s in 'ABC'):
                        continue
                    print('★★ base=%d (pure=%s) swap=%s order=%s' % (d, pure, swap, order))
                    print('   378: %s' % got)
                    print('   565: %s' % got565)
                    hits += 1
    print('命中 %d' % hits)


if __name__ == '__main__':
    main()
