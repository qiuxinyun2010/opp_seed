# -*- coding: utf-8 -*-
"""推理每轮「显示屏上的 3 个图案」（不管调频器）。

假设：屏幕上这 3 个是直接从 PossibleClueNames 里逐个无放回抽 3 个，
种子 = GetSeed(协调器) + offset + i，与调频器抽取相互独立。

实测（release/home/test.txt）：
  轮1 RichDistrict (图案池 5)  417417: 月亮-兔子-梅花      737737: 月亮-黑桃-梅花
  轮2 School      (图案池 6)  417417: 方块-红心-兔子      737737: 梅花-月亮-红心
  轮3 SasExit     (图案池 6)  417417: 方块-月亮-兔子      737737: 月亮-红心-方块

两个 seed 同时约束 → 轮1 假阳性 1/60²，轮2/3 假阳性 1/120²。
"""
import sys

M32 = 0xFFFFFFFF
M64 = 0xFFFFFFFFFFFFFFFF

_T = []
for _i in range(256):
    _c = _i
    for _ in range(8):
        _c = ((_c >> 1) ^ 0xEDB88320) if (_c & 1) else (_c >> 1)
    _T.append(_c & M32)


def crc32_fname(text):
    crc = M32
    for ch in text:
        u = ord(ch) & 0xFFFF
        crc = _T[(crc ^ (u & 0xFF)) & 0xFF] ^ (crc >> 8)
        crc = _T[(crc ^ (u >> 8)) & 0xFF] ^ (crc >> 8)
        crc = _T[crc & 0xFF] ^ (crc >> 8)
        crc = _T[crc & 0xFF] ^ (crc >> 8)
    return (~crc) & M32


def seed_of_object(name):
    value = (crc32_fname(name) + crc32_fname('PersistentLevel')) & M32
    return value if value < 0x80000000 else (0x100000000 - value) & M32


def mix1(x):
    z = (0xBF58476D1CE4E5B9 * (x ^ (x >> 30))) & M64
    return z ^ (z >> 27)


def rs(seed, n, salt):
    if not n or not seed:
        return 0
    B = (0x94D049BB133111EB * mix1(salt % 1000)) & M64
    v = ((0x94D049BB133111EB * mix1(seed)) & M64) ^ B
    t = (v ^ (v >> 31)) & M64
    w = (0xBF58476D1CE4E5B9 * (t ^ (t >> 30))) & M64
    u = (w ^ (w >> 27)) & M64
    r = (((321982955 * u) & M64) ^ (((0x94D049BB133111EB * u) & M64) >> 31)) & M64
    return (r & 0xFFFF) % n


CLUES = {
    'RichDistrict': ['Bunny', 'Heart', 'Moon', 'Spade', 'Club'],
    'School': ['Bunny', 'Heart', 'Moon', 'Spade', 'Club', 'Diamond'],
    'SasExit': ['Bunny', 'Heart', 'Moon', 'Spade', 'Club', 'Diamond'],
}
COORD = {
    'RichDistrict': 'SRR_MT02_OrderedClueFrequency_RichDistrict',
    'School': 'SRR_MT02_OrderedClueFrequency_School',
    'SasExit': 'SRR_MT02_OrderedClueFrequency_SasExit',
}
WANT = {
    ('RichDistrict', 417417): ['Moon', 'Bunny', 'Club'],
    ('RichDistrict', 737737): ['Moon', 'Spade', 'Club'],
    ('School', 417417): ['Diamond', 'Heart', 'Bunny'],
    ('School', 737737): ['Club', 'Moon', 'Heart'],
    ('SasExit', 417417): ['Diamond', 'Moon', 'Bunny'],
    ('SasExit', 737737): ['Moon', 'Heart', 'Diamond'],
}
SALT_CRC = crc32_fname('Objective Actors')


def draw(key, base, off, salt, n=3, swap=True):
    pool = list(CLUES[key])
    out = []
    for i in range(n):
        k = rs((base + off + i) & M32, len(pool), salt)
        out.append(pool[k])
        if swap:
            pool[k] = pool[-1]
            pool.pop()
        else:
            del pool[k]
    return out


def main():
    span = int(sys.argv[1]) if len(sys.argv) > 1 else 200000
    for key in ('RichDistrict', 'School', 'SasExit'):
        base = seed_of_object(COORD[key])
        bases = {'coord': base, '+salt': (base + SALT_CRC) & M32}
        for btag, b0 in bases.items():
            for swap in (True, False):
                hits = []
                for off in range(span):
                    if draw(key, b0, off, 417417, swap=swap) != WANT[(key, 417417)]:
                        continue
                    if draw(key, b0, off, 737737, swap=swap) != WANT[(key, 737737)]:
                        continue
                    hits.append(off)
                if hits:
                    print('★★ %-13s base=%-6s swap=%-5s offset=%s'
                          % (key, btag, swap, hits[:8]))
                    o0 = hits[0]
                    print('     417: %s' % draw(key, b0, o0, 417417, swap=swap))
                    print('     737: %s' % draw(key, b0, o0, 737737, swap=swap))
                else:
                    print('   %-13s base=%-6s swap=%-5s 无命中' % (key, btag, swap))


if __name__ == '__main__':
    main()
