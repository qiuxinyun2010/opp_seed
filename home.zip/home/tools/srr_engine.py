# -*- coding: utf-8 -*-
"""SRR_MT02 抽取引擎模拟器（依据 sub_1402B05C0 的完整反编译结果重建）。

packages:
  Phase C 主抽取（0x1402B17F0 - 0x1402B1AF5）
      for 组 in 组数组:                    # 24 字节步进
          for k in 0 .. 组.desired-1:
              n    = 组.Num
              if n <= 0: break
              seed = base + 已选总数        # 已选总数 = coord+1640，跨组累计
              pos  = (mix(seed, level_seed) & 0xFFFF) % n
              pick = 组.Data[pos]
              RemoveAtSwap(组, pos)
              已选总数 += 1
              sub_1402B3C30(...)           # 剪枝

  Phase D 补足（0x1402B20A7 - 0x1402B22D5）
      while 已选总数 < DesiredCount:
          pool = 剩余候选
          idx  = RandSeeded(base + 已选总数, 0, len(pool)-1)
          pick = pool[idx] ; RemoveAt(pool, idx)
          已选总数 += 1

base 的两个分支（0x1402B1600 - 0x1402B163F / 0x1402B1F91 - 0x1402B1FD8）:
      Path A: base = ~crc32("Objective Actors") + GetSeed(协调器)
      Path B: base = ~crc32("Objective Actors") + crc32(类名串)
"""
import os
import sys

_HERE = os.path.dirname(os.path.abspath(__file__))
_HOME = os.path.dirname(_HERE)
if _HOME not in sys.path:
    sys.path.insert(0, _HOME)

import srr_mt02 as m  # noqa: E402

M32 = 0xFFFFFFFF
M64 = 0xFFFFFFFFFFFFFFFF


def mix_a(seed, level_seed):
    """sub_1402D29E0 / 内联混合的完整输出（64 位）。"""
    a = (0xBF58476D1CE4E5B9 * ((seed ^ (seed >> 30)) & M64)) & M64
    a ^= a >> 27
    b = (0xBF58476D1CE4E5B9 * (level_seed % 1000)) & M64
    b ^= b >> 27
    v = (((0x94D049BB133111EB * a) & M64) ^ ((0x94D049BB133111EB * b) & M64)) & M64
    t = (v ^ (v >> 31)) & M64
    w = (0xBF58476D1CE4E5B9 * (t ^ (t >> 30))) & M64
    u = (w ^ (w >> 27)) & M64
    return (((321982955 * u) & M64) ^ (((0x94D049BB133111EB * u) & M64) >> 31)) & M64


def rand16(seed, level_seed):
    """主抽取循环用的混合器，返回低 16 位（其后才 %n）。"""
    if not seed or not level_seed:
        return 0
    return mix_a(seed & M32, level_seed) & 0xFFFF


def pick_pos(seed, n, level_seed):
    """(uint16)mix % n —— 与 `div di` 指令一致。"""
    if n <= 0 or not level_seed or not seed:
        return 0
    return (rand16(seed, level_seed) % (n & 0xFFFF))


def remove_at_swap(arr, i):
    """UE TArray::RemoveAtSwap：把最后一个搬到坑里。"""
    last = arr.pop()
    if i < len(arr):
        arr[i] = last


def remove_at(arr, i):
    """UE TArray::RemoveAt：保序。"""
    del arr[i]


# --------------------------------------------------------------------------
def _dist(a, b, xyz=True):
    pa, pb = m.TUNERS[a][1], m.TUNERS[b][1]
    n = 3 if xyz else 2
    return sum((pa[i] - pb[i]) ** 2 for i in range(n)) ** 0.5


def simulate(coord_key, level_seed, base, pool,
             desired=None, remove='swap', topup=True,
             prune=0.0, prune_xyz=True, prune_mode='dist', trace=False):
    """返回选中的 actor 列表（按抽取顺序）。

    prune_mode:
      'dist'  剪掉「与任一已选台距离 < prune」的候选（§12.2 的旧读法）
      'room'  剪掉「与刚抽中那台同房间」的候选（§23.8 依据 sub_1402B3C30 提出）
      'both'  两者都剪
      'none'  不剪
    """
    cfg = m.COORDS[coord_key]
    desired = desired if desired is not None else cfg['desired']
    pool = list(pool)
    selected = []
    count = 0
    steps = []
    for _k in range(desired):
        n = len(pool)
        if n <= 0:
            break
        pos = pick_pos((base + count) & M32, n, level_seed)
        actor = pool[pos]
        if remove == 'swap':
            remove_at_swap(pool, pos)
        else:
            remove_at(pool, pos)
        selected.append(actor)
        count += 1
        if prune_mode in ('room', 'both'):
            before = len(pool)
            room = m.TUNERS[actor][0]
            pool = [c for c in pool if m.TUNERS[c][0] != room]
            steps.append((actor, 'room', before, len(pool)))
        if prune_mode in ('dist', 'both') and prune > 0:
            before = len(pool)
            pool = [c for c in pool
                    if all(_dist(c, s, prune_xyz) >= prune for s in selected)]
            steps.append((actor, 'dist', before, len(pool)))
    # Phase D（主循环抽不满时补货）
    while topup and count < desired and pool:
        idx = m.rand_seeded((base + count) & M32, len(pool), level_seed)
        selected.append(pool[idx])
        remove_at(pool, idx)
        count += 1
    if trace:
        return selected, steps
    return selected


# --------------------------------------------------------------------------
TARGETS = {
    # coordinator -> seed -> (前 3 台有序, 6 台集合)
    'RichDistrict': {
        417417: (['BP', 'BP2', 'BP3'], set(['BP', 'BP2', 'BP3', 'BP49'])),
        737737: (['BP2', 'BP3', 'BP49'], set(['BP', 'BP2', 'BP3', 'BP49'])),
    },
    'School': {
        417417: (['BP24', 'BP26', 'BP5'],
                 set(['BP5', 'BP6', 'BP19', 'BP26', 'BP24', 'BP29'])),
        737737: (['BP21', 'BP25', 'BP11'],
                 set(['BP5', 'BP8', 'BP11', 'BP21', 'BP27_3', 'BP25'])),
    },
    'SasExit': {
        417417: (['BP43', 'BP45', 'BP36'],
                 set(['BP45', 'BP43', 'BP31', 'BP38', 'BP36', 'BP47'])),
        737737: (['BP40', 'BP45', 'BP30'],
                 set(['BP30', 'BP33', 'BP37', 'BP45', 'BP40', 'BP47'])),
    },
}


def check(coord_key, level_seed, base, pool, **kw):
    got = simulate(coord_key, level_seed, base, pool, **kw)
    head, want_set = TARGETS[coord_key][level_seed]
    ok_head = list(got[:len(head)]) == head
    ok_set = (len(got) >= len(want_set)) and (set(got[:len(want_set)]) == want_set)
    return ok_head, ok_set, got


def sweep(profile=True):
    """把所有已识别的自由度跑一遍，对两个 seed 的「前 3 有序」与「6 台集合」同时检验。"""
    orders = {'fwd': lambda p: list(p),
              'rev': lambda p: list(reversed(p)),
              'fwd_no0': lambda p: list(reversed(p[1:])),
              }
    bases = {'A': m.base_of, 'Araw': lambda k: m.seed_of_object(m.COORDS[k]['actor'])}
    rows = []
    for ck in ('RichDistrict', 'School', 'SasExit'):
        thr = m.COORDS[ck]['min_distance']
        pool = m.COORDS[ck]['pool']
        for on, of in orders.items():
            for bn, bf in bases.items():
                for rm in ('swap', 'at'):
                    for pm in ('none', 'room', 'dist', 'both'):
                        for pr in ((0.0, True), (thr, True), (thr, False)):
                            score = 0
                            detail = []
                            for sd in TARGETS[ck]:
                                okh, oks, got = check(ck, sd, bf(ck), of(pool),
                                                      remove=rm, prune=pr[0],
                                                      prune_xyz=pr[1],
                                                      prune_mode=pm)
                                score += (2 if okh else 0) + (1 if oks else 0)
                                detail.append((sd, okh, oks, got))
                            rows.append((score, ck, on, bn, rm, (pm, pr), detail))
    rows.sort(key=lambda r: -r[0])
    for score, ck, on, bn, rm, pr, detail in rows:
        pm, p = pr
        tag = '%s/thr%.0f%s' % (pm, p[0], 'XYZ' if p[1] else 'XY')
        print('score=%d  %-13s %-8s %-5s %-5s %-16s  %s'
              % (score, ck, on, bn, rm, tag,
                 ' | '.join('%d:%s%s' % (sd, 'H' if h else '-', 'S' if s else '-')
                            for sd, h, s, _ in detail)))
    if profile:
        print()
        for _s, ck, on, bn, rm, pr, detail in rows[:6]:
            for sd, h, s, got in detail:
                print('  %-13s %d  %-8s %-5s %-5s thr=%.0f -> %s'
                      % (ck, sd, on, bn, rm, pr[0], ','.join(got[:6])))


def main():
    try:
        sys.stdout.reconfigure(encoding='utf-8')
    except Exception:
        pass
    sweep()


if __name__ == '__main__':
    main()
