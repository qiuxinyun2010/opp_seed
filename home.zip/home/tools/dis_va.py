# -*- coding: utf-8 -*-
"""裸反汇编小工具（capstone + pefile）——IDA 掉线 / provider 报 -32001 时的兜底。

    python tools/dis_va.py 0x1433B5BC0            # 默认 0x100 字节
    python tools/dis_va.py 0x1433B5BC0 0x200
    python tools/dis_va.py 0x1433B5BC0 --raw      # 只打十六进制，不给反汇编

依赖：pip install capstone pefile
exe 路径可用环境变量 TOT_EXE 覆盖。
"""
import os
import sys

import pefile
from capstone import Cs, CS_ARCH_X86, CS_MODE_64

EXE = os.environ.get('TOT_EXE', r'd:/workspace/outlast/TOTClient-Win64-Shipping.exe')
BASE = 0x140000000


def va2off(pe, va):
    rva = va - BASE
    for s in pe.sections:
        if s.VirtualAddress <= rva < s.VirtualAddress + max(s.Misc_VirtualSize, s.SizeOfRawData):
            return s.PointerToRawData + (rva - s.VirtualAddress)
    raise ValueError('VA 不在任何节里：' + hex(va))


def load():
    pe = pefile.PE(EXE, fast_load=True)
    with open(EXE, 'rb') as f:
        return pe, f.read()


def dump(va, n, data, pe):
    md = Cs(CS_ARCH_X86, CS_MODE_64)
    md.detail = False
    off = va2off(pe, va)
    for ins in md.disasm(data[off:off + n], va):
        print('%012X  %-8s %s' % (ins.address, ins.mnemonic, ins.op_str))


def raw(va, n, data, pe):
    off = va2off(pe, va)
    blob = data[off:off + n]
    for i in range(0, len(blob), 16):
        print('%012X  %s' % (va + i, ' '.join('%02X' % b for b in blob[i:i + 16])))


def main():
    if len(sys.argv) < 2:
        print(__doc__)
        return 2
    va = int(sys.argv[1], 16)
    args = sys.argv[2:]
    hexed = '--raw' in args
    n = int([a for a in args if a != '--raw'][0], 16) if \
        [a for a in args if a != '--raw'] else 0x100
    pe, data = load()
    (raw if hexed else dump)(va, n, data, pe)
    return 0


if __name__ == '__main__':
    sys.exit(main())
