# -*- coding: utf-8 -*-
"""按 §17.3 读出来的**指令级公式**验证抽取顺序。

公式（0x1402B17F0-0x1402B18E0）：
    seed = O + 已选数            (O 来自 [rsp+0Ch] = coordSeed + crc(盐名) 之类别)
    h    = mix(seed, level_seed)
    pos  = (h & 0xFFFF) % n      (div di)
    pool 稳定删除 pos（memcpy 移位 = RemoveAt）

检验目标：
    R1 两 seed 的完整 4 台顺序；
    R2/R3 两 seed 的「前 3 台」= 屏幕顺序（其余 3 台只比集合）。

    python srr_pick_test.py            # 先试 O = base
    python srr_pick_test.py --scan 1<<20   # 把 O 当未知常数扫
"""
import os
import sys

sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.abspath(__file__))))
import srr_mt02 as m

# (seed, 轮次 key, 前 3 台（屏序）, 全部选中集合)
CASES = [
    (417417, 'RichDistrict', ['BP', 'BP2', 'BP3'], {'BP', 'BP2', 'BP3', 'BP49'}),
    (737737, 'RichDistrict', ['BP2', 'BP3', 'BP49'], {'BP', 'BP2', 'BP3', 'BP49'}),
    (417417, 'School', ['BP24', 'BP26', 'BP5'], {'BP24', 'BP26', 'BP5', 'BP6', 'BP19', 'BP29'}),
    (737737, 'School', ['BP21', 'BP25', 'BP11'], {'BP21', 'BP25', 'BP11', 'BP5', 'BP8', 'BP27_3'}),
    (417417, 'SasExit', ['BP43', 'BP45', 'BP36'], {'BP43', 'BP45', 'BP36', 'BP31', 'BP38', 'BP47'}),
    (737737, 'SasExit', ['BP40', 'BP45', 'BP30'], {'BP40', 'BP45', 'BP30', 'BP33', 'BP37', 'BP47'}),
]


def picks(key, level_seed, delta, count):
    pool = list(m.COORDS[key]['pool'])
    O = (m.base_of(key) + delta) & m.M32
    out = []
    for k in range(count):
        h = m.rand_seeded((O + k) & m.M32, len(pool), level_seed)
        out.append(pool[h])
        pool.pop(h)                      # 稳定删除
    return out


def check(delta, verbose=False):
    ok_front = 0
    ok_set = 0
    for seed, key, front, full in CASES:
        got = picks(key, seed, delta, len(full))
        if got[:3] == front:
            ok_front += 1
        if set(got) == full:
            ok_set += 1
        if verbose:
            print('   seed=%-7d %-12s got=%-34s front=%s set=%s'
                  % (seed, key, ','.join(got), got[:3] == front, set(got) == full))
    return ok_front, ok_set


def main():
    if '--scan' in sys.argv:
        span = int(sys.argv[sys.argv.index('--scan') + 1])
        print('扫描 delta = 0..%d（O = base(协调器) + delta）' % span)
        hits = 0
        # 三条独立约束做前置过滤
        pre = []
        for seed, key, front, _ in CASES:
            n = len(m.COORDS[key]['pool'])
            pre.append((m.base_of(key), seed, n, m.COORDS[key]['pool'].index(front[0])))
        for d in range(span):
            good = True
            for base, seed, n, want in pre:
                if m.rand_seeded((base + d) & m.M32, n, seed) != want:
                    good = False
                    break
            if not good:
                continue
            f, s = check(d)
            if f >= 3:
                hits += 1
                print('  HIT delta=%d front=%d/6 set=%d/6' % (d, f, s))
        print('扫描完成，命中 %d 个' % hits)
        return
    print('delta = 0（O = base）')
    f, s = check(0, verbose=True)
    print('前3台命中 %d/6，集合命中 %d/6' % (f, s))


if __name__ == '__main__':
    main()
