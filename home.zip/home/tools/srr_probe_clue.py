# -*- coding: utf-8 -*-
"""反解「图案序列」的抽取常数。

前提（已由两个 seed 的第一轮验证）：Pattern 按「候选池顺序」逐台赋给被选中的调频器。
因此把实测的 (机器=图案) 按池序排列，就得到该 seed 的图案序列。

序列模型：seq[i] = clue[ RandSeeded(S + O + stride*i, len-i) ]，取出即删（swap / 保序）。
S = GetSeed(协调器)。要求 6 个样本同时成立（4 个 6 元排列 + 2 个 4 元排列），
随机期望命中 ≈ 扫描量 / (720*720*720*720*24*24) —— 也就是唯一解。
"""
import os
import sys

sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.abspath(__file__))))
import srr_mt02 as m

# 由实测 (seed, round) 反推出的图案序列（按池序）
EXPECT = {
    (417417, 'RichDistrict'): ['Moon', 'Bunny', 'Club', 'Heart'],
    (737737, 'RichDistrict'): ['Heart', 'Moon', 'Spade', 'Club'],
    (417417, 'School'): ['Diamond', 'Heart', 'Spade', 'Club', 'Bunny', 'Moon'],
    (737737, 'School'): ['Moon', 'Bunny', 'Spade', 'Club', 'Heart', 'Diamond'],
    (417417, 'SasExit'): ['Heart', 'Club', 'Diamond', 'Bunny', 'Moon', 'Spade'],
    (737737, 'SasExit'): ['Diamond', 'Spade', 'Moon', 'Club', 'Heart', 'Bunny'],
}


def build(base_kind):
    rows = []
    for (seed, key), seq in EXPECT.items():
        S = m.seed_of_object(m.COORDS[key]['actor'])
        if base_kind == 'salt':
            S = (S + m.crc32_fname(m.SALT_NAME)) & m.M32
        clues = m.COORDS[key]['clues']
        rows.append((S, seed, clues, [clues.index(c) for c in seq]))
    return rows


def check(rows, O, stride, mode):
    for S, seed, clues, want in rows:
        pool = list(range(len(clues)))
        for i, w in enumerate(want):
            k = m.rand_seeded((S + O + stride * i) & m.M32, len(pool), seed)
            if pool[k] != w:
                return False
            if mode == 'swap':
                pool[k] = pool[-1]
                pool.pop()
            else:
                pool.pop(k)
    return True


def main():
    span = int(sys.argv[1]) if len(sys.argv) > 1 else (1 << 22)
    for base_kind in ('coord', 'salt'):
        rows = build(base_kind)
        for stride in (0, 1, 2):
            for mode in ('swap', 'stable'):
                found = []
                for O in range(span):
                    # 先用第一抽做过滤（6 元环 3 个、4 元环 2 个）
                    ok = True
                    for S, seed, clues, want in rows:
                        k = m.rand_seeded((S + O) & m.M32, len(clues), seed)
                        if k != want[0]:
                            ok = False
                            break
                    if ok and check(rows, O, stride, mode):
                        found.append(O)
                        if len(found) >= 8:
                            break
                print('%-5s stride=%d %-6s -> %s'
                      % (base_kind, stride, mode,
                         [hex(x) for x in found] if found else 'none'))


if __name__ == '__main__':
    main()
