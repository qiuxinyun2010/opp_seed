# -*- coding: utf-8 -*-
"""检验 B 是否随 run 变化：B_run = crc(coord) + level_seed 等假设。

并测「9/9 命中」在 B 空间中的密度，判断此前的完美命中是否为巧合。
"""
import sys, os
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
from psb_sort import rand_seeded, crc32_fname, M32

POOL = ["Bunny", "Club", "Diamond", "Fire", "Heart",
        "Spade", "Crown", "Eye", "Moon", "Star"]
LAYOUTS = {
    'A3C4B3': [('A', 3), ('C', 4), ('B', 3)],
    'B3A3C4': [('B', 3), ('A', 3), ('C', 4)],
    'A3B3C4': [('A', 3), ('B', 3), ('C', 4)],
    'C4A3B3': [('C', 4), ('A', 3), ('B', 3)],
}
# 观测：run -> {扇区: set(图案)}
OBS = {
    378378: {'A': {'Moon', 'Heart', 'Crown'},
             'B': {'Fire', 'Diamond', 'Bunny'},
             'C': {'Spade', 'Eye', 'Club'}},
    565565: {'A': {'Heart'}, 'B': {'Club'}, 'C': {'Eye'}},
}
EXACT = {378378: {'A': 3, 'B': 3, 'C': 3}, 565565: {'A': 1, 'B': 1, 'C': 1}}
SECTOR_N = {'A': 15, 'B': 10, 'C': 16}
COORD = 'PSB_MT01_B01_CorpseSearch_3'


def run_sets(B, OK, seed, layout, salt):
    pool = list(POOL)
    bysec = {}
    t = 0
    for sec, cnt in layout:
        for _ in range(cnt):
            ki = rand_seeded((B + OK + t) & M32, len(pool), salt)
            bysec.setdefault(sec, set()).add(pool.pop(ki))
            t += 1
    return bysec


def score(B, OK, layout, smode):
    ok = bad = 0
    for seed, obs in OBS.items():
        salt = seed % 1000 if smode == 'mod1000' else seed
        got = run_sets(B, OK, seed, layout, salt)
        for sec, pats in obs.items():
            for p in pats:
                if p in got.get(sec, ()):
                    ok += 1
                else:
                    bad += 1
    return ok, bad


def main():
    try:
        sys.stdout.reconfigure(encoding='utf-8')
    except Exception:
        pass
    C = crc32_fname(COORD)
    print('crc(coord) = 0x%08X   (0xCD055621 - crc = %d)' % (C, (0xCD055621 - C)))

    print('\n[A] 假设 B_run = crc(coord) + f(seed)：')
    cands = []
    for name, fn in (
        ('crc+seed', lambda s: (C + s) & M32),
        ('crc-seed', lambda s: (C - s) & M32),
        ('seed', lambda s: s & M32),
        ('crc', lambda s: C),
        ('crc+seed*2', lambda s: (C + 2 * s) & M32),
    ):
        for sm in ('mod1000', 'full'):
            for ln, lay in LAYOUTS.items():
                for OK in (223551, 243551):
                    ok = bad = 0
                    for seed, obs in OBS.items():
                        B = fn(seed)
                        salt = seed % 1000 if sm == 'mod1000' else seed
                        got = run_sets(B, OK, seed, lay, salt)
                        for sec, pats in obs.items():
                            for p in pats:
                                if p in got.get(sec, ()):
                                    ok += 1
                                else:
                                    bad += 1
                    cands.append((ok, -bad, name, sm, ln, OK))
    cands.sort(reverse=True)
    for c in cands[:6]:
        print('  ok=%2d bad=%d  B=%s salt=%s layout=%s OK=%d'
              % (c[0], -c[1], c[2], c[3], c[4], c[5]))

    print('\n[B] 密度：固定 OK=223551 layout=B3A3C4 salt=mod1000，扫 B')
    base = 0xCFE2D35F
    n = 200000
    n9 = 0
    best = []
    for i in range(n):
        B = (base + i) & M32
        ok, bad = score(B, 223551, LAYOUTS['B3A3C4'], 'mod1000')
        if ok >= 10:
            best.append((ok, B))
        if ok >= 9:
            n9 += 1
    print('  ok>=9 的比例 %.2e   期望 1/432000 = 2.3e-6' % (n9 / float(n)))
    for ok, B in sorted(best, reverse=True)[:10]:
        print('    ok=%d B=0x%08X' % (ok, B))


if __name__ == '__main__':
    main()
