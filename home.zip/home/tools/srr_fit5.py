# -*- coding: utf-8 -*-
"""SRR_MT02 双 seed 交叉验证器（决定性检验）。

关键性质：**base 不含 level_seed**（= crc32_fname(盐名) + GetSeed(协调器)，两者都只跟
对象和名字有关），而 RandSeeded 内部掺的 salt = level_seed % 1000 随 seed 变。
所以「同一个 base，salt=417 与 salt=737 必须同时给出各自实测的 6 台」——
随机假阳性约 (1/C(26,6))^2 ≈ 1.9e-11，命中即定解。

实测（release/home/test.txt）：
  seed 417417  School : BP5 BP6 BP19 BP24 BP26 BP29      SasExit: BP45 BP43 BP31 BP38 BP36 BP47
  seed 737737  School : BP5 BP8 BP11 BP21 BP25 BP27_3    SasExit: BP30 BP33 BP37 BP45 BP40 BP47
"""
import sys
from collections import OrderedDict

M32 = 0xFFFFFFFF
M64 = 0xFFFFFFFFFFFFFFFF

_T = []
for _i in range(256):
    _c = _i
    for _ in range(8):
        _c = ((_c >> 1) ^ 0xEDB88320) if (_c & 1) else (_c >> 1)
    _T.append(_c & M32)


def crc32_fname(text):
    crc = M32
    for ch in text:
        u = ord(ch) & 0xFFFF
        crc = _T[(crc ^ (u & 0xFF)) & 0xFF] ^ (crc >> 8)
        crc = _T[(crc ^ (u >> 8)) & 0xFF] ^ (crc >> 8)
        crc = _T[crc & 0xFF] ^ (crc >> 8)
        crc = _T[crc & 0xFF] ^ (crc >> 8)
    return (~crc) & M32


def seed_of_object(name):
    value = (crc32_fname(name) + crc32_fname('PersistentLevel')) & M32
    return value if value < 0x80000000 else (0x100000000 - value) & M32


def mix1(x):
    z = (0xBF58476D1CE4E5B9 * (x ^ (x >> 30))) & M64
    return z ^ (z >> 27)


BCACHE = {}


def B_of(salt):
    if salt not in BCACHE:
        BCACHE[salt] = (0x94D049BB133111EB * mix1(salt % 1000)) & M64
    return BCACHE[salt]


def rs(seed, n, B):
    if not n or not seed:
        return 0
    v = ((0x94D049BB133111EB * mix1(seed)) & M64) ^ B
    t = (v ^ (v >> 31)) & M64
    w = (0xBF58476D1CE4E5B9 * (t ^ (t >> 30))) & M64
    u = (w ^ (w >> 27)) & M64
    r = (((321982955 * u) & M64) ^ (((0x94D049BB133111EB * u) & M64) >> 31)) & M64
    return (r & 0xFFFF) % n


POOLS = {
    'School': ['BP23', 'BP24', 'BP25', 'BP27_3', 'BP26', 'BP29', 'BP28', 'BP16',
               'BP17', 'BP15', 'BP13', 'BP14', 'BP4', 'BP6', 'BP7', 'BP5',
               'BP19_22', 'BP19', 'BP21', 'BP20', 'BP22', 'BP11', 'BP12', 'BP10',
               'BP8', 'BP9'],
    'SasExit': ['BP30', 'BP31', 'BP33', 'BP32', 'BP35', 'BP34', 'BP38', 'BP39',
                'BP40', 'BP41', 'BP42', 'BP43', 'BP44', 'BP37', 'BP36', 'BP45',
                'BP46', 'BP47', 'BP48'],
}
ROOM = {
    'BP4': 'H2_Chambre', 'BP5': 'H2_Storage', 'BP6': 'H2_Salon', 'BP7': 'H2_Kitchen',
    'BP8': 'H1_Storage', 'BP9': 'H1_Bathroom', 'BP10': 'H1_Chambre',
    'BP11': 'H1_Salon', 'BP12': 'H1_Salon', 'BP13': 'H3_Salon',
    'BP14': 'H3_SmallStorage', 'BP15': 'H3_Chambre', 'BP16': 'H3_BigStorage',
    'BP17': 'H3_BigStorage', 'BP19': 'H4_ConstrRoom2', 'BP19_22': 'H4_ConstrRoom2',
    'BP20': 'H4_ConstructionRoom2', 'BP21': 'H4_ConstrRoom1', 'BP22': 'H4_Storage',
    'BP23': 'H5_Salon', 'BP24': 'H5_Entrance', 'BP25': 'H5_Entrance',
    'BP26': 'H5_Chambre', 'BP27_3': 'H5_Storage', 'BP28': 'ConstHouse',
    'BP29': 'ConstHouse', 'BP30': 'Sc_Secreteria', 'BP31': 'Sc_Secreteria',
    'BP32': 'Sc_Kitchen', 'BP33': 'Sc_Kitchen', 'BP34': 'Sc_Toilet', 'BP35': 'Sc_Toilet',
    'BP36': 'Sc_Class04', 'BP37': 'Sc_Class04', 'BP38': 'Sc_Class03', 'BP39': 'Sc_Class03',
    'BP40': 'MusicStorage', 'BP41': 'Sc_Class02', 'BP42': 'Sc_Class02',
    'BP43': 'Sc_Class01', 'BP44': 'Sc_Class01', 'BP45': 'Sc_Library', 'BP46': 'Sc_Library',
    'BP47': 'Ext_WomenToilet', 'BP48': 'Ext_MaleToilet',
}
WANT = {
    ('School', 417417): frozenset(['BP5', 'BP6', 'BP19', 'BP24', 'BP26', 'BP29']),
    ('School', 737737): frozenset(['BP5', 'BP8', 'BP11', 'BP21', 'BP25', 'BP27_3']),
    ('SasExit', 417417): frozenset(['BP45', 'BP43', 'BP31', 'BP38', 'BP36', 'BP47']),
    ('SasExit', 737737): frozenset(['BP30', 'BP33', 'BP37', 'BP45', 'BP40', 'BP47']),
}
COORD = {
    'School': 'SRR_MT02_OrderedClueFrequency_School',
    'SasExit': 'SRR_MT02_OrderedClueFrequency_SasExit',
}
SALT_CRC = crc32_fname('Objective Actors')
D = 6


def draw(name, base, mode, salt, rev=False):
    pool = list(POOLS[name])
    if rev:
        pool.reverse()
    B = B_of(salt)
    out = []
    if mode == 'plain':                       # 逐个抽取 + RemoveAtSwap
        mem = list(pool)
        for i in range(D):
            k = rs((base + i) & M32, len(mem), B)
            out.append(mem[k])
            mem[k] = mem[-1]
            mem.pop()
    elif mode == 'rm':                        # 逐个抽取 + 保序 RemoveAt
        mem = list(pool)
        for i in range(D):
            k = rs((base + i) & M32, len(mem), B)
            out.append(mem[k])
            del mem[k]
    elif mode == 'rm1':                       # 同上，计数从 1 开始
        mem = list(pool)
        for i in range(1, D + 1):
            k = rs((base + i) & M32, len(mem), B)
            out.append(mem[k])
            del mem[k]
    elif mode == 'fy':                        # 经典 Fisher-Yates
        mem = list(pool)
        v = 0
        for i in range(len(mem), 1, -1):
            j = rs((base + v) & M32, i, B)
            v += 1
            mem[i - 1], mem[j] = mem[j], mem[i - 1]
        out = mem[:D]
    elif mode == 'popall':                    # 逐个取出（n = 剩余）
        mem = list(pool)
        cnt = 0
        for _ in range(D):
            k = rs((base + cnt) & M32, len(mem), B)
            cnt += 1
            out.append(mem[k])
            mem[k] = mem[-1]
            mem.pop()
    elif mode == 'room':                      # 按房间分组 + 洗牌取前 D 组（每组取 1）
        g = OrderedDict()
        for a in pool:
            g.setdefault(ROOM[a], []).append(a)
        rest = [list(v) for v in g.values()]
        cnt = 0
        for _ in range(D):
            k = rs((base + cnt) & M32, len(rest), B)
            cnt += 1
            grp = rest[k]
            j = rs((base + cnt) & M32, len(grp), B)
            cnt += 1
            out.append(grp[j])
            rest[k] = rest[-1]
            rest.pop()
    return out


def main():
    span = int(sys.argv[1]) if len(sys.argv) > 1 else 300000
    modes = sys.argv[2:] or ['plain', 'rm', 'rm1', 'fy', 'popall', 'room']
    bases = {
        '+salt': {k: (seed_of_object(v) + SALT_CRC) & M32 for k, v in COORD.items()},
        'plain': {k: seed_of_object(v) for k, v in COORD.items()},
    }
    for tag, bs in bases.items():
        for mode in modes:
            for rev in (False, True):
                hits = []
                for delta in range(span):
                    b = (bs['School'] + delta) & M32
                    if set(draw('School', b, mode, 417417, rev)) == WANT[('School', 417417)]:
                        hits.append(delta)
                if not hits:
                    print('%-6s %-7s rev=%-5s School@417 无候选' % (tag, mode, rev))
                    continue
                good = []
                for delta in hits:
                    b = (bs['School'] + delta) & M32
                    if set(draw('School', b, mode, 737737, rev)) != WANT[('School', 737737)]:
                        continue
                    b2 = (bs['SasExit'] + delta) & M32
                    if set(draw('SasExit', b2, mode, 417417, rev)) != WANT[('SasExit', 417417)]:
                        continue
                    if set(draw('SasExit', b2, mode, 737737, rev)) != WANT[('SasExit', 737737)]:
                        continue
                    good.append(delta)
                print('%-6s %-7s rev=%-5s School@417 候选 %d → 四重验证后: %s'
                      % (tag, mode, rev, len(hits), good if good else '空'))
                if good:
                    d0 = good[0]
                    b = (bs['School'] + d0) & M32
                    print('      ★ delta=%d  School@417=%s' % (
                        d0, draw('School', b, mode, 417417, rev)))
                    print('                 School@737=%s' % draw('School', b, mode, 737737, rev))
                    b2 = (bs['SasExit'] + d0) & M32
                    print('                 SasExit@417=%s' % draw('SasExit', b2, mode, 417417, rev))
                    print('                 SasExit@737=%s' % draw('SasExit', b2, mode, 737737, rev))


if __name__ == '__main__':
    main()
