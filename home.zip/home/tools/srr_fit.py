# -*- coding: utf-8 -*-
"""SRR_MT02 拟合探查器 v2：枚举「抽取算法 × 种子基偏移」看能否命中 seed=417417 实测。

mode:
  plain    不分组：逐个 RandSeeded(base+i, remaining) + RemoveAtSwap
  fy       Fisher-Yates：i 从 n 到 2，j = RandSeeded(base+i, i)，取前 D
  popall   n 个单元素组全洗牌（逐个 RandSeeded(base+i, n-i) 取出），取前 D
  room     按房间分组（+ 洗牌 + desired 分配）
"""
import sys
from collections import OrderedDict

M32 = 0xFFFFFFFF
M64 = 0xFFFFFFFFFFFFFFFF

_T = []
for _i in range(256):
    _c = _i
    for _ in range(8):
        _c = ((_c >> 1) ^ 0xEDB88320) if (_c & 1) else (_c >> 1)
    _T.append(_c & M32)


def crc32_fname(text):
    crc = M32
    for ch in text:
        u = ord(ch) & 0xFFFF
        crc = _T[(crc ^ (u & 0xFF)) & 0xFF] ^ (crc >> 8)
        crc = _T[(crc ^ (u >> 8)) & 0xFF] ^ (crc >> 8)
        crc = _T[crc & 0xFF] ^ (crc >> 8)
        crc = _T[crc & 0xFF] ^ (crc >> 8)
    return (~crc) & M32


def seed_of_object(name, outer_seed=None):
    if outer_seed is None:
        outer_seed = crc32_fname('PersistentLevel')
    value = (crc32_fname(name) + outer_seed) & M32
    return value if value < 0x80000000 else (0x100000000 - value) & M32


def mix_a(seed, salt):
    a = (0xBF58476D1CE4E5B9 * ((seed ^ (seed >> 30)) & M64)) & M64
    a ^= a >> 27
    b = (0xBF58476D1CE4E5B9 * (salt % 1000)) & M64
    b ^= b >> 27
    v = (((0x94D049BB133111EB * a) & M64) ^ ((0x94D049BB133111EB * b) & M64)) & M64
    t = (v ^ (v >> 31)) & M64
    w = (0xBF58476D1CE4E5B9 * (t ^ (t >> 30))) & M64
    u = (w ^ (w >> 27)) & M64
    r = (((321982955 * u) & M64) ^ (((0x94D049BB133111EB * u) & M64) >> 31)) & M64
    return r & M32


def mix_b(seed, salt):
    def m1(x):
        z = (0xBF58476D1CE4E5B9 * (x ^ (x >> 30))) & M64
        return z ^ (z >> 27)
    a = (0x94D049BB133111EB * m1(seed)) & M64
    b = (0x94D049BB133111EB * m1(salt % 1000)) & M64
    t = (a ^ b ^ ((a ^ b) >> 31)) & M64
    u = (0x94D049BB133111EB * m1(t)) & M64
    return (u ^ (u >> 31)) & M32


def rs(seed, n, level_seed, ver):
    if not n or not level_seed or not seed:
        return 0
    h = mix_a(seed & M32, level_seed) if ver == 'a' else mix_b(seed & M32, level_seed)
    return (h & 0xFFFF) % n


# --------------------------------------------------------------------------- 静态
POOLS = {
    'RichDistrict': ['BP', 'BP2', 'BP3', 'BP49'],
    'School': ['BP23', 'BP24', 'BP25', 'BP27_3', 'BP26', 'BP29', 'BP28', 'BP16',
               'BP17', 'BP15', 'BP13', 'BP14', 'BP4', 'BP6', 'BP7', 'BP5',
               'BP19_22', 'BP19', 'BP21', 'BP20', 'BP22', 'BP11', 'BP12', 'BP10',
               'BP8', 'BP9'],
    'SasExit': ['BP30', 'BP31', 'BP33', 'BP32', 'BP35', 'BP34', 'BP38', 'BP39',
                'BP40', 'BP41', 'BP42', 'BP43', 'BP44', 'BP37', 'BP36', 'BP45',
                'BP46', 'BP47', 'BP48'],
}
DESIRED = {'RichDistrict': 4, 'School': 6, 'SasExit': 6}
ROOM = {
    'BP': 'GarageVilla', 'BP2': 'GarageVilla', 'BP3': 'GarageVilla', 'BP49': 'GarageVilla',
    'BP4': 'H2_Chambre', 'BP5': 'H2_Storage', 'BP6': 'H2_Salon', 'BP7': 'H2_Kitchen',
    'BP8': 'H1_Storage', 'BP9': 'H1_Bathroom', 'BP10': 'H1_Chambre',
    'BP11': 'H1_Salon', 'BP12': 'H1_Salon', 'BP13': 'H3_Salon',
    'BP14': 'H3_SmallStorage', 'BP15': 'H3_Chambre', 'BP16': 'H3_BigStorage',
    'BP17': 'H3_BigStorage', 'BP19': 'H4_ConstrRoom2', 'BP19_22': 'H4_ConstrRoom2',
    'BP20': 'H4_ConstructionRoom2', 'BP21': 'H4_ConstrRoom1', 'BP22': 'H4_Storage',
    'BP23': 'H5_Salon', 'BP24': 'H5_Entrance', 'BP25': 'H5_Entrance',
    'BP26': 'H5_Chambre', 'BP27_3': 'H5_Storage', 'BP28': 'ConstHouse',
    'BP29': 'ConstHouse', 'BP30': 'Sc_Secreteria', 'BP31': 'Sc_Secreteria',
    'BP32': 'Sc_Kitchen', 'BP33': 'Sc_Kitchen', 'BP34': 'Sc_Toilet', 'BP35': 'Sc_Toilet',
    'BP36': 'Sc_Class04', 'BP37': 'Sc_Class04', 'BP38': 'Sc_Class03', 'BP39': 'Sc_Class03',
    'BP40': 'MusicStorage', 'BP41': 'Sc_Class02', 'BP42': 'Sc_Class02',
    'BP43': 'Sc_Class01', 'BP44': 'Sc_Class01', 'BP45': 'Sc_Library', 'BP46': 'Sc_Library',
    'BP47': 'Ext_WomenToilet', 'BP48': 'Ext_MaleToilet',
}
EXPECT = {
    'RichDistrict': ['BP', 'BP2', 'BP3', 'BP49'],
    'School': ['BP5', 'BP6', 'BP19', 'BP24', 'BP26', 'BP29'],
    'SasExit': ['BP45', 'BP43', 'BP31', 'BP38', 'BP36', 'BP47'],
}
COORD = {
    'RichDistrict': 'SRR_MT02_OrderedClueFrequency_RichDistrict',
    'School': 'SRR_MT02_OrderedClueFrequency_School',
    'SasExit': 'SRR_MT02_OrderedClueFrequency_SasExit',
}
LEVEL_SEED = 417417
SALT_CRC = crc32_fname('Objective Actors')

# 坐标（release/coop/SRR_MT02/srr_mt02_tuners.json）
POS = {
    'BP': (-1293.1, -1993.9, 400.0), 'BP2': (-1769.7, -1179.0, 400.0),
    'BP3': (-2057.0, -1669.0, 400.0), 'BP49': (-2059.2, -1993.5, 400.0),
    'BP4': (-362.6, -1680.7, 400.0), 'BP5': (-144.6, -1159.7, 400.0),
    'BP6': (-59.0, -2224.0, 400.0), 'BP7': (758.4, -1384.5, 400.0),
    'BP8': (1890.8, -1196.4, 400.0), 'BP9': (2540.6, -988.8, 400.0),
    'BP10': (2455.6, -1897.6, 400.0), 'BP11': (3352.0, -2207.3, 400.0),
    'BP12': (3360.1, -1360.2, 400.0), 'BP13': (-791.9, -4621.1, 400.0),
    'BP14': (-15.1, -3665.7, 400.0), 'BP15': (652.7, -4197.7, 400.0),
    'BP16': (190.3, -5031.6, 400.0), 'BP17': (652.4, -4547.4, 400.0),
    'BP19': (1497.1, -3585.8, 400.0), 'BP19_22': (1374.9, -4180.6, 400.0),
    'BP20': (1919.2, -3971.5, 400.0), 'BP21': (2132.7, -4109.3, 400.0),
    'BP22': (2553.0, -4911.1, 400.0), 'BP23': (136.2, -6220.2, 400.5),
    'BP24': (140.1, -6422.8, 400.5), 'BP25': (726.2, -6188.9, 400.5),
    'BP26': (1347.4, -6689.6, 400.5), 'BP27_3': (1277.0, -7069.8, 400.0),
    'BP28': (2447.1, -6267.4, 399.0), 'BP29': (3024.9, -6267.7, 399.0),
    'BP30': (5031.2, -2740.8, 400.0), 'BP31': (5911.2, -3158.7, 400.0),
    'BP32': (4947.5, -5841.4, 400.0), 'BP33': (6552.9, -5840.8, 400.0),
    'BP34': (6641.0, -4824.6, 400.0), 'BP35': (7006.3, -4142.2, 400.0),
    'BP36': (8255.5, -4800.6, 399.9), 'BP37': (7908.3, -4333.5, 399.9),
    'BP38': (7510.2, -6094.9, 400.0), 'BP39': (7730.7, -5443.3, 400.0),
    'BP40': (8785.7, -6005.5, 400.0), 'BP41': (9562.4, -6158.6, 400.0),
    'BP42': (9286.7, -5555.4, 400.0), 'BP43': (9215.7, -4167.5, 399.9),
    'BP44': (8405.1, -4170.7, 399.9), 'BP45': (11353.4, -5431.5, 400.0),
    'BP46': (11233.3, -4202.8, 400.0), 'BP47': (9970.1, -2738.4, 400.0),
    'BP48': (9978.3, -2328.1, 400.0),
}


def d2(a, b):
    pa, pb = POS[a], POS[b]
    return (pa[0] - pb[0]) ** 2 + (pa[1] - pb[1]) ** 2 + (pa[2] - pb[2]) ** 2


def make_groups(pool, keyfn):
    g = OrderedDict()
    for a in pool:
        g.setdefault(keyfn(a), []).append(a)
    return [{'key': k, 'members': list(v), 'desired': 0} for k, v in g.items()]


def split_desired(groups, d, total):
    n = len(groups)
    remaining = d
    k = 0
    while k < n and (d - k) >= 2:
        groups[k]['desired'] += 1
        remaining -= 1
        k += 1
    if remaining > 0 and n > 0:
        for j in range(n):
            share = (len(groups[j]['members']) / float(total)) * d
            if share > 1.0:
                add = int(int((share - 1.0) + (share - 1.0) + 0.5) >> 1)
                if remaining < add:
                    add = remaining
                groups[j]['desired'] += add
                remaining -= add
                if remaining <= 0:
                    break
        if remaining > 0:
            for j in range(n):
                if len(groups[j]['members']) >= remaining + groups[j]['desired']:
                    groups[j]['desired'] += remaining
                    break
    return groups


REV = False


def draw(name, base, mode, ver):
    pool = list(POOLS[name])
    if REV:
        pool.reverse()
    d = DESIRED[name]
    ls = LEVEL_SEED
    out = []
    if mode == 'plain':
        mem = list(pool)
        for i in range(d):
            k = rs((base + i) & M32, len(mem), ls, ver)
            out.append(mem[k])
            mem[k] = mem[-1]
            mem.pop()
    elif mode == 'fy':
        mem = list(pool)
        v = 0
        for i in range(len(mem), 1, -1):
            j = rs((base + v) & M32, i, ls, ver)
            v += 1
            mem[i - 1], mem[j] = mem[j], mem[i - 1]
        out = mem[:d]
    elif mode == 'popall':
        rest = list(pool)
        cnt = 0
        while rest:
            k = rs((base + cnt) & M32, len(rest), ls, ver)
            cnt += 1
            out.append(rest[k])
            rest[k] = rest[-1]
            rest.pop()
        out = out[:d]
    elif mode.startswith('room'):
        # room / room6 / room6z：分组 + 洗牌，desired 分配规则不同
        #   room   : 前 D-1 组各 1 + 余量补偿
        #   room6  : 前 min(n,D) 组各 1
        #   room6z : 前 min(n,D) 组各 1，且主抽取计数不接在洗牌之后
        groups = make_groups(pool, lambda a: ROOM[a])
        rest = list(groups)
        order = []
        cnt = 0
        while rest:
            k = rs((base + cnt) & M32, len(rest), ls, ver)
            cnt += 1
            order.append(rest[k])
            rest[k] = rest[-1]
            rest.pop()
        if mode == 'room':
            total = sum(len(g['members']) for g in order)
            split_desired(order, d, total)
        else:
            for g in order[:min(len(order), d)]:
                g['desired'] = 1
        start = 0 if mode == 'room6z' else cnt
        c2 = start
        for g in order:
            mem = list(g['members'])
            for _ in range(g['desired']):
                k = rs((base + c2) & M32, len(mem), ls, ver)
                c2 += 1
                out.append(mem[k])
                mem[k] = mem[-1]
                mem.pop()
    elif mode.startswith('rm'):
        # rm / rmrev / rmT：sub_1401A0F00 补充抽取 —— min + (uint16)hash % (max-min+1)，
        # 取出后 **保序 RemoveAt**（sub_141D24D40），不是 RemoveAtSwap。
        #   rm    : 正序池，计数从 0
        #   rmrev : 倒序池，计数从 0
        #   rm1   : 正序池，计数从 1（主循环先吃掉一个）
        #   rmrev1: 倒序池，计数从 1
        mem = list(pool)
        if 'rev' in mode:
            mem.reverse()
        tail = mode[2:].replace('rev', '')
        start = int(tail) if tail else 0
        for i in range(start, start + d):
            if not mem:
                break
            k = rs((base + i) & M32, len(mem), ls, ver)
            out.append(mem[k])
            del mem[k]                       # 保序 RemoveAt
    elif mode.startswith('dist'):
        # dist / distswap：抽一个 → 把池内所有距离 < 1000 的剔掉，再抽下一个
        #   dist     RemoveAt（保序）
        #   distswap RemoveAtSwap
        swap = mode.startswith('distswap')
        tail = mode[4:] if not swap else mode[8:]
        thr = float(tail) if tail else 1000.0
        mem = list(pool)
        t2 = thr * thr
        if swap:
            for i in range(d):
                if not mem:
                    break
                k = rs((base + i) & M32, len(mem), ls, ver)
                pick = mem[k]
                out.append(pick)
                mem[k] = mem[-1]
                mem.pop()
                mem = [x for x in mem if d2(x, pick) >= t2]
        else:
            for i in range(d):
                if not mem:
                    break
                k = rs((base + i) & M32, len(mem), ls, ver)
                pick = mem[k]
                out.append(pick)
                del mem[k]
                mem = [x for x in mem if d2(x, pick) >= t2]
    return out


def main():
    global REV
    span = int(sys.argv[1]) if len(sys.argv) > 1 else 3000
    REV = len(sys.argv) > 2 and sys.argv[2] == 'rev'
    base0 = {k: seed_of_object(v) for k, v in COORD.items()}
    bases = {'+salt': {k: (base0[k] + SALT_CRC) & M32 for k in base0},
             'plain': base0}
    for tag, bs in bases.items():
        for mode in ('rm', 'rm1', 'rm2', 'rm3', 'rm4',
                     'rmrev', 'rmrev1', 'rmrev2', 'rmrev3', 'rmrev4'):
            for ver in ('a',):
                line = []
                for name in ('School', 'SasExit'):
                    hit = None
                    for delta in range(0, span):
                        got = draw(name, (bs[name] + delta) & M32, mode, ver)
                        if sorted(got) == sorted(EXPECT[name]):
                            hit = delta
                            break
                    line.append('%s=%s' % (name, ('HIT@%d' % hit) if hit is not None else 'miss'))
                print('%-6s %-7s ver=%s  %s' % (tag, mode, ver, '  '.join(line)))


if __name__ == '__main__':
    main()
