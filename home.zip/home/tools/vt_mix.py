# -*- coding: utf-8 -*-
"""在一段 vtable 里，找出「目标函数内联了 seeded RNG（mix 常数）」的槽。

用法：
    python vt_mix.py 0x145A05440 0x145A063F8
    python vt_mix.py 0x145A05440 0x145A063F8 --calls 0x1402D29E0
"""
import struct
import sys
import os

_HERE = os.path.dirname(os.path.abspath(__file__))
sys.path.insert(0, _HERE)
import scan_disp as sd

MIX = struct.pack('<Q', 0xBF58476D1CE4E5B9)
MIX2 = struct.pack('<Q', 0x94D049BB133111EB)


def mixer(funcs_set):
    name, sva, vsize, rawptr, rawsize = sd.sec('.text')
    for pat, tag in ((MIX, 'mix_a'), (MIX2, 'mix_b')):
        i = sd.d.find(pat, rawptr, rawptr + vsize)
        while i >= 0:
            va = sd.image_base + sva + (i - rawptr)
            c = sd.containing(va)
            if c:
                funcs_set.add((c[0], tag))
            i = sd.d.find(pat, i + 1, rawptr + vsize)
    return funcs_set


def callers_of(target):
    name, sva, vsize, rawptr, rawsize = sd.sec('.text')
    base = sd.image_base + sva
    out = set()
    i = sd.d.find(b'\xe8', rawptr, rawptr + vsize)
    while i >= 0:
        rel = struct.unpack_from('<i', sd.d, i + 1)[0]
        va = base + (i - rawptr)
        if va + 5 + rel == target:
            c = sd.containing(va)
            if c:
                out.add(c[0])
        i = sd.d.find(b'\xe8', i + 1, rawptr + vsize)
    return out


def main():
    lo = int(sys.argv[1], 16)
    hi = int(sys.argv[2], 16)
    interesting = mixer(set())
    funcs = set(f for f, _ in interesting)
    if '--calls' in sys.argv:
        tgt = int(sys.argv[sys.argv.index('--calls') + 1], 16)
        funcs |= callers_of(tgt)
        print('候选函数（含 mix / 调 RandSeeded）：%d 个' % len(funcs))
    tags = {}
    for f, tag in interesting:
        tags.setdefault(f, set()).add(tag)
    print('=== 表区 %X..%X 中命中候选的槽' % (lo, hi))
    hit = 0
    for a in range(lo, hi, 8):
        q = struct.unpack_from('<Q', sd.d, sd.va2off(a))[0]
        if q in funcs:
            hit += 1
            print('  slot %X (idx %3d) -> %X   %s'
                  % (a, (a - lo) // 8, q, ' '.join(sorted(tags.get(q, [])))))
    if not hit:
        print('  无')


if __name__ == '__main__':
    main()
