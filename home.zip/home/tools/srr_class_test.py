# -*- coding: utf-8 -*-
"""验证「分组种子 = f(名字 CRC, 盐 CRC, 协调器种子)」。

依据 §21.5：`[[rcx+0x10]+0x18]` 在 UE4 布局里是 `Object->ClassPrivate->NamePrivate`，
随后 FName::ToString → crc32 → `add eax, esi`（esi 可能是 ~crc(盐)，也可能是别的）。

这里穷举三种组合 × 一组候选名字（含**蓝图类名**）。

    python srr_class_test.py
"""
import os
import sys

sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.abspath(__file__))))
import srr_mt02 as m

CASES = [
    (417417, 'School', {'BP24', 'BP26', 'BP5', 'BP6', 'BP19', 'BP29'}),
    (737737, 'School', {'BP21', 'BP25', 'BP11', 'BP5', 'BP8', 'BP27_3'}),
    (417417, 'SasExit', {'BP43', 'BP45', 'BP36', 'BP31', 'BP38', 'BP47'}),
    (737737, 'SasExit', {'BP40', 'BP45', 'BP30', 'BP33', 'BP37', 'BP47'}),
]

NAMES = [
    'OrderedClueFrequency_Coord_BP_C',
    'OrderedClueFrequency_Coord_BP',
    'Default__OrderedClueFrequency_Coord_BP_C',
    'FrequencyMatchSuburbs_BP_C',
    'FrequencyMatchBlacklit_BP_C',
    'Objective Actors',
]


def picks(key, level_seed, sb, count):
    pool = list(m.COORDS[key]['pool'])
    out = []
    for k in range(count):
        h = m.rand_seeded((sb + k) & m.M32, len(pool), level_seed)
        out.append(pool[h])
        pool.pop(h)
    return out


def main():
    salt = m.crc32_fname(m.SALT_NAME)
    for nm in NAMES:
        c = m.crc32_fname(nm)
        variants = [
            ('name+salt', c + salt),
            ('seed+name+salt', None),
            ('seed+name', None),
        ]
        for label, const in variants:
            tot = 0
            det = []
            for seed, key, want in CASES:
                gs = m.seed_of_object(m.COORDS[key]['actor'])
                if label == 'name+salt':
                    sb = const
                elif label == 'seed+name+salt':
                    sb = (gs + c + salt) & m.M32
                else:
                    sb = (gs + c) & m.M32
                got = picks(key, seed, sb & m.M32, 6)
                ov = len(set(got) & want)
                tot += ov
                det.append('%d' % ov)
            if tot >= 6:
                print('%-42s %-16s avg %.2f/6  %s'
                      % (nm, label, tot / len(CASES), ' '.join(det)))


if __name__ == '__main__':
    main()
