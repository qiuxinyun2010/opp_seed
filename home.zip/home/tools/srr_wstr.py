# -*- coding: utf-8 -*-
"""在 exe 里按 UTF-16LE 搜关键词，并还原完整的宽字符串（用来捞盐名）。

用法：python tools\srr_wstr.py Actors
"""
import re
import sys

EXE = r"d:\workspace\outlast\TOTClient-Win64-Shipping.exe"


def wstr_at(data, pos):
    """以 pos 为中心，向前后扩展到完整 UTF-16LE 串。"""
    start = pos
    while start >= 2 and data[start - 1] == 0 and 32 <= data[start - 2] < 127:
        start -= 2
    end = pos
    n = len(data)
    while end + 4 <= n and data[end + 3] == 0 and 32 <= data[end + 2] < 127:
        end += 2
    raw = data[start:end + 2]
    try:
        s = raw.decode('utf-16-le')
    except Exception:
        return None
    return s.rstrip('\x00')


def main():
    kw = sys.argv[1] if len(sys.argv) > 1 else 'Actors'
    pat = kw.encode('utf-16-le')
    with open(EXE, 'rb') as f:
        data = f.read()
    seen = set()
    for m in re.finditer(re.escape(pat), data):
        s = wstr_at(data, m.start())
        if not s or s in seen:
            continue
        seen.add(s)
        print('0x%X  %s' % (m.start(), s))


if __name__ == '__main__':
    main()
