# -*- coding: utf-8 -*-
"""只检验「图案侧」模型：不涉及 L / 排序 / 尸体。

模型：slot t 从 0..9；图案 = pool[ RandSeeded(B+OK+t, |pool|, seed%1000) ] 保序删除。
      slot 分组 A(3) C(4) B(3)。
观测：每个 run 在每个扇区里出现的图案集合。
"""
import sys, os, itertools
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
from psb_sort import rand_seeded, crc32_fname, M32

POOL = ["Bunny", "Club", "Diamond", "Fire", "Heart",
        "Spade", "Crown", "Eye", "Moon", "Star"]

# 观测：run -> {扇区: {图案}}
OBS = {
    378378: {'A': {'Moon', 'Heart'},                 # 第 3 个未知
             'B': {'Fire', 'Diamond', 'Bunny'},      # 全部已知
             'C': {'Spade', 'Eye', 'Club'}},         # 第 4 个未知
    565565: {'A': {'Heart'}, 'B': {'Club'}, 'C': {'Eye'}},
}
# A 的第 3 个（378）：王冠
OBS[378378]['A'].add('Crown')

LAYOUTS = [
    ('A3C4B3', [('A', 3), ('C', 4), ('B', 3)]),
    ('A3B3C4', [('A', 3), ('B', 3), ('C', 4)]),
    ('C4A3B3', [('C', 4), ('A', 3), ('B', 3)]),
    ('C4B3A3', [('C', 4), ('B', 3), ('A', 3)]),
    ('B3A3C4', [('B', 3), ('A', 3), ('C', 4)]),
    ('B3C4A3', [('B', 3), ('C', 4), ('A', 3)]),
]


def run_patterns(B, OK, seed, layout, salt_mode='mod1000'):
    salt = seed % 1000 if salt_mode == 'mod1000' else seed
    pool = list(POOL)
    out = {}
    t = 0
    for sec, cnt in layout:
        for j in range(cnt):
            ki = rand_seeded((B + OK + t) & M32, len(pool), salt)
            out[t] = (sec, pool.pop(ki), j)
            t += 1
    return out


def score(B, OK, seed, layout, salt_mode):
    got = run_patterns(B, OK, seed, layout, salt_mode)
    bysec = {}
    for t, (sec, pat, j) in got.items():
        bysec.setdefault(sec, set()).add(pat)
    ok = bad = 0
    for sec, pats in OBS[seed].items():
        for p in pats:
            if p in bysec.get(sec, ()):
                ok += 1
            else:
                bad += 1
    return ok, bad, got


def main():
    try:
        sys.stdout.reconfigure(encoding='utf-8')
    except Exception:
        pass
    Bs = [0xCD055621]
    # B 也可能等于 crc(协调器)+k
    for k in range(0, 64):
        Bs.append((crc32_fname('PSB_MT01_B01_CorpseSearch_3') + k) & M32)
        Bs.append((0xCD055621 - k) & M32)
    Bs = list(dict.fromkeys(Bs))
    OKs = [223551, 243551, 924519, 264069, 951320, 850321,
           90601, 90681, 0]
    best = []
    for B in Bs:
        for OK in OKs:
            for name, layout in LAYOUTS:
                for sm in ('mod1000', 'full'):
                    tot_ok = tot_bad = 0
                    for seed in OBS:
                        o, b, _ = score(B, OK, seed, layout, sm)
                        tot_ok += o
                        tot_bad += b
                    best.append((tot_ok, -tot_bad, B, OK, name, sm))
    best.sort(reverse=True)
    print('top 12:')
    for ok, nb, B, OK, name, sm in best[:12]:
        print('  ok=%2d bad=%2d  B=0x%08X OK=%-7d layout=%-6s salt=%s'
              % (ok, -nb, B, OK, name, sm))
    ok, nb, B, OK, name, sm = best[0]
    print('\nbest detail  B=0x%08X OK=%d layout=%s salt=%s' % (B, OK, name, sm))
    lay = dict(LAYOUTS)[name]
    for seed in sorted(OBS):
        got = run_patterns(B, OK, seed, lay, sm)
        print(' run %d' % seed)
        for t in sorted(got):
            sec, pat, j = got[t]
            mark = 'OBS+ ' if pat in OBS[seed][sec] else '     '
            print('   t=%d sec=%s j=%d %-8s %s' % (t, sec, j, pat, mark))


if __name__ == '__main__':
    main()
