# -*- coding: utf-8 -*-
"""收集 .text 里所有 `lea reg,[rip+disp32]` 指向的目标地址，用来找 vtable 起点。

类 vtable 一定会被构造器/注册函数以 lea 引用；而 vtable 槽只能通过 xrefs 拿到单个槽，
用"被 lea 引用的地址"与"槽地址 - 8*k"取交集，就能反推表头。

    python lea_targets.py 0x145A061C8 0x145A04000 0x145A06400
"""
import struct
import sys
import os

_HERE = os.path.dirname(os.path.abspath(__file__))
sys.path.insert(0, _HERE)
import scan_disp as sd

# 常见 REX + 8D 组合（lea r64, [rip+disp32]）
PRE = [b'\x48\x8d\x05', b'\x48\x8d\x0d', b'\x48\x8d\x15', b'\x48\x8d\x1d',
       b'\x48\x8d\x25', b'\x48\x8d\x2d', b'\x48\x8d\x35', b'\x48\x8d\x3d',
       b'\x4c\x8d\x05', b'\x4c\x8d\x0d', b'\x4c\x8d\x15', b'\x4c\x8d\x1d',
       b'\x4c\x8d\x25', b'\x4c\x8d\x2d', b'\x4c\x8d\x35', b'\x4c\x8d\x3d']


def main():
    slot = int(sys.argv[1], 16)
    lo = int(sys.argv[2], 16) if len(sys.argv) > 2 else slot - 0x2000
    hi = int(sys.argv[3], 16) if len(sys.argv) > 3 else slot + 0x800
    name, sva, vsize, rawptr, rawsize = sd.sec('.text')
    base = sd.image_base + sva
    data = sd.d
    start, end = rawptr, rawptr + vsize
    targets = set()
    for pre in PRE:
        i = data.find(pre, start, end)
        while i >= 0:
            rel = struct.unpack_from('<i', data, i + 3)[0]
            va = base + (i - start)
            t = va + 7 + rel
            if lo <= t <= hi:
                targets.add(t)
            i = data.find(pre, i + 1, end)
    print('lea 指向 [%X, %X] 的不同目标：%d 个' % (lo, hi, len(targets)))
    hits = []
    for t in sorted(targets):
        k = (slot - t) // 8
        if slot - t >= 0 and (slot - t) % 8 == 0 and k <= 700:
            hits.append((t, k))
    print('=== 与槽 %X 对齐的候选表基址（k = 槽序号）' % slot)
    for t, k in hits:
        print('  base=0x%X  槽序号=%d  (+0x898 → 0x%X)' % (t, k, sd.qword_at(t + 0x898)
                                                          if hasattr(sd, 'qword_at') else 0))


if __name__ == '__main__':
    main()
