// SRR_MT02 全扫器 2：分层抽取（先抽房间 → 房间内抽调频器）。
//
// base = GetSeed(协调器) + delta，delta 扫 2^32（等价于 base 取遍所有 32 位值）。
// 约束：School 与 SasExit 的 6 台集合在 seed 417417 / 737737 下都要对上
//   误报期望 ≈ 2^32 / (C(26,6)^2 * C(19,6)^2) ≈ 1e-10
//
// 用法: scan_srr2 <model>  0 = 先抽完 6 个房间再逐间抽  1 = 房间/调频器交替抽
#include <stdio.h>
#include <stdint.h>
#include <stdlib.h>
#include <omp.h>

static uint32_t TBL[256];
static void mk_table(void) {
    for (uint32_t i = 0; i < 256; i++) {
        uint32_t c = i;
        for (int k = 0; k < 8; k++) c = (c & 1) ? ((c >> 1) ^ 0xEDB88320u) : (c >> 1);
        TBL[i] = c;
    }
}
static inline uint64_t fmix_a(uint32_t s) {
    uint64_t x = 0xBF58476D1CE4E5B9ull * (uint64_t)(s ^ (s >> 30));
    return x ^ (x >> 27);
}
static inline uint64_t salt_b(uint32_t salt) {
    uint64_t x = 0xBF58476D1CE4E5B9ull * (uint64_t)(salt % 1000u);
    return x ^ (x >> 27);
}
static inline uint32_t rand_seeded(uint32_t seed, uint32_t n, uint64_t b) {
    uint64_t a, v5, t, v6, u, v7;
    if (!n || !seed) return 0;
    a = fmix_a(seed);
    v5 = (0x94D049BB133111EBull * a) ^ (0x94D049BB133111EBull * b);
    t = v5 ^ (v5 >> 31);
    v6 = 0xBF58476D1CE4E5B9ull * (t ^ (t >> 30));
    u = v6 ^ (v6 >> 27);
    v7 = (uint64_t)((uint32_t)(321982955u * (uint32_t)u)) ^ ((0x94D049BB133111EBull * u) >> 31);
    return (uint32_t)((uint16_t)v7 % (uint16_t)n);
}

/* School：21 个房间（按候选池首次出现顺序），每间 1~2 台 */
#define S_NR 21
static const int S_RSIZE[S_NR] = {1,2,1,1,2,2,1,1,1,1,1,1,1,2,1,1,1,2,1,1,1};
static const int S_MEM[S_NR][2] = {
    {0,-1},{1,2},{3,-1},{4,-1},{5,6},{7,8},{9,-1},{10,-1},{11,-1},{12,-1},
    {13,-1},{14,-1},{15,-1},{16,17},{18,-1},{19,-1},{20,-1},{21,22},{23,-1},{24,-1},{25,-1}};
static const int WANT_S417[6] = {15,13,17,1,4,5};
static const int WANT_S737[6] = {15,24,21,18,2,3};

/* SasExit：11 个房间 */
#define E_NR 11
static const int E_RSIZE[E_NR] = {2,2,2,2,1,2,2,2,2,1,1};
static const int E_MEM[E_NR][2] = {
    {0,1},{2,3},{4,5},{6,7},{8,-1},{9,10},{11,12},{13,14},{15,16},{17,-1},{18,-1}};
static const int WANT_E417[6] = {15,11,1,6,14,17};
static const int WANT_E737[6] = {0,2,13,15,8,17};

static const uint32_t BASE_S = 0x201DAC20u;
static const uint32_t BASE_E = 0x69516727u;

static int MODEL = 0;

static int draw_mask(uint32_t base, int nr, const int *rsize, const int (*mem)[2], uint64_t B) {
    int rooms[32];
    int i, m = nr, mask = 0, cnt = 0;
    for (i = 0; i < nr; i++) rooms[i] = i;
    if (MODEL == 0) {
        int picked[8];
        for (i = 0; i < 6; i++) {
            int k = (int)rand_seeded((uint32_t)(base + i), (uint32_t)m, B);
            picked[i] = rooms[k];
            rooms[k] = rooms[m - 1];
            m--;
        }
        for (i = 0; i < 6; i++) {
            int r = picked[i];
            int k = (int)rand_seeded((uint32_t)(base + 6 + i), (uint32_t)rsize[r], B);
            mask |= 1 << mem[r][k];
        }
        return mask;
    }
    for (i = 0; i < 6; i++) {
        int k = (int)rand_seeded((uint32_t)(base + cnt), (uint32_t)m, B);
        cnt++;
        int r = rooms[k];
        rooms[k] = rooms[m - 1];
        m--;
        int k2 = (int)rand_seeded((uint32_t)(base + cnt), (uint32_t)rsize[r], B);
        cnt++;
        mask |= 1 << mem[r][k2];
    }
    return mask;
}

static int wmask(const int *w) {
    int i, m = 0;
    for (i = 0; i < 6; i++) m |= 1 << w[i];
    return m;
}

int main(int argc, char **argv) {
    mk_table();
    if (argc > 1) MODEL = atoi(argv[1]);
    uint64_t B417 = salt_b(417), B737 = salt_b(737);
    int mS417 = wmask(WANT_S417), mS737 = wmask(WANT_S737);
    int mE417 = wmask(WANT_E417), mE737 = wmask(WANT_E737);
    long long total = 4294967296LL, hits = 0, d;
    fprintf(stderr, "model=%d  scanning 2^32 ...\n", MODEL);
#pragma omp parallel for schedule(dynamic, 1048576) reduction(+:hits)
    for (d = 0; d < total; d++) {
        uint32_t bs = BASE_S + (uint32_t)d;
        if (draw_mask(bs, S_NR, S_RSIZE, S_MEM, B417) != mS417) continue;
        if (draw_mask(bs, S_NR, S_RSIZE, S_MEM, B737) != mS737) continue;
        uint32_t be = BASE_E + (uint32_t)d;
        if (draw_mask(be, E_NR, E_RSIZE, E_MEM, B417) != mE417) continue;
        if (draw_mask(be, E_NR, E_RSIZE, E_MEM, B737) != mE737) continue;
        hits++;
        printf("HIT delta=%lld (0x%llX)\n", d, (unsigned long long)d);
        fflush(stdout);
    }
    fprintf(stderr, "done, hits=%lld\n", hits);
    return 0;
}
