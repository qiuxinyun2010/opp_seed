# -*- coding: utf-8 -*-
"""完整模型（§18 六步）实现 + 对拍。

模式 A：按房间分组（每个房间一个组），组间洗牌用计数器 c（初值 = 协调器 GetSeed），
        然后 DesiredCount 平均分配，组内用 (base + 已选数) 抽取。
模式 B：按 objective 类型分组（本关所有调频器同类型 → 单组）。

    python srr_model.py A          # 按房间分组
    python srr_model.py B          # 单组
"""
import os
import sys
from collections import OrderedDict

sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.abspath(__file__))))
import srr_mt02 as m

CASES = [
    (417417, 'School', {'BP24', 'BP26', 'BP5', 'BP6', 'BP19', 'BP29'}),
    (737737, 'School', {'BP21', 'BP25', 'BP11', 'BP5', 'BP8', 'BP27_3'}),
    (417417, 'SasExit', {'BP43', 'BP45', 'BP36', 'BP31', 'BP38', 'BP47'}),
    (737737, 'SasExit', {'BP40', 'BP45', 'BP30', 'BP33', 'BP37', 'BP47'}),
]


REV = False
CLS_NAME = 'OrderedClueFrequency_Coord_BP_C'


def groups_of(key, mode):
    pool = list(m.COORDS[key]['pool'])
    if REV:
        pool.reverse()
    if mode == 'B':
        return [pool]
    g = OrderedDict()
    for a in pool:
        g.setdefault(m.TUNERS[a][0], []).append(a)
    return [list(v) for v in g.values()]


def run(key, seed, mode='A', shuffle_start='coord', oto='same', seedmode='base'):
    coord = m.seed_of_object(m.COORDS[key]['actor'])
    base = (m.crc32_fname(m.SALT_NAME) + coord) & m.M32
    G = groups_of(key, mode)
    ng = len(G)

    # ① 组间洗牌：计数器初值 = a5 指向的 [rsp+0CCh] = base（§17.5 已证）
    if shuffle_start == 'base':
        c = base
    elif shuffle_start == 'coord':
        c = coord
    else:
        c = 0
    order = []
    for _ in range(ng):
        j = m.rand_seeded(c & m.M32, len(G), seed)
        order.append(G.pop(j))
        c = (c + 1) & m.M32

    # ② DesiredCount 分配：轮转 +1，再按比例补
    want = m.COORDS[key]['desired']
    desired = [0] * ng
    left = want
    i = 0
    while left > 0 and i < ng:
        desired[i] += 1
        left -= 1
        i += 1
    total = sum(len(g) for g in order)
    for gi in range(ng):
        if left <= 0:
            break
        share = (len(order[gi]) / total) * want
        if share > 1.0:
            add = min(left, int(share - 1.0 + 0.5))
            desired[gi] += add
            left -= add

    # ③ 组内抽取；O 与洗牌共用同一个计数器 [rsp+0CCh]，洗牌每组 +1
    o_base = (base + (ng if oto == 'after' else 0)) & m.M32
    picked = []
    salt_crc = m.crc32_fname(m.SALT_NAME)
    for gi, g in enumerate(order):
        for _ in range(desired[gi]):
            if seedmode == 'name':
                room = m.TUNERS[g[0]][0]
                sb = (m.crc32_fname(room) + salt_crc) & m.M32
            elif seedmode == 'cls':
                sb = (m.crc32_fname(CLS_NAME) + salt_crc) & m.M32
            else:
                sb = o_base
            pos = m.rand_seeded((sb + len(picked)) & m.M32, len(g), seed)
            picked.append(g.pop(pos))
    return picked


def main():
    mode = sys.argv[1] if len(sys.argv) > 1 else 'A'
    start = sys.argv[2] if len(sys.argv) > 2 else 'coord'
    oto = sys.argv[3] if len(sys.argv) > 3 else 'same'
    seedmode = sys.argv[4] if len(sys.argv) > 4 and sys.argv[4] in ('base', 'name') else 'base'
    global REV
    REV = len(sys.argv) > 4 and sys.argv[4] == 'rev'
    print('模式 %s，洗牌初值=%s，抽取起点=%s，池序=%s'
          % (mode, start, oto, '反序' if REV else '正序'))
    ok = 0
    best = 0
    for seed, key, want in CASES:
        got = run(key, seed, mode, start, oto, seedmode)
        hit = set(got) == want
        ov = len(set(got) & want)
        best += ov
        ok += hit
        print('  seed=%-7d %-9s got=%-40s 重合%d/6 %s'
              % (seed, key, ','.join(got), ov, 'OK' if hit else ''))
    print('集合命中 %d/%d，平均重合 %.2f/6' % (ok, len(CASES), best / len(CASES)))


if __name__ == '__main__':
    main()
