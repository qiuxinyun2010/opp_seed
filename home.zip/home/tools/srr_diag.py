# -*- coding: utf-8 -*-
"""诊断：若「全部选择都在 Phase D（补足循环）」成立，先看第一个抽取值。

Phase D 用的就是 rand_seeded(base + 已选数, 池剩余, level_seed)，
它对「池的大小」极敏感。实测两个 seed 的第一台不同：
    School   417417 -> BP24      737737 -> BP21
    SasExit  417417 -> BP43      737737 -> BP40
若两个 N 下算出的下标总相同（或相同太多），则该形态直接被否。
"""
import os
import sys

_HERE = os.path.dirname(os.path.abspath(__file__))
_HOME = os.path.dirname(_HERE)
if _HOME not in sys.path:
    sys.path.insert(0, _HOME)

import srr_mt02 as m  # noqa: E402

WANT1 = {'School': {417417: 'BP24', 737737: 'BP21'},
         'SasExit': {417417: 'BP43', 737737: 'BP40'}}


def main():
    try:
        sys.stdout.reconfigure(encoding='utf-8')
    except Exception:
        pass
    for ck in ('School', 'SasExit'):
        base = m.base_of(ck)
        n_max = len(m.COORDS[ck]['pool'])
        print('=== %s  base=0x%08X  池原始大小=%d' % (ck, base, n_max))
        print('   N   idx(417) idx(737)   相同?')
        same = 0
        for N in range(2, n_max + 1):
            a = m.rand_seeded(base, N, 417417)
            b = m.rand_seeded(base, N, 737737)
            if a == b:
                same += 1
            print('  %2d      %3d      %3d   %s' % (N, a, b, '=' if a == b else ''))
        print('   -> 相同 %d / %d' % (same, n_max - 1))
        # 同时也看 seed = base + 1 / base + 2 的形态（若计数器不从 0 起）
        print('   -- 若首抽的计数不是 0：')
        for off in (1, 2, 3, 4):
            for N in (n_max, n_max - 1, 6):
                a = m.rand_seeded((base + off) & 0xFFFFFFFF, N, 417417)
                b = m.rand_seeded((base + off) & 0xFFFFFFFF, N, 737737)
                print('      off=%d N=%2d : %3d / %3d %s'
                      % (off, N, a, b, '=' if a == b else ''))


if __name__ == '__main__':
    main()
