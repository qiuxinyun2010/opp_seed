# -*- coding: utf-8 -*-
"""假设 3 块显示屏各自独立抽一个图案：每块屏用自己的 GetSeed(屏幕对象)。

  FrequencyClue_TvChannel_SchoolEntrance_1/2/3        （第二轮）
  FrequencyClue_TvChannel_BP_SASExit_1/2/3            （第三轮）
  FrequencyClue_TvChannel_BP_RichDistrictEntrance_1/2/3（第一轮）

每块屏：图案 = PossibleClueNames[ RandSeeded(GetSeed(屏幕) + offset, len) ]
每块屏单独 1/6 约束，两个 seed → 1/36；3 块屏 × 2 seed = 6 个约束 → 1/46656。
"""
import sys

M32 = 0xFFFFFFFF
M64 = 0xFFFFFFFFFFFFFFFF

_T = []
for _i in range(256):
    _c = _i
    for _ in range(8):
        _c = ((_c >> 1) ^ 0xEDB88320) if (_c & 1) else (_c >> 1)
    _T.append(_c & M32)


def crc32_fname(text):
    crc = M32
    for ch in text:
        u = ord(ch) & 0xFFFF
        crc = _T[(crc ^ (u & 0xFF)) & 0xFF] ^ (crc >> 8)
        crc = _T[(crc ^ (u >> 8)) & 0xFF] ^ (crc >> 8)
        crc = _T[crc & 0xFF] ^ (crc >> 8)
        crc = _T[crc & 0xFF] ^ (crc >> 8)
    return (~crc) & M32


def seed_of_object(name, outer=None):
    if outer is None:
        outer = crc32_fname('PersistentLevel')
    value = (crc32_fname(name) + outer) & M32
    return value if value < 0x80000000 else (0x100000000 - value) & M32


def mix1(x):
    z = (0xBF58476D1CE4E5B9 * (x ^ (x >> 30))) & M64
    return z ^ (z >> 27)


def rs(seed, n, salt):
    if not n or not seed:
        return 0
    B = (0x94D049BB133111EB * mix1(salt % 1000)) & M64
    v = ((0x94D049BB133111EB * mix1(seed)) & M64) ^ B
    t = (v ^ (v >> 31)) & M64
    w = (0xBF58476D1CE4E5B9 * (t ^ (t >> 30))) & M64
    u = (w ^ (w >> 27)) & M64
    r = (((321982955 * u) & M64) ^ (((0x94D049BB133111EB * u) & M64) >> 31)) & M64
    return (r & 0xFFFF) % n


CLUES5 = ['Bunny', 'Heart', 'Moon', 'Spade', 'Club']
CLUES6 = ['Bunny', 'Heart', 'Moon', 'Spade', 'Club', 'Diamond']

ROUNDS = {
    'r1': {'clues': CLUES5,
           'screens': ['FrequencyClue_TvChannel_BP_RichDistrictEntrance_1',
                       'FrequencyClue_TvChannel_BP_RichDistrictEntrance_2',
                       'FrequencyClue_TvChannel_BP_RichDistrictEntrance_3'],
           'want': {417417: ['Moon', 'Bunny', 'Club'],
                    737737: ['Moon', 'Spade', 'Club']}},
    'r2': {'clues': CLUES6,
           'screens': ['FrequencyClue_TvChannel_SchoolEntrance_1',
                       'FrequencyClue_TvChannel_SchoolEntrance_2',
                       'FrequencyClue_TvChannel_SchoolEntrance_3'],
           'want': {417417: ['Diamond', 'Heart', 'Bunny'],
                    737737: ['Club', 'Moon', 'Heart']}},
    'r3': {'clues': CLUES6,
           'screens': ['FrequencyClue_TvChannel_BP_SASExit_1',
                       'FrequencyClue_TvChannel_BP_SASExit_2',
                       'FrequencyClue_TvChannel_BP_SASExit_3'],
           'want': {417417: ['Diamond', 'Moon', 'Bunny'],
                    737737: ['Moon', 'Heart', 'Diamond']}},
}
COORD = {
    'r1': 'SRR_MT02_OrderedClueFrequency_RichDistrict',
    'r2': 'SRR_MT02_OrderedClueFrequency_School',
    'r3': 'SRR_MT02_OrderedClueFrequency_SasExit',
}
SALT_CRC = crc32_fname('Objective Actors')


def main():
    span = int(sys.argv[1]) if len(sys.argv) > 1 else 200000
    mode = sys.argv[2] if len(sys.argv) > 2 else 'screen'
    for rk in ('r1', 'r2', 'r3'):
        R = ROUNDS[rk]
        clues = R['clues']
        n = len(clues)
        if mode == 'screen':
            bases = [seed_of_object(s) for s in R['screens']]
        else:                                    # coord：三块屏共用协调器种子 + i
            b0 = seed_of_object(COORD[rk])
            bases = [(b0 + i) & M32 for i in range(3)]
        tag = mode
        for extra, delta0 in (('', 0), ('+salt', SALT_CRC)):
            hits = []
            for off in range(span):
                ok = True
                for si in range(3):
                    b = (bases[si] + delta0 + off) & M32
                    for seed in (417417, 737737):
                        if clues[rs(b, n, seed)] != R['want'][seed][si]:
                            ok = False
                            break
                    if not ok:
                        break
                if ok:
                    hits.append(off)
            print('%-3s %-6s%s  命中 offset: %s' % (rk, tag, extra, hits[:8] if hits else '无'))
            if hits:
                o0 = hits[0]
                for seed in (417417, 737737):
                    got = [clues[rs((bases[i] + delta0 + o0) & M32, n, seed)]
                           for i in range(3)]
                    print('     %d 预测 %s  实测 %s' % (seed, got, R['want'][seed]))


if __name__ == '__main__':
    main()
