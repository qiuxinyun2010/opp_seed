@echo off
call "C:\Program Files\Microsoft Visual Studio\2022\Community\VC\Auxiliary\Build\vcvars64.bat"
cl /nologo /O2 /openmp /Fe:scan_srr.exe scan_srr.c
echo EXIT=%ERRORLEVEL%
