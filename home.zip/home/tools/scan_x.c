// Full 2^32 scan of X for the puzzle-room seed chain.
//
// Model (from sub_1436FE410 / sub_143620E70 / sub_1402D29E0 / sub_141CBDC30):
//   compSeed   = |crc(comp) + f(crc(room), X)|       (mode selects the abs form)
//   digit_i    = pool[ rand_seeded(compSeed + i + 7168, |pool|, salt = S % 1000) ]
// Constraint: the three passcodes of one run must all match.
//   P(false positive) ~ 2^32 / 5040^3 ~ 0.03
//
// usage: scan_x <hash> <mode> <count> <base> [c0 c1 c2] [roomPrefix] [compName] [model]
//   hash 0 = per-char [lo,hi,0]   1 = per-char [lo,hi]   2 = per-char [lo]
//        3 = uppercase + hash 0  4 = uppercase + hash 1
//   mode 0 = |CC + |cR+X||   1 = |cR+X|   2 = |CC + cR+X|   3 = CC + |cR+X|
//   model 0 = digits in draw order   1 = reversed
#include <stdio.h>
#include <stdint.h>
#include <stdlib.h>
#include <string.h>
#include <omp.h>

static uint32_t TBL[256];

static void mk_table(void) {
    for (uint32_t i = 0; i < 256; i++) {
        uint32_t c = i;
        int k;
        for (k = 0; k < 8; k++) c = (c & 1) ? ((c >> 1) ^ 0xEDB88320u) : (c >> 1);
        TBL[i] = c;
    }
}

static int HASH;

static uint32_t crc_str(const char *s) {
    uint32_t crc = 0xFFFFFFFFu;
    const unsigned char *p;
    int steps;   // 每个 16 位字符走几步 CRC32
    for (p = (const unsigned char *)s; *p; p++) {
        uint32_t u = *p;
        if (HASH == 3 || HASH == 4) {
            if (u >= 'a' && u <= 'z') u -= 32;
        }
        // bytes: lo, hi, 0, 0
        steps = (HASH == 2) ? 1 : (HASH == 1 ? 2 : (HASH == 5 ? 4 : 3));
        if (HASH == 4) steps = 2;
        crc = TBL[(crc ^ (u & 0xFF)) & 0xFF] ^ (crc >> 8);
        if (steps >= 2) crc = TBL[(crc ^ (u >> 8)) & 0xFF] ^ (crc >> 8);
        if (steps >= 3) crc = TBL[crc & 0xFF] ^ (crc >> 8);
        if (steps >= 4) crc = TBL[crc & 0xFF] ^ (crc >> 8);
    }
    return ~crc;
}

static inline uint64_t fmix_a(uint32_t seed) {
    uint64_t x = 0xBF58476D1CE4E5B9ull * (uint64_t)(seed ^ (seed >> 30));
    x ^= x >> 27;
    return x;
}

static inline uint64_t salt_b(uint32_t salt) {
    uint64_t x = 0xBF58476D1CE4E5B9ull * (uint64_t)(salt % 1000u);
    x ^= x >> 27;
    return x;
}

static inline uint32_t rand_seeded(uint32_t seed, uint32_t n, uint64_t b) {
    uint64_t a, v5, t, v6, u, v7;
    if (!n || !seed) return 0;
    a = fmix_a(seed);
    v5 = (0x94D049BB133111EBull * a) ^ (0x94D049BB133111EBull * b);
    t = v5 ^ (v5 >> 31);
    v6 = 0xBF58476D1CE4E5B9ull * (t ^ (t >> 30));
    u = v6 ^ (v6 >> 27);
    v7 = (uint64_t)((uint32_t)(321982955u * (uint32_t)u)) ^ ((0x94D049BB133111EBull * u) >> 31);
    return (uint32_t)((uint16_t)v7 % n);
}

static inline uint32_t iabs32(uint32_t v) {
    return (v < 0x80000000u) ? v : (uint32_t)(0u - v);
}

#define NROOM 3
static const char *ROOMS[NROOM] = {
    "RBRoom_West_Bureau", "RBRoom_West_Maintenance", "RBRoom_East_JudgesOffice"};
static const char *CODES[NROOM] = {"3894", "7481", "7319"};
static char NAMES[NROOM][128];
static uint32_t CR[NROOM];
static uint32_t CC;
static uint64_t B;
static int MODEL;
static int MODE;

static void digits(uint32_t roomseed, char *out) {
    int pool[10];
    int i, k, n = 10;
    for (i = 0; i < 10; i++) pool[i] = i;
    for (i = 0; i < 4; i++) {
        uint32_t idx = rand_seeded(roomseed + (uint32_t)i + 7168u, (uint32_t)n, B);
        out[i] = (char)('0' + pool[idx]);
        for (k = (int)idx; k < n - 1; k++) pool[k] = pool[k + 1];
        n--;
    }
    out[4] = 0;
    if (MODEL == 1) {
        char t = out[0];
        out[0] = out[3];
        out[3] = t;
        t = out[1];
        out[1] = out[2];
        out[2] = t;
    }
}

static inline uint32_t comp_seed(int r, uint32_t X) {
    uint32_t cR = CR[r];
    switch (MODE) {
        case 0: return iabs32(CC + iabs32(cR + X));
        case 1: return iabs32(cR + X);
        case 2: return iabs32(CC + (cR + X));
        case 3: return (CC + iabs32(cR + X));
        default: return 0;
    }
}

int main(int argc, char **argv) {
    int r;
    uint32_t salt = 987u;
    const char *prefix = "RBRoom_";
    const char *comp = "RBPuzzleRoomComponent_0";
    long long lim, base;
    uint64_t hits = 0;
    double t0;

    mk_table();
    HASH = (argc > 1) ? atoi(argv[1]) : 0;
    MODE = (argc > 2) ? atoi(argv[2]) : 0;
    lim = (argc > 3) ? atoll(argv[3]) : 4294967296LL;
    base = (argc > 4) ? atoll(argv[4]) : 0LL;
    if (argc > 7) { CODES[0] = argv[5]; CODES[1] = argv[6]; CODES[2] = argv[7]; }
    if (argc > 8) prefix = argv[8];
    if (argc > 9) comp = argv[9];
    if (argc > 10) MODEL = atoi(argv[10]); else MODEL = 0;

    CC = crc_str(comp);
    for (r = 0; r < NROOM; r++) {
        snprintf(NAMES[r], sizeof(NAMES[r]), "%s%s", prefix, ROOMS[r] + 7);
        CR[r] = crc_str(NAMES[r]);
    }
    B = salt_b(salt);

    {
        char d[5];
        digits(123u, d);
        fprintf(stderr, "hash=%d mode=%d model=%d salt=%u CC=0x%08x CR0=0x%08x name0=%s\n",
                HASH, MODE, MODEL, salt, CC, CR[0], NAMES[0]);
        fflush(stderr);
    }

    t0 = omp_get_wtime();
    {
        long long x;
        #pragma omp parallel for schedule(static, 65536)
        for (x = 0; x < lim; x++) {
            uint32_t X = (uint32_t)(base + x);
            int ok = 1;
            int rr;
            char dd[5];
            for (rr = 0; rr < NROOM; rr++) {
                uint32_t cs = comp_seed(rr, X);
                uint32_t idx = rand_seeded(cs + 7168u, 10u, B);
                int want = (MODEL == 1) ? (CODES[rr][3] - '0') : (CODES[rr][0] - '0');
                if (idx != (uint32_t)want) { ok = 0; break; }
            }
            if (!ok) continue;
            for (rr = 0; rr < NROOM; rr++) {
                uint32_t cs = comp_seed(rr, X);
                digits(cs, dd);
                if (strcmp(dd, CODES[rr])) { ok = 0; break; }
            }
            if (ok) {
                #pragma omp atomic
                hits++;
                #pragma omp critical
                printf("HIT X=%u (0x%08x)\n", X, X);
            }
        }
    }
    printf("RESULT hash=%d mode=%d model=%d hits=%llu %.1fs\n",
           HASH, MODE, MODEL, (unsigned long long)hits, omp_get_wtime() - t0);
    return 0;
}
