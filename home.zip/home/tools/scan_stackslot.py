# -*- coding: utf-8 -*-
"""在函数范围内找「写入某个 [rsp+disp8]」的指令（mov [rsp+d], reg / mov dword [rsp+d], imm）。

    python scan_stackslot.py 0x1402B05C0 0x1402B28B2 0x0C
"""
import struct
import sys
import os

_HERE = os.path.dirname(os.path.abspath(__file__))
sys.path.insert(0, _HERE)
import scan_disp as sd

REG32 = ['eax', 'ecx', 'edx', 'ebx', 'esp', 'ebp', 'esi', 'edi']
REG64 = ['rax', 'rcx', 'rdx', 'rbx', 'rsp', 'rbp', 'rsi', 'rdi']


def main():
    lo = int(sys.argv[1], 16)
    hi = int(sys.argv[2], 16)
    disp = int(sys.argv[3], 16)
    off = sd.va2off(lo)
    code = sd.d[off:off + (hi - lo)]
    print('=== %X..%X 中写入 [rsp+%02Xh] 的位置' % (lo, hi, disp))
    n = 0
    wide = disp > 0x7F
    dlen = 4 if wide else 1
    for i in range(len(code) - 8):
        j = i
        rex = 0
        if code[j] in range(0x40, 0x50):
            rex = code[j]
            j += 1
        if code[j] != 0x89:
            continue
        modrm = code[j + 1]
        if (modrm & 0xC7) != (0x84 if wide else 0x44):
            continue
        if code[j + 2] != 0x24:
            continue
        val = (struct.unpack_from('<i', code, j + 3)[0] if wide else code[j + 3])
        if val != disp:
            continue
        reg = (modrm >> 3) & 7
        name = (REG64 if rex & 8 else REG32)[reg]
        print('  %X  mov [rsp+%03Xh], %s' % (lo + i, disp, name))
        n += 1
    # mov dword ptr [rsp+d], imm32
    for i in range(len(code) - 12):
        mod = 0x84 if wide else 0x44
        if code[i] != 0xC7 or code[i + 1] != mod or code[i + 2] != 0x24:
            continue
        k = i + 3
        val = (struct.unpack_from('<i', code, k)[0] if wide else code[k])
        if val != disp:
            continue
        imm = struct.unpack_from('<i', code, k + dlen)[0]
        print('  %X  mov dword [rsp+%03Xh], %d' % (lo + i, disp, imm))
        n += 1
    print('共 %d 处' % n)


if __name__ == '__main__':
    main()
