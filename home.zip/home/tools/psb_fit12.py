# -*- coding: utf-8 -*-
"""PSB_MT01 第十二轮：只解「每区刷出来的 3 具是谁」（不管图案）。

模型（sub_14361C230 循环体 @0x14361CA08）：
    for group (一区, 顺序待定):            # v70 = 跨组累加
        for v71 in 0..2:
            idx = RandSeeded(base + 243551 + v71 + v70, |组内候选|)
            取走该候补（保序 RemoveAt 或 RemoveAtSwap）

目标（seed 378378，组内下标）：
    A {0,4,6}   B {1,5,9}   C {8,9,14}
"""
import itertools
import os
import sys

sys.path.insert(0, os.path.abspath(os.path.join(os.path.dirname(__file__), '..', '..', 'seed')))
import seedcore as sc  # noqa: E402

A_LIST = [0, 1, 2, 4, 8, 15, 16, 17, 18, 19, 22, 33, 34, 35, 40]
B_LIST = [9, 10, 21, 23, 24, 25, 26, 32, 36, 37]
C_LIST = [3, 5, 6, 7, 11, 12, 13, 14, 20, 27, 28, 29, 30, 31, 38, 39]
LISTS = {'A': A_LIST, 'B': B_LIST, 'C': C_LIST}
WANT = {'A': {0, 4, 6}, 'B': {1, 5, 9}, 'C': {8, 9, 14}}
COORD = 'PSB_MT01_B01_CorpseSearch_3'
SEED = 378378


def one_group(base, sec, swap):
    """v70 = 0 时某区的 3 具（组内下标）。"""
    salt = SEED % 1000
    g = list(range(len(LISTS[sec])))
    out = []
    for k in range(3):
        i = sc.rand_seeded((base + 243551 + k) & 0xFFFFFFFF, len(g), salt)
        out.append(g[i])
        if swap:
            g[i] = g[-1]
        g.pop(i)
    return out


def run(base, order, swap):
    salt = SEED % 1000
    got = {}
    v70 = 0
    for sec in order:
        g = list(range(len(LISTS[sec])))
        s = set()
        for k in range(3):
            i = sc.rand_seeded((base + 243551 + k + v70) & 0xFFFFFFFF, len(g), salt)
            s.add(g[i])
            if swap:
                g[i] = g[-1]
            g.pop(i)
        got[sec] = s
        v70 += 3
    return got


def main():
    try:
        sys.stdout.reconfigure(encoding='utf-8')
    except Exception:
        pass
    scan = int(sys.argv[1]) if len(sys.argv) > 1 else (1 << 22)
    lvl = sc.crc32_fname('PersistentLevel')
    coord = sc.seed_of_object(COORD, lvl)
    orders = list(itertools.permutations('ABC'))
    print('扫 d=0..%d（base = K 与 GetSeed(coord)+K，两种删除语义）' % (scan - 1))

    hits = 0
    for d in range(scan):
        for pure in (True, False):
            base = d if pure else (coord + d) & 0xFFFFFFFF
            for swap in (True, False):
                firsts = [sec for sec in 'ABC' if set(one_group(base, sec, swap)) == WANT[sec]]
                if not firsts:
                    continue
                for order in orders:
                    if order[0] not in firsts:
                        continue
                    if all(run(base, order, swap)[s] == WANT[s] for s in 'ABC'):
                        print('★ d=%d pure=%s swap=%s order=%s' % (d, pure, swap, order))
                        hits += 1
    print('命中 %d' % hits)


if __name__ == '__main__':
    main()
