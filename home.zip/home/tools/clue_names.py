# -*- coding: utf-8 -*-
"""打印三个协调器的 PossibleClueNames 真实顺序 / 数量。"""
import io
import re

P = r'd:/workspace/outlast/pak/OPP/Content/Maps_json/SuburbRiotResidential/SRR_MT02_B00.json'


def grab_array(t, start):
    k = t.find('[', start)
    if k < 0:
        return None
    depth = 0
    for i in range(k, len(t)):
        if t[i] == '[':
            depth += 1
        elif t[i] == ']':
            depth -= 1
            if depth == 0:
                return t[k:i + 1]
    return None


def main():
    t = io.open(P, encoding='utf-8').read()
    for coord in ('RichDistrict', 'School', 'SasExit'):
        key = '"SRR_MT02_OrderedClueFrequency_%s"' % coord
        i = t.find(key)
        seg = t[i:i + 24000]
        j = seg.find('"PossibleClueNames"')
        print('== %s (PossibleClueNames at +%d)' % (coord, j))
        if j < 0:
            continue
        arr = grab_array(seg, j)
        names = re.findall(r'"([A-Za-z][A-Za-z0-9_]*)"', arr)
        names = [n for n in names if n.lower() not in ('name', 'number')]
        print('   %d 项: %s' % (len(names), names))


if __name__ == '__main__':
    main()
