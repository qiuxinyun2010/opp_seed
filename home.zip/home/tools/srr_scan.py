# -*- coding: utf-8 -*-
"""SRR_MT02 关卡 JSON 探查器（只读 pak/，产物写 home/）。

用法：
  python tools\srr_scan.py kinds                 # 顶层对象类型统计
  python tools\srr_scan.py find <关键字>          # 名字含关键字的对象
  python tools\srr_scan.py props <对象名>         # 打印该对象 Properties
  python tools\srr_scan.py tuners                # 49 台调频器 + 房间
"""
import json
import sys
import os

MAPS = r"d:\workspace\outlast\pak\OPP\Content\Maps_json\SuburbRiotResidential"
CACHE = {}


def load(level="SRR_MT02_B00"):
    if level in CACHE:
        return CACHE[level]
    p = os.path.join(MAPS, level + ".json")
    with open(p, "r", encoding="utf-8") as f:
        data = json.load(f)
    CACHE[level] = data
    return data


def name_of(o):
    if not isinstance(o, dict):
        return ""
    return str(o.get("Name") or o.get("ObjectName") or "")


def class_of(o):
    if not isinstance(o, dict):
        return ""
    c = o.get("Class")
    if isinstance(c, dict):
        c = c.get("ObjectName") or c.get("ObjectPath")
    return str(c or "")


def walk(o):
    """深度优先遍历对象树。"""
    if isinstance(o, dict):
        yield o
        for v in o.values():
            for x in walk(v):
                yield x
    elif isinstance(o, list):
        for v in o:
            for x in walk(v):
                yield x


def main():
    cmd = sys.argv[1] if len(sys.argv) > 1 else "kinds"
    data = load()
    if cmd == "kinds":
        from collections import Counter
        c = Counter()
        for o in data:
            c[(o.get("Type"), class_of(o))] += 1
        for k, v in c.most_common(60):
            print(v, k)
    elif cmd == "find":
        kw = sys.argv[2]
        for o in walk(data):
            n = name_of(o)
            if kw.lower() in n.lower():
                outer = o.get("Outer")
                print("%-70s | %s | outer=%s" % (n, class_of(o), outer))
    elif cmd == "props":
        kw = sys.argv[2]
        seen = set()
        for o in walk(data):
            n = name_of(o)
            if kw.lower() not in n.lower():
                continue
            if n != kw:                      # 只看完全同名的 actor/对象
                continue
            if "BlueprintGeneratedClass" not in class_of(o):
                continue
            if id(o) in seen:
                continue
            seen.add(id(o))
            print("=" * 80)
            print(name_of(o), class_of(o))
            props = o.get("Properties")
            if props is None:
                print("  (no Properties)")
                continue
            if isinstance(props, dict):
                for k, v in props.items():
                    print("   %-40s = %s" % (k, brief(v)))
            else:
                print(props)
    elif cmd == "pool":
        kw = sys.argv[2]
        for o in walk(data):
            n = name_of(o)
            if n != kw or "BlueprintGeneratedClass" not in class_of(o):
                continue
            props = o.get("Properties") or {}
            for key in ("ObjectiveActors", "OrderedClueActors", "PossibleClueNames"):
                arr = props.get(key)
                if arr is None:
                    continue
                print("--- %s [%d]" % (key, len(arr)))
                for i, s in enumerate(arr):
                    s = s if isinstance(s, str) else json.dumps(s, ensure_ascii=False)
                    print("  %2d  %s" % (i, s.split("SubPathString:'")[-1].rstrip("}'")))
            print("--- PrimaryActorsRandomizationSetup")
            print(json.dumps(props.get("PrimaryActorsRandomizationSetup"), ensure_ascii=False, indent=1))
            print("--- all bool-ish props")
            for k, v in props.items():
                if isinstance(v, bool):
                    print("   %-40s = %s" % (k, v))
            break
    elif cmd == "sections":
        rows = []
        for o in walk(data):
            n = name_of(o)
            if not n.startswith("FrequencyMatchBlacklit_BP"):
                continue
            if "BlueprintGeneratedClass" not in class_of(o):
                continue
            props = o.get("Properties") or {}
            sec = props.get("SectionIndex")
            if sec is not None:
                rows.append((n, sec))
        rows.sort(key=lambda r: r[0])
        for n, sec in rows:
            print("%-12s SectionIndex=%s" % (n, sec))
        from collections import Counter
        print("--- 分布:", Counter(s for _, s in rows).most_common())
    elif cmd == "tuners":
        for o in walk(data):
            n = name_of(o)
            if "FrequencyMatchBlacklit" in n:
                print("%-40s %s" % (n, class_of(o)))
    else:
        print(__doc__)


def brief(v, depth=0):
    if depth > 3:
        return "..."
    if isinstance(v, list):
        return "[%d] %s" % (len(v), [brief(x, depth + 1) for x in v[:6]])
    if isinstance(v, dict):
        return "{%s}" % ", ".join("%s:%s" % (k, brief(x, depth + 1)) for k, x in list(v.items())[:8])
    return repr(v)[:160]


if __name__ == "__main__":
    main()
