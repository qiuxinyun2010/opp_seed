/* PSB_MT01 「每区钥匙图案」反解器 v11
 *
 * 模型全部来自 sub_14361C230 的反编译（逐行语义），不是拍脑袋：
 *
 *   v143 = GetSeed(协调器) 经 sub_1402C30C0 写回后的 B（唯一未知，32 位）
 *   盐沌:v120 = B + 243551(选尸体)   v123 = B + 223551(选图案)
 *   组: for g in groups: for j in 0..count_g-1:
 *          saltpair = v71 + v70 = 组已用数 + 组内序号  ->  S_g + 2*j
 *          图案idx = RandSeeded(B + 223551 + S_g + 2j, |pool|)
 *          图案    = pool[idx];  pool.RemoveAt(idx)（保序）
 *          v70++
 *   pool = QuestItemClasses = Bunny Club Diamond Fire Heart Spade Crown Eye Moon Star
 *
 * 约束（实测 3 条 seed）：
 *   111111 -> A=Star  B=Bunny C=Diamond
 *   565565 -> A=Heart B=Club  C=Eye
 *   378378 -> A=Moon  B=Fire  C=Spade      （另有一局全 9 具的完整图案）
 *
 * 用法: psb_key_scan.exe [keypos] [listCnt]
 *   keypos: 0=组内第 1 具是真钥匙  1=第 2 具  2=最后一具
 *   listCnt: 0=(3,3,3)  1=(3,3,3)+(3,3,4)+(3,4,3)+(4,3,3)  2=每组 3..5 任意(sum<=10)
 */
#include <stdio.h>
#include <stdint.h>
#include <stdlib.h>
#include <string.h>
#include <omp.h>

/* ---------------- sub_1402D29E0 : RandSeeded ---------------- */
static inline uint64_t mixA(uint32_t s) {
    uint64_t x = 0xBF58476D1CE4E5B9ull * (uint64_t)(s ^ (s >> 30));
    return x ^ (x >> 27);
}
static inline uint32_t rand_seeded(uint32_t s, uint32_t n, uint64_t b) {
    uint64_t a, v5, t, v6, u, v7;
    if (!n || !s) return 0;
    a  = mixA(s);
    v5 = (0x94D049BB133111EBull * a) ^ (0x94D049BB133111EBull * b);
    t  = v5 ^ (v5 >> 31);
    v6 = 0xBF58476D1CE4E5B9ull * (t ^ (t >> 30));
    u  = v6 ^ (v6 >> 27);
    v7 = (uint64_t)(uint32_t)(321982955u * (uint32_t)u) ^ ((0x94D049BB133111EBull * u) >> 31);
    return (uint32_t)(((uint16_t)v7) % n);
}
static inline uint64_t salt_b(uint32_t salt) {
    uint64_t x = 0xBF58476D1CE4E5B9ull * (uint64_t)(salt % 1000u);
    return x ^ (x >> 27);
}

#define NSEED 3
static const uint32_t SALTS[NSEED] = { 111u, 565u, 378u };

/* pool 下标（QuestItemClasses 顺序） */
/* 0 Bunny 1 Club 2 Diamond 3 Fire 4 Heart 5 Spade 6 Crown 7 Eye 8 Moon 9 Star */

/* 实测钥匙图案：[扇区][seed]，seed 序 = 111111 / 565565 / 378378 */
static const int KEY_IX[3][NSEED] = {
    { 9, 4, 8 },   /* A */
    { 0, 1, 3 },   /* B */
    { 2, 7, 5 }    /* C */
};
/* 378378 每区实际出现的全部图案（位集），用于二次确认 */
static const unsigned FULL_SET[3] = {
    (1u << 4) | (1u << 6) | (1u << 8),   /* A: Heart Crown Moon */
    (1u << 2) | (1u << 3) | (1u << 0),   /* B: Diamond Fire Bunny */
    (1u << 7) | (1u << 5) | (1u << 1)    /* C: Eye Spade Club */
};

static uint64_t BSALT[NSEED];
static int KEYPOS = 0;
static int CNT[64][3];
static int NCNT = 1;

static int which_cnt(void) { return 0; }

static int check_full(uint32_t B, const int *sec, const int *cnt) {
    int s, g, k;
    for (s = 0; s < NSEED; s++) {
        int pool[10];
        int n = 10, V = 0;
        int keys[3];
        unsigned sets[3];
        for (g = 0; g < 3; g++) { pool[g] = 0; }
        for (g = 0; g < 10; g++) pool[g] = g;
        for (g = 0; g < 3; g++) { keys[g] = -1; sets[g] = 0u; }
        for (g = 0; g < 3; g++) {
            int c = cnt[g], j, kj;
            kj = (KEYPOS == 0) ? 0 : ((KEYPOS == 1) ? 1 : c - 1);
            if (kj < 0) kj = 0;
            if (kj > c - 1) kj = c - 1;
            for (j = 0; j < c; j++) {
                uint32_t saltpair = (uint32_t)(V + j);
                int idx = (int)rand_seeded((uint32_t)(B + 223551u + saltpair),
                                           (uint32_t)n, BSALT[s]);
                int cls = pool[idx];
                for (k = idx; k < n - 1; k++) pool[k] = pool[k + 1];
                n--;
                if (j == kj) keys[g] = cls;
                sets[g] |= (1u << cls);
                V++;
            }
        }
        for (g = 0; g < 3; g++) {
            int sx = sec[g];
            if (keys[g] != KEY_IX[sx][s]) return 0;
        }
        if (s == 2) {
            for (g = 0; g < 3; g++) {
                int sx = sec[g];
                if ((sets[g] & FULL_SET[sx]) != FULL_SET[sx]) return 0;
            }
        }
    }
    return 1;
}

int main(int argc, char **argv) {
    long long hits = 0;
    double t0;
    int i, s, nc = 0;
    const char *secname = "ABC";

    KEYPOS = (argc > 1) ? atoi(argv[1]) : 0;
    s = (argc > 2) ? atoi(argv[2]) : 0;

    if (argc > 1 && argv[1][0] == 't') {          /* 自检：与 seedcore.rand_seeded 对齐 */
        uint32_t tb[5] = { 1u, 0x12345678u, 0xDEADBEEFu, 0x4C09CC22u, 4294967295u };
        int q;
        for (i = 0; i < NSEED; i++) BSALT[i] = salt_b(SALTS[i]);
        for (q = 0; q < 5; q++)
            printf("T %u %u %u %u\n", tb[q],
                   rand_seeded(tb[q], 10u, BSALT[0]),
                   rand_seeded(tb[q], 10u, BSALT[1]),
                   rand_seeded(tb[q], 10u, BSALT[2]));
        return 0;
    }

    for (i = 0; i < NSEED; i++) BSALT[i] = salt_b(SALTS[i]);

    if (s == 0) {
        int base[3] = { 3, 3, 3 };
        memcpy(CNT[nc], base, sizeof(base)); nc++;
    } else if (s == 1) {
        int b1[3] = { 3, 3, 3 }, b2[3] = { 3, 3, 4 }, b3[3] = { 3, 4, 3 }, b4[3] = { 4, 3, 3 };
        memcpy(CNT[nc], b1, sizeof(b1)); nc++;
        memcpy(CNT[nc], b2, sizeof(b2)); nc++;
        memcpy(CNT[nc], b3, sizeof(b3)); nc++;
        memcpy(CNT[nc], b4, sizeof(b4)); nc++;
    } else {
        int a, b, c;
        for (a = 3; a <= 5; a++)
            for (b = 3; b <= 5; b++)
                for (c = 3; c <= 5; c++)
                    if (a + b + c <= 10) { CNT[nc][0] = a; CNT[nc][1] = b; CNT[nc][2] = c; nc++; }
    }
    NCNT = nc;

    fprintf(stderr, "PSB key scan: keypos=%d ncnt=%d\n", KEYPOS, NCNT);
    fprintf(stderr, "  key.pos <= 0 .. 9 of %d patterns\n", (int)(sizeof(unsigned) * 8));
    fflush(stderr);

    t0 = omp_get_wtime();
    {
        long long xx;
#pragma omp parallel for schedule(dynamic, 1) reduction(+:hits)
        for (xx = 0; xx < 4294967296LL; xx++) {
        uint32_t B = (uint32_t)xx;
        uint32_t idx0[NSEED];
        int si;
        for (si = 0; si < NSEED; si++)
            idx0[si] = rand_seeded((uint32_t)(B + 223551u), 10u, BSALT[si]);
        for (si = 0; si < 3; si++) {          /* 哪一个扇区是「第 0 组」 */
            int X0 = si, Y = -1, Z = -1, ci;
            int okall = 1;
            for (i = 0; i < NSEED; i++)
                if (idx0[i] != (uint32_t)KEY_IX[X0][i]) { okall = 0; break; }
            if (!okall) continue;
            for (Y = 0; Y < 3; Y++) {
                if (Y == X0) continue;
                Z = 3 - X0 - Y;
                {
                    int sec[3];
                    sec[0] = X0; sec[1] = Y; sec[2] = Z;
                    for (ci = 0; ci < NCNT; ci++) {
                        if (check_full(B, sec, CNT[ci])) {
                            hits++;
#pragma omp critical
                            printf("HIT B=0x%08X  I=%lld  order=%c%c%c cnt=%d/%d/%d\n",
                                   B, xx, secname[sec[0]], secname[sec[1]],
                                   secname[sec[2]], CNT[ci][0], CNT[ci][1], CNT[ci][2]);
                            fflush(stdout);
                        }
                    }
                }
            }
        }
        }
    }
    printf("RESULT keypos=%d ncnt=%d hits=%lld  %.1fs\n",
           KEYPOS, NCNT, hits, omp_get_wtime() - t0);
    return 0;
}
