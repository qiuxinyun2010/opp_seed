# -*- coding: utf-8 -*-
"""从 PE 里按 VA 读原始字节（不依赖 IDA）。

用法: python tools/pe_read.py 0x145066680 0x1451BC758 [--f32]
"""
import struct
import sys

EXE = r'd:\workspace\outlast\TOTClient-Win64-Shipping.exe'


class PE:
    def __init__(self, path):
        self.f = open(path, 'rb')
        d = self.f.read(0x1000)
        self.base = struct.unpack_from('<Q', d, 0x30 + 0x10)[0] if False else None
        e_lfanew = struct.unpack_from('<I', d, 0x3C)[0]
        self.f.seek(e_lfanew)
        nt = self.f.read(0x18)
        assert nt[:4] == b'PE\0\0'
        nsec = struct.unpack_from('<H', nt, 6)[0]
        optsz = struct.unpack_from('<H', nt, 20)[0]
        opt = self.f.read(optsz)
        magic = struct.unpack_from('<H', opt, 0)[0]
        if magic == 0x20b:
            self.image_base = struct.unpack_from('<Q', opt, 24)[0]
        else:
            self.image_base = struct.unpack_from('<I', opt, 28)[0]
        self.secs = []
        self.f.seek(e_lfanew + 0x18 + optsz)
        for i in range(nsec):
            s = self.f.read(40)
            name = s[:8].rstrip(b'\0').decode()
            vsz, va, rsz, raw = struct.unpack_from('<IIII', s, 8)
            self.secs.append((name, va, vsz, raw, rsz))

    def off(self, va):
        rva = va - self.image_base
        for name, sva, vsz, raw, rsz in self.secs:
            if sva <= rva < sva + max(vsz, rsz):
                return raw + (rva - sva)
        raise ValueError('VA 0x%X 不在任何段内 (rva 0x%X)' % (va, rva))

    def read(self, va, n):
        self.f.seek(self.off(va))
        return self.f.read(n)


def main():
    pe = PE(EXE)
    print('image_base = 0x%X' % pe.image_base)
    for name, sva, vsz, raw, rsz in pe.secs:
        print('  %-10s va=0x%08X vsz=0x%-8X raw=0x%08X' % (name, sva, vsz, raw))
    for a in sys.argv[1:]:
        va = int(a, 0)
        b = pe.read(va, 8)
        u32 = struct.unpack('<I', b[:4])[0]
        f32 = struct.unpack('<f', b[:4])[0]
        print('0x%08X: bytes=%s  u32=0x%08X  f32=%r' % (va, b.hex(), u32, f32))


if __name__ == '__main__':
    main()
