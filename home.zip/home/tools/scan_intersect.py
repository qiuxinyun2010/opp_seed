# -*- coding: utf-8 -*-
"""求「访问若干个结构体偏移」的函数集合的交集。

    python scan_intersect.py 0x24B0 0x19E8
    python scan_intersect.py 0x24B0 0x19E8 0x1A00
"""
import sys
import os

_HERE = os.path.dirname(os.path.abspath(__file__))
sys.path.insert(0, _HERE)
import scan_disp as sd


def funcs_for(disp):
    out = {}
    for va in sd.scan(disp):
        c = sd.containing(va)
        if c:
            out.setdefault(c[0], []).append(va)
    return out


def main():
    disps = [int(a, 16) for a in sys.argv[1:]]
    if not disps:
        print(__doc__)
        return
    sets = []
    for d in disps:
        s = funcs_for(d)
        print('  0x%-6X -> %d 个函数' % (d, len(s)))
        sets.append(s)
    common = set(sets[0])
    for s in sets[1:]:
        common &= set(s)
    print('=== 交集 %d 个函数' % len(common))
    for fn in sorted(common):
        c = sd.containing(fn)
        hits = []
        for d, s in zip(disps, sets):
            hits.append('%X x%d' % (d, len(s[fn])))
        print('  0x%X  size 0x%-6X  %s' % (fn, c[1] - c[0], '  '.join(hits)))


if __name__ == '__main__':
    main()
