# -*- coding: utf-8 -*-
"""用第一轮的「抽序」反定 base。

图案解（srr_fit6）推出：两个 seed 的抽序都是 [BP, BP2, BP3, BP49]（= 池序）。
这给出一个不依赖图案的独立约束：某个 base 必须用某种算法在两个 salt 下都抽出池序。
随机假阳性 (1/4!)^2 = 1/576 per (base, mode)，只测少量候选 base → 命中即可信。
"""
import sys
from itertools import product

M32 = 0xFFFFFFFF
M64 = 0xFFFFFFFFFFFFFFFF

_T = []
for _i in range(256):
    _c = _i
    for _ in range(8):
        _c = ((_c >> 1) ^ 0xEDB88320) if (_c & 1) else (_c >> 1)
    _T.append(_c & M32)


def crc32_fname(text):
    crc = M32
    for ch in text:
        u = ord(ch) & 0xFFFF
        crc = _T[(crc ^ (u & 0xFF)) & 0xFF] ^ (crc >> 8)
        crc = _T[(crc ^ (u >> 8)) & 0xFF] ^ (crc >> 8)
        crc = _T[crc & 0xFF] ^ (crc >> 8)
        crc = _T[crc & 0xFF] ^ (crc >> 8)
    return (~crc) & M32


def seed_of_object(name):
    value = (crc32_fname(name) + crc32_fname('PersistentLevel')) & M32
    return value if value < 0x80000000 else (0x100000000 - value) & M32


def mix1(x):
    z = (0xBF58476D1CE4E5B9 * (x ^ (x >> 30))) & M64
    return z ^ (z >> 27)


def rs(seed, n, salt):
    if not n or not seed:
        return 0
    B = (0x94D049BB133111EB * mix1(salt % 1000)) & M64
    v = ((0x94D049BB133111EB * mix1(seed)) & M64) ^ B
    t = (v ^ (v >> 31)) & M64
    w = (0xBF58476D1CE4E5B9 * (t ^ (t >> 30))) & M64
    u = (w ^ (w >> 27)) & M64
    r = (((321982955 * u) & M64) ^ (((0x94D049BB133111EB * u) & M64) >> 31)) & M64
    return (r & 0xFFFF) % n


POOL = ['BP', 'BP2', 'BP3', 'BP49']
COORD = 'SRR_MT02_OrderedClueFrequency_RichDistrict'
SEED = seed_of_object(COORD)
SALT_CRC = crc32_fname('Objective Actors')
D = 4


def draw(base, mode, salt):
    if mode == 'plain':
        mem = list(POOL)
        out = []
        for i in range(D):
            k = rs((base + i) & M32, len(mem), salt)
            out.append(mem[k])
            mem[k] = mem[-1]
            mem.pop()
        return out
    if mode == 'rm':
        mem = list(POOL)
        out = []
        for i in range(D):
            k = rs((base + i) & M32, len(mem), salt)
            out.append(mem[k])
            del mem[k]
        return out
    if mode == 'popall':
        mem = list(POOL)
        out = []
        for i in range(D):
            k = rs((base + i) & M32, len(mem), salt)
            out.append(mem[k])
            mem[k] = mem[-1]
            mem.pop()
        return out
    if mode == 'fy':
        mem = list(POOL)
        for i in range(len(mem), 1, -1):
            j = rs((base + (len(mem) - i)) & M32, i, salt)
            mem[i - 1], mem[j] = mem[j], mem[i - 1]
        return mem[:D]
    raise ValueError(mode)


def main():
    span = int(sys.argv[1]) if len(sys.argv) > 1 else 0
    cands = [('GetSeed', SEED), ('GetSeed+saltCrc', (SEED + SALT_CRC) & M32),
             ('GetSeed+503', (SEED + 503) & M32)]
    if span:
        cands += [('GetSeed+%d' % d, (SEED + d) & M32) for d in range(span)]
        cands += [('+salt+%d' % d, (SEED + SALT_CRC + d) & M32) for d in range(span)]
    for btag, base in cands:
        for mode in ('plain', 'rm', 'popall', 'fy'):
            if (draw(base, mode, 417417) == POOL
                    and draw(base, mode, 737737) == POOL):
                print('★ %-18s mode=%-7s  两 seed 抽序都 = 池序  (base=0x%08X)'
                      % (btag, mode, base))
                print('   417: %s' % draw(base, mode, 417417))
                print('   737: %s' % draw(base, mode, 737737))


if __name__ == '__main__':
    main()
