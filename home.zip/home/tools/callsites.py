# -*- coding: utf-8 -*-
"""在某个函数范围内列出对指定被调函数的相对调用（E8 rel32），并打印调用前的字节。

用来读「随机原语」的调用上下文（种子基 = 哪个常数 + 哪个计数），比整函数反编译省事。

    python callsites.py 0x1402B05C0 0x1402B28B2 0x1402D29E0 0x1401A0F00
"""
import struct
import sys
import os

_HERE = os.path.dirname(os.path.abspath(__file__))
sys.path.insert(0, _HERE)
import vaq


def main():
    lo = int(sys.argv[1], 16)
    hi = int(sys.argv[2], 16)
    targets = set(int(a, 16) for a in sys.argv[3:] if a != '--all')
    all_calls = '--all' in sys.argv
    off = vaq.va2off(lo)
    n = hi - lo
    code = vaq.d[off:off + n]
    print('=== 范围 %X..%X（%d 字节），目标 %s'
          % (lo, hi, n, ' '.join('%X' % t for t in sorted(targets))))
    i = 0
    hits = 0
    while i < len(code) - 5:
        if code[i] == 0xE8:
            rel = struct.unpack_from('<i', code, i + 1)[0]
            tgt = lo + i + 5 + rel
            if all_calls or tgt in targets:
                hits += 1
                va = lo + i
                back = vaq.d[vaq.va2off(va - 28):vaq.va2off(va) + 5]
                print('  call @%X -> %X' % (va, tgt))
                print('     pre: %s' % ' '.join('%02x' % b for b in back))
        i += 1
    print('共 %d 处调用' % hits)


if __name__ == '__main__':
    main()
