# -*- coding: utf-8 -*-
"""只扫「图案序列」本身的偏移：假设图案按选中机器的池序（或倒序）赋给。

不需要机器抽取算法 —— 选中机器已知（实测），只需它们的池序。
两个 seed 同时约束 → 1/(6!)^2 ≈ 1/518400，扫 30 万期望假阳性 0.6，命中即可信。
"""
import sys

M32 = 0xFFFFFFFF
M64 = 0xFFFFFFFFFFFFFFFF

_T = []
for _i in range(256):
    _c = _i
    for _ in range(8):
        _c = ((_c >> 1) ^ 0xEDB88320) if (_c & 1) else (_c >> 1)
    _T.append(_c & M32)


def crc32_fname(text):
    crc = M32
    for ch in text:
        u = ord(ch) & 0xFFFF
        crc = _T[(crc ^ (u & 0xFF)) & 0xFF] ^ (crc >> 8)
        crc = _T[(crc ^ (u >> 8)) & 0xFF] ^ (crc >> 8)
        crc = _T[crc & 0xFF] ^ (crc >> 8)
        crc = _T[crc & 0xFF] ^ (crc >> 8)
    return (~crc) & M32


def seed_of_object(name):
    value = (crc32_fname(name) + crc32_fname('PersistentLevel')) & M32
    return value if value < 0x80000000 else (0x100000000 - value) & M32


def mix1(x):
    z = (0xBF58476D1CE4E5B9 * (x ^ (x >> 30))) & M64
    return z ^ (z >> 27)


def rs(seed, n, salt):
    if not n or not seed:
        return 0
    B = (0x94D049BB133111EB * mix1(salt % 1000)) & M64
    v = ((0x94D049BB133111EB * mix1(seed)) & M64) ^ B
    t = (v ^ (v >> 31)) & M64
    w = (0xBF58476D1CE4E5B9 * (t ^ (t >> 30))) & M64
    u = (w ^ (w >> 27)) & M64
    r = (((321982955 * u) & M64) ^ (((0x94D049BB133111EB * u) & M64) >> 31)) & M64
    return (r & 0xFFFF) % n


POOLS = {
    'School': ['BP23', 'BP24', 'BP25', 'BP27_3', 'BP26', 'BP29', 'BP28', 'BP16',
               'BP17', 'BP15', 'BP13', 'BP14', 'BP4', 'BP6', 'BP7', 'BP5',
               'BP19_22', 'BP19', 'BP21', 'BP20', 'BP22', 'BP11', 'BP12', 'BP10',
               'BP8', 'BP9'],
    'SasExit': ['BP30', 'BP31', 'BP33', 'BP32', 'BP35', 'BP34', 'BP38', 'BP39',
                'BP40', 'BP41', 'BP42', 'BP43', 'BP44', 'BP37', 'BP36', 'BP45',
                'BP46', 'BP47', 'BP48'],
}
COORD = {
    'School': 'SRR_MT02_OrderedClueFrequency_School',
    'SasExit': 'SRR_MT02_OrderedClueFrequency_SasExit',
}
CLUES6 = ['Bunny', 'Heart', 'Moon', 'Spade', 'Club', 'Diamond']

PAIRS = {
    ('School', 417417): {'BP24': 'Diamond', 'BP26': 'Heart', 'BP29': 'Spade',
                         'BP6': 'Club', 'BP5': 'Bunny', 'BP19': 'Moon'},
    ('School', 737737): {'BP25': 'Moon', 'BP27_3': 'Bunny', 'BP5': 'Spade',
                         'BP21': 'Club', 'BP11': 'Heart', 'BP8': 'Diamond'},
    ('SasExit', 417417): {'BP31': 'Heart', 'BP38': 'Club', 'BP43': 'Diamond',
                          'BP36': 'Bunny', 'BP45': 'Moon', 'BP47': 'Spade'},
    ('SasExit', 737737): {'BP30': 'Diamond', 'BP33': 'Spade', 'BP40': 'Moon',
                          'BP37': 'Club', 'BP45': 'Heart', 'BP47': 'Bunny'},
}


def want_seq(key, seed):
    pool = POOLS[key]
    d = PAIRS[(key, seed)]
    picks = sorted(d, key=lambda a: pool.index(a))
    return [d[a] for a in picks]


def seq_of(key, base, off, salt):
    cp = list(CLUES6)
    out = []
    for i in range(6):
        k = rs((base + off + i) & M32, len(cp), salt)
        out.append(cp[k])
        cp[k] = cp[-1]
        cp.pop()
    return out


def main():
    span = int(sys.argv[1]) if len(sys.argv) > 1 else 300000
    for key in ('School', 'SasExit'):
        base = seed_of_object(COORD[key])
        w1 = want_seq(key, 417417)
        w2 = want_seq(key, 737737)
        print('%s  base=0x%08X' % (key, base))
        print('   目标 417: %s' % w1)
        print('   目标 737: %s' % w2)
        hits = []
        for off in range(span):
            if seq_of(key, base, off, 417417) != w1:
                continue
            if seq_of(key, base, off, 737737) != w2:
                continue
            hits.append(off)
        print('   offset 命中: %s' % (hits[:10] if hits else '无'))
        # 顺带看只命中单个 seed 的数量，判断是不是纯噪声
        n1 = sum(1 for off in range(span)
                 if seq_of(key, base, off, 417417) == w1)
        print('   （只匹配 417 的 offset 数 = %d，期望 %.1f）' % (n1, span / 720.0))


if __name__ == '__main__':
    main()
