# -*- coding: utf-8 -*-
"""在函数范围内找出所有除法/取模指令（div / idiv），用来定位 RNG 的 "mod 剩余"。

    python scan_div.py 0x1402B05C0 0x1402B28B2
"""
import sys
import os

_HERE = os.path.dirname(os.path.abspath(__file__))
sys.path.insert(0, _HERE)
import scan_disp as sd


def main():
    lo = int(sys.argv[1], 16)
    hi = int(sys.argv[2], 16)
    off = sd.va2off(lo)
    code = sd.d[off:off + (hi - lo)]
    hits = []
    i = 0
    n = len(code)
    while i < n - 2:
        b = code[i]
        if b in (0xF7, 0xF6):
            modrm = code[i + 1]
            reg = (modrm >> 3) & 7
            if reg in (6, 7):
                hits.append((lo + i, 'idiv' if reg == 6 else 'div',
                             '64' if (i > 0 and code[i - 1] == 0x48) else '32'))
        i += 1
    print('=== %X..%X 共 %d 条 div/idiv' % (lo, hi, len(hits)))
    for va, kind, w in hits:
        print('  %X  %s%s' % (va, kind, w))


if __name__ == '__main__':
    main()
