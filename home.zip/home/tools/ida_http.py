# -*- coding: utf-8 -*-
"""直连 IDA 的 MCP 插件（127.0.0.1:13337）的 JSON-RPC 客户端。

REA 的 ida provider 本轮不可用（upstream ida_pro_mcp server 进程崩了），
但 IDA GUI 里的 MCP 插件端口是通的，于是绕过 REA 直接走 HTTP。

用法:
    python tools/ida_http.py meta
    python tools/ida_http.py dec 0x14361C230            # 反编译，结果写 _ida_out.txt
    python tools/ida_http.py dec 0x14361C230 --out x.c
    python tools/ida_http.py dis 0x14361C230            # 反汇编
    python tools/ida_http.py callers 0x14361CA08
    python tools/ida_http.py callees 0x14361C230
    python tools/ida_http.py xrefs 0x14665E254
    python tools/ida_http.py bytes 0x14361C230 64
    python tools/ida_http.py raw decompile_function 0x14361C230
"""
import sys
import json
import http.client


HOST = '127.0.0.1'
PORT = 13337
_rid = [0]


def rpc(method, *params):
    _rid[0] += 1
    body = {'jsonrpc': '2.0', 'method': method, 'params': list(params), 'id': _rid[0]}
    conn = http.client.HTTPConnection(HOST, PORT, timeout=180)
    try:
        conn.request('POST', '/mcp', json.dumps(body), {'Content-Type': 'application/json'})
        data = json.loads(conn.getresponse().read().decode('utf-8'))
    finally:
        conn.close()
    if 'error' in data:
        raise RuntimeError('RPC %s 失败: %s' % (method, data['error']))
    return data['result']


def _s(x):
    if isinstance(x, str):
        return x
    return json.dumps(x, ensure_ascii=False, indent=1)


def main(argv):
    if not argv:
        print(__doc__)
        return 0
    cmd = argv[0]
    args = [a for a in argv[1:] if not a.startswith('--')]
    out = None
    for i, a in enumerate(argv):
        if a == '--out':
            out = argv[i + 1]
    if out in args:
        args.remove(out)
    addr = args[0] if args else None

    if cmd == 'meta':
        text = _s(rpc('get_metadata'))
    elif cmd == 'dec':
        text = rpc('decompile_function', addr)
    elif cmd == 'dis':
        text = rpc('disassemble_function', addr)
    elif cmd == 'callers':
        text = _s(rpc('get_callers', addr))
    elif cmd == 'callees':
        text = _s(rpc('get_callees', addr))
    elif cmd == 'xrefs':
        text = _s(rpc('get_xrefs_to', addr))
    elif cmd == 'bytes':
        n = int(args[1]) if len(args) > 1 else 32
        text = _s(rpc('read_memory_bytes', addr, n))
    elif cmd == 'raw':
        text = _s(rpc(args[0], *args[1:]))
    else:
        print(__doc__)
        return 2

    if isinstance(text, (dict, list)):
        text = json.dumps(text, ensure_ascii=False, indent=1)

    if out:
        with open(out, 'w', encoding='utf-8') as f:
            f.write(text)
        print('写入 %s（%d 字节）' % (out, len(text)))
    else:
        try:
            sys.stdout.reconfigure(encoding='utf-8')
        except Exception:
            pass
        print(text)
    return 0


if __name__ == '__main__':
    sys.exit(main(sys.argv[1:]))
