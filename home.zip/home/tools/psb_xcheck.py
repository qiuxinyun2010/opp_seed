# -*- coding: utf-8 -*-
"""C ↔ Python 排序器转录交叉校验：给定 L / seed / model / inv，打印同样 4 行。"""
import sys, os
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.abspath(__file__))))
sys.stdout.reconfigure(encoding='utf-8')
from psb_sort import crc32_fname, seed_of_object, rand_seeded, hi16, intro_sort, P
import psb_mt01_static as S
import psb_mt01 as M

B, OK, OC = M.B, M.OFF_KEY, M.OFF_CORPSE
GROUPS = M.GROUPS
NAMES = [c['actor'] for c in S.CORPSES]
SEC = [c['sector'] for c in S.CORPSES]


def run(L, seed, model=0, inv=0):
    salt = seed % 1000
    seeds = [seed_of_object(n, L) for n in NAMES]
    hotv = [hi16(s, salt) ^ inv for s in seeds]
    if model == 0:
        a = list(range(len(NAMES)))
        intro_sort(a, lambda i: hotv[i])
        grp = {s: [] for s in 'ABC'}
        for i in a:
            grp[SEC[i]].append(i)
    else:
        grp = {}
        for s in 'ABC':
            a = [i for i in range(len(NAMES)) if SEC[i] == s]
            intro_sort(a, lambda i: hotv[i])
            grp[s] = a
    print('P L=0x%08X seed=%d model=%d inv=%d' % (L, seed, model, inv))
    for s in 'ABC':
        print('  sec %s:' % s, ' '.join(NAMES[i].replace(P, '') for i in grp[s]))
    pool = list(M.POOL)
    V = 0
    for sec, cnt in GROUPS:
        mem = list(grp[sec])
        for j in range(cnt):
            pick = rand_seeded((B + OC + V + j) & 0xFFFFFFFF, len(mem), salt)
            act = mem.pop(pick)
            ki = rand_seeded((B + OK + V + j) & 0xFFFFFFFF, len(pool), salt)
            pat = pool.pop(ki)
            print('  V=%d sec=%s j=%d pat=%s actor=%s' % (V, sec, j, pat, NAMES[act].replace(P, '')))
            V += 1


if __name__ == '__main__':
    L = int(sys.argv[1], 16) if len(sys.argv) > 1 else 0x4C09CC22
    seed = int(sys.argv[2]) if len(sys.argv) > 2 else 378378
    model = int(sys.argv[3]) if len(sys.argv) > 3 else 0
    inv = int(sys.argv[4]) if len(sys.argv) > 4 else 0
    run(L, seed, model, inv)
