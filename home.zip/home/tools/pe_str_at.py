# -*- coding: utf-8 -*-
"""读 PE 里某个 VA 处的 ASCII / UTF-16 字符串（用于 pe_scan.py find 的命中地址）。

用法:
    python pe_str_at.py 0x14661858A [0x... ...]        # 每个地址打印 ascii + utf16
    python pe_str_at.py 0x14661858A --wide             # 只读 UTF-16
"""
import struct
import sys

PATH = r"d:\workspace\outlast\TOTClient-Win64-Shipping.exe"
D = open(PATH, "rb").read()

_pe = struct.unpack_from("<I", D, 0x3C)[0]
_nsec = struct.unpack_from("<H", D, _pe + 6)[0]
_opt = _pe + 24
_magic = struct.unpack_from("<H", D, _opt)[0]
BASE = (struct.unpack_from("<Q", D, _opt + 24)[0] if _magic == 0x20B
        else struct.unpack_from("<I", D, _opt + 28)[0])
_secoff = _opt + struct.unpack_from("<H", D, _pe + 20)[0]
SECS = []
for _i in range(_nsec):
    _o = _secoff + 40 * _i
    _name = D[_o:_o + 8].rstrip(b"\x00").decode("latin1")
    _vsize, _va, _rawsize, _rawptr = struct.unpack_from("<IIII", D, _o + 8)
    SECS.append((_name, _va, _vsize, _rawptr, _rawsize))


def va2off(va):
    rva = va - BASE
    for _name, _sva, _vsize, _rawptr, _rawsize in SECS:
        if _sva <= rva < _sva + max(_vsize, _rawsize):
            return _rawptr + (rva - _sva)
    return None


def rd(va, n):
    off = va2off(va)
    return b"" if off is None else D[off:off + n]


def ascii_at(va, limit=200):
    b = rd(va, limit)
    end = b.find(b"\x00")
    return b[:end if end >= 0 else limit].decode("latin1", "replace")


def wide_at(va, limit=200):
    b = rd(va, limit * 2)
    end = 0
    while end + 1 < len(b) and b[end:end + 2] != b"\x00\x00":
        end += 2
    return b[:end].decode("utf-16-le", "replace")


def main(argv):
    wide_only = "--wide" in argv
    for a in [x for x in argv[1:] if not x.startswith("--")]:
        va = int(a, 16)
        if wide_only:
            print("%s  %s" % (a, wide_at(va)))
        else:
            print("%s  ascii=%r  utf16=%r" % (a, ascii_at(va), wide_at(va)))
    return 0


if __name__ == "__main__":
    try:
        sys.stdout.reconfigure(encoding="utf-8")
    except Exception:
        pass
    sys.exit(main(sys.argv))
