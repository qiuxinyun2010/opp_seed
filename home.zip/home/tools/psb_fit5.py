# -*- coding: utf-8 -*-
"""PSB_MT01 第五轮：验证 sub_14361CFA0 分支（每区单独抽 1 个钥匙图案）。

已知结构：
    v54 = GetSeed(coord) + 223551
    idx = RandSeeded(v54 + v9, |pool1|)      v9 = 第 i 个 ObjectiveActor(KID) 的序号
    RemoveAt(pool1, idx)                     池 = QuestItemClasses
样本：
    111111 → A=Star B=Bunny C=Diamond
    565565 → A=Heart B=Club C=Eye
"""
import itertools
import os
import sys

sys.path.insert(0, os.path.abspath(os.path.join(os.path.dirname(__file__), '..', '..', 'seed')))
import seedcore as sc  # noqa: E402

ORDERS = {
    'ADR': ['Bunny', 'Club', 'Diamond', 'Fire', 'Heart', 'Spade', 'Crown', 'Eye', 'Moon', 'Star'],
    'MAP': ['Bunny', 'Club', 'Diamond', 'Fire', 'Heart', 'Spade', 'Eye', 'Star', 'Crown', 'Moon'],
}

SAMPLES = [
    (111111, ['Star', 'Bunny', 'Diamond']),
    (565565, ['Heart', 'Club', 'Eye']),
]

LVL = 'PersistentLevel'
COORD = 'PSB_MT01_B01_CorpseSearch_3'
KIDS = ['KeyItemDestination_Device_Base_BP2',
        'KeyItemDestination_Device_Base_BP3',
        'KeyItemDestination_Device_Base_BP_2']


def draw(pool_names, base, salt, offsets, remove='order'):
    pool = list(pool_names)
    out = []
    for i in range(3):
        n = len(pool)
        idx = sc.rand_seeded((base + offsets[i]) & 0xFFFFFFFF, n, salt)
        out.append(pool[idx])
        if remove == 'order':
            pool.pop(idx)
        elif remove == 'swap':
            pool[idx] = pool[-1]
            pool.pop()
        else:
            pass
    return out


def main():
    lvl = sc.crc32_fname(LVL)
    coord = sc.seed_of_object(COORD, lvl)
    kid_seeds = [sc.seed_of_object(k, lvl) for k in KIDS]
    salt_names = ['QuestItemClasses', 'Clue', 'Clues', 'Objective Actors', 'Spawner Actors']

    bases = {
        'coord+223551': (coord + 223551) & 0xFFFFFFFF,
        'coord': coord,
        'coord+924519': (coord + 924519) & 0xFFFFFFFF,
        'coord+264069': (coord + 264069) & 0xFFFFFFFF,
    }
    for nm in salt_names:
        bases['coord+crc(%s)+223551' % nm] = (coord + sc.crc32_fname(nm) + 223551) & 0xFFFFFFFF
    for i, ks in enumerate(kid_seeds):
        bases['kid%d+223551' % (i + 1)] = (ks + 223551) & 0xFFFFFFFF
        bases['coord+kid%d+223551' % (i + 1)] = (coord + ks + 223551) & 0xFFFFFFFF

    off_sets = {
        'i': [0, 1, 2],
        'i+1': [1, 2, 3],
        '2i': [0, 2, 4],
        'kid_seed': None,
    }

    print('=== 全局 base + 偏移 ===')
    for bn, base in bases.items():
        for on, offs in off_sets.items():
            if offs is None:
                continue
            for pn, pool in ORDERS.items():
                for rm in ('order', 'swap', 'none'):
                    ok = True
                    for seed, want in SAMPLES:
                        got = draw(pool, base, seed % 1000, offs, rm)
                        if got != want:
                            ok = False
                            break
                    if ok:
                        print('  HIT base=%s off=%s pool=%s remove=%s' % (bn, on, pn, rm))

    print('=== 每个 KID 独立 base ===')
    for bn, basef in {
        'kid+223551': lambda i: (kid_seeds[i] + 223551) & 0xFFFFFFFF,
        'coord+kid+223551': lambda i: (coord + kid_seeds[i] + 223551) & 0xFFFFFFFF,
    }.items():
        for pn, pool in ORDERS.items():
            for rm in ('order', 'swap', 'none'):
                ok = True
                for seed, want in SAMPLES:
                    salt = seed % 1000
                    p = list(pool)
                    got = []
                    for i in range(3):
                        idx = sc.rand_seeded(basef(i), len(p), salt)
                        if idx >= len(p):
                            idx %= len(p)
                        got.append(p[idx])
                        if rm == 'order':
                            p.pop(idx)
                        elif rm == 'swap':
                            p[idx] = p[-1]
                            p.pop()
                    if got != want:
                        ok = False
                        break
                if ok:
                    print('  HIT base=%s pool=%s remove=%s' % (bn, pn, rm))


if __name__ == '__main__':
    main()
