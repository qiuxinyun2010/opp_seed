# -*- coding: utf-8 -*-
"""闭合 Q2：用 GetSeed(尸体) 的确定性 intro-sort 复刻「候选组初始顺序」。

关键结论（本轮敲定）：
  GetSeed(尸体) = |crc32_fname(尸体 FName) + crc32_fname('PersistentLevel')|
  即 seed_of_object(actor, crc32_fname('PersistentLevel'))。
  证据：尸体 Outer = Level'PSB_MT01_B01:PersistentLevel'（map JSON 实测）。

  hot(尸体) = (mix64(GetSeed(尸体), seed) & 0xFFFF) >= 0x8000   （sub_1413F02F0）
  排序 = sub_14361C230 开头的 MSVC intro-sort（psb_sort.intro_sort）。

用法：
  python tools/psb_sortfit.py             # 用 12 条实测约束校验（378378 9 条 + 565565 3 条）
  python tools/psb_sortfit.py 378378      # 打印该 seed 每区排序后的尸体顺序
"""
import sys, os
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.abspath(__file__))))
import psb_sort as ps
import psb_mt01_static as S

P = 'CorpseSearch_PS_Trial02_'
LEVEL_NAME = 'PersistentLevel'
L = ps.crc32_fname(LEVEL_NAME)

# 12 条实测约束：seed -> 扇区 -> {候选组初始下标: 尸体短名}
# 注意：旧 §6 表有 4 处错误（psb_check.py 的 per-sector 图案池 bug 所致），已按
# psb_corpses.py（共享图案池，与 psb_model.py 一致）重推：
#   A[12] 378378 王冠 = BP3_8（非 AgainstWall_BP3_8）
#   C[11] = WallThroat_BP8_32（非 C[6]）；C[0] = BP7_2（非 C[9]）
#   B[7] = AgainstWall_BP5_2 作废：该尸体属 C 区（KID=BP_2），无法显示 B 区「方块」
CONSTRAINTS = {
    378378: {
        'A': {3: 'AgainstWall_BP2_5', 4: 'AgainstWall_BP_2', 12: 'BP3_8'},
        'B': {0: 'Desk_BP2_2', 4: 'WallThroat_BP7_26', 5: 'Desk_BP_5'},
        'C': {0: 'BP7_2', 9: 'OnChair_BP3_8', 11: 'WallThroat_BP8_32'},
    },
    565565: {
        'A': {12: 'AgainstWall_BP3_8'},
        'B': {5: 'BP10_35'},
        'C': {10: 'AgainstWall_BP9_2'},
    },
}

SECTOR_OF = {c['actor']: c['sector'] for c in S.CORPSES}


def get_seed(actor):
    return ps.seed_of_object(actor, L)


def sorted_sectors(seed, actors=None, trace=False):
    """seed -> {'A': [尸体短名...], 'B': [...], 'C': [...]}（排序后、按扇区分组）。"""
    arr = [a for a in (actors or [c['actor'] for c in S.CORPSES])]
    if trace:
        print('  [sort input n=%d] %s' % (len(arr), [a.replace(P, '') for a in arr]))
    ps.intro_sort(arr, lambda a: ps.hi16(get_seed(a), seed))
    out = {}
    for a in arr:
        out.setdefault(SECTOR_OF[a], []).append(a.replace(P, ''))
    return out


def check(verbose=True):
    total = 0
    good = 0
    for seed, cons in sorted(CONSTRAINTS.items()):
        secs = sorted_sectors(seed)
        for sec, slots in cons.items():
            for idx, want in slots.items():
                total += 1
                got = secs[sec][idx] if idx < len(secs[sec]) else '?'
                ok = (got == want)
                good += 1 if ok else 0
                if verbose:
                    print('  seed %-7d %s[%2d] = %-20s 期望 %-20s %s'
                          % (seed, sec, idx, got, want, 'OK' if ok else 'MISMATCH'))
    print('约束命中：%d/%d' % (good, total))
    return good == total


def show(seed):
    print('seed %d  salt %d   level_name=%s (L=0x%08X)' % (seed, seed % 1000, LEVEL_NAME, L))
    secs = sorted_sectors(seed)
    for sec in 'ABC':
        print('  Sector %s (%d 具):' % (sec, len(secs[sec])))
        for i, a in enumerate(secs[sec]):
            mark = ''
            for sd, cons in CONSTRAINTS.items():
                if sd == seed and a == cons.get(sec, {}).get(i):
                    mark = '   << 约束命中'
            print('    %2d  %s%s' % (i, a, mark))


def fit_level_names():
    """遍历候选 level_name / salt，报告每条实测约束的命中情况，定位偏差来源。"""
    names = ['PersistentLevel', 'PersistentLevel_0', 'PSB_MT01_B01',
             'PSB_MT01_B00', 'PSB_MT01', 'PSB_MT01_B01.PersistentLevel',
             'PSB_MT01_B01:PersistentLevel', 'FileName', 'World']
    seeds = sorted(CONSTRAINTS)
    best = []
    for name in names:
        Lv = ps.crc32_fname(name)
        for salt_mode in ('seed', 'seed%1000', '0'):
            good = 0
            detail = []
            for seed, cons in CONSTRAINTS.items():
                salt = seed if salt_mode == 'seed' else (seed % 1000 if salt_mode == 'seed%1000' else 0)
                arr = [c['actor'] for c in S.CORPSES]
                ps.intro_sort(arr, lambda a: ps.hi16(
                    ps.seed_of_object(a, Lv), salt))
                for sec, slots in cons.items():
                    for idx, want in slots.items():
                        lst = [a for a in arr if SECTOR_OF[a] == sec]
                        got = lst[idx].replace(P, '') if idx < len(lst) else '?'
                        if got == want:
                            good += 1
            best.append((good, name, salt_mode))
            print('  %-30s salt=%-9s 命中 %d/7' % (name, salt_mode, good))
    best.sort(reverse=True)
    print('最佳：%s' % (best[0],))
    return best[0]


if __name__ == '__main__':
    try:
        sys.stdout.reconfigure(encoding='utf-8')
    except Exception:
        pass
    if len(sys.argv) > 1 and sys.argv[1] == 'fit':
        print('crc32_fname(\'PersistentLevel\') = 0x%08X (期望 0x4C09CC22)'
              % ps.crc32_fname('PersistentLevel'))
        fit_level_names()
    elif len(sys.argv) > 1 and sys.argv[1].isdigit():
        show(int(sys.argv[1]))
    else:
        print('level_name=%r  L=crc32_fname=0x%08X' % (LEVEL_NAME, L))
        print('crc32_fname(\'PersistentLevel\') 校验 = 0x%08X (期望 0x4C09CC22)'
              % ps.crc32_fname('PersistentLevel'))
        check()
