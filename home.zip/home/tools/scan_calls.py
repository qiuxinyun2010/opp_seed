# -*- coding: utf-8 -*-
"""全局扫 .text 里对所有指定被调函数的 E8 相对调用，按函数入口归类。

    python scan_calls.py 0x1402D29E0 0x1401A0F00
"""
import struct
import sys
import os

_HERE = os.path.dirname(os.path.abspath(__file__))
sys.path.insert(0, _HERE)
import scan_disp as sd


def main():
    targets = set(int(a, 16) for a in sys.argv[1:])
    name, sva, vsize, rawptr, rawsize = sd.sec('.text')
    base = sd.image_base + sva
    data = sd.d
    lo = rawptr
    hi = rawptr + vsize
    hits = {}
    i = data.find(b'\xe8', lo, hi)
    n = 0
    while i >= 0:
        rel = struct.unpack_from('<i', data, i + 1)[0]
        va = base + (i - lo)
        tgt = va + 5 + rel
        if tgt in targets:
            c = sd.containing(va)
            if c:
                hits.setdefault((c[0], tgt), 0)
                hits[(c[0], tgt)] += 1
            n += 1
        i = data.find(b'\xe8', i + 1, hi)
    print('命中 %d 处，%d 个 (函数, 被调) 组合' % (n, len(hits)))
    for (fn, tgt) in sorted(hits):
        c = sd.containing(fn)
        print('  0x%X  size 0x%-6X -> %X  (%d 次)'
              % (fn, c[1] - c[0], tgt, hits[(fn, tgt)]))


if __name__ == '__main__':
    main()
