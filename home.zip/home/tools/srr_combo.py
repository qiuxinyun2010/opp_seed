# -*- coding: utf-8 -*-
"""不扫偏移，只测「具体的 base / salt 组合」× 各类算法。

2^32 全扫已证明「base = GetSeed(协调器) + 任意偏移」配上五种算法都不成立，
所以剩下的可能是：base 里掺了 level_seed（CHJ 里没有，但 SRR 未必），
或 salt 不是 level_seed % 1000。这些都是**具体**组合，不用扫。
"""
import sys

M32 = 0xFFFFFFFF
M64 = 0xFFFFFFFFFFFFFFFF

_T = []
for _i in range(256):
    _c = _i
    for _ in range(8):
        _c = ((_c >> 1) ^ 0xEDB88320) if (_c & 1) else (_c >> 1)
    _T.append(_c & M32)


def crc32_fname(text):
    crc = M32
    for ch in text:
        u = ord(ch) & 0xFFFF
        crc = _T[(crc ^ (u & 0xFF)) & 0xFF] ^ (crc >> 8)
        crc = _T[(crc ^ (u >> 8)) & 0xFF] ^ (crc >> 8)
        crc = _T[crc & 0xFF] ^ (crc >> 8)
        crc = _T[crc & 0xFF] ^ (crc >> 8)
    return (~crc) & M32


def seed_of_object(name):
    value = (crc32_fname(name) + crc32_fname('PersistentLevel')) & M32
    return value if value < 0x80000000 else (0x100000000 - value) & M32


def mix1(x):
    z = (0xBF58476D1CE4E5B9 * (x ^ (x >> 30))) & M64
    return z ^ (z >> 27)


def rs(seed, n, salt):
    if not n or not seed:
        return 0
    B = (0x94D049BB133111EB * mix1(salt % 1000)) & M64
    v = ((0x94D049BB133111EB * mix1(seed)) & M64) ^ B
    t = (v ^ (v >> 31)) & M64
    w = (0xBF58476D1CE4E5B9 * (t ^ (t >> 30))) & M64
    u = (w ^ (w >> 27)) & M64
    r = (((321982955 * u) & M64) ^ (((0x94D049BB133111EB * u) & M64) >> 31)) & M64
    return (r & 0xFFFF) % n


sys.path.insert(0, '.')
import srr_mt02 as M

POOLS = {k: M.COORDS[k]['pool'] for k in ('RichDistrict', 'School', 'SasExit')}
COORD = {k: M.COORDS[k]['actor'] for k in ('RichDistrict', 'School', 'SasExit')}
POS = {k: M.TUNERS[k][1] for k in M.TUNERS}
SET6 = {
    ('School', 417417): {'BP5', 'BP6', 'BP19', 'BP24', 'BP26', 'BP29'},
    ('School', 737737): {'BP5', 'BP8', 'BP11', 'BP21', 'BP25', 'BP27_3'},
    ('SasExit', 417417): {'BP45', 'BP43', 'BP31', 'BP38', 'BP36', 'BP47'},
    ('SasExit', 737737): {'BP30', 'BP33', 'BP37', 'BP45', 'BP40', 'BP47'},
}
TARGET3 = {
    ('School', 417417): ['BP24', 'BP26', 'BP5'],
    ('School', 737737): ['BP21', 'BP25', 'BP11'],
    ('SasExit', 417417): ['BP43', 'BP45', 'BP36'],
    ('SasExit', 737737): ['BP40', 'BP45', 'BP30'],
}
SALT_CRC = crc32_fname('Objective Actors')


def d2(a, b):
    pa, pb = POS[a], POS[b]
    return (pa[0] - pb[0]) ** 2 + (pa[1] - pb[1]) ** 2 + (pa[2] - pb[2]) ** 2


def draw(key, base, mode, salt, n=6, rev=False, thr=0.0):
    pool = list(POOLS[key])
    if rev:
        pool.reverse()
    out = []
    if mode in ('plain', 'rm'):
        mem = list(pool)
        for i in range(n):
            k = rs((base + i) & M32, len(mem), salt)
            out.append(mem[k])
            if mode == 'plain':
                mem[k] = mem[-1]
                mem.pop()
            else:
                del mem[k]
    elif mode == 'fy':
        mem = list(pool)
        for i in range(len(mem), 1, -1):
            j = rs((base + (len(mem) - i)) & M32, i, salt)
            mem[i - 1], mem[j] = mem[j], mem[i - 1]
        out = mem[:n]
    elif mode == 'dist':
        mem = list(pool)
        t2 = thr * thr
        for i in range(n):
            if not mem:
                break
            k = rs((base + i) & M32, len(mem), salt)
            pick = mem[k]
            out.append(pick)
            mem[k] = mem[-1]
            mem.pop()
            mem = [x for x in mem if d2(x, pick) >= t2]
    return out


def base_variants(kind, key, level_seed):
    g = seed_of_object(COORD[key])
    ls = level_seed & M32
    return {
        'g': g,
        'g+saltCrc': (g + SALT_CRC) & M32,
        'g+ls': (g + ls) & M32,
        'g^ls': (g ^ ls) & M32,
        'g+ls%1000': (g + ls % 1000) & M32,
        'g*ls': (g * ls) & M32,
        'ls': ls,
        'g+503': (g + 503) & M32,
    }.get(kind)


def main():
    kinds = ('g', 'g+saltCrc', 'g+ls', 'g^ls', 'g+ls%1000', 'g*ls', 'ls', 'g+503')
    for kind in kinds:
        for mode in ('plain', 'rm', 'fy', 'dist'):
            for rev in (False, True):
                thr = 1000.0 if mode == 'dist' else 0.0
                res = []
                for key in ('School', 'SasExit'):
                    ok_set, ok_t3 = True, True
                    for seed in (417417, 737737):
                        b = base_variants(kind, key, seed)
                        got = draw(key, b, mode, seed, rev=rev, thr=thr)
                        if set(got) != SET6[(key, seed)]:
                            ok_set = False
                        if got[:3] != TARGET3[(key, seed)]:
                            ok_t3 = False
                    res.append('%s:%s%s' % (key, '集' if ok_set else '', '序' if ok_t3 else ''))
                s = ' '.join(res)
                if '集' in s or '序' in s:
                    print('★ %-10s %-5s rev=%-5s  %s' % (kind, mode, rev, s))
                    for key in ('School', 'SasExit'):
                        b = base_variants(kind, key, 417417)
                        print('     %s 417 前6=%s' % (key, draw(key, b, mode, 417417, rev=rev, thr=thr)))
    print('（无 ★ 即全部不匹配）')


if __name__ == '__main__':
    main()
