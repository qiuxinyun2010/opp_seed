# -*- coding: utf-8 -*-
"""生成 psb_mt01_static.py（PSB_MT01 固化静态表）。

数据来源（只读）：
  pak/OPP/Content/Maps_json/PoliceStationBasement/PSB_MT01_B00.json   协调器 / 3 个锁位
  pak/OPP/Content/Maps_json/PoliceStationBasement/PSB_MT01_B01.json   41 具尸体 / 电视
  pak/OPP/Content/LD/Operatable/CorpseSearch/CorpseSearch_BP.json     图案 → 贴图
  opp_seed/ui/data/maps/PSB_MT01.json                                 房间 hull / 区域 / 点位
  release/seed/seedcore.py                                            随机原语

用法：python tools/psb_gen.py
"""
import json
import os
import sys

HERE = os.path.dirname(os.path.abspath(__file__))
HOME = os.path.dirname(HERE)
ROOT = os.path.dirname(os.path.dirname(HOME))
MJDIR = os.path.join(ROOT, 'pak', 'OPP', 'Content', 'Maps_json', 'PoliceStationBasement')
UIDIR = os.path.join(ROOT, 'opp_seed', 'ui', 'data', 'maps')

CORPSE_TYPES = ('CorpseSearch_PS_Trial02_BP_C',
                'CorpseSearch_PS_Trial02_AgainstWall_BP_C',
                'CorpseSearch_PS_Trial02_WallThroat_BP_C',
                'CorpseSearch_PS_Trial02_OnChair_BP_C',
                'CorpseSearch_PS_Trial02_Desk_BP_C')

TARGET_TO_SECTOR = {
    'KeyItemDestination_Device_Base_BP2': 'A',
    'KeyItemDestination_Device_Base_BP3': 'B',
    'KeyItemDestination_Device_Base_BP_2': 'C',
}


def load(name):
    with open(os.path.join(MJDIR, name), encoding='utf-8') as fp:
        return json.load(fp)


def main():
    try:
        sys.stdout.reconfigure(encoding='utf-8')
    except Exception:
        pass

    b00 = load('PSB_MT01_B00.json')
    b01 = load('PSB_MT01_B01.json')
    uimap = json.load(open(os.path.join(UIDIR, 'PSB_MT01.json'), encoding='utf-8'))
    clue = json.load(open(os.path.join(
        ROOT, 'pak', 'OPP', 'Content', 'LD', 'Operatable', 'CorpseSearch',
        'CorpseSearch_BP.json'), encoding='utf-8'))
    cdo = [o for o in clue if isinstance(o, dict) and o.get('Name') == 'Default__CorpseSearch_BP_C'][0]

    # ---- 3 个锁位（扇区 A/B/C 的顺序 = ObjectiveActors 顺序）----
    coord = [o for o in b00 if isinstance(o, dict) and o.get('Name') == 'PSB_MT01_B01_CorpseSearch_3'][0]
    kids = [a['SubPathString'].split('.')[-1] for a in coord['Properties']['ObjectiveActors']]
    sectors = []
    for i, kid in enumerate(kids):
        sec = TARGET_TO_SECTOR[kid]
        pts = [p for p in uimap['points'] if p['actor'] == kid]
        tv = None
        for o in b01:
            if isinstance(o, dict) and o.get('Name') == kid:
                tvref = (o.get('Properties') or {}).get('AssociatedTvChannel') or {}
                tv = tvref.get('SubPathString', '').split('.')[-1] or None
        sectors.append({'key': sec, 'kid': kid, 'tv': tv})

    # ---- 41 具尸体（JSON 顺序 = 池顺序）----
    corpses, idx = [], 0
    for o in b01:
        if not isinstance(o, dict) or o.get('Type') not in CORPSE_TYPES:
            continue
        tgt = ((o.get('Properties') or {}).get('SpecificObjectiveActorTarget') or {}).get('SubPathString', '')
        sec = TARGET_TO_SECTOR.get(tgt.split('.')[-1], '?')
        pt = [p for p in uimap['points'] if p['actor'] == o.get('Name')]
        if pt:
            p, room = pt[0]['p'], pt[0]['room']
        else:
            p, room = (0.0, 0.0, 0.0), None
        corpses.append({'i': idx, 'actor': o.get('Name'), 'sector': sec,
                        'room': room, 'p': [round(v, 1) for v in p],
                        'type': o.get('Type').replace('CorpseSearch_PS_Trial02_', '').replace('_BP_C', '')})
        idx += 1

    rooms = {r['id']: [r['raw'], r.get('name_zh') or r.get('name')] for r in uimap['rooms']}

    # ---- 图案池（CluesMapping 顺序，仅用于贴图/中文名）----
    mapping = cdo['Properties']['CluesMapping']
    zh = {'Bunny': '兔子', 'Club': '梅花', 'Diamond': '方块', 'Fire': '火焰', 'Heart': '红心',
          'Spade': '黑桃', 'Crown': '王冠', 'Eye': '眼睛', 'Moon': '月亮', 'Star': '五角星'}

    out = os.path.join(HOME, 'psb_mt01_static.py')
    with open(out, 'w', encoding='utf-8') as fp:
        fp.write('# -*- coding: utf-8 -*-\n')
        fp.write('"""PSB_MT01 固化静态表 —— 由 tools/psb_gen.py 生成，勿手改。\n\n')
        fp.write('数据源：pak/.../PSB_MT01_B00.json、PSB_MT01_B01.json、CorpseSearch_BP.json、\n')
        fp.write('        opp_seed/ui/data/maps/PSB_MT01.json（房间 hull / 点位 → 房间）\n"""\n\n')
        fp.write('SECTORS = %s\n\n' % json.dumps(sectors, ensure_ascii=False, indent=1))
        fp.write('ZONES = %s\n\n' % json.dumps(
            [{'id': z['id'], 'name_zh': z.get('name_zh'), 'note_zh': z.get('note_zh')}
             for z in uimap.get('zones', [])], ensure_ascii=False, indent=1))
        fp.write('# QuestItemClasses 顺序（release/coop/PSB_MT01/evidence/ADDR.md §1，非字母序）\n')
        fp.write('QUEST_ITEM_CLASSES = %s\n\n' % json.dumps(
            ['Bunny', 'Club', 'Diamond', 'Fire', 'Heart', 'Spade', 'Crown', 'Eye', 'Moon', 'Star'],
            ensure_ascii=False))
        fp.write('PATTERN_ZH = %s\n\n' % json.dumps(zh, ensure_ascii=False))
        fp.write('# 图案 → 贴图（CluesMapping 的书写顺序，和 QuestItemClasses 顺序不同）\n')
        fp.write('PATTERN_TEXTURE = %s\n\n' % json.dumps(
            {e['Key']: e['Value']['ObjectName'] for e in mapping}, ensure_ascii=False))
        fp.write('# 41 具尸体：JSON(池)顺序 / 扇区 / 房间 id / 坐标\n')
        fp.write('CORPSES = %s\n\n' % json.dumps(corpses, ensure_ascii=False, indent=0))
        fp.write('ROOMS = %s\n' % json.dumps(rooms, ensure_ascii=False, indent=0))
    print('已写入 %s（%d 具尸体 / %d 个房间）' % (out, len(corpses), len(rooms)))


if __name__ == '__main__':
    main()
