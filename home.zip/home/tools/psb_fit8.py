# -*- coding: utf-8 -*-
"""PSB_MT01 第八轮：把「盐基数」当自由量，扫 2^24。

背景：同类关卡 PSA_MT01 的图案抽取用的是**纯常数**盐（38322 / 45834 / 320239…），
不带协调器种子（见 opp_seed/seed.py §PSA）。所以 PSB 的 `v143` 也可能被
`sub_1402C30C0` 写回成一个与 coord 无关的值。

做法：先过 A 区两条最便宜的约束（图案 = Heart@565565 / Star@111111），
命中率 1/100，再对幸存者做完整模拟。

    base = K                （纯常数候选）
    base = GetSeed(coord)+K （相对候选）
"""
import itertools
import os
import sys

sys.path.insert(0, os.path.abspath(os.path.join(os.path.dirname(__file__), '..', '..', 'seed')))
import seedcore as sc  # noqa: E402

POOL = ['Bunny', 'Club', 'Diamond', 'Fire', 'Heart', 'Spade', 'Crown', 'Eye', 'Moon', 'Star']
SECTOR = {}
_RAW = ('0 A 1 A 2 A 3 C 4 A 5 C 6 C 7 C 8 A 9 B 10 B 11 C 12 C 13 C 14 C '
        '15 A 16 A 17 A 18 A 19 A 20 C 21 B 22 A 23 B 24 B 25 B 26 B 27 C '
        '28 C 29 C 30 C 31 C 32 B 33 A 34 A 35 A 36 B 37 B 38 C 39 C 40 A').split()
for i in range(0, len(_RAW), 2):
    SECTOR[int(_RAW[i])] = _RAW[i + 1]
GROUPS = {s: [i for i in sorted(SECTOR) if SECTOR[i] == s] for s in 'ABC'}

COORD = 'PSB_MT01_B01_CorpseSearch_3'
SCAN = 1 << 22

FACTS = {565565: {'A': (1, 'Heart'), 'B': (0, 'Club'), 'C': (3, 'Eye')},
         111111: {'A': (None, 'Star'), 'B': (None, 'Bunny'), 'C': (None, 'Diamond')}}
CFGS = [(o, c) for o in itertools.permutations('ABC')
        for c in ((3, 3, 3), (3, 3, 4), (3, 4, 3), (4, 3, 3))]


def sim(base, seed, cfg):
    order, counts = cfg
    salt = seed % 1000
    pool = list(POOL)
    v70 = 0
    key = {}
    for sec, cnt in zip(order, counts):
        g = list(GROUPS[sec])
        for v71 in range(cnt):
            ci = sc.rand_seeded((base + 243551 + v71 + v70) & 0xFFFFFFFF, len(g), salt)
            g.pop(ci)
            pi = sc.rand_seeded((base + 223551 + v71 + v70) & 0xFFFFFFFF, len(pool), salt)
            pat = pool.pop(pi)
            if v71 == 0:
                key[sec] = (ci, pat)
            v70 += 1
    return key


def check(base):
    out = []
    for cfg in CFGS:
        ok = True
        for seed, want in FACTS.items():
            r = sim(base, seed, cfg)
            for sec, (wci, wpat) in want.items():
                got = r.get(sec)
                if not got or got[1] != wpat or (wci is not None and got[0] != wci):
                    ok = False
                    break
            if not ok:
                break
        if ok:
            out.append(cfg)
    return out


def main():
    try:
        sys.stdout.reconfigure(encoding='utf-8')
    except Exception:
        pass
    lvl = sc.crc32_fname('PersistentLevel')
    coord = sc.seed_of_object(COORD, lvl)
    s1, s2 = 565565, 111111
    r = sc.rand_seeded
    print('扫 K = 0 .. %d（两种基：纯 K / GetSeed(coord)+K）' % (SCAN - 1))
    npass = 0
    for K in range(SCAN):
        for base in (K, (coord + K) & 0xFFFFFFFF):
            if r((base + 223551) & 0xFFFFFFFF, 10, s1 % 1000) != 4:
                continue
            if r((base + 223551) & 0xFFFFFFFF, 10, s2 % 1000) != 9:
                continue
            npass += 1
            hits = check(base)
            if hits:
                print('  ★ K=%d base=0x%08X cfg=%s' % (K, base, hits))
    print('A 区第一层通过 %d 次' % npass)


if __name__ == '__main__':
    main()
