# -*- coding: utf-8 -*-
"""PSB_MT01 第三轮：按 sub_14361C230 的真实结构拟合。

代码结构（0x14361CA08 / 0x14361CA7C）：
    v143 = GetSeed(coord)（被 sub_1402C30C0 分组器写回，未知加数 d）
    v70  = 已处理尸体总数（跨组累加）
    v71  = 组内序号
    图案 = pool1[ RandSeeded(v143 + 223551 + v71 + v70, |pool1|) ]；保序删除 pool1
    pool1 = QuestItemClasses = [Bunny Club Diamond Fire Heart Spade Crown Eye Moon Star]
    DesiredCount = 10 → 10 具尸体，10 个图案各用一次
"""
import itertools
import os
import sys

sys.path.insert(0, os.path.abspath(os.path.join(os.path.dirname(__file__), '..', '..', 'seed')))
import seedcore as sc  # noqa: E402

POOL = ['Bunny', 'Club', 'Diamond', 'Fire', 'Heart', 'Spade', 'Crown', 'Eye', 'Moon', 'Star']
SECTORS = ['A', 'B', 'C']
GROUP_SIZE = {'A': 15, 'B': 10, 'C': 16}
DESIRED = 10

SAMPLES = [
    (111111, {'A': 'Star', 'B': 'Bunny', 'C': 'Diamond'}),
    (565565, {'A': 'Heart', 'B': 'Club', 'C': 'Eye'}),
]

COORD = 'PSB_MT01_B01_CorpseSearch_3'


def compositions(total, parts):
    if parts == 1:
        yield (total,)
        return
    for i in range(total + 1):
        for rest in compositions(total - i, parts - 1):
            yield (i,) + rest


def simulate(seed, base, order, counts):
    """返回 {(sector, 组内序号): 图案}"""
    salt = seed % 1000
    pool = list(POOL)
    out = {}
    v70 = 0
    for sec, cnt in zip(order, counts):
        if cnt > GROUP_SIZE[sec]:
            return None
        for v71 in range(cnt):
            if not pool:
                return None
            idx = sc.rand_seeded((base + 223551 + v71 + v70) & 0xFFFFFFFF, len(pool), salt)
            out[(sec, v71)] = pool.pop(idx)
            v70 += 1
    return out


def main():
    lvl = sc.crc32_fname('PersistentLevel')
    coord = sc.seed_of_object(COORD, lvl)
    print('GetSeed(coord) = 0x%08X' % coord)

    hits = []
    for d in range(0, 256):
        base = (coord + d) & 0xFFFFFFFF
        for order in itertools.permutations(SECTORS):
            for counts in compositions(DESIRED, 3):
                ok = True
                for seed, want in SAMPLES:
                    res = simulate(seed, base, order, counts)
                    if not res:
                        ok = False
                        break
                    # 假设：每组第一具尸体 = 该扇区的钥匙
                    if any(res.get((s, 0)) != want[s] for s in SECTORS):
                        ok = False
                        break
                if ok:
                    hits.append((d, order, counts))
    print('d/order/counts 命中：%d' % len(hits))
    for h in hits[:40]:
        print('   d=%d order=%s counts=%s' % h)

    # 放宽：不要求组内第一具，只要该组里存在这个图案
    hits2 = []
    for d in range(0, 256):
        base = (coord + d) & 0xFFFFFFFF
        for order in itertools.permutations(SECTORS):
            for counts in compositions(DESIRED, 3):
                ok = True
                for seed, want in SAMPLES:
                    res = simulate(seed, base, order, counts)
                    if not res:
                        ok = False
                        break
                    for s in SECTORS:
                        vals = [v for (k, _), v in res.items() if k == s]
                        if want[s] not in vals:
                            ok = False
                            break
                    if not ok:
                        break
                if ok:
                    hits2.append((d, order, counts))
    print('「组内存在」命中：%d' % len(hits2))
    for h in hits2[:40]:
        print('   d=%d order=%s counts=%s' % h)


if __name__ == '__main__':
    main()
