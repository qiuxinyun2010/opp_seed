# -*- coding: utf-8 -*-
"""用「反推出的真实抽序」定机器抽取算法。

图案序列已由 srr_verify.py 预测（GetSeed(coord)+503+i，逐个抽取+RemoveAtSwap），
结合实测「机器↔图案」配对，可反推出每轮的**真实抽取顺序**（有序 6 元组）：

  School @417417 : BP24 BP5 BP6 BP19 BP29 BP26
  School @737737 : BP25 BP27_3 BP5 BP21 BP11 BP8
  SasExit@417417 : BP47 BP38 BP36 BP43 BP45 BP31
  SasExit@737737 : BP45 BP33 BP37 BP40 BP30 BP47

拿这个有序序列直接比对各种抽取算法（不再只用集合）。
"""
import sys

M32 = 0xFFFFFFFF
M64 = 0xFFFFFFFFFFFFFFFF

_T = []
for _i in range(256):
    _c = _i
    for _ in range(8):
        _c = ((_c >> 1) ^ 0xEDB88320) if (_c & 1) else (_c >> 1)
    _T.append(_c & M32)


def crc32_fname(text):
    crc = M32
    for ch in text:
        u = ord(ch) & 0xFFFF
        crc = _T[(crc ^ (u & 0xFF)) & 0xFF] ^ (crc >> 8)
        crc = _T[(crc ^ (u >> 8)) & 0xFF] ^ (crc >> 8)
        crc = _T[crc & 0xFF] ^ (crc >> 8)
        crc = _T[crc & 0xFF] ^ (crc >> 8)
    return (~crc) & M32


def seed_of_object(name):
    value = (crc32_fname(name) + crc32_fname('PersistentLevel')) & M32
    return value if value < 0x80000000 else (0x100000000 - value) & M32


def mix1(x):
    z = (0xBF58476D1CE4E5B9 * (x ^ (x >> 30))) & M64
    return z ^ (z >> 27)


def rs(seed, n, salt):
    if not n or not seed:
        return 0
    B = (0x94D049BB133111EB * mix1(salt % 1000)) & M64
    v = ((0x94D049BB133111EB * mix1(seed)) & M64) ^ B
    t = (v ^ (v >> 31)) & M64
    w = (0xBF58476D1CE4E5B9 * (t ^ (t >> 30))) & M64
    u = (w ^ (w >> 27)) & M64
    r = (((321982955 * u) & M64) ^ (((0x94D049BB133111EB * u) & M64) >> 31)) & M64
    return (r & 0xFFFF) % n


POOLS = {
    'School': ['BP23', 'BP24', 'BP25', 'BP27_3', 'BP26', 'BP29', 'BP28', 'BP16',
               'BP17', 'BP15', 'BP13', 'BP14', 'BP4', 'BP6', 'BP7', 'BP5',
               'BP19_22', 'BP19', 'BP21', 'BP20', 'BP22', 'BP11', 'BP12', 'BP10',
               'BP8', 'BP9'],
    'SasExit': ['BP30', 'BP31', 'BP33', 'BP32', 'BP35', 'BP34', 'BP38', 'BP39',
                'BP40', 'BP41', 'BP42', 'BP43', 'BP44', 'BP37', 'BP36', 'BP45',
                'BP46', 'BP47', 'BP48'],
}
COORD = {
    'School': 'SRR_MT02_OrderedClueFrequency_School',
    'SasExit': 'SRR_MT02_OrderedClueFrequency_SasExit',
}
CLUE_OFFSET = 503

ORDER = {
    ('School', 417417): ['BP24', 'BP5', 'BP6', 'BP19', 'BP29', 'BP26'],
    ('School', 737737): ['BP25', 'BP27_3', 'BP5', 'BP21', 'BP11', 'BP8'],
    ('SasExit', 417417): ['BP47', 'BP38', 'BP36', 'BP43', 'BP45', 'BP31'],
    ('SasExit', 737737): ['BP45', 'BP33', 'BP37', 'BP40', 'BP30', 'BP47'],
}


def draw_order(key, base, mode, salt, d=6, rev=False):
    pool = list(POOLS[key])
    if rev:
        pool.reverse()
    if mode == 'plain':            # 逐个抽取 + RemoveAtSwap
        mem = list(pool)
        return [take(mem, base, i, salt, True) for i in range(d)]
    if mode == 'rm':               # 逐个抽取 + 保序 RemoveAt
        mem = list(pool)
        return [take(mem, base, i, salt, False) for i in range(d)]
    if mode == 'fy':               # Fisher-Yates 后取前 d
        mem = list(pool)
        for i in range(len(mem), 1, -1):
            j = rs((base + (len(mem) - i)) & M32, i, salt)
            mem[i - 1], mem[j] = mem[j], mem[i - 1]
        return mem[:d]
    if mode == 'popall':           # 逐个取出（n = 剩余），RemoveAtSwap
        mem = list(pool)
        return [take(mem, base, i, salt, True) for i in range(d)]
    raise ValueError(mode)


def take(mem, base, k, salt, swap):
    i = rs((base + k) & M32, len(mem), salt)
    v = mem[i]
    if swap:
        mem[i] = mem[-1]
        mem.pop()
    else:
        del mem[i]
    return v


PAIRS = {
    ('School', 417417): {'BP24': 'Diamond', 'BP5': 'Bunny', 'BP6': 'Club',
                         'BP19': 'Moon', 'BP29': 'Spade', 'BP26': 'Heart'},
    ('School', 737737): {'BP25': 'Moon', 'BP27_3': 'Bunny', 'BP5': 'Spade',
                         'BP21': 'Club', 'BP11': 'Heart', 'BP8': 'Diamond'},
    ('SasExit', 417417): {'BP47': 'Spade', 'BP38': 'Club', 'BP36': 'Bunny',
                          'BP43': 'Diamond', 'BP45': 'Moon', 'BP31': 'Heart'},
    ('SasExit', 737737): {'BP45': 'Heart', 'BP33': 'Spade', 'BP37': 'Club',
                          'BP40': 'Moon', 'BP30': 'Diamond', 'BP47': 'Bunny'},
}
CLUES6 = ['Bunny', 'Heart', 'Moon', 'Spade', 'Club', 'Diamond']


def clue_seq(key, base, off, salt, n=6):
    cp = list(CLUES6)
    out = []
    for i in range(n):
        k = rs((base + off + i) & M32, len(cp), salt)
        out.append(cp[k])
        cp[k] = cp[-1]
        cp.pop()
    return out


def main():
    span = int(sys.argv[1]) if len(sys.argv) > 1 else 1000
    bases = {'coord': {k: seed_of_object(v) for k, v in COORD.items()}}
    bases['+503'] = {k: (b + CLUE_OFFSET) & M32 for k, b in bases['coord'].items()}
    found = False
    for btag, bs in bases.items():
        for off in range(span):
            for mode in ('plain', 'rm', 'fy', 'popall'):
                for rev in (False, True):
                    allok = True
                    for key in ('School', 'SasExit'):
                        for seed in (417417, 737737):
                            o = draw_order(key, bs[key], mode, seed, rev=rev)
                            if sorted(o) != sorted(PAIRS[(key, seed)].keys()):
                                allok = False
                                break
                            cl = clue_seq(key, bs[key], off, seed)
                            if dict(zip(o, cl)) != PAIRS[(key, seed)]:
                                allok = False
                                break
                        if not allok:
                            break
                    if allok:
                        print('★★★ 四组全匹配  base=%s off=%d mode=%s rev=%s'
                              % (btag, off, mode, rev))
                        found = True
    if not found:
        print('无命中（base × off∈[0,%d) × 4 种算法 × 正/倒序）' % span)
    # 无论是否命中，都打印 coord/plain 的实际输出供人工比对
    print('\n--- 对照：base=GetSeed, mode=plain 的预测抽序')
    for key in ('School', 'SasExit'):
        for seed in (417417, 737737):
            print('  %-8s@%d 预测 %s' % (key, seed,
                                          draw_order(key, bases['coord'][key], 'plain', seed)))
            print('  %-8s@%d 实测 %s' % (key, seed, ORDER[(key, seed)]))


if __name__ == '__main__':
    main()
