"""在候选模型族里搜索「seed -> 每回合 2 间房」的模型（FPI_MT02, 1P）。

约束（4 条，随机命中概率 ~1/153^4，极小）：
  189189 : r1={11,14}  r2={1,17}
  346346 : r1={3,6}    r2={9,16}

模型族：idx_j = RandSeeded(C + k*j, pool, salt) ，pool 保序抽走
  - C 遍历 0..LIMIT
  - j 的偏移量 k ∈ {1, 2, 4}
  - 每回合是否重置 pool
  - salt: S%1000 / 0 / S
"""
import sys

sys.path.insert(0, r"d:\workspace\outlast\release")
import seedcore as sc

N = 18
OBS = [
    (189189, {0: {11, 14}, 1: {1, 17}}),
    (346346, {0: {3, 6}, 1: {9, 16}}),
]
LIMIT = 1 << 18


def draw(C, step, reset_pool, salt, per_round=2):
    """返回 {(round, tuple(sorted(rooms)))}"""
    out = {}
    pool = list(range(N))
    for r in range(2):
        if reset_pool:
            pool = list(range(N))
        got = []
        for j in range(per_round):
            seed = (C + step * (r * per_round + j)) & 0xFFFFFFFF
            idx = sc.rand_seeded(seed, len(pool), salt) % len(pool)
            got.append(pool.pop(idx))
        out[r] = tuple(sorted(got))
    return out


def main():
    hits = 0
    for step in (1, 2, 4):
        for reset in (False, True):
            for salt_mode in ('mod', 'zero'):
                for C in range(LIMIT):
                    ok = True
                    for seed, want in OBS:
                        salt = 0 if salt_mode == 'zero' else seed % 1000
                        got = draw(C, step, reset, salt)
                        for r in (0, 1):
                            if set(got[r]) != want[r]:
                                ok = False
                                break
                        if not ok:
                            break
                    if ok:
                        hits += 1
                        print('HIT step=%d reset=%s salt=%s C=%d'
                              % (step, reset, salt_mode, C))
        print('  ... step=%d done' % step)
    print('total hits', hits)


if __name__ == '__main__':
    main()
