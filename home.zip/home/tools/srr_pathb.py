# -*- coding: utf-8 -*-
"""检验 sub_1402B05C0 中 base 计算的 if/else 分支（2026-10-30 新发现）。

字节流证据（xwin.py 0x1402B1600-0x1402B1660 / 0x1402B1F80-0x1402B1FE8）：

    1402B1620  mov rcx,[rsp+88h]              ; rcx = 协调器对象
    1402B1628  cmp byte [rcx+2E8h],1          ; +744
    1402B62F  jz  0x1402B1F91                 ; → Path B
    1402B1635  xor edx,edx
    1402B1637  call GetSeed(rcx,0)            ; Path A: base = GetSeed(coord) + ~crc(salt)
    1402B163C  add eax,esi
    1402B163E  mov [rsp+0CCh],eax
    1402B1645  ...                            ; 汇合
      ; Path B:
    1402B1F91  cmp byte [rcx+359h],0          ; +857
    1402B1F98  jnz 0x1402B1635                ; → 回退 Path A
    1402B1F9E  mov rax,[rcx+10h]              ; ClassPrivate
    1402B1FA2  mov rax,[rax+18h]              ; Class->NamePrivate (FName)
    1402B1FBC  call FName::ToString
    1402B1FC4  call sub_1402B4C10             ; crc32(类名串)（已核实返回 ~crc）
    1402B1FC9  add eax,esi                    ; + ~crc("Objective Actors")
    1402B1FCB  mov [rsp+0CCh],eax             ; ★ base = crc32(类名) + crc32(盐名)
    1402B1FE3  jmp 0x1402B1645                ; 汇合

⇒ Path B 的 base 与 GetSeed(协调器) 无关，是**类名常量**（三个协调器同类 → 同一个 base）。
此前所有拟合只用过 Path A 形态的 base（GetSeed + 盐），Path B 从未被检验。

用法：
    python srr_pathb.py r1      # R1 抽序（两 seed 全序，约束 ~9 bit）
    python srr_pathb.py r23     # R2/R3 六台集合（分组模型）
    python srr_pathb.py all
"""
import os
import sys

_HERE = os.path.dirname(os.path.abspath(__file__))
sys.path.insert(0, os.path.join(_HERE, '..'))
import srr_mt02 as m

M32 = m.M32
SALT = m.SALT_NAME

# 类名候选（FName::ToString(UClass) 的可能形态）
NAMES = [
    'OrderedClueFrequency_Coord_BP_C',
    'Default__OrderedClueFrequency_Coord_BP_C',
    'OrderedClueFrequency_Coord_BP',
    'RBOrderedPanelObjectiveCoordinator',
]

# R1（RichDistrict，池=需求=4，非分组路径）实测抽序（§4.5）
EXPECTED_R1_ORDER = {
    417417: ['BP', 'BP2', 'BP3', 'BP49'],
    737737: ['BP2', 'BP3', 'BP49', 'BP'],
}

# R2/R3 实测 6 台集合
EXPECTED_SETS = {
    (417417, 'School'): ['BP5', 'BP6', 'BP19', 'BP26', 'BP24', 'BP29'],
    (417417, 'SasExit'): ['BP45', 'BP43', 'BP31', 'BP38', 'BP36', 'BP47'],
    (737737, 'School'): ['BP5', 'BP8', 'BP11', 'BP21', 'BP27_3', 'BP25'],
    (737737, 'SasExit'): ['BP30', 'BP33', 'BP37', 'BP45', 'BP40', 'BP47'],
}


def base_variants(name):
    """Path B 的 base 公式变体。"""
    c = m.crc32_fname(name)
    s = m.crc32_fname(SALT)
    v = (c + s) & M32
    abs_v = v if v < 0x80000000 else (0x100000000 - v) & M32
    out = {'add': v}
    if abs_v != v:
        out['abs'] = abs_v
    return out


def path_a_base(key):
    return m.base_of(key)


def draw(pool, base, level_seed, removal, off=0, n=None):
    """逐个抽取：seed_i = base + off + i，pos = rand_seeded(seed, 剩余)。"""
    pool = list(pool)
    out = []
    n = n or len(pool)
    for i in range(n):
        if not pool:
            break
        pos = m.rand_seeded((base + off + i) & M32, len(pool), level_seed)
        out.append(pool[pos])
        if removal == 'stable':
            pool.pop(pos)
        else:
            pool[pos] = pool[-1]
            pool.pop()
    return out


def shuffle_groups(groups, counter0, level_seed, removal):
    groups = list(groups)
    out = []
    c = counter0
    while groups:
        j = m.rand_seeded(c & M32, len(groups), level_seed)
        c += 1
        out.append(groups[j])
        if removal == 'swap':
            groups[j] = groups[-1]
        groups.pop(j)
    return out, c


def group_by_room(key):
    from collections import OrderedDict
    g = OrderedDict()
    for a in m.COORDS[key]['pool']:
        g.setdefault(m.TUNERS[a][0], []).append(a)
    return list(g.items())


def try_r1():
    """非分组路径：抽 4 台的顺序必须同时匹配两个 seed。"""
    pool = m.COORDS['RichDistrict']['pool']
    hits = []
    candidates = []
    for name in NAMES:
        for formula, base in base_variants(name).items():
            candidates.append(('PathB:%s:%s' % (name, formula), base))
    for key in ('RichDistrict', 'School', 'SasExit'):
        candidates.append(('PathA:%s' % key, path_a_base(key)))

    for label, base in candidates:
        for removal in ('stable', 'swap'):
            for off in range(4):
                ok = True
                for seed, expect in EXPECTED_R1_ORDER.items():
                    got = draw(pool, base, seed, removal, off)
                    if got != expect:
                        ok = False
                        break
                if ok:
                    hits.append((label, base, removal, off))
    return hits


def grouped_pick(key, base, level_seed, cfg):
    """mode A（按房间分组）完整六步的一个变体。"""
    groups = group_by_room(key)
    G = len(groups)
    shuf, counter_after = shuffle_groups(
        groups, base + cfg['shuffle_off'], level_seed, cfg['shuffle_rm'])
    desired = cfg['desired'](shuf, m.COORDS[key]['desired'])
    picked = []
    if cfg['draw_counter'] == 'after':
        c = counter_after + cfg['draw_off']
    else:
        c = base + cfg['draw_off']
    for (room, members), want in zip(shuf, desired):
        mem = list(members)
        for _ in range(want):
            if not mem or len(picked) >= m.COORDS[key]['desired']:
                break
            j = m.rand_seeded(c & M32, len(mem), level_seed)
            c += 1
            picked.append(mem[j])
            if cfg['draw_rm'] == 'stable':
                mem.pop(j)
            else:
                mem[j] = mem[-1]
                mem.pop()
        if len(picked) >= m.COORDS[key]['desired']:
            break
    return picked


def desired_first(shuf, want):
    return [1 if i < want else 0 for i in range(len(shuf))]


def desired_roundrobin(shuf, want):
    """§18.3 简化：轮转 +1 直到 remaining < 2，余量给第一个成员数够的组。"""
    d = [0] * len(shuf)
    return d


def try_r23(base_label, base):
    """mode A 分组模型 × 各变体，要求 4 个样本集合全中。"""
    hits = []
    for shuffle_rm in ('swap', 'stable'):
        for draw_rm in ('stable', 'swap'):
            for draw_counter in ('after', 'same'):
                for shuffle_off in (0,):
                    for draw_off in (0, 1):
                        cfg = {'shuffle_rm': shuffle_rm, 'draw_rm': draw_rm,
                               'draw_counter': draw_counter,
                               'shuffle_off': shuffle_off, 'draw_off': draw_off,
                               'desired': desired_first}
                        good = 0
                        for (seed, key), expect in EXPECTED_SETS.items():
                            got = grouped_pick(key, base, seed, cfg)
                            if sorted(got) == sorted(expect):
                                good += 1
                        if good >= 2:
                            hits.append((good, cfg))
    return hits


def main():
    what = sys.argv[1] if len(sys.argv) > 1 else 'all'
    if what in ('r1', 'all'):
        print('=== R1 抽序检验（Path B / Path A base，全序 × 2 seed）===')
        hits = try_r1()
        if hits:
            for h in hits:
                print('  命中:', h)
        else:
            print('  无命中')

    if what in ('r23', 'all'):
        print('=== R2/R3 集合检验（mode A 按房间分组）===')
        candidates = []
        for name in NAMES:
            for formula, base in base_variants(name).items():
                candidates.append(('PathB:%s:%s' % (name, formula), base))
        for key in ('School', 'SasExit'):
            candidates.append(('PathA:%s' % key, path_a_base(key)))
        any_hit = False
        for label, base in candidates:
            hits = try_r23(label, base)
            if hits:
                any_hit = True
                print('  %s base=0x%08X:' % (label, base))
                for good, cfg in sorted(hits, reverse=True):
                    print('     %d/4 %s' % (good, cfg))
        if not any_hit:
            print('  无 ≥2/4 命中')


if __name__ == '__main__':
    main()
