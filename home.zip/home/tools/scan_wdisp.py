# -*- coding: utf-8 -*-
"""找「写入 [reg+disp32]」的位置（只匹配 mov byte/word/dword 到内存）。

    python scan_wdisp.py 0x359 byte
    python scan_wdisp.py 0x359 dword
"""
import struct
import sys
import os

_HERE = os.path.dirname(os.path.abspath(__file__))
sys.path.insert(0, _HERE)
import scan_disp as sd


def main():
    disp = int(sys.argv[1], 16)
    kind = sys.argv[2] if len(sys.argv) > 2 else 'byte'
    name, sva, vsize, rawptr, rawsize = sd.sec('.text')
    base = sd.image_base + sva
    data = sd.d
    lo, hi = rawptr, rawptr + vsize
    pat = struct.pack('<I', disp)
    hits = []
    i = data.find(pat, lo, hi)
    while i >= 0:
        # 往前看 2~4 字节判断是否 "mov [reg+disp32], src"
        for back, opc in ((2, 0xC6), (2, 0x88), (2, 0xC7), (2, 0x89)):
            if i - 2 >= lo and data[i - 2] == opc:
                m = data[i - 1]
                if (m & 0xC0) == 0x80 and (m & 7) != 4:
                    isbyte = opc in (0xC6, 0x88)
                    if (kind == 'byte') == isbyte:
                        hits.append(base + (i - 2 - lo))
        i = data.find(pat, i + 1, hi)
    print('=== 写 [reg+%Xh] 的指令 %d 处' % (disp, len(hits)))
    seen = set()
    for va in hits:
        c = sd.containing(va)
        fn = c[0] if c else va
        if fn in seen:
            continue
        seen.add(fn)
        print('  %X  (func %X, size 0x%X)' % (va, fn, (c[1] - c[0]) if c else 0))


if __name__ == '__main__':
    main()
