# -*- coding: utf-8 -*-
"""检验：屏幕上 3 个图案是否只由「协调器种子」决定（与哪 6 台被选中无关）。

做法：clues_of 的计数偏移 C 当作自由参数扫一遍，
要求 4 个样本（R2/R3 × 2 个 seed）的「前 3 个抽取结果」与实测屏幕**逐位相同**。
命中概率量级：单样本 1/(6*5*4)=1/120，4 个样本 ~5e-9 ⇒ 扫 4000 个 C 也不会有假阳性。
"""
import os
import sys

sys.path.insert(0, r'd:/workspace/outlast/release/home')
sys.path.insert(0, r'd:/workspace/outlast/release/seed')
import srr_mt02 as m
from seedcore import rand_seeded, seed_of_object
from srr_mt02 import M32, COORDS

CASES = [
    # (coord, seed, 屏幕 3 图案, 屏幕顺序)
    ('School', 417417, ['Diamond', 'Heart', 'Bunny']),
    ('School', 737737, ['Club', 'Moon', 'Heart']),
    ('SasExit', 417417, ['Diamond', 'Moon', 'Bunny']),
    ('SasExit', 737737, ['Moon', 'Heart', 'Diamond']),
]


def draw(key, level_seed, offset, n_draw=None, mode='swap'):
    base = seed_of_object(COORDS[key]['actor'])
    pool = list(COORDS[key]['clues'])
    out = []
    cnt = len(pool) if n_draw is None else n_draw
    for i in range(cnt):
        k = rand_seeded((base + offset + i) & M32, len(pool), level_seed)
        out.append(pool[k])
        if mode == 'swap':
            pool[k] = pool[-1]
            pool.pop()
        else:
            pool.pop(k)
    return out


def main():
    hits_order = []
    hits_set = []
    for mode in ('swap', 'del'):
        for C in range(0, 4000):
            ok_order = ok_set = 0
            for key, seed, screens in CASES:
                got = draw(key, seed, C, 3, mode)
                if got == screens:
                    ok_order += 1
                if set(got) == set(screens):
                    ok_set += 1
            if ok_order == len(CASES):
                hits_order.append((mode, C))
            if ok_set == len(CASES):
                hits_set.append((mode, C))
        print('mode=%s  逐位全中: %d  集合全中: %d' % (mode, len(hits_order), len(hits_set)))
    print('\n逐位命中的 C:', hits_order[:10])
    print('集合命中的 C:', hits_set[:20])

    # 对照：固定偏移 503 现在的表现
    print('\n[对照] C=503 的预测 vs 实测')
    for key, seed, screens in CASES:
        got = draw(key, seed, 503, 3)
        print('  %-8s seed=%d  预测=%s  实测=%s' % (key, seed, got, screens))


main()
