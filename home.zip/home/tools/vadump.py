"""按 VA 直接 dump 字节（只读 exe，无需 IDA）。用法: python vadump.py 0x145CD0400 256"""
import struct
import sys

EXE = r"D:\workspace\outlast\TOTClient-Win64-Shipping.exe"
BASE = 0x140000000

data = open(EXE, "rb").read()
pe = struct.unpack_from("<I", data, 0x3C)[0]
nsec = struct.unpack_from("<H", data, pe + 6)[0]
optsz = struct.unpack_from("<H", data, pe + 20)[0]
image_base = struct.unpack_from("<Q", data, pe + 24 + 24)[0]
sec = []
s0 = pe + 24 + optsz
for i in range(nsec):
    s = s0 + i * 40
    name = data[s:s + 8].rstrip(b"\x00").decode(errors="replace")
    vsize, vaddr, rsize, raddr = struct.unpack_from("<IIII", data, s + 8)
    sec.append((name, vaddr, vsize, raddr, rsize))


def rva2off(rva):
    for name, vaddr, vsize, raddr, rsize in sec:
        if vaddr <= rva < vaddr + max(vsize, rsize):
            return raddr + (rva - vaddr)
    return None


def cstr(va, limit=80):
    off = rva2off(va - image_base)
    if off is None:
        return "?"
    end = data.find(b"\x00", off, off + limit)
    if end < 0:
        return "?"
    return data[off:end].decode(errors="replace")


va = int(sys.argv[1], 16)
n = int(sys.argv[2]) if len(sys.argv) > 2 else 128
off = rva2off(va - image_base)
print("VA 0x%X -> file 0x%X" % (va, off))
for i in range(0, n, 16):
    chunk = data[off + i:off + i + 16]
    hexs = " ".join("%02X" % b for b in chunk)
    asc = "".join(chr(b) if 32 <= b < 127 else "." for b in chunk)
    print("%08X  %-47s  %s" % (va + i, hexs, asc))
# 把疑似指针解析成字符串
print("\n-- qword 指针指向的字符串 --")
for i in range(0, n, 8):
    v = struct.unpack_from("<Q", data, off + i)[0]
    if 0x140000000 <= v < 0x147625000:
        print("  +0x%02X -> 0x%X  %r" % (i, v, cstr(v)[:70]))
    elif 0 < v < 0x10000:
        print("  +0x%02X = 0x%X (%d)" % (i, v, v))
