# -*- coding: utf-8 -*-
"""把 psb_mt01_static.CORPSES 渲染成 Q2 用的 markdown 表（按扇区 A/C/B）。

用法：
    python tools/mt01_q2_table.py            # 打印到 stdout
    python tools/mt01_q2_table.py --md out.md
"""
import os
import sys

sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.abspath(__file__))))

import psb_mt01_static as S


def room_name(rid):
    r = S.ROOMS[str(rid)]
    if isinstance(r, dict):
        return r.get('name_zh') or r.get('name') or str(rid)
    if isinstance(r, (list, tuple)):
        return ' '.join(str(x) for x in reversed(r))
    return str(r)


def main():
    lines = []
    for sec in ('A', 'C', 'B'):
        rows = [c for c in S.CORPSES if c['sector'] == sec]
        lines.append('#### %s 区（%d 具候选，池内顺序 = 关卡 actor 顺序）' % (sec, len(rows)))
        lines.append('')
        lines.append('| 池序 | 尸体 actor | 房间 | 坐标 (X, Y, Z) |')
        lines.append('|---:|---|---|---|')
        for n, c in enumerate(rows):
            p = c['p']
            lines.append('| %d | %s | %s | %.0f, %.0f, %.0f |'
                         % (n, c['actor'], room_name(c['room']), p[0], p[1], p[2]))
        lines.append('')
    txt = '\n'.join(lines)
    if '--md' in sys.argv:
        out = sys.argv[sys.argv.index('--md') + 1]
        open(out, 'w', encoding='utf-8').write(txt)
        print('写入 %s' % out)
    else:
        print(txt)


if __name__ == '__main__':
    main()
