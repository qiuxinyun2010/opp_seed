# -*- coding: utf-8 -*-
"""SRR_MT02 拟合探查器 v3：只验证「洗牌后前 D 组」的 key 集合，可扫更大范围。

mode:
  room  分组 key = 房间     → 命中概率 1/C(21,6)=1/54264（School）
  unit  分组 key = 每台唯一  → 命中概率 1/C(26,6)=1/230230（School）
"""
import sys
from collections import OrderedDict

M32 = 0xFFFFFFFF
M64 = 0xFFFFFFFFFFFFFFFF

_T = []
for _i in range(256):
    _c = _i
    for _ in range(8):
        _c = ((_c >> 1) ^ 0xEDB88320) if (_c & 1) else (_c >> 1)
    _T.append(_c & M32)


def crc32_fname(text):
    crc = M32
    for ch in text:
        u = ord(ch) & 0xFFFF
        crc = _T[(crc ^ (u & 0xFF)) & 0xFF] ^ (crc >> 8)
        crc = _T[(crc ^ (u >> 8)) & 0xFF] ^ (crc >> 8)
        crc = _T[crc & 0xFF] ^ (crc >> 8)
        crc = _T[crc & 0xFF] ^ (crc >> 8)
    return (~crc) & M32


def seed_of_object(name, outer_seed=None):
    if outer_seed is None:
        outer_seed = crc32_fname('PersistentLevel')
    value = (crc32_fname(name) + outer_seed) & M32
    return value if value < 0x80000000 else (0x100000000 - value) & M32


def rs(seed, n, level_seed):
    if not n or not level_seed or not seed:
        return 0
    a = (0xBF58476D1CE4E5B9 * ((seed ^ (seed >> 30)) & M64)) & M64
    a ^= a >> 27
    b = (0xBF58476D1CE4E5B9 * (level_seed % 1000)) & M64
    b ^= b >> 27
    v = (((0x94D049BB133111EB * a) & M64) ^ ((0x94D049BB133111EB * b) & M64)) & M64
    t = (v ^ (v >> 31)) & M64
    w = (0xBF58476D1CE4E5B9 * (t ^ (t >> 30))) & M64
    u = (w ^ (w >> 27)) & M64
    r = (((321982955 * u) & M64) ^ (((0x94D049BB133111EB * u) & M64) >> 31)) & M64
    return (r & 0xFFFF) % n


POOLS = {
    'School': ['BP23', 'BP24', 'BP25', 'BP27_3', 'BP26', 'BP29', 'BP28', 'BP16',
               'BP17', 'BP15', 'BP13', 'BP14', 'BP4', 'BP6', 'BP7', 'BP5',
               'BP19_22', 'BP19', 'BP21', 'BP20', 'BP22', 'BP11', 'BP12', 'BP10',
               'BP8', 'BP9'],
    'SasExit': ['BP30', 'BP31', 'BP33', 'BP32', 'BP35', 'BP34', 'BP38', 'BP39',
                'BP40', 'BP41', 'BP42', 'BP43', 'BP44', 'BP37', 'BP36', 'BP45',
                'BP46', 'BP47', 'BP48'],
}
ROOM = {
    'BP4': 'H2_Chambre', 'BP5': 'H2_Storage', 'BP6': 'H2_Salon', 'BP7': 'H2_Kitchen',
    'BP8': 'H1_Storage', 'BP9': 'H1_Bathroom', 'BP10': 'H1_Chambre',
    'BP11': 'H1_Salon', 'BP12': 'H1_Salon', 'BP13': 'H3_Salon',
    'BP14': 'H3_SmallStorage', 'BP15': 'H3_Chambre', 'BP16': 'H3_BigStorage',
    'BP17': 'H3_BigStorage', 'BP19': 'H4_ConstrRoom2', 'BP19_22': 'H4_ConstrRoom2',
    'BP20': 'H4_ConstructionRoom2', 'BP21': 'H4_ConstrRoom1', 'BP22': 'H4_Storage',
    'BP23': 'H5_Salon', 'BP24': 'H5_Entrance', 'BP25': 'H5_Entrance',
    'BP26': 'H5_Chambre', 'BP27_3': 'H5_Storage', 'BP28': 'ConstHouse',
    'BP29': 'ConstHouse', 'BP30': 'Sc_Secreteria', 'BP31': 'Sc_Secreteria',
    'BP32': 'Sc_Kitchen', 'BP33': 'Sc_Kitchen', 'BP34': 'Sc_Toilet', 'BP35': 'Sc_Toilet',
    'BP36': 'Sc_Class04', 'BP37': 'Sc_Class04', 'BP38': 'Sc_Class03', 'BP39': 'Sc_Class03',
    'BP40': 'MusicStorage', 'BP41': 'Sc_Class02', 'BP42': 'Sc_Class02',
    'BP43': 'Sc_Class01', 'BP44': 'Sc_Class01', 'BP45': 'Sc_Library', 'BP46': 'Sc_Library',
    'BP47': 'Ext_WomenToilet', 'BP48': 'Ext_MaleToilet',
}
WANT_ROOM = {
    'School': {'H2_Storage', 'H2_Salon', 'H4_ConstrRoom2', 'H5_Entrance',
               'H5_Chambre', 'ConstHouse'},
    'SasExit': {'Sc_Library', 'Sc_Class01', 'Sc_Class03', 'Sc_Class04',
                'Sc_Library', 'Sc_Secreteria'},
}
WANT_ROOM['SasExit'] = {'Sc_Library', 'Sc_Class01', 'Sc_Class03', 'Sc_Class04',
                        'Sc_Secreteria', 'Ext_WomenToilet'}
WANT_UNIT = {
    'School': {'BP5', 'BP6', 'BP19', 'BP24', 'BP26', 'BP29'},
    'SasExit': {'BP45', 'BP43', 'BP31', 'BP38', 'BP36', 'BP47'},
}
COORD = {
    'School': 'SRR_MT02_OrderedClueFrequency_School',
    'SasExit': 'SRR_MT02_OrderedClueFrequency_SasExit',
}
LEVEL_SEED = 417417
SALT_CRC = crc32_fname('Objective Actors')
DESIRED = 6


def keys_of(pool, mode):
    if mode == 'room':
        g = OrderedDict()
        for a in pool:
            g.setdefault(ROOM[a], []).append(a)
        return list(g.keys())
    return list(pool)                      # unit：每台自成一组


def shuffle_keys(pool, base, d, mode, turn=0):
    if mode == 'fy':
        # 经典 Fisher-Yates：i 从 n 到 2，j = RandSeeded(base + v++, i)
        mem = list(pool)
        v = turn
        for i in range(len(mem), 1, -1):
            j = rs((base + v) & M32, i, LEVEL_SEED)
            v += 1
            mem[i - 1], mem[j] = mem[j], mem[i - 1]
        return mem[:d]
    if mode == 'fyrev':
        mem = list(pool)
        mem.reverse()
        v = turn
        for i in range(len(mem), 1, -1):
            j = rs((base + v) & M32, i, LEVEL_SEED)
            v += 1
            mem[i - 1], mem[j] = mem[j], mem[i - 1]
        return mem[:d]
    rest = keys_of(pool, mode)
    order = []
    cnt = turn
    while rest:
        k = rs((base + cnt) & M32, len(rest), LEVEL_SEED)
        cnt += 1
        order.append(rest[k])
        rest[k] = rest[-1]
        rest.pop()
    return order[:d]


def main():
    span = int(sys.argv[1]) if len(sys.argv) > 1 else 200000
    modes = sys.argv[2:] or ['room', 'unit']
    base_sets = {
        '+salt': {k: (seed_of_object(v) + SALT_CRC) & M32 for k, v in COORD.items()},
        'plain': {k: seed_of_object(v) for k, v in COORD.items()},
    }
    for mode in modes:
        want = WANT_ROOM if mode == 'room' else WANT_UNIT
        for tag, bs in base_sets.items():
            # 同一个 delta 必须同时让 School 与 SasExit 命中 → 交集才是信号
            hs = {}
            for name in ('School', 'SasExit'):
                s = set()
                b = bs[name]
                for delta in range(0, span):
                    keys = shuffle_keys(POOLS[name], (b + delta) & M32, DESIRED, mode)
                    if set(keys) == want[name]:
                        s.add(delta)
                hs[name] = s
            inter = sorted(hs['School'] & hs['SasExit'])
            print('%-5s %-6s  School=%d SasExit=%d  交集=%s'
                  % (mode, tag, len(hs['School']), len(hs['SasExit']), inter[:10]))


if __name__ == '__main__':
    main()
