# -*- coding: utf-8 -*-
"""SRR_MT02 拟合探查器 v4：把「RandSeeded 内部掺的 salt」也当未知量扫。

此前所有拟合都假定 salt = level_seed % 1000 = 417。这里扫 salt ∈ [0,1000) 与
种子基偏移 delta ∈ [0, span)，用「同一 (salt, delta) 必须同时命中 School 与 SasExit」
的交集检验排除假阳性。

加速：salt 只影响常量项 B = 0x94D049BB133111EB * mix1(salt)，预计算 1000 个值；
且洗牌只取前 D 组 → 只需 D 次 RandSeeded，不必跑完整条洗牌。
"""
import sys
from collections import OrderedDict

M32 = 0xFFFFFFFF
M64 = 0xFFFFFFFFFFFFFFFF

_T = []
for _i in range(256):
    _c = _i
    for _ in range(8):
        _c = ((_c >> 1) ^ 0xEDB88320) if (_c & 1) else (_c >> 1)
    _T.append(_c & M32)


def crc32_fname(text):
    crc = M32
    for ch in text:
        u = ord(ch) & 0xFFFF
        crc = _T[(crc ^ (u & 0xFF)) & 0xFF] ^ (crc >> 8)
        crc = _T[(crc ^ (u >> 8)) & 0xFF] ^ (crc >> 8)
        crc = _T[crc & 0xFF] ^ (crc >> 8)
        crc = _T[crc & 0xFF] ^ (crc >> 8)
    return (~crc) & M32


def seed_of_object(name):
    value = (crc32_fname(name) + crc32_fname('PersistentLevel')) & M32
    return value if value < 0x80000000 else (0x100000000 - value) & M32


def mix1(x):
    z = (0xBF58476D1CE4E5B9 * (x ^ (x >> 30))) & M64
    return z ^ (z >> 27)


BCACHE = [(0x94D049BB133111EB * mix1(s)) & M64 for s in range(1000)]


def rs_b(seed, n, B):
    """RandSeeded，salt 项已预计算。"""
    if not n or not seed:
        return 0
    v = ((0x94D049BB133111EB * mix1(seed)) & M64) ^ B
    t = (v ^ (v >> 31)) & M64
    w = (0xBF58476D1CE4E5B9 * (t ^ (t >> 30))) & M64
    u = (w ^ (w >> 27)) & M64
    r = (((321982955 * u) & M64) ^ (((0x94D049BB133111EB * u) & M64) >> 31)) & M64
    return (r & 0xFFFF) % n


POOLS = {
    'School': ['BP23', 'BP24', 'BP25', 'BP27_3', 'BP26', 'BP29', 'BP28', 'BP16',
               'BP17', 'BP15', 'BP13', 'BP14', 'BP4', 'BP6', 'BP7', 'BP5',
               'BP19_22', 'BP19', 'BP21', 'BP20', 'BP22', 'BP11', 'BP12', 'BP10',
               'BP8', 'BP9'],
    'SasExit': ['BP30', 'BP31', 'BP33', 'BP32', 'BP35', 'BP34', 'BP38', 'BP39',
                'BP40', 'BP41', 'BP42', 'BP43', 'BP44', 'BP37', 'BP36', 'BP45',
                'BP46', 'BP47', 'BP48'],
}
ROOM = {
    'BP4': 'H2_Chambre', 'BP5': 'H2_Storage', 'BP6': 'H2_Salon', 'BP7': 'H2_Kitchen',
    'BP8': 'H1_Storage', 'BP9': 'H1_Bathroom', 'BP10': 'H1_Chambre',
    'BP11': 'H1_Salon', 'BP12': 'H1_Salon', 'BP13': 'H3_Salon',
    'BP14': 'H3_SmallStorage', 'BP15': 'H3_Chambre', 'BP16': 'H3_BigStorage',
    'BP17': 'H3_BigStorage', 'BP19': 'H4_ConstrRoom2', 'BP19_22': 'H4_ConstrRoom2',
    'BP20': 'H4_ConstructionRoom2', 'BP21': 'H4_ConstrRoom1', 'BP22': 'H4_Storage',
    'BP23': 'H5_Salon', 'BP24': 'H5_Entrance', 'BP25': 'H5_Entrance',
    'BP26': 'H5_Chambre', 'BP27_3': 'H5_Storage', 'BP28': 'ConstHouse',
    'BP29': 'ConstHouse', 'BP30': 'Sc_Secreteria', 'BP31': 'Sc_Secreteria',
    'BP32': 'Sc_Kitchen', 'BP33': 'Sc_Kitchen', 'BP34': 'Sc_Toilet', 'BP35': 'Sc_Toilet',
    'BP36': 'Sc_Class04', 'BP37': 'Sc_Class04', 'BP38': 'Sc_Class03', 'BP39': 'Sc_Class03',
    'BP40': 'MusicStorage', 'BP41': 'Sc_Class02', 'BP42': 'Sc_Class02',
    'BP43': 'Sc_Class01', 'BP44': 'Sc_Class01', 'BP45': 'Sc_Library', 'BP46': 'Sc_Library',
    'BP47': 'Ext_WomenToilet', 'BP48': 'Ext_MaleToilet',
}
WANT_ROOM = {
    'School': frozenset(['H2_Storage', 'H2_Salon', 'H4_ConstrRoom2', 'H5_Entrance',
                         'H5_Chambre', 'ConstHouse']),
    'SasExit': frozenset(['Sc_Library', 'Sc_Class01', 'Sc_Class03', 'Sc_Class04',
                          'Sc_Secreteria', 'Ext_WomenToilet']),
}
WANT_UNIT = {
    'School': frozenset(['BP5', 'BP6', 'BP19', 'BP24', 'BP26', 'BP29']),
    'SasExit': frozenset(['BP45', 'BP43', 'BP31', 'BP38', 'BP36', 'BP47']),
}
COORD = {
    'School': 'SRR_MT02_OrderedClueFrequency_School',
    'SasExit': 'SRR_MT02_OrderedClueFrequency_SasExit',
}
SALT_CRC = crc32_fname('Objective Actors')
D = 6


def keys_of(name, mode):
    if mode == 'room':
        g = OrderedDict()
        for a in POOLS[name]:
            g.setdefault(ROOM[a], []).append(a)
        return list(g.keys())
    return list(POOLS[name])


def front(keys, base, B):
    rest = list(keys)
    out = []
    cnt = 0
    for _ in range(min(D, len(rest))):
        k = rs_b((base + cnt) & M32, len(rest), B)
        cnt += 1
        out.append(rest[k])
        rest[k] = rest[-1]
        rest.pop()
    return out


def main():
    span = int(sys.argv[1]) if len(sys.argv) > 1 else 600
    mode = sys.argv[2] if len(sys.argv) > 2 else 'room'
    want = WANT_ROOM if mode == 'room' else WANT_UNIT
    base_sets = {
        '+salt': {k: (seed_of_object(v) + SALT_CRC) & M32 for k, v in COORD.items()},
        'plain': {k: seed_of_object(v) for k, v in COORD.items()},
    }
    keys = {n: keys_of(n, mode) for n in COORD}
    for tag, bs in base_sets.items():
        cand = []
        for s in range(1000):
            B = BCACHE[s]
            b = bs['School']
            for delta in range(span):
                if set(front(keys['School'], (b + delta) & M32, B)) == want['School']:
                    cand.append((s, delta))
        print('%s/%s  School 候选 %d 个' % (tag, mode, len(cand)))
        good = []
        for s, delta in cand:
            B = BCACHE[s]
            got = front(keys['SasExit'], (bs['SasExit'] + delta) & M32, B)
            if set(got) == want['SasExit']:
                good.append((s, delta))
        print('   经 SasExit 交叉验证后剩: %s' % (good[:10] if good else '空'))
        if good:
            for s, delta in good[:5]:
                print('   salt=%d delta=%d  School=%s' % (
                    s, delta, front(keys['School'], (bs['School'] + delta) & M32, BCACHE[s])))


if __name__ == '__main__':
    main()
