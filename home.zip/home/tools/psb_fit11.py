# -*- coding: utf-8 -*-
"""PSB_MT01 第十一轮：按「通用引擎 sub_1402B05C0」的标准形态找 9 具尸体。

MHS_MT01 那轮读出来的引擎事实（release/home/MHS_MT01.md §3.1）：
    base  = crc32_fname(盐名) + GetSeed(协调器)          @0x1402B163E
    idx   = (uint16)hash(base + 偏移) % 池大小            ← RandSeeded 内联
    删除  = RemoveAtSwap                                 @0x1402B17FE
盐名（本关入口 sub_1402AE7F0 传的宽串 @0x14665E254）= "Objective Actors"

实测目标 seed 378378：一局 9 具（全局序）
    {0, 8, 16} (A) / {23, 25, 37} (B) / {20, 27, 38} (C)
"""
import itertools
import os
import sys

sys.path.insert(0, os.path.abspath(os.path.join(os.path.dirname(__file__), '..', '..', 'seed')))
import seedcore as sc  # noqa: E402

ALL = list(range(41))
A_LIST = [0, 1, 2, 4, 8, 15, 16, 17, 18, 19, 22, 33, 34, 35, 40]
B_LIST = [9, 10, 21, 23, 24, 25, 26, 32, 36, 37]
C_LIST = [3, 5, 6, 7, 11, 12, 13, 14, 20, 27, 28, 29, 30, 31, 38, 39]
LISTS = {'A': A_LIST, 'B': B_LIST, 'C': C_LIST}

S378 = {'A': {0, 8, 16}, 'B': {23, 25, 37}, 'C': {20, 27, 38}}
COORD = 'PSB_MT01_B01_CorpseSearch_3'
SALTS = ['Objective Actors', 'Spawner Actors', 'Quest Items', 'Corpses']


def draw(pool, base, seed, n, swap, step=1):
    salt = seed % 1000
    p = list(pool)
    out = []
    for t in range(n):
        i = sc.rand_seeded((base + t * step) & 0xFFFFFFFF, len(p), salt)
        out.append(p[i])
        if swap:
            p[i] = p[-1]
        p.pop(i)
    return out


def test_all(base, seed, swap, n):
    """单一 41 池里抽 n 具。"""
    got = set(draw(ALL, base, seed, n, swap))
    return all(S378[s] <= got for s in 'ABC')


def test_zone(base, seed, swap, order, per, step_zone=0):
    """按扇区分组，每组 from 该区候选里抽 per 具。"""
    got = {}
    v = 0
    for sec in order:
        b = (base + step_zone * v) & 0xFFFFFFFF if step_zone else base
        got[sec] = set(draw(LISTS[sec], b, seed, per, swap))
        v += per
    return all(got[s] == S378[s] for s in 'ABC')


def main():
    try:
        sys.stdout.reconfigure(encoding='utf-8')
    except Exception:
        pass
    lvl = sc.crc32_fname('PersistentLevel')
    coord = sc.seed_of_object(COORD, lvl)
    print('GetSeed(coord)=0x%08X' % coord)
    found = 0

    for salt in SALTS:
        crc = sc.crc32_fname(salt)
        for d in range(0, 65536):
            base = (coord + crc + d) & 0xFFFFFFFF
            for swap in (True, False):
                for n in (9, 10):
                    if test_all(base, 378378, swap, n):
                        print('★ 单一41池 salt=%s d=%d swap=%s n=%d' % (salt, d, swap, n))
                        found += 1
    print('单一 41 池：%d 命中' % found)

    for salt in SALTS:
        crc = sc.crc32_fname(salt)
        for d in range(0, 16384):
            base = (coord + crc + d) & 0xFFFFFFFF
            for swap in (True, False):
                for order in itertools.permutations('ABC'):
                    if test_zone(base, 378378, swap, order, 3):
                        print('★ 分区池 salt=%s d=%d swap=%s order=%s' % (salt, d, swap, order))
                        found += 1
    print('总计命中 %d' % found)


if __name__ == '__main__':
    main()
