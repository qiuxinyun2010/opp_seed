# -*- coding: utf-8 -*-
"""IDA 批处理通用查询（只读，退出不保存）。

环境变量：
    IDA_Q       decompile | callers | xrefs | callees | vtdiff | qwords | strings
    IDA_ARGS    逗号分隔的参数（地址/十六进制/字面串）
    IDA_OUT     输出文件

用法（PowerShell）：
    $env:IDA_Q='callers'; $env:IDA_ARGS='0x1402C30C0'
    $env:IDA_OUT='d:\workspace\outlast\release\home\_ida_out.txt'
    & "C:\Program Files\IDA Professional 9.3\idat.exe" -A `
        -S"d:\workspace\outlast\release\home\tools\ida_query.py" `
        "d:\workspace\outlast\TOTClient-Win64-Shipping.exe.i64"
"""
import os

import ida_bytes
import ida_funcs
import ida_hexrays
import ida_kernwin
import ida_lines
import idautils
import idc


def out_lines(lines):
    path = os.environ.get("IDA_OUT", "")
    text = "\n".join(lines)
    with open(path, "w", encoding="utf-8") as fp:
        fp.write(text)
    ida_kernwin.msg("wrote %s (%d chars)\n" % (path, len(text)))


def func_at(ea):
    f = ida_funcs.get_func(ea)
    return f


def fname(ea):
    return idc.get_func_name(ea) or idc.get_name(ea) or "?"


def dec(ea):
    f = func_at(ea)
    if not f:
        return ["(no function at 0x%X)" % ea]
    lines = ["=" * 70,
             "0x%X  %s  size=0x%X" % (f.start_ea, fname(ea), f.end_ea - f.start_ea)]
    try:
        cf = ida_hexrays.decompile(f.start_ea)
    except Exception as exc:                          # noqa: BLE001
        lines.append("decompile failed: %r" % (exc,))
        return lines
    if not cf:
        lines.append("decompile returned None")
        return lines
    for sl in cf.get_pseudocode():
        lines.append(ida_lines.tag_remove(sl.line))
    return lines


def main():
    q = os.environ.get("IDA_Q", "decompile")
    raw = os.environ.get("IDA_ARGS", "")
    args = [a.strip() for a in raw.split(",") if a.strip()]
    adds = [int(a, 0) for a in args if a.lower().startswith("0x")]
    lines = []

    if q == "decompile":
        for ea in adds:
            lines.extend(dec(ea))

    elif q == "callers":
        for ea in adds:
            lines.append("=" * 70)
            lines.append("callers of 0x%X" % ea)
            seen = set()
            for xr in idautils.XrefsTo(ea, 0):
                f = func_at(xr.frm)
                if not f or f.start_ea in seen:
                    continue
                seen.add(f.start_ea)
                lines.append("  0x%X  %s" % (f.start_ea, fname(f.start_ea)))

    elif q == "xrefs":
        for ea in adds:
            lines.append("=" * 70)
            lines.append("xrefs to 0x%X" % ea)
            for xr in idautils.XrefsTo(ea, 0):
                f = func_at(xr.frm)
                lines.append("  0x%X  type=%d  in=%s"
                             % (xr.frm, xr.type,
                                fname(f.start_ea) if f else "-"))

    elif q == "callees":
        for ea in adds:
            lines.append("=" * 70)
            lines.append("callees of 0x%X" % ea)
            for xr in idautils.XrefsFrom(ea, 0):
                f = func_at(xr.to)
                lines.append("  0x%X -> 0x%X %s" % (ea, xr.to, fname(xr.to) if f else ""))

    elif q == "vtdiff":
        a, b = adds[0], adds[1]
        n = int(args[2], 0) if len(args) > 2 else 300
        for i in range(n):
            va = ida_bytes.get_qword(a + 8 * i)
            vb = ida_bytes.get_qword(b + 8 * i)
            if va != vb:
                lines.append("+0x%03X  %s  %s -> %s  %s"
                             % (8 * i,
                                hex(va) if va else "-", hex(vb) if vb else "-",
                                fname(va) if va else "", fname(vb) if vb else ""))

    elif q == "qwords":
        ea = adds[0]
        n = int(args[1], 0) if len(args) > 1 else 32
        for i in range(n):
            v = ida_bytes.get_qword(ea + 8 * i)
            lines.append("0x%X: 0x%X  %s" % (ea + 8 * i, v, fname(v) if v else ""))

    elif q == "strings":
        for s in args:
            lines.append("=" * 70)
            lines.append("string %r" % s)
            for ea, val in idautils.Strings():
                v = str(val)
                if s in v:
                    lines.append("  0x%X %s" % (ea, v))

    else:
        lines.append("unknown IDA_Q=%r" % q)

    out_lines(lines)
    idc.qexit(0)


main()
