"""用 home/test.txt 里的样本反解 FPI_MT02 的「图案 / 总答案」抽取模型。

直接读 test.txt（经 samples.py 解析），补充数据后无需改代码，重跑即可。

模型族：value = F(base + K, salt = S % 1000)
  base ∈ {GetSeed(房间), 房间 CRC 不加 abs, GetSeed(协调器), 分区序号, 0}
  F    ∈ {RandSeeded(n=9/10), RandSeeded(n=9)+1, FRandomStream.RandRange(9),
          RandRange(9)+1, SelectSubset(10)}
命中要求：所有观测同时成立（误报概率 ~(1/9)^N）。
"""
import os
import sys

sys.path.insert(0, r"d:\workspace\outlast\release")
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
import seedcore as sc
import samples

LVL = 'PersistentLevel'
COORD = 'MT02_GameShowObjectiveCoordinator'
SECTION = {
    'RBRoom_RabbitTortur': 0, 'RBRoom_RabbitHole_CarrotsStorage': 1,
    'RBRoom_RabbitHole_Bedroom_Master': 2, 'RBRoom_RabbitHole_DinnerTable': 3,
    'RBRoom15_9': 4, 'RBRoom_QueenTrone': 5, 'RBRoom_CreepyHands': 6,
    'RBRoom_Library': 7, 'RBRoom_Storm': 8, 'RBRoom_UpsideDownStorm': 9,
    'RBRoom_UpsideDown_Church': 10, 'RBRoom_SpaceConsoleStation': 11,
    'RBRoom_UpsideUp_Church': 12, 'RBRoom_ShowRoom_Master': 13,
    'RBRoom_Eyes': 14, 'RBRoom_Tesseract': 15,
    'RBRoom_DinningIllusion': 16, 'RBRoom_DarkMannequin': 17,
}

LVL_CRC = sc.crc32_fname(LVL)
COORD_SEED = sc._abs32(sc.crc32_fname(COORD) + LVL_CRC)
ROOM_SEED = {r: sc._abs32(sc.crc32_fname(r) + LVL_CRC) for r in SECTION}
ROOM_RAW = {r: (sc.crc32_fname(r) + LVL_CRC) & 0xFFFFFFFF for r in SECTION}

BASES = [
    ('room', lambda r: ROOM_SEED[r]),
    ('roomRaw', lambda r: ROOM_RAW[r]),
    ('coord', lambda r: COORD_SEED),
    ('section', lambda r: SECTION.get(r, 0)),
    ('zero', lambda r: 0),
]

MODELS = [
    ('sym/seeded9', 'sym', lambda x, salt: sc.rand_seeded(x, 9, salt)),
    ('sym/seeded10', 'sym', lambda x, salt: sc.rand_seeded(x, 10, salt)),
    ('sym/stream9', 'sym', lambda x, salt: sc.rand_range(x, 9)[0]),
    ('sym/subset10', 'sym', lambda x, salt: sc.select_subset(list(range(10)), x, 1)[0]),
    ('tot/seeded9', 'tot', lambda x, salt: sc.rand_seeded(x, 9, salt) + 1),
    ('tot/seeded10', 'tot', lambda x, salt: sc.rand_seeded(x, 10, salt)),
    ('tot/stream9', 'tot', lambda x, salt: sc.rand_range(x, 9)[0] + 1),
]


def load(path):
    """-> [(seed, room, symbolIndex, total)]，教学关（stage 1）不参与拟合。"""
    obs = []
    for s in samples.parse(path):
        for stage, entries in s['stages'].items():
            if stage == 1:
                continue          # 教学关大概率是固定脚本
            for e in entries:
                if e['room'] and e['symbol'] is not None and e['total'] is not None:
                    obs.append((s['seed'], e['room'], e['symbol'], e['total']))
    return obs


def main():
    home = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
    path = sys.argv[1] if len(sys.argv) > 1 and not sys.argv[1].isdigit() \
        else os.path.join(home, 'test.txt')
    limit = int(sys.argv[2]) if len(sys.argv) > 2 else (1 << 19)

    obs = load(path)
    print('样本 %d 条：' % len(obs))
    for seed, room, sym, tot in obs:
        print('  %-7d %-36s symbol=%d total=%d' % (seed, room, sym, tot))
    if not obs:
        print('没有可用样本')
        return

    found = 0
    for bname, bfn in BASES:
        for mname, kind, fn in MODELS:
            for K in range(limit):
                ok = True
                for seed, room, sym, tot in obs:
                    v = fn((bfn(room) + K) & 0xFFFFFFFF, seed % 1000)
                    if v != (sym if kind == 'sym' else tot):
                        ok = False
                        break
                if ok:
                    found += 1
                    print('HIT base=%-8s model=%-12s K=%d' % (bname, mname, K))
        print('  ... base=%s done' % bname)
    print('常数扫描 0..%d 完成，命中 %d' % (limit - 1, found))


if __name__ == '__main__':
    main()
