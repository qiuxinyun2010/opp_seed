# -*- coding: utf-8 -*-
"""双 seed 检验「抽一个 → 剔除距离 < 1000 的候选 → 再抽」的最小间距算法。

实测选中机器两两距离都 > 1000（selftest 已断言），且协调器上确实配了
DistanceBetweenSameObjectives = 1000。单 seed 扫时假阳性太多无法判定，
现在用两个 seed 同时约束：School 可行组合 49778，双 seed 假阳性约 300000/49778^2 ≈ 0。
"""
import sys

M32 = 0xFFFFFFFF
M64 = 0xFFFFFFFFFFFFFFFF

_T = []
for _i in range(256):
    _c = _i
    for _ in range(8):
        _c = ((_c >> 1) ^ 0xEDB88320) if (_c & 1) else (_c >> 1)
    _T.append(_c & M32)


def crc32_fname(text):
    crc = M32
    for ch in text:
        u = ord(ch) & 0xFFFF
        crc = _T[(crc ^ (u & 0xFF)) & 0xFF] ^ (crc >> 8)
        crc = _T[(crc ^ (u >> 8)) & 0xFF] ^ (crc >> 8)
        crc = _T[crc & 0xFF] ^ (crc >> 8)
        crc = _T[crc & 0xFF] ^ (crc >> 8)
    return (~crc) & M32


def seed_of_object(name):
    value = (crc32_fname(name) + crc32_fname('PersistentLevel')) & M32
    return value if value < 0x80000000 else (0x100000000 - value) & M32


def mix1(x):
    z = (0xBF58476D1CE4E5B9 * (x ^ (x >> 30))) & M64
    return z ^ (z >> 27)


def rs(seed, n, salt):
    if not n or not seed:
        return 0
    B = (0x94D049BB133111EB * mix1(salt % 1000)) & M64
    v = ((0x94D049BB133111EB * mix1(seed)) & M64) ^ B
    t = (v ^ (v >> 31)) & M64
    w = (0xBF58476D1CE4E5B9 * (t ^ (t >> 30))) & M64
    u = (w ^ (w >> 27)) & M64
    r = (((321982955 * u) & M64) ^ (((0x94D049BB133111EB * u) & M64) >> 31)) & M64
    return (r & 0xFFFF) % n


sys.path.insert(0, '.')
import srr_mt02 as M

POOLS = {k: M.COORDS[k]['pool'] for k in ('School', 'SasExit')}
COORD = {k: M.COORDS[k]['actor'] for k in ('School', 'SasExit')}
POS = {k: M.TUNERS[k][1] for k in M.TUNERS}
WANT = {
    ('School', 417417): frozenset(['BP5', 'BP6', 'BP19', 'BP24', 'BP26', 'BP29']),
    ('School', 737737): frozenset(['BP5', 'BP8', 'BP11', 'BP21', 'BP25', 'BP27_3']),
    ('SasExit', 417417): frozenset(['BP45', 'BP43', 'BP31', 'BP38', 'BP36', 'BP47']),
    ('SasExit', 737737): frozenset(['BP30', 'BP33', 'BP37', 'BP45', 'BP40', 'BP47']),
}
D = 6


def d2(a, b):
    pa, pb = POS[a], POS[b]
    return (pa[0] - pb[0]) ** 2 + (pa[1] - pb[1]) ** 2 + (pa[2] - pb[2]) ** 2


def draw(key, base, salt, thr=1000.0, rev=False, swap=True):
    pool = list(POOLS[key])
    if rev:
        pool.reverse()
    mem = list(pool)
    t2 = thr * thr
    out = []
    i = 0
    while len(out) < D and mem:
        k = rs((base + i) & M32, len(mem), salt)
        i += 1
        pick = mem[k]
        out.append(pick)
        if swap:
            mem[k] = mem[-1]
            mem.pop()
        else:
            del mem[k]
        mem = [x for x in mem if d2(x, pick) >= t2]
    return out


def main():
    span = int(sys.argv[1]) if len(sys.argv) > 1 else 100000
    salt_crc = crc32_fname('Objective Actors')
    bases = {'coord': {k: seed_of_object(v) for k, v in COORD.items()}}
    bases['+salt'] = {k: (b + salt_crc) & M32 for k, b in bases['coord'].items()}
    for btag, bs in bases.items():
        for rev in (False, True):
            for swap in (True, False):
                for key in ('School', 'SasExit'):
                    cand = []
                    for delta in range(span):
                        if set(draw(key, (bs[key] + delta) & M32, 417417,
                                    rev=rev, swap=swap)) == WANT[(key, 417417)]:
                            cand.append(delta)
                    good = [d for d in cand
                            if set(draw(key, (bs[key] + d) & M32, 737737,
                                        rev=rev, swap=swap)) == WANT[(key, 737737)]]
                    if cand or good:
                        print('%-6s rev=%-5s swap=%-5s %-8s 417候选=%d → 双seed: %s'
                              % (btag, rev, swap, key, len(cand), good[:5] if good else '空'))
                        if good:
                            d0 = good[0]
                            b = (bs[key] + d0) & M32
                            print('      ★ delta=%d  417=%s' % (d0, draw(key, b, 417417, rev=rev, swap=swap)))
                            print('               737=%s' % draw(key, b, 737737, rev=rev, swap=swap))
                    else:
                        print('%-6s rev=%-5s swap=%-5s %-8s 无候选'
                              % (btag, rev, swap, key))


if __name__ == '__main__':
    main()
