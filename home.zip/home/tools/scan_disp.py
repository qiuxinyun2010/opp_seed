# -*- coding: utf-8 -*-
"""按「结构体偏移」定位代码：扫 .text 里的 [reg + disp32] 常量，再用 .pdata 归到函数入口。

这是反编译的定位手段，不是盲扫：只有用到某个成员偏移（例如 SRR 协调器的
+0x24B0 调频器数组 / +0x24C0 显示屏数组）的函数才会被挑出来，然后逐个反编译。

用法：
    python scan_disp.py 0x24B0 0x24C0           # 找用到这些偏移的函数
    python scan_disp.py 0x24B0 --bytes          # 同时打印命中附近的指令字节
    python scan_disp.py 0x24B0 --func 0x14358EA00   # 只查某个函数内部是否用到
"""
import struct
import sys

PATH = r"d:\workspace\outlast\TOTClient-Win64-Shipping.exe"
d = open(PATH, "rb").read()

pe = struct.unpack_from("<I", d, 0x3C)[0]
nsec = struct.unpack_from("<H", d, pe + 6)[0]
opt = pe + 24
magic = struct.unpack_from("<H", d, opt)[0]
image_base = (struct.unpack_from("<Q", d, opt + 24)[0] if magic == 0x20B
              else struct.unpack_from("<I", d, opt + 28)[0])
secoff = opt + struct.unpack_from("<H", d, pe + 20)[0]
SECS = []
for i in range(nsec):
    o = secoff + 40 * i
    name = d[o:o + 8].rstrip(b"\x00").decode("latin1")
    vsize, va, rawsize, rawptr = struct.unpack_from("<IIII", d, o + 8)
    SECS.append((name, va, vsize, rawptr, rawsize))


def va2off(va):
    rva = va - image_base
    for name, sva, vsize, rawptr, rawsize in SECS:
        if sva <= rva < sva + max(vsize, rawsize):
            return rawptr + (rva - sva)
    return None


def sec(name):
    for s in SECS:
        if s[0] == name:
            return s
    return None


def build_funcmap():
    """从 .pdata 建 RUNTIME_FUNCTION 表：begin -> (begin, end)。"""
    name, sva, vsize, rawptr, rawsize = sec('.pdata')
    entries = []
    for o in range(0, vsize, 12):
        begin, end, unwind = struct.unpack_from("<III", d, rawptr + o)
        if not begin or not end or end <= begin:
            continue
        entries.append((image_base + begin, image_base + end))
    entries.sort()
    return entries


FUNCS = build_funcmap()


def containing(va):
    lo, hi = 0, len(FUNCS) - 1
    while lo <= hi:
        mid = (lo + hi) // 2
        b, e = FUNCS[mid]
        if va < b:
            hi = mid - 1
        elif va >= e:
            lo = mid + 1
        else:
            return b, e
    return None


def scan(disp):
    """只保留真正的 `[reg+disp32]` 寻址：disp 前必须是一个 mod=10 的 ModRM。"""
    pat = struct.pack("<I", disp)
    name, sva, vsize, rawptr, rawsize = sec('.text')
    hits = []
    start = rawptr
    end = rawptr + vsize
    i = d.find(pat, start, end)
    while i >= 0:
        ok = False
        if i >= start + 1:
            modrm = d[i - 1]
            if (modrm & 0xC0) == 0x80 and (modrm & 0x07) != 0x04:
                ok = True            # [reg + disp32]
            elif (modrm & 0xC0) >= 0x80 and i >= start + 2:
                modrm2 = d[i - 2]
                if (modrm2 & 0xC0) == 0x80 and (modrm2 & 0x07) == 0x04:
                    ok = True        # [reg + index*n + disp32]
        if ok:
            hits.append(image_base + sva + (i - rawptr))
        i = d.find(pat, i + 1, end)
    return hits


def main():
    args = [a for a in sys.argv[1:] if not a.startswith('--')]
    if not args:
        print(__doc__)
        return
    only_func = None
    if '--func' in sys.argv:
        only_func = int(sys.argv[sys.argv.index('--func') + 1], 16)
    show_bytes = '--bytes' in sys.argv
    for a in args:
        disp = int(a, 16)
        if disp > 0x7FFFFF:
            continue
        hits = scan(disp)
        groups = {}
        for va in hits:
            c = containing(va)
            key = c[0] if c else None
            groups.setdefault(key, []).append(va)
        print('=== disp 0x%X : %d 处命中，%d 个函数' % (disp, len(hits), len(groups)))
        for fn in sorted(k for k in groups if k):
            if only_func and fn != only_func:
                continue
            c = containing(fn)
            offs = groups[fn]
            print('  0x%X  (size 0x%X, %d 处) %s'
                  % (fn, c[1] - c[0], len(offs),
                     ' '.join('%X' % o for o in offs[:8])))
            if show_bytes:
                for o in offs[:4]:
                    fo = va2off(o - 2)
                    print('     @%X: %s' % (o, ' '.join('%02x' % x for x in d[fo:fo + 10])))


if __name__ == '__main__':
    main()
