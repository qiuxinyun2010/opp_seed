# -*- coding: utf-8 -*-
"""用「屏幕顺序 = 抽序前 3 台」这个有序约束定机器抽取算法。

玩法澄清：6 台里只有 3 台需要调频，顺序就是 3 块屏幕从左到右的图案顺序。
所以每轮的「抽序前 3 台」是已知的（见下表），约束是有序 3 元组：

  轮1 RichDistrict(池4)  417: BP BP2 BP3        737: BP2 BP3 BP49
  轮2 School      (池26) 417: BP24 BP26 BP5     737: BP21 BP25 BP11
  轮3 SasExit     (池19) 417: BP43 BP45 BP36    737: BP40 BP45 BP30

单 seed 命中率 1/P(n,3)：轮2 = 1/15600，轮3 = 1/5814，轮1 = 1/24。
双 seed 联合后假阳性约 1e-9 量级 → 命中即定解。
"""
import sys

M32 = 0xFFFFFFFF
M64 = 0xFFFFFFFFFFFFFFFF

_T = []
for _i in range(256):
    _c = _i
    for _ in range(8):
        _c = ((_c >> 1) ^ 0xEDB88320) if (_c & 1) else (_c >> 1)
    _T.append(_c & M32)


def crc32_fname(text):
    crc = M32
    for ch in text:
        u = ord(ch) & 0xFFFF
        crc = _T[(crc ^ (u & 0xFF)) & 0xFF] ^ (crc >> 8)
        crc = _T[(crc ^ (u >> 8)) & 0xFF] ^ (crc >> 8)
        crc = _T[crc & 0xFF] ^ (crc >> 8)
        crc = _T[crc & 0xFF] ^ (crc >> 8)
    return (~crc) & M32


def seed_of_object(name):
    value = (crc32_fname(name) + crc32_fname('PersistentLevel')) & M32
    return value if value < 0x80000000 else (0x100000000 - value) & M32


def mix1(x):
    z = (0xBF58476D1CE4E5B9 * (x ^ (x >> 30))) & M64
    return z ^ (z >> 27)


def rs(seed, n, salt):
    if not n or not seed:
        return 0
    B = (0x94D049BB133111EB * mix1(salt % 1000)) & M64
    v = ((0x94D049BB133111EB * mix1(seed)) & M64) ^ B
    t = (v ^ (v >> 31)) & M64
    w = (0xBF58476D1CE4E5B9 * (t ^ (t >> 30))) & M64
    u = (w ^ (w >> 27)) & M64
    r = (((321982955 * u) & M64) ^ (((0x94D049BB133111EB * u) & M64) >> 31)) & M64
    return (r & 0xFFFF) % n


sys.path.insert(0, '.')
import srr_mt02 as M

POOLS = {k: M.COORDS[k]['pool'] for k in ('RichDistrict', 'School', 'SasExit')}
COORD = {k: M.COORDS[k]['actor'] for k in ('RichDistrict', 'School', 'SasExit')}
POS = {k: M.TUNERS[k][1] for k in M.TUNERS}

# 屏幕顺序 ⇒ 抽序前 3 台
ORDER3 = {
    ('RichDistrict', 417417): ['BP', 'BP2', 'BP3'],
    ('RichDistrict', 737737): ['BP2', 'BP3', 'BP49'],
    ('School', 417417): ['BP24', 'BP26', 'BP5'],
    ('School', 737737): ['BP21', 'BP25', 'BP11'],
    ('SasExit', 417417): ['BP43', 'BP45', 'BP36'],
    ('SasExit', 737737): ['BP40', 'BP45', 'BP30'],
}


def d2(a, b):
    pa, pb = POS[a], POS[b]
    return (pa[0] - pb[0]) ** 2 + (pa[1] - pb[1]) ** 2 + (pa[2] - pb[2]) ** 2


def draw(key, base, mode, salt, n=3, rev=False, thr=0.0):
    pool = list(POOLS[key])
    if rev:
        pool.reverse()
    out = []
    if mode == 'plain':
        mem = list(pool)
        for i in range(n):
            k = rs((base + i) & M32, len(mem), salt)
            out.append(mem[k])
            mem[k] = mem[-1]
            mem.pop()
    elif mode == 'rm':
        mem = list(pool)
        for i in range(n):
            k = rs((base + i) & M32, len(mem), salt)
            out.append(mem[k])
            del mem[k]
    elif mode == 'fy':
        mem = list(pool)
        for i in range(len(mem), 1, -1):
            j = rs((base + (len(mem) - i)) & M32, i, salt)
            mem[i - 1], mem[j] = mem[j], mem[i - 1]
        out = mem[:n]
    elif mode == 'popall':
        mem = list(pool)
        for i in range(n):
            k = rs((base + i) & M32, len(mem), salt)
            out.append(mem[k])
            mem[k] = mem[-1]
            mem.pop()
    elif mode == 'dist':                      # 抽一个 → 剔除 thr 内的
        mem = list(pool)
        t2 = thr * thr
        for i in range(n):
            if not mem:
                break
            k = rs((base + i) & M32, len(mem), salt)
            pick = mem[k]
            out.append(pick)
            mem[k] = mem[-1]
            mem.pop()
            mem = [x for x in mem if d2(x, pick) >= t2]
    return out


def main():
    span = int(sys.argv[1]) if len(sys.argv) > 1 else 300000
    salt_crc = crc32_fname('Objective Actors')
    base_sets = {
        'coord': {k: seed_of_object(v) for k, v in COORD.items()},
        '+salt': {k: (seed_of_object(v) + salt_crc) & M32 for k, v in COORD.items()},
    }
    modes = sys.argv[2].split(',') if len(sys.argv) > 2 else ('plain', 'rm', 'fy', 'popall')
    for key in ('School', 'SasExit', 'RichDistrict'):
        print('=== %s (池 %d)' % (key, len(POOLS[key])))
        for btag, bs in base_sets.items():
            for mode in modes:
                for rev in (False, True):
                    cand = []
                    thr = 1000.0 if mode == 'dist' else 0.0
                    for delta in range(span):
                        if draw(key, (bs[key] + delta) & M32, mode, 417417,
                                rev=rev, thr=thr) == ORDER3[(key, 417417)]:
                            cand.append(delta)
                    if not cand:
                        continue
                    good = [d for d in cand
                            if draw(key, (bs[key] + d) & M32, mode, 737737,
                                    rev=rev, thr=thr) == ORDER3[(key, 737737)]]
                    print('   %-6s %-7s rev=%-5s 417候选=%d → 双seed: %s'
                          % (btag, mode, rev, len(cand), good[:6] if good else '空'))
                    if good:
                        d0 = good[0]
                        b = (bs[key] + d0) & M32
                        print('      ★ delta=%d 417=%s' % (d0, draw(key, b, mode, 417417, rev=rev)))
                        print('                737=%s' % draw(key, b, mode, 737737, rev=rev))


if __name__ == '__main__':
    main()
