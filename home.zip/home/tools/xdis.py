# -*- coding: utf-8 -*-
"""最小 x86-64 长度解码器：只求"指令边界正确 + 关键操作数可见"，不做完整反汇编。

覆盖范围（够读本工程的目标代码）：
  REX / 66 / F2 / F3 前缀
  mov 88 89 8A 8B C6 C7 B0-BF A0-A3
  lea 8D            add/sub/and/or/xor/cmp 00-3B 80 81 83 84 85
  test A8 A9        imul 69 6B 0F AF        movzx/movsx 0F B6 B7 BE BF
  push/pop 50-5F 68 6A FF/6    inc/dec FF/0 FF/1 FE/0 FE/1
  call/jmp E8 E9 EB + FF/2 FF/4 + 0F 8x + 7x
  ret C3 C2         leave C9      nop 90      int3 CC
  shl/shr/sar C0 C1 D0-D3
  div/idiv F6 F7 /6 /7          cdqe/cqo 98 99
  setcc 0F 90-9F    cmov 0F 40-4F
  SSE: 0F 10/11/28/29/57/6E/7E, F3/F2/66 前缀组合

    python xdis.py 0x1402B1F60 0x1402B2020
"""
import sys
import os

_HERE = os.path.dirname(os.path.abspath(__file__))
sys.path.insert(0, _HERE)
import scan_disp as sd

R64 = ['rax', 'rcx', 'rdx', 'rbx', 'rsp', 'rbp', 'rsi', 'rdi',
       'r8', 'r9', 'r10', 'r11', 'r12', 'r13', 'r14', 'r15']
R32 = ['eax', 'ecx', 'edx', 'ebx', 'esp', 'ebp', 'esi', 'edi',
       'r8d', 'r9d', 'r10d', 'r11d', 'r12d', 'r13d', 'r14d', 'r15d']
R8 = ['al', 'cl', 'dl', 'bl', 'spl', 'bpl', 'sil', 'dil',
      'r8b', 'r9b', 'r10b', 'r11b', 'r12b', 'r13b', 'r14b', 'r15b']


def decode(code, i, va):
    """返回 (长度, 文本)。无法识别时返回 (1, 'db 0xXX')。"""
    start = i
    rex = 0
    p66 = pF2 = pF3 = False
    while i < len(code):
        b = code[i]
        if 0x40 <= b <= 0x4F:
            rex = b
            i += 1
            continue
        if b == 0x66:
            p66 = True
            i += 1
            continue
        if b == 0xF2:
            pF2 = True
            i += 1
            continue
        if b == 0xF3:
            pF3 = True
            i += 1
            continue
        break
    if i >= len(code):
        return (i - start, 'prefix')
    op = code[i]
    i += 1
    W = bool(rex & 0x08)
    R = (rex & 0x04) << 1
    X = (rex & 0x02) << 1
    B = (rex & 0x01) << 3

    def reg(n):
        n = (n & 7) | (B if False else 0)
        return n

    def rm_operand(ri, size_w):
        """解析 modrm+sib+disp，返回 (长度, 文本)"""
        if i + ri >= len(code):
            return (0, '')
        m = code[i + ri]
        mod = m >> 6
        rmn = (m & 7) | B
        ln = 1
        sib_txt = ''
        if mod == 3:
            return (1, R64[rmn])
        if mod != 3 and (m & 7) == 4:
            sib = code[i + ri + 1]
            ln += 1
            base = (sib & 7) | B
            index = ((sib >> 3) & 7) | X
            scale = 1 << (sib >> 6)
            sib_txt = R64[base]
            if index != 4:
                sib_txt = '%s+%s*%d' % (sib_txt, R64[index], scale)
        if mod == 0:
            if (m & 7) == 5:
                d = int.from_bytes(code[i + ri + 1:i + ri + 5], 'little', signed=True)
                return (ln + 4, '[rip%+d]' % d)
            if sib_txt:
                return (ln, '[%s]' % sib_txt)
            return (ln, '[%s]' % R64[rmn])
        if mod == 1:
            d = int.from_bytes(code[i + ri + ln:i + ri + ln + 1], 'little', signed=True)
            return (ln + 1, '[%s%+d]' % (sib_txt or R64[rmn], d))
        d = int.from_bytes(code[i + ri + ln:i + ri + ln + 4], 'little', signed=True)
        return (ln + 4, '[%s%+d]' % (sib_txt or R64[rmn], d))

    # --- 固定格式 / 单字节 ---
    if op == 0x90:
        return (i - start, 'nop')
    if op == 0xCC:
        return (i - start, 'int3')
    if op == 0xC3:
        return (i - start, 'ret')
    if op == 0xC9:
        return (i - start, 'leave')
    if op in (0x98, 0x99):
        return (i - start, 'cdq/cqo')
    if op == 0xC2:
        return (i - start + 2, 'ret imm16')
    if 0x50 <= op <= 0x57:
        return (i - start, 'push %s' % R64[(op - 0x50) | B])
    if 0x58 <= op <= 0x5F:
        return (i - start, 'pop %s' % R64[(op - 0x58) | B])
    if op == 0x68:
        return (i - start + 4, 'push imm32')
    if op == 0x6A:
        return (i - start + 1, 'push imm8')
    if 0xB0 <= op <= 0xB7:
        return (i - start + 1, 'mov %s, imm8' % R8[(op - 0xB0) | B])
    if 0xB8 <= op <= 0xBF:
        n = R64[(op - 0xB8) | B]
        if W:
            return (i - start + 8, 'mov %s, imm64' % n)
        return (i - start + 4, 'mov %s, imm32' % n)
    if op in (0xE8, 0xE9):
        rel = int.from_bytes(code[i:i + 4], 'little', signed=True)
        tgt = va + (i - start) + 4 + rel
        return (i - start + 4, '%s 0x%X' % ('call' if op == 0xE8 else 'jmp', tgt))
    if op == 0xEB:
        rel = int.from_bytes(code[i:i + 1], 'little', signed=True)
        return (i - start + 1, 'jmp short 0x%X' % (va + (i - start) + 1 + rel))
    if 0x70 <= op <= 0x7F:
        rel = int.from_bytes(code[i:i + 1], 'little', signed=True)
        return (i - start + 1, 'jcc 0x%X' % (va + (i - start) + 1 + rel))

    # --- 双字节 ---
    if op == 0x0F:
        op2 = code[i]
        i += 1
        if 0x80 <= op2 <= 0x8F:
            rel = int.from_bytes(code[i:i + 4], 'little', signed=True)
            return (i - start + 4, 'jcc near 0x%X' % (va + (i - start) + 4 + rel))
        if op2 in (0x10, 0x11, 0x28, 0x29, 0x57, 0x6E, 0x7E):
            ln, t = rm_operand(0, W)
            m = code[i]
            regn = ((m >> 3) & 7) | R
            return (i - start + ln, 'movss/movaps xmm%d, %s' % (regn, t))
        if op2 in (0xB6, 0xB7, 0xBE, 0xBF):
            ln, t = rm_operand(0, W)
            m = code[i]
            regn = ((m >> 3) & 7) | R
            return (i - start + ln, 'movzx/movsx %s, %s' % (R64[regn], t))
        if op2 == 0xAF:
            ln, t = rm_operand(0, W)
            m = code[i]
            regn = ((m >> 3) & 7) | R
            return (i - start + ln, 'imul %s, %s' % (R64[regn], t))
        if 0x40 <= op2 <= 0x4F:
            ln, t = rm_operand(0, W)
            return (i - start + ln, 'cmov%s %s' % (op2 & 0xF, t))
        if 0x90 <= op2 <= 0x9F:
            ln, t = rm_operand(0, W)
            return (i - start + ln, 'setcc %s' % t)
        if op2 == 0x1F:
            ln, t = rm_operand(0, W)
            return (i - start + ln, 'nop %s' % t)
        return (i - start + 1, '0f %02x ?' % op2)

    # --- modrm 家族 ---
    if op in (0x88, 0x89, 0x8A, 0x8B, 0x8D, 0x00, 0x01, 0x02, 0x03,
              0x28, 0x29, 0x2A, 0x2B, 0x30, 0x31, 0x32, 0x33,
              0x38, 0x39, 0x3A, 0x3B, 0x84, 0x85, 0x86, 0x87):
        ln, t = rm_operand(0, W)
        m = code[i]
        regn = ((m >> 3) & 7) | R
        mod = m >> 6
        is8 = (op in (0x88, 0x8A, 0x00, 0x02, 0x28, 0x2A, 0x30, 0x32, 0x38, 0x3A, 0x84, 0x86))
        if mod == 3:
            src = R8[regn] if is8 else (R64[regn] if W else R32[regn])
            dst = R8[(m & 7) | B] if is8 else (R64[(m & 7) | B] if W else R32[(m & 7) | B])
        else:
            src = R8[regn] if is8 else (R64[regn] if W else R32[regn])
            dst = t
        mn = {0x88: 'mov', 0x89: 'mov', 0x8A: 'mov', 0x8B: 'mov', 0x8D: 'lea',
              0x00: 'add', 0x01: 'add', 0x02: 'add', 0x03: 'add',
              0x28: 'sub', 0x29: 'sub', 0x2A: 'sub', 0x2B: 'sub',
              0x30: 'xor', 0x31: 'xor', 0x32: 'xor', 0x33: 'xor',
              0x38: 'cmp', 0x39: 'cmp', 0x3A: 'cmp', 0x3B: 'cmp',
              0x84: 'test', 0x85: 'test', 0x86: 'xchg', 0x87: 'xchg'}[op]
        if op in (0x8A, 0x8B, 0x8D, 0x02, 0x03, 0x2A, 0x2B, 0x32, 0x33, 0x3A, 0x3B):
            return (i - start + ln, '%s %s, %s' % (mn, src, dst))
        return (i - start + ln, '%s %s, %s' % (mn, dst, src))

    if op == 0x63:
        ln, t = rm_operand(0, W)
        m = code[i]
        regn = ((m >> 3) & 7) | R
        return (i - start + ln, 'movsxd %s, %s' % (R64[regn], t))

    if op in (0xC6, 0xC7):
        ln, t = rm_operand(0, W)
        if op == 0xC6:
            return (i - start + ln + 1, 'mov %s, imm8' % t)
        return (i - start + ln + 4, 'mov %s, imm32' % t)

    if op in (0x80, 0x81, 0x83):
        ln, t = rm_operand(0, W)
        m = code[i]
        sub = (m >> 3) & 7
        names = ['add', 'or', 'adc', 'sbb', 'and', 'sub', 'xor', 'cmp']
        if op == 0x80:
            return (i - start + ln + 1, '%s %s, imm8' % (names[sub], t))
        if op == 0x83:
            return (i - start + ln + 1, '%s %s, imm8' % (names[sub], t))
        return (i - start + ln + 4, '%s %s, imm32' % (names[sub], t))

    if op in (0xA8, 0xA9):
        n = 1 if op == 0xA8 else 4
        return (i - start + n, 'test acc, imm')

    if op == 0xF6 or op == 0xF7:
        ln, t = rm_operand(0, W)
        sub = (code[i] >> 3) & 7
        nm = {0: 'test', 2: 'not', 3: 'neg', 4: 'mul', 5: 'imul',
              6: 'div', 7: 'idiv'}.get(sub, 'grp3')
        if sub in (0,):
            return (i - start + ln + (1 if op == 0xF6 else 4), '%s %s, imm' % (nm, t))
        return (i - start + ln, '%s %s' % (nm, t))

    if op == 0xFF:
        ln, t = rm_operand(0, W)
        sub = (code[i] >> 3) & 7
        nm = {0: 'inc', 1: 'dec', 2: 'call', 3: 'callf', 4: 'jmp', 6: 'push'}.get(sub, 'ff')
        return (i - start + ln, '%s %s' % (nm, t))

    if op == 0xFE:
        ln, t = rm_operand(0, W)
        sub = (code[i] >> 3) & 7
        return (i - start + ln, '%s %s' % ('inc' if sub == 0 else 'dec', t))

    if op == 0x69 or op == 0x6B:
        ln, t = rm_operand(0, W)
        m = code[i]
        regn = ((m >> 3) & 7) | R
        n = 4 if op == 0x69 else 1
        return (i - start + ln + n, 'imul %s, %s, imm' % (R64[regn], t))

    if op in (0xC0, 0xC1, 0xD0, 0xD1, 0xD2, 0xD3):
        ln, t = rm_operand(0, W)
        sub = (code[i] >> 3) & 7
        nm = ['rol', 'ror', 'rcl', 'rcr', 'shl', 'shr', 'sal', 'sar'][sub]
        n = 0 if op in (0xD0, 0xD1, 0xD2, 0xD3) else 1
        return (i - start + ln + n, '%s %s' % (nm, t))

    # 兜底：按 1 字节
    return (1, 'db 0x%02X' % code[start])


def main():
    lo = int(sys.argv[1], 16)
    hi = int(sys.argv[2], 16)
    off = sd.va2off(lo)
    code = sd.d[off:off + (hi - lo)]
    va = lo
    i = 0
    unknown = 0
    while i < len(code):
        ln, txt = decode(code, i, va)
        if ln <= 0:
            ln = 1
        if txt.startswith('db'):
            unknown += 1
        raw = ' '.join('%02x' % b for b in code[i:i + ln])
        print('%X  %-24s %s' % (va, raw, txt))
        i += ln
        va += ln
    print('--- 未知字节 %d 个 / 总 %d 字节' % (unknown, len(code)))


if __name__ == '__main__':
    main()
