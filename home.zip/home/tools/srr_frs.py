# -*- coding: utf-8 -*-
"""试 FRandomStream 这条随机链（与 RandSeeded 是不同原语，此前完全没试过）。

home/README.md 的《随机原语速查》记录：
    FRandomStream | state = state*196314165 + 907633515
                    GetFraction 取 state>>9 | 0x3F800000（位模式当 float，再 -1）
                    select_subset = 保序抽走
    RandHelper(n) = TruncToInt(GetFraction() * n)

FRandomStream 自身不含 level_seed，所以种子里必须掺入 level_seed 才能解释
两个 seed 结果不同 —— 试几种掺法。
"""
import struct
import sys

M32 = 0xFFFFFFFF

_T = []
for _i in range(256):
    _c = _i
    for _ in range(8):
        _c = ((_c >> 1) ^ 0xEDB88320) if (_c & 1) else (_c >> 1)
    _T.append(_c & M32)


def crc32_fname(text):
    crc = M32
    for ch in text:
        u = ord(ch) & 0xFFFF
        crc = _T[(crc ^ (u & 0xFF)) & 0xFF] ^ (crc >> 8)
        crc = _T[(crc ^ (u >> 8)) & 0xFF] ^ (crc >> 8)
        crc = _T[crc & 0xFF] ^ (crc >> 8)
        crc = _T[crc & 0xFF] ^ (crc >> 8)
    return (~crc) & M32


def seed_of_object(name):
    value = (crc32_fname(name) + crc32_fname('PersistentLevel')) & M32
    return value if value < 0x80000000 else (0x100000000 - value) & M32


sys.path.insert(0, '.')
import srr_mt02 as M

POOLS = {k: M.COORDS[k]['pool'] for k in ('RichDistrict', 'School', 'SasExit')}
COORD = {k: M.COORDS[k]['actor'] for k in ('RichDistrict', 'School', 'SasExit')}
POS = {k: M.TUNERS[k][1] for k in M.TUNERS}

SET6 = {
    ('School', 417417): {'BP5', 'BP6', 'BP19', 'BP24', 'BP26', 'BP29'},
    ('School', 737737): {'BP5', 'BP8', 'BP11', 'BP21', 'BP25', 'BP27_3'},
    ('SasExit', 417417): {'BP45', 'BP43', 'BP31', 'BP38', 'BP36', 'BP47'},
    ('SasExit', 737737): {'BP30', 'BP33', 'BP37', 'BP45', 'BP40', 'BP47'},
    ('RichDistrict', 417417): {'BP', 'BP2', 'BP3', 'BP49'},
    ('RichDistrict', 737737): {'BP', 'BP2', 'BP3', 'BP49'},
}
TARGET3 = {
    ('RichDistrict', 417417): ['BP', 'BP2', 'BP3'],
    ('RichDistrict', 737737): ['BP2', 'BP3', 'BP49'],
    ('School', 417417): ['BP24', 'BP26', 'BP5'],
    ('School', 737737): ['BP21', 'BP25', 'BP11'],
    ('SasExit', 417417): ['BP43', 'BP45', 'BP36'],
    ('SasExit', 737737): ['BP40', 'BP45', 'BP30'],
}
SALT_CRC = crc32_fname('Objective Actors')


def mutate(s):
    return (s * 196314165 + 907633515) & M32


def fraction(s):
    bits = (s >> 9) | 0x3F800000
    return struct.unpack('<f', struct.pack('<I', bits))[0] - 1.0


def seed_init(kind, key, level_seed):
    g = seed_of_object(COORD[key])
    if kind == 'level':
        return level_seed & M32
    if kind == 'g+level':
        return (g + level_seed) & M32
    if kind == 'g^level':
        return (g ^ level_seed) & M32
    if kind == 'g+salt+level':
        return (g + SALT_CRC + level_seed) & M32
    if kind == 'level*g':
        return (g * level_seed) & M32
    if kind == 'g+level%1000':
        return (g + level_seed % 1000) & M32
    return None


def draw(key, state0, n, swap=False, thr=0.0):
    """保序 / swap 移除两种都试；thr>0 时额外剔除距离内的候选。"""
    mem = list(POOLS[key])
    out = []
    s = state0
    t2 = thr * thr
    for _ in range(n):
        if not mem:
            break
        s = mutate(s)
        k = int(fraction(s) * len(mem))
        if k >= len(mem):
            k = len(mem) - 1
        pick = mem[k]
        out.append(pick)
        if swap:
            mem[k] = mem[-1]
            mem.pop()
        else:
            del mem[k]
        if t2:
            mem = [x for x in mem if d2(x, pick) >= t2]
    return out


def d2(a, b):
    pa, pb = POS[a], POS[b]
    return (pa[0] - pb[0]) ** 2 + (pa[1] - pb[1]) ** 2 + (pa[2] - pb[2]) ** 2


def main():
    kinds = ('level', 'g+level', 'g^level', 'g+salt+level', 'level*g', 'g+level%1000')
    for kind in kinds:
        for swap in (False, True):
            for thr in (0.0, 1000.0):
                lines = []
                for key in ('School', 'SasExit'):
                    n = 6 if key != 'RichDistrict' else 4
                    ok_set = all(set(draw(key, seed_init(kind, key, s), n, swap, thr)) == SET6[(key, s)]
                                 for s in (417417, 737737))
                    ok_t3 = all(draw(key, seed_init(kind, key, s), 3, swap, thr) == TARGET3[(key, s)]
                                for s in (417417, 737737))
                    if ok_set or ok_t3:
                        lines.append('%s: %s%s' % (key, '集合✔ ' if ok_set else '',
                                                   '前3✔' if ok_t3 else ''))
                if lines:
                    print('★ %-13s swap=%-5s thr=%-6s  %s' % (kind, swap, thr, ' | '.join(lines)))
                    for key in ('School', 'SasExit'):
                        s0 = seed_init(kind, key, 417417)
                        print('     %s 417 前3=%s  前6=%s'
                              % (key, draw(key, s0, 3, swap, thr), draw(key, s0, 6, swap, thr)))
    print('（未打印 ★ 的组合即全部不匹配）')


if __name__ == '__main__':
    main()
