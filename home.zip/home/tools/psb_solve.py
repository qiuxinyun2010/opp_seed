# -*- coding: utf-8 -*-
"""PSB_MT01：联合反解「每区候选组的初始顺序」。

尸体 = group[ RandSeeded(B + 243551 + V + j, |group|, salt) ]（抽后保序删除）
图案 = pool[ RandSeeded(B + 223551 + V + j, |pool|,  salt) ]（抽后保序删除）

未知量：三个扇区候选组的**初始顺序**（以及组大小 nA/nB/nC）。
已知：两条实测 seed 的「图案 ↔ 尸体」配对。

用法： python tools/psb_solve.py
"""
import sys, os, itertools
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.abspath(__file__))))
sys.path.insert(0, r'd:\workspace\outlast\opp_seed')
import seedcore as sc
import psb_mt01_static as S
import psb_model as pm

B, OK, OC = pm.B, pm.OFF_KEY, pm.OFF_CORPSE
GROUPS = pm.GROUPS
M32 = 0xFFFFFFFF

P = 'CorpseSearch_PS_Trial02_'
# 实测「图案 -> 尸体」
OBS = {
    378378: {
        'A': {'Moon': P + 'AgainstWall_BP_2',
              'Crown': P + 'BP3_8',
              'Heart': P + 'AgainstWall_BP2_5'},
        'C': {'Spade': P + 'WallThroat_BP8_32',
              'Eye': P + 'BP7_2',
              'Club': P + 'OnChair_BP3_8'},
        'B': {'Fire': P + 'WallThroat_BP7_26',
              'Diamond': P + 'Desk_BP_5',
              'Bunny': P + 'Desk_BP2_2'},
    },
    565565: {
        'A': {'Heart': P + 'AgainstWall_BP3_8'},
        'B': {'Club': P + 'BP10_35'},
    },
}
# 565565 那条「方块 = AgainstWall_BP5_2」到底落在哪个扇区，交给求解器判定
AMBIG = (565565, P + 'AgainstWall_BP5_2')


def plan(seed, sizes):
    """返回 [(sec, j, slot, n, pattern)]，slot = 该组员在**初始**顺序里的下标。"""
    salt = seed % 1000
    out = []
    V = 0
    for sec, cnt in GROUPS:
        n = sizes[sec]
        free = list(range(n))
        pool = list(pm.POOL)
        for j in range(cnt):
            ci = sc.rand_seeded((B + OC + V + j) & M32, len(free), salt)
            slot = free.pop(ci)
            ki = sc.rand_seeded((B + OK + V + j) & M32, len(pool), salt)
            pat = pool.pop(ki)
            out.append((sec, j, slot, n, pat))
            V += 1
    return out


def solve():
    by_actor = {c['actor']: c for c in S.CORPSES}
    results = []
    for dia_sec in ('B', 'C', 'A'):
        obs = {sd: {s: dict(d) for s, d in v.items()} for sd, v in OBS.items()}
        for _sec in 'ABC':
            obs[565565].setdefault(_sec, {})
        obs[565565][dia_sec]['Diamond'] = AMBIG[1]
        # 一致性：任何 actor 不能出现在两个扇区
        seen = {}
        bad = False
        for sd, per in obs.items():
            for s, m in per.items():
                for pat, act in m.items():
                    if act in seen and seen[act] != s:
                        bad = True
                    seen[act] = s
        if bad:
            continue
        for nA in range(3, 21):
            for nC in range(4, 21):
                for nB in range(3, 21):
                    sizes = {'A': nA, 'B': nB, 'C': nC}
                    cons = {s: {} for s in 'ABC'}
                    conflict = False
                    for sd in sorted(obs):
                        for sec, j, slot, n, pat in plan(sd, sizes):
                            act = obs[sd].get(sec, {}).get(pat)
                            if not act:
                                continue
                            if slot in cons[sec] and cons[sec][slot] != act:
                                conflict = True
                                break
                            cons[sec][slot] = act
                        if conflict:
                            break
                    if conflict:
                        continue
                    tot = sum(len(v) for v in cons.values())
                    results.append((tot, sizes, dia_sec, cons))
    results.sort(key=lambda r: -r[0])
    print('可行解 %d 组（按「确定的槽位数」降序，前 12 组）：' % len(results))
    for tot, sizes, dia, cons in results[:12]:
        print('  nA=%-2d nC=%-2d nB=%-2d  方块565565∈%s  已定槽位=%d  (%s)'
              % (sizes['A'], sizes['C'], sizes['B'], dia, tot,
                 ','.join('%s:%d' % (s, len(cons[s])) for s in 'ABC')))
    return results


if __name__ == '__main__':
    try:
        sys.stdout.reconfigure(encoding='utf-8')
    except Exception:
        pass
    res = solve()
    if res:
        tot, sizes, dia, cons = res[0]
        print('\n最优解：nA=%d nC=%d nB=%d，方块565565 ∈ %s' % (sizes['A'], sizes['C'], sizes['B'], dia))
        for s in 'ABC':
            print('  Sector %s 初始槽位约束：' % s)
            for k in sorted(cons[s]):
                print('    %2d -> %s' % (k, cons[s][k].replace(P, '')))
