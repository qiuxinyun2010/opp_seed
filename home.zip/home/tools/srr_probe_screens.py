# -*- coding: utf-8 -*-
"""定向验证：显示屏上的 3 个图案，能否由 seed 直接抽出来？

模型（都要求 6 个样本同时成立）：
  B1  screen[i] = clue[ RandSeeded(S + O + stride*i, len-i) ]，取出即删
  B2  screen 顺序无所谓，只看「3 个图案的集合」
S = GetSeed(协调器)；另测 base = S + crc32('Objective Actors')。

命中门槛：6 个样本全中。随机期望命中数 ≈ 扫描量 / (各样本排列数之积) ≈ 0。
"""
import os
import sys

sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.abspath(__file__))))
import srr_mt02 as m

TESTS = [
    (417417, 'RichDistrict', ['Moon', 'Bunny', 'Club']),
    (417417, 'School', ['Diamond', 'Heart', 'Bunny']),
    (417417, 'SasExit', ['Diamond', 'Moon', 'Bunny']),
    (737737, 'RichDistrict', ['Moon', 'Spade', 'Club']),
    (737737, 'School', ['Club', 'Moon', 'Heart']),
    (737737, 'SasExit', ['Moon', 'Heart', 'Diamond']),
]


def prep(base_kind):
    preps = []
    for level_seed, key, screens in TESTS:
        S = m.seed_of_object(m.COORDS[key]['actor'])
        if base_kind == 'salt':
            S = (S + m.crc32_fname(m.SALT_NAME)) & m.M32
        clues = m.COORDS[key]['clues']
        idx = [clues.index(c) for c in screens]
        preps.append((S, level_seed, clues, idx))
    return preps


def run(base_kind, span, stride, mode, ordered=True):
    preps = prep(base_kind)
    hits = []
    for O in range(span):
        ok = True
        for S, level_seed, clues, want in preps:
            pool = list(clues)
            for i in range(3):
                k = m.rand_seeded((S + O + stride * i) & m.M32, len(pool), level_seed)
                if ordered:
                    if k != want[i]:
                        ok = False
                        break
                else:
                    # 只看集合：按 want 位置顺序消掉
                    if clues[k] not in want:
                        ok = False
                        break
                if mode == 'swap':
                    pool[k] = pool[-1]
                    pool.pop()
                else:
                    pool.pop(k)
            if not ok:
                break
        if ok:
            hits.append(O)
    return hits


def main():
    span = int(sys.argv[1]) if len(sys.argv) > 1 else 1 << 18
    for ordered in (True, False):
        for base_kind in ('coord', 'salt'):
            for stride in (0, 1, 2):
                for mode in ('swap', 'stable'):
                    h = run(base_kind, span, stride, mode, ordered)
                    tag = 'ORDERED' if ordered else 'SET'
                    if h:
                        print('HIT %-7s base=%-5s stride=%d %-6s  offs=%s'
                              % (tag, base_kind, stride, mode, [hex(x) for x in h[:12]]))
                    else:
                        print('none  %-7s base=%-5s stride=%d %-6s' % (tag, base_kind, stride, mode))


if __name__ == '__main__':
    main()
