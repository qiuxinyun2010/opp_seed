# -*- coding: utf-8 -*-
"""MHS_MT01 探针：符号 → 房间，以及「每房间最多一个目标」约束验证。

只读 paks/ 与 release/map/，输出 30 个投影符号的房间归属。
"""
import json
import sys
from pathlib import Path

ROOT = Path(__file__).resolve().parents[3]          # d:/workspace/outlast
LEVEL_JSON = ROOT / 'paks/MAP/Maps/MobsterHideoutSyndicate/MHS_LD_MT01_B00.json'
PLAN_JSON = ROOT / 'release/map/out/MobsterHideoutSyndicate/plan.json'
SYMBOL_PREFIX = 'MT01_ProjectionSymbol_BP_'
ZONES = ['DrugLab', 'Shipyard', 'TrainDepot']


def load_objects(path):
    data = json.loads(Path(path).read_text(encoding='utf-8'))
    objs = []
    for item in data:
        objs.extend(item) if isinstance(item, list) else objs.append(item)
    return [o for o in objs if isinstance(o, dict)]


def inside(point, hull):
    x, y = point
    flag = False
    n = len(hull)
    for i in range(n):
        x1, y1 = hull[i]
        x2, y2 = hull[(i + 1) % n]
        if (y1 > y) != (y2 > y):
            if x < x1 + (y - y1) * (x2 - x1) / (y2 - y1):
                flag = not flag
    return flag


def room_at(rooms, x, y, z):
    def zdist(r):
        return max(0.0, r['zmin'] - z, z - r['zmax'])

    hits = [r for r in rooms if any(inside((x, y), h) for h in r['hulls'])]
    if hits:
        best = min(hits, key=lambda r: (zdist(r), (r['cx'] - x) ** 2 + (r['cy'] - y) ** 2))
        return best['raw_name'], zdist(best) > 150.0
    best = min(rooms, key=lambda r: ((r['cx'] - x) ** 2 + (r['cy'] - y) ** 2) * (1.0 + zdist(r)))
    return best['raw_name'], True


def main():
    objs = load_objects(LEVEL_JSON)
    rooms = json.loads(PLAN_JSON.read_text(encoding='utf-8')).get('rooms', [])
    print('rooms =', len(rooms))

    loc = {}
    for o in objs:
        if o.get('Name') != 'Root':
            continue
        outer = (o.get('Outer') or {}).get('ObjectName') or ''
        if SYMBOL_PREFIX not in outer:
            continue
        name = outer.split('.')[-1].rstrip("'")
        p = o['Properties'].get('RelativeLocation') or {}
        loc[name] = (p.get('X', 0.0), p.get('Y', 0.0), p.get('Z', 0.0))

    rows = []
    for o in objs:
        if o.get('Type') != 'ProjectionSymbol_BP_C':
            continue
        name = o.get('Name') or ''
        zone = next((z for z in ZONES if name.startswith(SYMBOL_PREFIX + z + '_')), None)
        if not zone:
            continue
        x, y, z = loc.get(name, (0.0, 0.0, 0.0))
        room, approx = room_at(rooms, x, y, z)
        rows.append((zone, name[len(SYMBOL_PREFIX + zone + '_'):], name, (x, y, z), room, approx))

    rows.sort(key=lambda r: (ZONES.index(r[0]), int(r[1])))
    print('%-11s %-4s %-42s %-22s %-40s' % ('zone', '#', 'actor', 'loc', 'room'))
    for zone, short, name, l, room, approx in rows:
        print('%-11s %-4s %-42s %-22s %-40s'
              % (zone, short, name, '%.0f,%.0f,%.0f' % l, room + ('?' if approx else '')))


if __name__ == '__main__':
    sys.stdout.reconfigure(encoding='utf-8')
    main()
