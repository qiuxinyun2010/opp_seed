# -*- coding: utf-8 -*-
"""只用「选中集合」验证 §17.3 的抽取公式（不依赖屏幕顺序）。

    python srr_pick_set.py 1<<20
"""
import os
import sys

sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.abspath(__file__))))
import srr_mt02 as m

# 只保留"已知 6 台集合"的样本（R2/R3，两个 seed）
CASES = [
    (417417, 'School', {'BP24', 'BP26', 'BP5', 'BP6', 'BP19', 'BP29'}),
    (737737, 'School', {'BP21', 'BP25', 'BP11', 'BP5', 'BP8', 'BP27_3'}),
    (417417, 'SasExit', {'BP43', 'BP45', 'BP36', 'BP31', 'BP38', 'BP47'}),
    (737737, 'SasExit', {'BP40', 'BP45', 'BP30', 'BP33', 'BP37', 'BP47'}),
]


def first3(key, level_seed, delta):
    pool = list(m.COORDS[key]['pool'])
    O = (m.base_of(key) + delta) & m.M32
    out = []
    for k in range(3):
        h = m.rand_seeded((O + k) & m.M32, len(pool), level_seed)
        out.append(pool[h])
        pool.pop(h)
    return out, pool, O


def full(key, level_seed, delta):
    pool = list(m.COORDS[key]['pool'])
    O = (m.base_of(key) + delta) & m.M32
    out = []
    for k in range(6):
        h = m.rand_seeded((O + k) & m.M32, len(pool), level_seed)
        out.append(pool[h])
        pool.pop(h)
    return out


def main():
    span = int(sys.argv[1]) if len(sys.argv) > 1 else (1 << 20)
    print('扫描 delta = 0..%d（集合检验，不依赖顺序）' % span)
    hits = 0
    for d in range(span):
        ok = True
        for seed, key, want in CASES:
            got, _, _ = first3(key, seed, d)
            if not set(got) <= want:
                ok = False
                break
        if not ok:
            continue
        for seed, key, want in CASES:
            if set(full(key, seed, d)) != want:
                ok = False
                break
        if ok:
            hits += 1
            print('  HIT delta=%d' % d)
    print('扫描完成，命中 %d 个' % hits)


if __name__ == '__main__':
    main()
