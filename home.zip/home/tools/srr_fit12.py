# -*- coding: utf-8 -*-
"""检验「固定必选名额」假设：某些候选不参与随机，先占掉 DesiredCount 名额。

线索：两个 seed 的选中集合有交集 ——
  School : 417417 ∩ 737737 = {BP5}
  SasExit: 417417 ∩ 737737 = {BP45, BP47}
若这些是强制项（引擎里 v242/v244 就是先占名额的强制数组），
则随机只作用于剩下的候选。
"""
import sys
from itertools import product

M32 = 0xFFFFFFFF
M64 = 0xFFFFFFFFFFFFFFFF

_T = []
for _i in range(256):
    _c = _i
    for _ in range(8):
        _c = ((_c >> 1) ^ 0xEDB88320) if (_c & 1) else (_c >> 1)
    _T.append(_c & M32)


def crc32_fname(text):
    crc = M32
    for ch in text:
        u = ord(ch) & 0xFFFF
        crc = _T[(crc ^ (u & 0xFF)) & 0xFF] ^ (crc >> 8)
        crc = _T[(crc ^ (u >> 8)) & 0xFF] ^ (crc >> 8)
        crc = _T[crc & 0xFF] ^ (crc >> 8)
        crc = _T[crc & 0xFF] ^ (crc >> 8)
    return (~crc) & M32


def seed_of_object(name):
    value = (crc32_fname(name) + crc32_fname('PersistentLevel')) & M32
    return value if value < 0x80000000 else (0x100000000 - value) & M32


def mix1(x):
    z = (0xBF58476D1CE4E5B9 * (x ^ (x >> 30))) & M64
    return z ^ (z >> 27)


def rs(seed, n, salt):
    if not n or not seed:
        return 0
    B = (0x94D049BB133111EB * mix1(salt % 1000)) & M64
    v = ((0x94D049BB133111EB * mix1(seed)) & M64) ^ B
    t = (v ^ (v >> 31)) & M64
    w = (0xBF58476D1CE4E5B9 * (t ^ (t >> 30))) & M64
    u = (w ^ (w >> 27)) & M64
    r = (((321982955 * u) & M64) ^ (((0x94D049BB133111EB * u) & M64) >> 31)) & M64
    return (r & 0xFFFF) % n


sys.path.insert(0, '.')
import srr_mt02 as M

FULL = {k: M.COORDS[k]['pool'] for k in ('School', 'SasExit')}
COORD = {k: M.COORDS[k]['actor'] for k in ('School', 'SasExit')}

# 假设的强制项（两个 seed 的交集）
FIXED = {'School': ['BP5'], 'SasExit': ['BP45', 'BP47']}

ALL417 = {'School': {'BP5', 'BP6', 'BP19', 'BP24', 'BP26', 'BP29'},
          'SasExit': {'BP45', 'BP43', 'BP31', 'BP38', 'BP36', 'BP47'}}
ALL737 = {'School': {'BP5', 'BP8', 'BP11', 'BP21', 'BP25', 'BP27_3'},
          'SasExit': {'BP30', 'BP33', 'BP37', 'BP45', 'BP40', 'BP47'}}


def draw(key, base, mode, salt):
    pool = [a for a in FULL[key] if a not in FIXED[key]]
    want_n = 6 - len(FIXED[key])
    out = []
    if mode == 'rm':
        mem = list(pool)
        for i in range(want_n):
            k = rs((base + i) & M32, len(mem), salt)
            out.append(mem[k])
            del mem[k]
    elif mode == 'plain':
        mem = list(pool)
        for i in range(want_n):
            k = rs((base + i) & M32, len(mem), salt)
            out.append(mem[k])
            mem[k] = mem[-1]
            mem.pop()
    elif mode == 'fy':
        mem = list(pool)
        for i in range(len(mem), 1, -1):
            j = rs((base + (len(mem) - i)) & M32, i, salt)
            mem[i - 1], mem[j] = mem[j], mem[i - 1]
        out = mem[:want_n]
    return out


def main():
    span = int(sys.argv[1]) if len(sys.argv) > 1 else 200000
    salt_crc = crc32_fname('Objective Actors')
    base_sets = {
        'coord': {k: seed_of_object(v) for k, v in COORD.items()},
        '+salt': {k: (seed_of_object(v) + salt_crc) & M32 for k, v in COORD.items()},
    }
    for key in ('School', 'SasExit'):
        w1 = ALL417[key] - set(FIXED[key])
        w2 = ALL737[key] - set(FIXED[key])
        print('%s 固定=%s  池 %d → 随机抽 %d 台' % (
            key, FIXED[key], len(FULL[key]) - len(FIXED[key]), 6 - len(FIXED[key])))
        for btag, bs in base_sets.items():
            for mode in ('plain', 'rm', 'fy'):
                good = []
                for delta in range(span):
                    b = (bs[key] + delta) & M32
                    if set(draw(key, b, mode, 417417)) != w1:
                        continue
                    if set(draw(key, b, mode, 737737)) != w2:
                        continue
                    good.append(delta)
                print('   %-6s %-6s 双 seed 命中: %s'
                      % (btag, mode, good[:5] if good else '空'))


if __name__ == '__main__':
    main()
