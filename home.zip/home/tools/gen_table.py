# -*- coding: utf-8 -*-
"""生成 mhs_mt01.py 需要的静态表字面量。

读 paks/ 的关卡 JSON + release/map/out 的房间 hull，输出 30 个投影符号的
(zone, short, texture, loc, rooms) Python 字面量。
"""
import json
import sys
from pathlib import Path

ROOT = Path(__file__).resolve().parents[3]          # d:/workspace/outlast
LEVEL_JSON = ROOT / 'paks/MAP/Maps/MobsterHideoutSyndicate/MHS_LD_MT01_B00.json'
PLAN_JSON = ROOT / 'release/map/out/MobsterHideoutSyndicate/plan.json'
ORDER = ['1', '10', '2', '3', '4', '5', '6', '7', '8', '9']
ZONES = ('DrugLab', 'Shipyard', 'TrainDepot')


def load_objects(path):
    data = json.loads(Path(path).read_text(encoding='utf-8'))
    objs = []
    for item in data:
        objs.extend(item) if isinstance(item, list) else objs.append(item)
    return [o for o in objs if isinstance(o, dict)]


def inside(point, hull):
    x, y = point
    flag = False
    n = len(hull)
    for i in range(n):
        x1, y1 = hull[i]
        x2, y2 = hull[(i + 1) % n]
        if (y1 > y) != (y2 > y):
            if x < x1 + (y - y1) * (x2 - x1) / (y2 - y1):
                flag = not flag
    return flag


def main():
    objs = load_objects(LEVEL_JSON)
    rooms = json.loads(PLAN_JSON.read_text(encoding='utf-8')).get('rooms', [])

    loc = {}
    for o in objs:
        if o.get('Name') != 'Root':
            continue
        outer = (o.get('Outer') or {}).get('ObjectName') or ''
        if 'MT01_ProjectionSymbol_BP_' not in outer:
            continue
        name = outer.split('.')[-1].rstrip("'")
        p = o['Properties'].get('RelativeLocation') or {}
        loc[name] = (round(p.get('X', 0.0), 1), round(p.get('Y', 0.0), 1), round(p.get('Z', 0.0), 1))

    for zone in ZONES:
        print('    #', zone)
        for short in ORDER:
            name = 'MT01_ProjectionSymbol_BP_%s_%s' % (zone, short)
            obj = next(x for x in objs if x.get('Name') == name)
            x, y, z = loc[name]
            hits = [r for r in rooms
                    if any(inside((x, y), h) for h in r['hulls'])]
            cells = ["('%s', %.0f, %.0f, %.0f, %.0f)"
                     % (r['raw_name'], r['zmin'], r['zmax'], r['cx'], r['cy'])
                     for r in hits]
            tex = (obj.get('Properties') or {}).get('TextureName') or ''
            print("    ('%s', '%s', '%s', (%s, %s, %s), [%s]),"
                  % (zone, short, tex, x, y, z, ', '.join(cells)))
        print()


if __name__ == '__main__':
    sys.stdout.reconfigure(encoding='utf-8')
    main()
