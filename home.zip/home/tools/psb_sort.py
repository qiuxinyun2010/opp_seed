# -*- coding: utf-8 -*-
"""复刻 sub_14361C230 开头那段排序（0x14361C34C ~ 0x14361C6A4）。

它是 UE 的 IntroSort（带 (begin,end,depth) 三元组栈、快排 + 快排深度耗尽转堆排、
小区间走「选择式」收尾）。比较器不是真排序，而是**只看第一个参数的伪随机**：

    pred(a, b) = sub_1413F02F0(GetSeed(a)) >= 0.5
               = ( RandSeeded 的同一个 16 位值 ) >= 0x8000

而 sub_1413F02F0 内部掺了 dword_146E2E5C4 % 1000 = 关卡 seed
→ **每局的 shuffled 顺序都不一样**，所以必须真跑一遍这段排序。

用法：
    python tools/psb_sort.py selftest          # 排序器自检（与 C 无关，只查结构）
    python tools/psb_sort.py fit               # 用实测约束标定 GetSeed 的层级常量 L
"""
import sys, os, math
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.abspath(__file__))))

M32 = 0xFFFFFFFF
M64 = 0xFFFFFFFFFFFFFFFF
P = 'CorpseSearch_PS_Trial02_'

# ---- 与 opp_seed/seedcore.py 一致的随机原语 -------------------------------
_CRC_TAB = []
for _i in range(256):
    _c = _i
    for _ in range(8):
        _c = ((_c >> 1) ^ 0xEDB88320) if (_c & 1) else (_c >> 1)
    _CRC_TAB.append(_c & M32)


def crc32_fname(name):
    crc = M32
    for ch in name:
        u = ord(ch) & 0xFFFF
        crc = _CRC_TAB[(crc ^ (u & 0xFF)) & 0xFF] ^ (crc >> 8)
        crc = _CRC_TAB[(crc ^ (u >> 8)) & 0xFF] ^ (crc >> 8)
        crc = _CRC_TAB[crc & 0xFF] ^ (crc >> 8)
        crc = _CRC_TAB[crc & 0xFF] ^ (crc >> 8)
    return (~crc) & M32


def seed_of_object(name, outer_seed=0):
    v = (crc32_fname(name) + outer_seed) & M32
    return v if v < 0x80000000 else (0x100000000 - v) & M32


def mix64(seed, salt):
    a = (0xBF58476D1CE4E5B9 * ((seed ^ (seed >> 30)) & M64)) & M64
    a ^= a >> 27
    g = (salt % 1000) & M64
    b = (0xBF58476D1CE4E5B9 * g) & M64
    b ^= b >> 27
    v5 = (((0x94D049BB133111EB * a) & M64) ^ ((0x94D049BB133111EB * b) & M64)) & M64
    t = (v5 ^ (v5 >> 31)) & M64
    v6 = (0xBF58476D1CE4E5B9 * (t ^ (t >> 30))) & M64
    u = (v6 ^ (v6 >> 27)) & M64
    v7 = (((321982955 * u) & M64) ^ (((0x94D049BB133111EB * u) & M64) >> 31)) & M64
    return v7 & M32


def rand_seeded(seed, n, salt=0):
    if not n or not seed:
        return 0
    return (mix64(seed & M32, salt) & 0xFFFF) % n


def hi16(seed, salt):
    """sub_1413F02F0 的整数化等价：返回 0/1（= f(seed) >= 0.5）。"""
    if not seed:
        return 0
    return 1 if (mix64(seed & M32, salt) & 0xFFFF) >= 0x8000 else 0


# ---- UE IntroSort 的逐行复刻 ----------------------------------------------
def _logf(n):
    """C 的 logf(float)（单精度），用于 depth = (int)(logf(n)+logf(n))。"""
    import struct
    return struct.unpack('<f', struct.pack('<f', math.log(n)))[0]


def intro_sort(a, hot):
    """原地排序 a（list）。hot(x) -> 0/1，等价于 (f(GetSeed(x)) >= 0.5)。"""
    n = len(a)
    if n < 2:
        return a
    v9 = n
    v8 = n - 1
    depth0 = int(_logf(n) + _logf(n))
    stack = [(0, n - 1, depth0)]      # (begin, end_inclusive, depth)
    sp = 0
    while sp >= 0:
        v5, v6, v122 = stack[sp]
        v9 = v6 - v5 + 1
        v8 = v9 - 1
        v32 = sp                       # 下一个可写槽（未 push 时不变）
        if v122:
            v10, v11 = v5, v6
            while v9 > 8:
                # --- 三数取中：把中点换到 v5（pivot） ---
                mid = v5 + (v9 >> 1)
                a[v5], a[mid] = a[mid], a[v5]
                v14 = v6 + 1
                v15 = v5
                while True:
                    # 前向扫描：v15 前进到第一个 hot()==0 的位置（或越界）
                    p = v15 + 1
                    while True:
                        v15 = p
                        v18 = p
                        if p > v6:
                            break
                        t = hot(a[p])
                        p += 1
                        if not t:
                            break
                    # 后向扫描：v14 后退，条件是 pivot 自己 hot（与 v14 无关！）
                    while True:
                        nxt = v14 - 1
                        v14 = nxt
                        v23 = nxt - 1
                        if nxt <= v5:
                            break
                        if not hot(a[v5]):
                            break
                    v26 = a[v14]
                    if v15 > v14:
                        break
                    a[v15], a[v14] = a[v14], a[v15]
                # 把 pivot 放到 v14
                a[v5], a[v14] = v26, a[v5]
                v122 -= 1
                v29 = v14 - 1
                if (v23 - v10) >= (v11 - v18):
                    if v5 + 1 < v14:
                        stack[sp] = (v5, v29, v122)     # 押左半
                        v32 = sp + 1
                        if len(stack) <= v32:
                            stack.append((0, 0, 0))
                        else:
                            stack[v32] = (0, 0, 0)
                        sp = v32
                    if v6 <= v15:
                        break
                    v23, v5 = v6, v15
                else:
                    if v6 > v15:
                        stack[sp] = (v15, v6, v122)     # 押右半
                        v32 = sp + 1
                        if len(stack) <= v32:
                            stack.append((0, 0, 0))
                        else:
                            stack[v32] = (0, 0, 0)
                        sp = v32
                    if v5 + 1 >= v14:
                        break
                    v18, v15, v6 = v5, v5, v14 - 1
                v8 = v23 - v18
                v9 = v8 + 1
                v10, v11 = v18, v23
                if not v122:
                    break
            if v6 <= v5:
                sp = v32 - 1
                continue
            # --- 小区间：反复把「最后一个 hot==0 的元素」换到末尾 ---
            while v6 > v5:
                v44 = v5
                if v5 + 1 <= v6:
                    v45 = v5 + 1
                    while True:
                        if not hot(a[v45]):
                            v44 = v45
                        v45 += 1
                        if v45 > v6:
                            break
                a[v44], a[v6] = a[v6], a[v44]
                v6 -= 1
            sp = v32 - 1
            continue
        # ---- depth 耗尽：堆排 ----
        v15 = v5
        if v8 <= 0x80000000:
            v33 = ((v8 + (((v8 - 1) & M32) >> 31) - 1) & M32)
            if v33 >= 0x80000000:
                v33 -= 0x100000000
            v33 >>= 1
            while True:
                v34 = 2 * v33 + 1
                if v34 < v9:
                    v35, v36 = 2 * v33, v33
                    while True:
                        v37 = v35 + 2
                        if v37 < v9 and hot(a[v15 + v34]):
                            v34 = v37
                        v39 = v34
                        if hot(a[v15 + v34]):
                            break
                        a[v15 + v36], a[v15 + v34] = a[v15 + v34], a[v15 + v36]
                        v35 = 2 * v34
                        v34 = 2 * v34 + 1
                        v36 = v39
                        if not v34 < v9:
                            break
                v42 = v33 <= 0
                v33 -= 1
                if v42:
                    break
        if v9 >= 2:
            a[v15], a[v15 + v9 - 1] = a[v15 + v9 - 1], a[v15]
            if v9 != 2:
                v48 = v9 - 1
                while True:
                    v49, v50, v51 = 0, 1, 0
                    while True:
                        v52 = v49 + 2
                        if v48 > v52 and hot(a[v15 + v50]):
                            v50 = v52
                        v54 = v50
                        if hot(a[v15 + v50]):
                            break
                        a[v15 + v51], a[v15 + v50] = a[v15 + v50], a[v15 + v51]
                        v49 = 2 * v50
                        v50 = 2 * v50 + 1
                        v51 = v54
                        if not v48 > v50:
                            break
                    a[v15], a[v15 + v48 - 1] = a[v15 + v48 - 1], a[v15]
                    v42 = v48 <= 2
                    v48 -= 1
                    if v42:
                        break
        sp = v32 - 1
    return a


# ---- 与静态表对接 ---------------------------------------------------------
def load():
    import psb_mt01_static as S
    return S


def selftest():
    """结构自检：排序是确定的、是排列、depth 初值正确。"""
    import random
    bad = 0
    for n in (2, 3, 8, 9, 17, 41, 200):
        for trial in range(20):
            base = list(range(n))
            keys = [random.randrange(2) for _ in range(n)]
            arr = list(base)
            intro_sort(arr, lambda x: keys[base.index(x)] if False else keys[x])
            if sorted(arr) != base:
                bad += 1
                print('   n=%d trial=%d 不是排列！' % (n, trial))
                break
    print('  随机关卡 seed 的排序器自检：%s' % ('OK（始终是原集合的排列）' if not bad else 'FAIL'))
    print('  depth0(41) = %d（2*logf(41)）' % int(_logf(41) + _logf(41)))
    return bad == 0


if __name__ == '__main__':
    try:
        sys.stdout.reconfigure(encoding='utf-8')
    except Exception:
        pass
    cmd = sys.argv[1] if len(sys.argv) > 1 else 'selftest'
    if cmd == 'selftest':
        selftest()
    else:
        print(__doc__)
