# -*- coding: utf-8 -*-
"""在 .text 里找 64 位立即数（如 seeded RNG 的乘法常数），并归到函数入口。

    python scan_qword.py 0xBF58476D1CE4E5B9          # splitmix 第一常数
    python scan_qword.py 0x94D049BB133111EB          # 第二常数
    python scan_qword.py 0xBF58476D1CE4E5B9 --only 0x14358EA00
"""
import struct
import sys
import os

_HERE = os.path.dirname(os.path.abspath(__file__))
sys.path.insert(0, _HERE)
import scan_disp as sd

CONSTS = {
    0xBF58476D1CE4E5B9: 'mix_a',
    0x94D049BB133111EB: 'mix_b',
    0xC2B2AE3D27D4EB4F: 'murmur_c1',
    0x165667B19E3779F9: 'murmur_c2',
    0x85EBCA77C2B2AE63: 'xxh_p5',
}


def main():
    args = [a for a in sys.argv[1:] if not a.startswith('--')]
    only = None
    if '--only' in sys.argv:
        only = int(sys.argv[sys.argv.index('--only') + 1], 16)
    name, sva, vsize, rawptr, rawsize = sd.sec('.text')
    for a in args:
        val = int(a, 16)
        pat = struct.pack('<Q', val)
        hits = []
        i = sd.d.find(pat, rawptr, rawptr + vsize)
        while i >= 0:
            hits.append(sd.image_base + sva + (i - rawptr))
            i = sd.d.find(pat, i + 1, rawptr + vsize)
        groups = {}
        for va in hits:
            c = sd.containing(va)
            if c:
                groups.setdefault(c[0], []).append(va)
        print('=== %X (%s): %d 处 / %d 个函数'
              % (val, CONSTS.get(val, '?'), len(hits), len(groups)))
        for fn in sorted(groups):
            if only and fn != only:
                continue
            c = sd.containing(fn)
            print('  0x%X  size 0x%-6X %d 处' % (fn, c[1] - c[0], len(groups[fn])))


if __name__ == '__main__':
    main()
