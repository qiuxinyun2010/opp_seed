# -*- coding: utf-8 -*-
"""检验：候选组的初始顺序 == 静态表里的 JSON 顺序？"""
import sys, os
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.abspath(__file__))))
import psb_mt01_static as S

P = 'CorpseSearch_PS_Trial02_'
WANT = {'A': {3: 'AgainstWall_BP2_5', 4: 'AgainstWall_BP_2', 12: 'AgainstWall_BP3_8'},
        'B': {5: 'Desk_BP_5', 7: 'AgainstWall_BP5_2'},
        'C': {6: 'WallThroat_BP8_32', 9: 'BP7_2'}}


def main():
    for sec in 'ABC':
        lst = [c for c in S.CORPSES if c['sector'] == sec]
        print('Sector %s  候选 %d 具（静态表 JSON 顺序）：' % (sec, len(lst)))
        for k, c in enumerate(lst):
            mark = ''
            exp = WANT[sec].get(k)
            if exp:
                got = c['actor'].replace(P, '')
                mark = '   << 期望 %s  %s' % (exp, 'OK' if got == exp else 'MISMATCH -> ' + got)
            print('  %2d %s%s' % (k, c['actor'].replace(P, ''), mark))
    print('')
    for nm in ('AgainstWall_BP5_2', 'BP3_8'):
        print('%s 扇区 = %s' % (nm, [c['sector'] for c in S.CORPSES if c['actor'] == P + nm]))


if __name__ == '__main__':
    try:
        sys.stdout.reconfigure(encoding='utf-8')
    except Exception:
        pass
    main()
