# -*- coding: utf-8 -*-
"""PSB_MT01 第四轮：用 565565 的「尸体 ↔ 图案」四元组钉死抽取参数。

样本 565565（实测）：
    A 区钥匙 = 红心，尸体 CorpseSearch_PS_Trial02_AgainstWall_BP3_8     (全局序 1)
    B 区钥匙 = 梅花，尸体 CorpseSearch_PS_Trial02_BP10_35              (全局序 9)
    C 区钥匙 = 眼睛，尸体 CorpseSearch_PS_Trial02_AgainstWall_BP9_2     (全局序 7)
    干扰尸体 方块 = CorpseSearch_PS_Trial02_AgainstWall_BP5_2           (全局序 3, C 区)

模型（sub_14361C230 @0x14361CA08 / 0x14361CA7C）：
    分组后逐组逐具：
        corpse = group[ RandSeeded(base + 243551 + v71 + v70, |group|) ]   保序删除
        pattern= pool [ RandSeeded(base + 223551 + v71 + v70, |pool| ) ]   保序删除
        v70 = 已处理尸体数（跨组累加）, v71 = 组内序号
"""
import itertools
import os
import sys

sys.path.insert(0, os.path.abspath(os.path.join(os.path.dirname(__file__), '..', '..', 'seed')))
import seedcore as sc  # noqa: E402

POOL = ['Bunny', 'Club', 'Diamond', 'Fire', 'Heart', 'Spade', 'Crown', 'Eye', 'Moon', 'Star']

# 41 具尸体的全局序号 -> 扇区（取自 PSB_MT01_B01.json，见 tools/psb_table.py）
SECTOR = {}
_RAW = """
0 A 1 A 2 A 3 C 4 A 5 C 6 C 7 C 8 A 9 B 10 B 11 C 12 C 13 C 14 C
15 A 16 A 17 A 18 A 19 A 20 C 21 B 22 A 23 B 24 B 25 B 26 B 27 C
28 C 29 C 30 C 31 C 32 B 33 A 34 A 35 A 36 B 37 B 38 C 39 C 40 A
"""
_t = _RAW.split()
for i in range(0, len(_t), 2):
    SECTOR[int(_t[i])] = _t[i + 1]

GROUPS = {s: [i for i in sorted(SECTOR) if SECTOR[i] == s] for s in 'ABC'}

FACTS = [(1, 'Heart'), (9, 'Club'), (7, 'Eye'), (3, 'Diamond')]
DESIRED = 10
COORD = 'PSB_MT01_B01_CorpseSearch_3'


def compositions(total, parts):
    if parts == 1:
        yield (total,)
        return
    for i in range(total + 1):
        for rest in compositions(total - i, parts - 1):
            yield (i,) + rest


def run(seed, base, order, counts):
    salt = seed % 1000
    pool = list(POOL)
    got = {}
    v70 = 0
    for sec, cnt in zip(order, counts):
        g = list(GROUPS[sec])
        if cnt > len(g):
            return None
        for v71 in range(cnt):
            i = sc.rand_seeded((base + 243551 + v71 + v70) & 0xFFFFFFFF, len(g), salt)
            actor = g.pop(i)
            j = sc.rand_seeded((base + 223551 + v71 + v70) & 0xFFFFFFFF, len(pool), salt)
            got[actor] = pool.pop(j)
            v70 += 1
    return got


def main():
    lvl = sc.crc32_fname('PersistentLevel')
    coord = sc.seed_of_object(COORD, lvl)
    print('GetSeed(coord)=0x%08X  分组：%s' % (coord, {k: len(v) for k, v in GROUPS.items()}))
    seed = 565565
    hits = []
    for d in range(0, 4096):
        base = (coord + d) & 0xFFFFFFFF
        for order in itertools.permutations('ABC'):
            for counts in compositions(DESIRED, 3):
                got = run(seed, base, order, counts)
                if not got:
                    continue
                if all(got.get(a) == p for a, p in FACTS):
                    hits.append((d, order, counts))
    print('命中：%d' % len(hits))
    for h in hits[:30]:
        print('   d=%d order=%s counts=%s' % h)


if __name__ == '__main__':
    main()
