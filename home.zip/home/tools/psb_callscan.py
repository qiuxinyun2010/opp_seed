# -*- coding: utf-8 -*-
"""离线扫描：找「RandSeeded(x, 10)」的调用点。

sub_1402D29E0 == RandSeeded（见 release/seed/seedcore.py）。
这里找 E8 直接调用 + 调用前不远处的 mov r32, 0xA。
用法：
    python psb_callscan.py [n]      # 只保留 N<=n 的调用点（默认 12）
"""
import re
import struct
import sys

EXE = r'd:\workspace\outlast\TOTClient-Win64-Shipping.exe'
RAND = 0x1402D29E0
BASE = 0x140000000

d = open(EXE, 'rb').read()
pe = struct.unpack_from('<I', d, 0x3C)[0]
nsec = struct.unpack_from('<H', d, pe + 6)[0]
opt = pe + 24
base = struct.unpack_from('<Q', d, opt + 24)[0]
secoff = opt + struct.unpack_from('<H', d, pe + 20)[0]
secs = []
for i in range(nsec):
    o = secoff + 40 * i
    nm = d[o:o + 8].rstrip(b'\x00').decode('latin1')
    vs, va, rs, rp = struct.unpack_from('<IIII', d, o + 8)
    secs.append((nm, va, vs, rp, rs))


def va2off(va):
    rva = va - base
    for nm, sva, vs, rp, rs in secs:
        if sva <= rva < sva + max(vs, rs):
            return rp + (rva - sva)
    return None


def off2va(off):
    for nm, sva, vs, rp, rs in secs:
        if rp <= off < rp + rs:
            return base + sva + (off - rp)
    return None


def main():
    try:
        sys.stdout.reconfigure(encoding='utf-8')
    except Exception:
        pass
    want = int(sys.argv[1]) if len(sys.argv) > 1 else 12
    text = [s for s in secs if s[0] == '.text'][0]
    nm, sva, vs, rp, rs = text
    lo, hi = rp, rp + rs
    hits = []
    for i in range(lo, hi - 5):
        if d[i] != 0xE8:
            continue
        rel = struct.unpack_from('<i', d, i + 1)[0]
        va = off2va(i)
        if va is None:
            continue
        tgt = (va + 5 + rel) & 0xFFFFFFFFFFFFFFFF
        if tgt != RAND:
            continue
        # 往前 64 字节找 mov r32, imm32 (0xA)
        ctx = d[i - 64:i]
        if re.search(rb'\xB8\x0A\x00\x00\x00|\xB9\x0A\x00\x00\x00|\xBA\x0A\x00\x00\x00|\xBE\x0A\x00\x00\x00|\xBF\x0A\x00\x00\x00', ctx):
            hits.append(va)
    print('RandSeeded(x,10) 调用点：%d' % len(hits))
    for h in hits:
        print('  0x%x' % h)


if __name__ == '__main__':
    main()
