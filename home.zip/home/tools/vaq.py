# -*- coding: utf-8 -*-
"""离线读 VA 处的 qword/dword/字符串（不占 IDA）。

用法：
    python vaq.py q 0x145A060C0 40          # 从该 VA 起 40 个 qword
    python vaq.py d 0x14665E230 16          # 16 个 dword
    python vaq.py w 0x1466E591E 64          # UTF-16 串
    python vaq.py a 0x14665E230 64          # ASCII 串
    python vaq.py vt 0x145A061C8            # 以该槽定位 vtable 范围
"""
import struct
import sys

PATH = r"d:\workspace\outlast\TOTClient-Win64-Shipping.exe"
d = open(PATH, "rb").read()

pe = struct.unpack_from("<I", d, 0x3C)[0]
nsec = struct.unpack_from("<H", d, pe + 6)[0]
opt = pe + 24
magic = struct.unpack_from("<H", d, opt)[0]
image_base = (struct.unpack_from("<Q", d, opt + 24)[0] if magic == 0x20B
              else struct.unpack_from("<I", d, opt + 28)[0])
secoff = opt + struct.unpack_from("<H", d, pe + 20)[0]
SECS = []
for i in range(nsec):
    o = secoff + 40 * i
    name = d[o:o + 8].rstrip(b"\x00").decode("latin1")
    vsize, va, rawsize, rawptr = struct.unpack_from("<IIII", d, o + 8)
    SECS.append((name, va, vsize, rawptr, rawsize))

TEXT_LO = image_base + 0x1000
TEXT_HI = image_base + 0x5064e2d


def va2off(va):
    rva = va - image_base
    for name, sva, vsize, rawptr, rawsize in SECS:
        if sva <= rva < sva + max(vsize, rawsize):
            return rawptr + (rva - sva)
    return None


def is_code(va):
    return TEXT_LO <= va < TEXT_HI


def cmd_q(args):
    va = int(args[0], 16)
    n = int(args[1]) if len(args) > 1 else 16
    off = va2off(va)
    for i in range(n):
        q = struct.unpack_from("<Q", d, off + 8 * i)[0]
        tag = ''
        if is_code(q):
            tag = '  ; code'
        print('%s+%03X  %016X%s' % (hex(va), 8 * i, q, tag))


def cmd_d(args):
    va = int(args[0], 16)
    n = int(args[1]) if len(args) > 1 else 16
    off = va2off(va)
    vals = struct.unpack_from("<%dI" % n, d, off)
    print(' '.join('%08X' % v for v in vals))
    print('floats:', ' '.join('%g' % struct.unpack('<f', struct.pack('<I', v))[0]
                              for v in vals))


def cmd_w(args):
    va = int(args[0], 16)
    n = int(args[1]) if len(args) > 1 else 64
    off = va2off(va)
    raw = d[off:off + 2 * n]
    print(raw.decode('utf-16-le', 'replace'))


def cmd_a(args):
    va = int(args[0], 16)
    n = int(args[1]) if len(args) > 1 else 64
    off = va2off(va)
    print(d[off:off + n].decode('latin1', 'replace'))


def cmd_vt(args):
    """从一个 vtable 槽回溯到表头、再向后扫，打印整张表。"""
    va = int(args[0], 16)
    start = va
    while True:
        q = struct.unpack_from("<Q", d, va2off(start - 8))[0]
        if is_code(q) or q == 0:
            start -= 8
            if start < image_base + 0x5066000 or va - start > 0x4000:
                break
        else:
            break
    print('vtable_start ~ %s' % hex(start))
    cur = start
    idx = 0
    zeros = 0
    while True:
        q = struct.unpack_from("<Q", d, va2off(cur))[0]
        if q == 0:
            zeros += 1
            if zeros > 24:
                break
        else:
            zeros = 0
        print('  +%04X [%3d] %016X%s%s'
              % (cur - start, idx, q,
                 '  ; code' if is_code(q) else '',
                 '  <== target' if cur == va else ''))
        cur += 8
        idx += 1
        if idx > 400:
            break


def main():
    if len(sys.argv) < 3:
        print(__doc__)
        return
    cmd, args = sys.argv[1], sys.argv[2:]
    {'q': cmd_q, 'd': cmd_d, 'w': cmd_w, 'a': cmd_a, 'vt': cmd_vt}[cmd](args)


if __name__ == '__main__':
    main()
