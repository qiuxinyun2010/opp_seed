# -*- coding: utf-8 -*-
"""用 sub_14361C230 里读到的真实常数偏移，对 SRR_MT02 的两个样本做定向验证。

sub_14361C230（通用 objective 随机化 + 赋图案）里出现的常数：
  RandSeeded(S + 243551 + v71 + v70, groupNum)   -> 选中的 actor
  RandSeeded(S + 223551 + v71 + v70, n138)       -> v74[2]/v74[5]
  RandSeeded(S +   851 ... ) 实际是 S + 850321 + v71
  RandSeeded(S + 951320 + v71, n135)             -> v74[4]
其中 S = GetSeed(协调器)，v71 = 组内序号，v70 = 全局已选计数。

本脚本只验「选机器顺序」与「赋图案顺序」这两件事，不做全空间瞎扫。
"""
import sys
import os

sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.abspath(__file__))))
import srr_mt02 as m

OFFS = {'actor': 243551, 'clueA': 850321, 'clueB': 951320, 'tv': 223551}

# 实测「按调频顺序」前 3 台（显示屏顺序 = 抽序前 3 台）
ORDERS = {
    (417417, 'RichDistrict'): ['BP', 'BP2', 'BP3', 'BP49'],
    (737737, 'RichDistrict'): ['BP2', 'BP3', 'BP49', 'BP'],
    (417417, 'School'): ['BP24', 'BP26', 'BP5'],
    (737737, 'School'): ['BP21', 'BP25', 'BP11'],
    (417417, 'SasExit'): ['BP43', 'BP45', 'BP36'],
    (737737, 'SasExit'): ['BP40', 'BP45', 'BP30'],
}


def pick_seq(key, level_seed, off, stride, mode='swap', pool=None, count=None):
    """按 RandSeeded(S+off+stride*i, 剩余) 依次取，返回下标序列。"""
    S = m.seed_of_object(m.COORDS[key]['actor'])
    p = list(pool if pool is not None else m.COORDS[key]['pool'])
    n = count if count is not None else m.COORDS[key]['desired']
    out = []
    for i in range(n):
        k = m.rand_seeded((S + off + stride * i) & m.M32, len(p), level_seed)
        out.append(p[k])
        if mode == 'swap':
            p[k] = p[-1]
            p.pop()
        else:
            p.pop(k)
    return out


def clue_seq(key, level_seed, off, stride, mode='swap'):
    S = m.seed_of_object(m.COORDS[key]['actor'])
    p = list(m.COORDS[key]['clues'])
    out = []
    for i in range(len(p)):
        k = m.rand_seeded((S + off + stride * i) & m.M32, len(p), level_seed)
        out.append(p[k])
        if mode == 'swap':
            p[k] = p[-1]
            p.pop()
        else:
            p.pop(k)
    return out


def check_actor_off(off, stride, mode):
    hit = 0
    total = 0
    for (seed, key), want in ORDERS.items():
        got = pick_seq(key, seed, off, stride, mode)
        want = want[:len(got)]
        total += 1
        if got[:len(want)] == want:
            hit += 1
        else:
            print('   miss seed=%-7d %-12s got=%-40s want=%s'
                  % (seed, key, ','.join(got), ','.join(want)))
    return hit, total


def check_clue_off(off, stride, mode):
    """赋图案：第 i 个图案 = clue[i]；第一轮 4 个图案应等于实测的 pool 顺序图案。"""
    hit = 0
    total = 0
    for (seed, key), want in ORDERS.items():
        if key != 'RichDistrict':
            continue
        pairs = [s for s in m.SAMPLES if s['seed'] == seed and s['round'] == 1][0]['pairs']
        want_clues = [c for _, c in pairs]
        got = clue_seq(key, seed, off, stride, mode)
        total += 1
        if got == want_clues:
            hit += 1
        else:
            print('   miss seed=%-7d %-12s got=%-40s want=%s'
                  % (seed, key, ','.join(got), ','.join(want_clues)))
    return hit, total


def main():
    print('== 选机器顺序：S+off+stride*i，RemoveAtSwap / RemoveAt ==')
    best = []
    for name, off in (('243551', 243551), ('223551', 223551),
                      ('850321', 850321), ('951320', 951320)):
        for stride in (0, 1, 2):
            for mode in ('swap', 'stable'):
                hit, total = check_actor_off(off, stride, mode)
                print('  off=%-7s stride=%d %-7s  %d/%d' % (name, stride, mode, hit, total))
                if hit:
                    best.append(('actor', name, stride, mode, hit, total))
    print()
    print('== 赋图案顺序（第一轮 4 个图案） ==')
    for name, off in (('243551', 243551), ('223551', 223551),
                      ('850321', 850321), ('951320', 951320)):
        for stride in (0, 1, 2):
            for mode in ('swap', 'stable'):
                hit, total = check_clue_off(off, stride, mode)
                if hit:
                    print('  off=%-7s stride=%d %-7s  %d/%d  <== HIT'
                          % (name, stride, mode, hit, total))
    print()
    if best:
        print('非零命中：', best)


if __name__ == '__main__':
    main()
