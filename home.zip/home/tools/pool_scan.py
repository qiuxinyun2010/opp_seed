# -*- coding: utf-8 -*-
"""检查关卡 JSON 里三个协调器的 ObjectiveActors 池到底包含哪些 actor。

用来回答：显示屏（FrequencyClue_TvChannel / NarrativeScreen）是否也被算进随机化池。
"""
import io
import json
import re
import sys

P = r'd:/workspace/outlast/pak/OPP/Content/Maps_json/SuburbRiotResidential/SRR_MT02_B00.json'
NAME = 'SRR_MT02_OrderedClueFrequency_'


def main():
    t = io.open(P, encoding='utf-8').read()
    for coord in ('RichDistrict', 'School', 'SasExit'):
        key = '"%s%s"' % (NAME, coord)
        i = t.find(key)
        seg = t[i:i + 24000]
        print('== %s%s  (offset %d)' % (NAME, coord, i))
        for field in ('ObjectiveActors', 'PossibleClueNames', 'Screens', 'LinkedScreens'):
            j = seg.find('"%s"' % field)
            print('   field %-18s %s' % (field, 'at +%d' % j if j >= 0 else 'absent'))
        j = seg.find('"ObjectiveActors"')
        if j < 0:
            continue
        # 找匹配的方括号
        k = seg.find('[', j)
        depth = 0
        end = k
        for idx in range(k, len(seg)):
            if seg[idx] == '[':
                depth += 1
            elif seg[idx] == ']':
                depth -= 1
                if depth == 0:
                    end = idx
                    break
        body = seg[k:end + 1]
        acts = re.findall(r'PersistentLevel\.([A-Za-z0-9_]+)', body)
        kinds = {}
        for a in acts:
            base = re.sub(r'[0-9_]+$', '', a)
            kinds[base] = kinds.get(base, 0) + 1
        print('   ObjectiveActors 条目: %d' % len(acts))
        for kk, vv in sorted(kinds.items()):
            print('      %-46s %d' % (kk, vv))
        print('   前 6 条: %s' % ', '.join(acts[:6]))
        print('   后 3 条: %s' % ', '.join(acts[-3:]))


if __name__ == '__main__':
    main()
