# -*- coding: utf-8 -*-
"""PSB_MT01 第六轮：按「每区 3 具，1 真 2 假」实测结构反解种子基。

用户实测结构：每区 3 具尸体，只有 1 具是真钥匙，另 2 具是干扰图案。
    → 9 具尸体（3×3），图案池 10 个，不重复

代码（sub_14361C230 @0x14361CA08 / 0x14361CA7C）：
    for group in groups:                       // 一组 = 一个扇区
        for v71 in 0..count-1:                 // v71=0 → 真钥匙（该区图案来自这里）
            corpse = group[ RandSeeded(base+243551+v71+v70, |group|) ]   保序删除
            pat    = pool [ RandSeeded(base+223551+v71+v70, |pool|) ]    保序删除
            v70 += 1                           // 跨组累加

待解：base = GetSeed(coord) + d（d = 分组器写回的加数）、组顺序、每组数量。
约束（565565 实测 + 111111 实测）：
    A v71=0 尸体 = A 区第 1 具（AgainstWall_BP3_8）、图案 = Heart
    B v71=0 尸体 = B 区第 0 具（BP10_35）、       图案 = Club
    C v71=0 尸体 = C 区第 3 具（AgainstWall_BP9_2）、图案 = Eye
    111111：A/B/C 图案 = Star / Bunny / Diamond
"""
import itertools
import os
import sys

sys.path.insert(0, os.path.abspath(os.path.join(os.path.dirname(__file__), '..', '..', 'seed')))
import seedcore as sc  # noqa: E402

POOL = ['Bunny', 'Club', 'Diamond', 'Fire', 'Heart', 'Spade', 'Crown', 'Eye', 'Moon', 'Star']

SECTOR = {}
_RAW = """
0 A 1 A 2 A 3 C 4 A 5 C 6 C 7 C 8 A 9 B 10 B 11 C 12 C 13 C 14 C
15 A 16 A 17 A 18 A 19 A 20 C 21 B 22 A 23 B 24 B 25 B 26 B 27 C
28 C 29 C 30 C 31 C 32 B 33 A 34 A 35 A 36 B 37 B 38 C 39 C 40 A
"""
_t = _RAW.split()
for i in range(0, len(_t), 2):
    SECTOR[int(_t[i])] = _t[i + 1]
GROUPS = {s: [i for i in sorted(SECTOR) if SECTOR[i] == s] for s in 'ABC'}

COORD = 'PSB_MT01_B01_CorpseSearch_3'

# seed -> {扇区: (真钥匙尸体在组内的下标, 图案)}
FACTS = {
    565565: {'A': (1, 'Heart'), 'B': (0, 'Club'), 'C': (3, 'Eye')},
    111111: {'A': (None, 'Star'), 'B': (None, 'Bunny'), 'C': (None, 'Diamond')},
}


def simulate(seed, base, order, counts, want_corpse=True):
    salt = seed % 1000
    pool = list(POOL)
    v70 = 0
    key_of = {}
    for sec, cnt in zip(order, counts):
        g = list(GROUPS[sec])
        if cnt > len(g):
            return None
        first = None
        for v71 in range(cnt):
            if not pool:
                return None
            ci = sc.rand_seeded((base + 243551 + v71 + v70) & 0xFFFFFFFF, len(g), salt)
            actor = g.pop(ci)
            pi = sc.rand_seeded((base + 223551 + v71 + v70) & 0xFFFFFFFF, len(pool), salt)
            pat = pool.pop(pi)
            if v71 == 0:
                first = (ci, pat, actor)
            v70 += 1
        key_of[sec] = first
    return key_of


def main():
    try:
        sys.stdout.reconfigure(encoding='utf-8')
    except Exception:
        pass
    lvl = sc.crc32_fname('PersistentLevel')
    coord = sc.seed_of_object(COORD, lvl)
    print('GetSeed(coord)=0x%08X' % coord)

    count_sets = [(3, 3, 3), (3, 3, 4), (3, 4, 3), (4, 3, 3), (2, 3, 4), (3, 2, 4), (4, 2, 3)]
    hits = []
    for d in range(0, 8192):
        base = (coord + d) & 0xFFFFFFFF
        for order in itertools.permutations('ABC'):
            for counts in count_sets:
                ok = True
                for seed, want in FACTS.items():
                    res = simulate(seed, base, order, counts)
                    if not res:
                        ok = False
                        break
                    for sec, (want_ci, want_pat) in want.items():
                        got = res.get(sec)
                        if not got:
                            ok = False
                            break
                        if got[1] != want_pat:
                            ok = False
                            break
                        if want_ci is not None and got[0] != want_ci:
                            ok = False
                            break
                    if not ok:
                        break
                if ok:
                    hits.append((d, order, counts))
    print('严格命中（图案 + 565565 尸体下标）：%d' % len(hits))
    for h in hits[:30]:
        print('   d=%d order=%s counts=%s' % h)

    # 放宽：只要图案（3+3 条），不要求尸体下标
    print('\n--- 只用图案约束（565565+111111 共 6 条）---')
    hits2 = []
    for d in range(0, 8192):
        base = (coord + d) & 0xFFFFFFFF
        for order in itertools.permutations('ABC'):
            for counts in count_sets:
                ok = True
                for seed, want in FACTS.items():
                    res = simulate(seed, base, order, counts)
                    if not res:
                        ok = False
                        break
                    if any(res[s][1] != p for s, (_, p) in want.items()):
                        ok = False
                        break
                if ok:
                    hits2.append((d, order, counts))
    print('命中：%d' % len(hits2))
    for h in hits2[:30]:
        print('   d=%d order=%s counts=%s' % h)


if __name__ == '__main__':
    main()
