# -*- coding: utf-8 -*-
"""SRR_MT02_B00：导出三个 OrderedClueFrequency 协调器的对象池（调频器名字 + 世界坐标 +
PossibleClueNames 顺序），供后续种子推断使用。产物写入 home/srr02_pool.json。"""
import io
import json
import re

SRC = r'd:/workspace/outlast/pak/OPP/Content/Maps_json/SuburbRiotResidential/SRR_MT02_B00.json'
OUT = r'd:/workspace/outlast/release/home/srr02_pool.json'

objs = json.load(io.open(SRC, encoding='utf-8'))


def outer_name(o):
    nm = (o.get('Outer') or {}).get('ObjectName') or ''
    if "'" in nm:
        nm = nm.split("'")[1]
    if ':' in nm:
        nm = nm.split(':', 1)[1]
    return nm.rsplit('.', 1)[-1]


def path_tail(entry):
    if isinstance(entry, str):
        return entry
    if not isinstance(entry, dict):
        return None
    sp = entry.get('SubPathString')
    if sp:
        return sp.rsplit('.', 1)[-1]
    nm = entry.get('ObjectName') or ''
    if "'" in nm:
        nm = nm.split("'")[1]
    return nm.rsplit('.', 1)[-1] if nm else None


# ---- 协调器 ----
coords = {}
for o in objs:
    nm = o.get('Name') or ''
    if not nm.startswith('SRR_MT02_OrderedClueFrequency_'):
        continue
    p = o.get('Properties') or {}
    coord = nm[len('SRR_MT02_OrderedClueFrequency_'):]
    pool = [path_tail(a) for a in (p.get('ObjectiveActors') or [])]
    coords[coord] = {
        'PossibleClueNames': p.get('PossibleClueNames') or [],
        'OrderedClueActors': [path_tail(a) for a in (p.get('OrderedClueActors') or [])],
        'ObjectiveActors': pool,
        'AlternatePairs': p.get('ObjectiveIndexAlternatePairs'),
        'DesiredCount': p.get('DesiredCount'),
        'bRevealOneByOne': p.get('bRevealOneByOne'),
    }
    print('== %s  pool=%d  clues=%s' % (coord, len(pool), coords[coord]['PossibleClueNames']))
    print('   屏幕(OrderedClueActors):', coords[coord]['OrderedClueActors'])
    print('   AlternatePairs:', coords[coord]['AlternatePairs'])
    print('   DesiredCount:', coords[coord]['DesiredCount'],
          ' bRevealOneByOne:', coords[coord]['bRevealOneByOne'])

# ---- 调频器位置 ----
tuners = {}
for o in objs:
    nm = o.get('Name') or ''
    if not re.match(r'^FrequencyMatchBlacklit_BP\d', nm):
        continue
    if 'FrequencyMatchBlacklit_BP_C' not in (o.get('Class') or ''):
        continue
    if outer_name(o).endswith('PersistentLevel') is False and outer_name(o) != 'PersistentLevel':
        pass
    tuners.setdefault(nm, {'name': nm, 'loc': None, 'rot': None, 'outer': outer_name(o)})

for o in objs:
    if o.get('Name') != 'SceneComp':
        continue
    owner = outer_name(o)
    if owner not in tuners:
        continue
    p = o.get('Properties') or {}
    loc = p.get('RelativeLocation')
    if loc and tuners[owner]['loc'] is None:
        tuners[owner]['loc'] = loc

print('\n共 %d 台调频器' % len(tuners))
for nm in sorted(tuners, key=lambda s: int(re.sub(r'\D', '', s.split('_BP')[-1].split('_')[0]) or 0)):
    print('  %-34s %s' % (nm, tuners[nm]['loc']))

json.dump({'coordinators': coords, 'tuners': tuners},
          io.open(OUT, 'w', encoding='utf-8'), ensure_ascii=False, indent=1)
print('\n-> %s' % OUT)
