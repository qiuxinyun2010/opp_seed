# -*- coding: utf-8 -*-
"""在函数范围里找「给某个 64 位寄存器赋值」的指令。

    python scan_reg.py 0x1402B05C0 0x1402B28B2 r15

支持：
  mov r64, r64         (89 /r, mod=11)
  mov r64, [rsp+d32]   (8B /r, modrm=BC, sib=24)
  lea r64, [rsp+d32]   (8D /r, modrm=BC, sib=24)
  lea r64, [rip+d32]   (8D /r, modrm=3D)
  mov r64, [rip+d32]   (8B /r, modrm=3D)
  mov r64, imm64       (B8+r)
"""
import struct
import sys
import os

_HERE = os.path.dirname(os.path.abspath(__file__))
sys.path.insert(0, _HERE)
import scan_disp as sd

NAMES = ['r0', 'r1', 'r2', 'r3', 'r4', 'r5', 'r6', 'r7',
         'r8', 'r9', 'r10', 'r11', 'r12', 'r13', 'r14', 'r15']


def main():
    lo = int(sys.argv[1], 16)
    hi = int(sys.argv[2], 16)
    want = int(sys.argv[3].lower().replace('r', ''))
    off = sd.va2off(lo)
    code = sd.d[off:off + (hi - lo)]
    print('=== %X..%X 中写入 r%d 的指令' % (lo, hi, want))
    n = 0
    for i in range(len(code) - 8):
        rex = 0
        j = i
        if 0x40 <= code[j] <= 0x4F:
            rex = code[j]
            j += 1
        op = code[j]
        modrm = code[j + 1]
        R_hi = 8 if (rex & 0x04) else 0
        B_hi = 8 if (rex & 0x01) else 0
        regf = ((modrm >> 3) & 7) | R_hi          # reg 字段
        rmf = (modrm & 7) | B_hi                  # rm 字段
        mod = modrm & 0xC0
        # mov r/m64, r64
        if op == 0x89 and mod == 0xC0 and rmf == want:
            print('  %X  mov r%d, r%d' % (lo + i, want, regf))
            n += 1
            continue
        # mov r64, imm64
        if 0xB8 <= op <= 0xBF and (op - 0xB8) | R_hi == want:
            imm = struct.unpack_from('<Q', code, j + 2)[0]
            print('  %X  mov r%d, 0x%X' % (lo + i, want, imm))
            n += 1
            continue
        if op not in (0x8B, 0x8D) or regf != want:
            continue
        if mod == 0xC0:
            continue
        if modrm == 0xBC and code[j + 2] == 0x24:
            disp = struct.unpack_from('<i', code, j + 3)[0]
            print('  %X  %s r%d, [rsp+%Xh]'
                  % (lo + i, 'mov' if op == 0x8B else 'lea', want, disp))
            n += 1
        elif modrm == 0x3D:
            disp = struct.unpack_from('<i', code, j + 2)[0]
            tgt = lo + i + (j - i) + 6 + disp
            print('  %X  %s r%d, [rip+%Xh] -> 0x%X'
                  % (lo + i, 'mov' if op == 0x8B else 'lea', want, disp, tgt))
            n += 1
        elif modrm == 0x84 and code[j + 2] == 0x24:
            disp = struct.unpack_from('<i', code, j + 3)[0]
            print('  %X  %s r%d, [rsp+%Xh]  (mod=10)'
                  % (lo + i, 'mov' if op == 0x8B else 'lea', want, disp))
            n += 1
    print('共 %d 处' % n)


if __name__ == '__main__':
    main()
