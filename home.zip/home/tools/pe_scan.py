# -*- coding: utf-8 -*-
"""离线读 TOTClient-Win64-Shipping.exe（PE32+）：VA→文件偏移、读串/qword、扫 UE 属性描述符表。

（本文件是 release/coop/tools/pe_scan.py 的副本，只把 PATH 改成本工作区的 exe。）

用法：
    python pe_scan.py sec                 # 节表
    python pe_scan.py str 0x146517792     # 读 ASCII/UTF-16 串
    python pe_scan.py ptrs 0x145C04F80 80 # 把该区域当 qword 数组打印（自动识别串/代码）
    python pe_scan.py props 0x145C04F80 0x145C06200
                                          # 按 0x30 步长解码「属性描述符」候选
    python pe_scan.py find w:Foo .rdata   # 在指定节里找 4 字节值 / ASCII / UTF-16 串
    python pe_scan.py disp 0x1788         # 在 .text 里找 [reg+disp32] 访问点
"""
import struct
import sys

PATH = r"d:\workspace\outlast\TOTClient-Win64-Shipping.exe"
D = open(PATH, "rb").read()

pe = struct.unpack_from("<I", D, 0x3C)[0]
nsec = struct.unpack_from("<H", D, pe + 6)[0]
opt = pe + 24
magic = struct.unpack_from("<H", D, opt)[0]
IMAGE_BASE = (struct.unpack_from("<Q", D, opt + 24)[0] if magic == 0x20B
              else struct.unpack_from("<I", D, opt + 28)[0])
secoff = opt + struct.unpack_from("<H", D, pe + 20)[0]
SECS = []
for i in range(nsec):
    o = secoff + 40 * i
    name = D[o:o + 8].rstrip(b"\x00").decode("latin1")
    vsize, va, rawsize, rawptr = struct.unpack_from("<IIII", D, o + 8)
    SECS.append((name, va, vsize, rawptr, rawsize))


def va2off(va):
    rva = va - IMAGE_BASE
    for name, sva, vsize, rawptr, rawsize in SECS:
        if sva <= rva < sva + max(vsize, rawsize):
            return rawptr + (rva - sva)
    return None


def off2va(off):
    for name, sva, vsize, rawptr, rawsize in SECS:
        if rawptr <= off < rawptr + rawsize:
            return IMAGE_BASE + sva + (off - rawptr)
    return None


def rd(va, n):
    off = va2off(va)
    return D[off:off + n] if off is not None else b""


def q(va):
    b = rd(va, 8)
    return struct.unpack("<Q", b)[0] if len(b) == 8 else None


def d(va, n=4):
    b = rd(va, n)
    return struct.unpack("<%dI" % (n // 4), b) if len(b) == n else ()


def cstr(va, limit=200):
    off = va2off(va)
    if off is None:
        return None
    end = D.find(b"\x00", off, off + limit)
    raw = D[off:end if end >= 0 else off + limit]
    try:
        return raw.decode("latin1")
    except Exception:
        return None


def wstr(va, limit=400):
    off = va2off(va)
    if off is None:
        return None
    end = off
    while end < off + limit and D[end:end + 2] != b"\x00\x00":
        end += 2
    try:
        return D[off:end].decode("utf-16-le")
    except Exception:
        return None


def section_of(va):
    rva = va - IMAGE_BASE
    for name, sva, vsize, rawptr, rawsize in SECS:
        if sva <= rva < sva + max(vsize, rawsize):
            return name
    return None


def show_ptr(va):
    v = q(va)
    if v is None:
        return "??"
    sec = section_of(v) or "-"
    if sec == ".rdata":
        s = wstr(v, 60) if v % 2 == 0 else None
        t = cstr(v, 60)
        txt = t if t and t.isprintable() and len(t) > 1 else (s or "")
        return "0x%016X %-8s %r" % (v, sec, txt[:70])
    return "0x%016X %-8s" % (v, sec)


def cmd_sec():
    print("image_base=0x%x" % IMAGE_BASE)
    for s in SECS:
        print("  %-8s va=0x%08x vsize=0x%08x raw=0x%08x size=0x%08x" % s)


def cmd_str(va):
    print("ascii:", cstr(va))
    print("utf16:", wstr(va))


def cmd_ptrs(start, count):
    for i in range(count):
        a = start + 8 * i
        print("0x%X: %s" % (a, show_ptr(a)))


def cmd_props(start, end, stride=0x30):
    a = start
    while a < end:
        vals = []
        for i in range(stride // 8):
            vals.append(show_ptr(a + 8 * i))
        print("0x%X" % a)
        for i, v in enumerate(vals):
            print("   +0x%02X %s" % (8 * i, v))
        a += stride


def cmd_find(pat, secname=".text"):
    """在指定节里找 4 字节小端值 / ASCII 串 / UTF-16 串"""
    for name, sva, vsize, rawptr, rawsize in SECS:
        if name != secname:
            continue
        blob = D[rawptr:rawptr + rawsize]
        hits = 0
        if pat.startswith("0x"):
            needle = struct.pack("<I", int(pat, 0))
        elif pat.startswith("w:"):
            needle = pat[2:].encode("utf-16-le")
        else:
            needle = pat.encode("latin1")
        i = blob.find(needle)
        while i >= 0:
            va = IMAGE_BASE + sva + i
            print("  0x%X" % va)
            hits += 1
            i = blob.find(needle, i + 1)
        print("%s: %d hits" % (pat, hits))


def cmd_finddisp(val, secname=".text", member=None):
    """找代码里形如 [reg+disp32] 的位移命中（modrm mod=10），可选按成员偏移辅助判断。

    member: 该对象里的属性偏移，若给出，会额外打印一次「附近是否出现该偏移」。
    """
    needle = struct.pack("<i", val)
    for name, sva, vsize, rawptr, rawsize in SECS:
        if name != secname:
            continue
        blob = D[rawptr:rawptr + rawsize]
        n = len(blob)
        i = blob.find(needle)
        hits = []
        while i >= 0:
            if i >= 2:
                b = blob[i - 1]
                b0 = blob[i - 2]
                # modrm mod=10 & rm!=4 -> 直接 disp32
                if (b & 0xC0) == 0x80 and (b & 7) != 4:
                    hits.append(i - 1)
                # rm==4 的 SIB 形式
                elif (b & 0xC0) == 0x80 and (b & 7) == 4:
                    hits.append(i - 2)
            i = blob.find(needle, i + 1)
        print("%s 0x%X: %d 处" % (secname, val, len(hits)))
        for h in hits:
            va = IMAGE_BASE + sva + h
            ctx = blob[max(0, h - 6):h + 8]
            print("  0x%X  %s" % (va, " ".join("%02x" % x for x in ctx)))


def cmd_dis(va, n=24):
    """粗略反汇编（用 IDA 更好，这里只做字节展示）"""
    b = rd(va, n)
    print("0x%X: %s" % (va, " ".join("%02x" % x for x in b)))


def main(argv):
    if len(argv) < 2:
        print(__doc__)
        return 2
    c = argv[1]
    if c == "find":
        cmd_find(argv[2], argv[3] if len(argv) > 3 else ".text")
        return 0
    if c == "disp":
        cmd_finddisp(int(argv[2], 0), argv[3] if len(argv) > 3 else ".text")
        return 0
    if c == "bytes":
        cmd_dis(int(argv[2], 0), int(argv[3], 0) if len(argv) > 3 else 24)
        return 0
    if c == "sec":
        cmd_sec()
    elif c == "str":
        cmd_str(int(argv[2], 0))
    elif c == "ptrs":
        cmd_ptrs(int(argv[2], 0), int(argv[3], 0))
    elif c == "props":
        cmd_props(int(argv[2], 0), int(argv[3], 0),
                  int(argv[4], 0) if len(argv) > 4 else 0x30)
    else:
        print(__doc__)
        return 2
    return 0


if __name__ == "__main__":
    try:
        sys.stdout.reconfigure(encoding="utf-8")
    except Exception:
        pass
    sys.exit(main(sys.argv))
