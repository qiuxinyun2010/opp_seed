// SRR_MT02 的 2^32 全扫器：找「种子基偏移量」delta。
//
// 模型：base = GetSeed(协调器) + delta，抽取 = RandSeeded(base + i, 剩余) + RemoveAtSwap
//       RandSeeded 内部掺 salt = level_seed % 1000
// 约束：School 与 SasExit 的 6 台集合，在 seed 417417 与 737737 下都要对上。
//   误报期望 = 2^32 / (C(26,6)^2 * C(19,6)^2) ≈ 1e-10  → 命中即真解。
//
// 用法: scan_srr <mode>   mode 0=RemoveAtSwap(逐个)  1=保序RemoveAt  2=Fisher-Yates
#include <stdio.h>
#include <stdint.h>
#include <stdlib.h>
#include <omp.h>

static uint32_t TBL[256];

static void mk_table(void) {
    for (uint32_t i = 0; i < 256; i++) {
        uint32_t c = i;
        for (int k = 0; k < 8; k++) c = (c & 1) ? ((c >> 1) ^ 0xEDB88320u) : (c >> 1);
        TBL[i] = c;
    }
}

static inline uint64_t fmix_a(uint32_t seed) {
    uint64_t x = 0xBF58476D1CE4E5B9ull * (uint64_t)(seed ^ (seed >> 30));
    return x ^ (x >> 27);
}

static inline uint64_t salt_b(uint32_t salt) {
    uint64_t x = 0xBF58476D1CE4E5B9ull * (uint64_t)(salt % 1000u);
    return x ^ (x >> 27);
}

static inline uint32_t rand_seeded(uint32_t seed, uint32_t n, uint64_t b) {
    uint64_t a, v5, t, v6, u, v7;
    if (!n || !seed) return 0;
    a = fmix_a(seed);
    v5 = (0x94D049BB133111EBull * a) ^ (0x94D049BB133111EBull * b);
    t = v5 ^ (v5 >> 31);
    v6 = 0xBF58476D1CE4E5B9ull * (t ^ (t >> 30));
    u = v6 ^ (v6 >> 27);
    v7 = (uint64_t)((uint32_t)(321982955u * (uint32_t)u)) ^ ((0x94D049BB133111EBull * u) >> 31);
    return (uint32_t)((uint16_t)v7 % (uint16_t)n);
}

/* ---- School：池 26，目标 6 ---- */
static const int WANT_S417[6] = {15, 13, 17, 1, 4, 5};    /* BP5 BP6 BP19 BP24 BP26 BP29 */
static const int WANT_S737[6] = {15, 24, 21, 18, 2, 3};   /* BP5 BP8 BP11 BP21 BP25 BP27_3 */
/* ---- SasExit：池 19 ---- */
static const int WANT_E417[6] = {15, 11, 1, 6, 14, 17};   /* BP45 BP43 BP31 BP38 BP36 BP47 */
static const int WANT_E737[6] = {0, 2, 13, 15, 8, 17};    /* BP30 BP33 BP37 BP45 BP40 BP47 */

static const uint32_t BASE_S = 0x201DAC20u;   /* GetSeed(SRR_MT02_OrderedClueFrequency_School) */
static const uint32_t BASE_E = 0x69516727u;   /* GetSeed(..._SasExit) */

static int MODE = 0;

/* 抽 6 个，返回位掩码（集合） */
static int draw_mask(uint32_t base, int n, uint64_t B) {
    int mem[32];
    int i, m = n, mask = 0;
    for (i = 0; i < n; i++) mem[i] = i;
    if (MODE == 2) {                       /* Fisher-Yates 后取前 6 */
        for (i = n; i > 1; i--) {
            int j = (int)rand_seeded((uint32_t)(base + (n - i)), (uint32_t)i, B);
            int t = mem[i - 1]; mem[i - 1] = mem[j]; mem[j] = t;
        }
        for (i = 0; i < 6; i++) mask |= 1 << mem[i];
        return mask;
    }
    for (i = 0; i < 6; i++) {
        int k = (int)rand_seeded((uint32_t)(base + i), (uint32_t)m, B);
        mask |= 1 << mem[k];
        if (MODE == 0) {                   /* RemoveAtSwap */
            mem[k] = mem[m - 1];
        } else {                           /* 保序 RemoveAt */
            int j;
            for (j = k; j < m - 1; j++) mem[j] = mem[j + 1];
        }
        m--;
    }
    return mask;
}

static int wmask(const int *w) {
    int i, m = 0;
    for (i = 0; i < 6; i++) m |= 1 << w[i];
    return m;
}

int main(int argc, char **argv) {
    mk_table();
    if (argc > 1) MODE = atoi(argv[1]);
    uint64_t B417 = salt_b(417), B737 = salt_b(737);
    int mS417 = wmask(WANT_S417), mS737 = wmask(WANT_S737);
    int mE417 = wmask(WANT_E417), mE737 = wmask(WANT_E737);
    long long total = 4294967296LL;
    long long hits = 0;
    long long d;
    fprintf(stderr, "mode=%d  scanning 2^32 ...\n", MODE);
#pragma omp parallel for schedule(dynamic, 1048576) reduction(+:hits)
    for (d = 0; d < total; d++) {
        uint32_t bs = BASE_S + (uint32_t)d;
        if (draw_mask(bs, 26, B417) != mS417) continue;
        if (draw_mask(bs, 26, B737) != mS737) continue;
        uint32_t be = BASE_E + (uint32_t)d;
        if (draw_mask(be, 19, B417) != mE417) continue;
        if (draw_mask(be, 19, B737) != mE737) continue;
        hits++;
        printf("HIT delta=%lld (0x%llX)  baseSchool=0x%08X baseSasExit=0x%08X\n",
               d, (unsigned long long)d, bs, be);
        fflush(stdout);
    }
    fprintf(stderr, "done, hits=%lld\n", hits);
    return 0;
}
