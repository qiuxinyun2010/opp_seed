# -*- coding: utf-8 -*-
"""PSB_MT01 第九轮：用完整实测（seed 378378，9 具 + 9 图案）反解。

实测 378378（release/home/test.txt 末尾）：
    A=月亮  B=火焰  C=黑桃
    A: 红心=AgainstWall_BP2_5(#0)  王冠=BP3_8(#16)  月亮=AgainstWall_BP_2(#8)
    B: 方块=Desk_BP_5(#25)         火焰=WallThroat_BP7_26(#37)  兔子=Desk_BP2_2(#23)
    C: 眼睛=BP7_2(#20)             黑桃=WallThroat_BP8_32(#38)  梅花=OnChair_BP3_8(#27)

模型（sub_14361C230 @0x14361CA08 / 0x14361CA7C）：
    for group (一区):                       # v70 = 跨组累加的已抽总数
        for v71 in 0..cnt-1:
            ci = RandSeeded(base + 243551 + v71 + v70, |group|)   保序删除
            pi = RandSeeded(base + 223551 + v71 + v70, |pool| )   保序删除

用法：
    python tools/psb_fit9.py [扫描上限]          # base = GetSeed(coord)+d
    python tools/psb_fit9.py 65536 --pure        # base = d（纯常数，PSA 那种）
"""
import itertools
import os
import sys

sys.path.insert(0, os.path.abspath(os.path.join(os.path.dirname(__file__), '..', '..', 'seed')))
import seedcore as sc  # noqa: E402

POOL = ['Bunny', 'Club', 'Diamond', 'Fire', 'Heart', 'Spade', 'Crown', 'Eye', 'Moon', 'Star']

A_LIST = [0, 1, 2, 4, 8, 15, 16, 17, 18, 19, 22, 33, 34, 35, 40]
B_LIST = [9, 10, 21, 23, 24, 25, 26, 32, 36, 37]
C_LIST = [3, 5, 6, 7, 11, 12, 13, 14, 20, 27, 28, 29, 30, 31, 38, 39]
LISTS = {'A': A_LIST, 'B': B_LIST, 'C': C_LIST}

COORD = 'PSB_MT01_B01_CorpseSearch_3'

S378 = {
    'A': {0: 'Heart', 16: 'Crown', 8: 'Moon'},
    'B': {25: 'Diamond', 37: 'Fire', 23: 'Bunny'},
    'C': {20: 'Eye', 38: 'Spade', 27: 'Club'},
}
S565 = {'A': {1: 'Heart'}, 'B': {9: 'Club'}, 'C': {7: 'Eye', 3: 'Diamond'}}
S111 = {'A': 'Star', 'B': 'Bunny', 'C': 'Diamond'}


def _set_of(mapping):
    return {sec: {LISTS[sec].index(a) for a in d} for sec, d in mapping.items()}


WANT378 = _set_of(S378)


def first_group(base, seed, sec):
    """只算某区作为首组（v70=0）时的 3 具下标。"""
    salt = seed % 1000
    g = list(LISTS[sec])
    out = []
    for k in range(3):
        i = sc.rand_seeded((base + 243551 + k) & 0xFFFFFFFF, len(g), salt)
        out.append(g.pop(i))
    return out


def run(base, seed, order, counts):
    salt = seed % 1000
    pool = list(POOL)
    got = {}
    v70 = 0
    for sec, cnt in zip(order, counts):
        g = list(LISTS[sec])
        for v71 in range(cnt):
            if not pool or not g:
                return None
            ci = sc.rand_seeded((base + 243551 + v71 + v70) & 0xFFFFFFFF, len(g), salt)
            actor = g.pop(ci)
            pi = sc.rand_seeded((base + 223551 + v71 + v70) & 0xFFFFFFFF, len(pool), salt)
            got[actor] = pool.pop(pi)
            v70 += 1
    return got


def check(base, d, orders, counts_list, verbose):
    for order in orders:
        for counts in counts_list:
            g378 = run(base, 378378, order, counts)
            if not g378:
                continue
            if not all(g378.get(a) == p for sec in 'ABC' for a, p in S378[sec].items()):
                continue
            print('★ 378378 全中 d=%d base=0x%08X order=%s counts=%s' % (d, base, order, counts))
            g565 = run(base, 565565, order, counts)
            ok565 = bool(g565) and all(g565.get(a) == p
                                       for sec in 'ABC' for a, p in S565[sec].items())
            print('   565565 校验：%s' % ('OK 4/4' if ok565 else '败 %s' % (g565,)))
            g111 = run(base, 111111, order, counts)
            ok111 = bool(g111) and all(S111[sec] in [g111.get(a) for a in LISTS[sec]]
                                       for sec in 'ABC')
            print('   111111 校验：%s' % ('OK 3/3' if ok111 else '败 %s' % (g111,)))
            if verbose:
                print('   378 映射：%s' % g378)
            return True
    return False


def main():
    try:
        sys.stdout.reconfigure(encoding='utf-8')
    except Exception:
        pass
    argv = [a for a in sys.argv[1:]]
    pure = '--pure' in argv
    nums = [a for a in argv if a.isdigit()]
    scan = int(nums[0]) if nums else (1 << 20)
    lvl = sc.crc32_fname('PersistentLevel')
    coord = sc.seed_of_object(COORD, lvl)
    orders = list(itertools.permutations('ABC'))
    counts_list = [(3, 3, 3), (3, 3, 4), (3, 4, 3), (4, 3, 3)]
    print('base = %s   d=0..%d' % ('K（纯常数）' if pure else 'GetSeed(coord)+K', scan - 1))

    npass = 0
    for d in range(scan):
        base = d if pure else (coord + d) & 0xFFFFFFFF
        matched = [sec for sec in 'ABC'
                   if {LISTS[sec].index(a) for a in first_group(base, 378378, sec)} == WANT378[sec]]
        if not matched:
            continue
        npass += 1
        sub_orders = [o for o in orders if o[0] in matched]
        check(base, d, sub_orders, counts_list, verbose=True)
    print('首组候选 %d 个 d；完成' % npass)


if __name__ == '__main__':
    main()
