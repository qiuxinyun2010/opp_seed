# -*- coding: utf-8 -*-
"""SRR_MT02：用第一轮 RichDistrict 的**两个 seed** 的「机器 ↔ 图案」配对定算法。

RichDistrict 池 4 = DesiredCount 4 → 4 台全取，位置与 seed 无关；
变的是「抽序 × 图案序列」的配对。两个 seed 同时匹配的概率约 1/(2880^2)，命中即定解。
而分组已退化（§4.2.1），RichDistrict 与 6/6 走同一条路径 → 定下它就能直接去验 6/6。

实测（release/home/test.txt）：
  seed 417417 : BP=月亮Moon  BP2=兔子Bunny  BP3=梅花Club  BP49=红心Heart
  seed 737737 : BP=红心Heart BP2=月亮Moon   BP3=黑桃Spade BP49=梅花Club
"""
import sys
from itertools import product

M32 = 0xFFFFFFFF
M64 = 0xFFFFFFFFFFFFFFFF

_T = []
for _i in range(256):
    _c = _i
    for _ in range(8):
        _c = ((_c >> 1) ^ 0xEDB88320) if (_c & 1) else (_c >> 1)
    _T.append(_c & M32)


def crc32_fname(text):
    crc = M32
    for ch in text:
        u = ord(ch) & 0xFFFF
        crc = _T[(crc ^ (u & 0xFF)) & 0xFF] ^ (crc >> 8)
        crc = _T[(crc ^ (u >> 8)) & 0xFF] ^ (crc >> 8)
        crc = _T[crc & 0xFF] ^ (crc >> 8)
        crc = _T[crc & 0xFF] ^ (crc >> 8)
    return (~crc) & M32


def seed_of_object(name):
    value = (crc32_fname(name) + crc32_fname('PersistentLevel')) & M32
    return value if value < 0x80000000 else (0x100000000 - value) & M32


def mix1(x):
    z = (0xBF58476D1CE4E5B9 * (x ^ (x >> 30))) & M64
    return z ^ (z >> 27)


def rs(seed, n, salt):
    if not n or not seed:
        return 0
    B = (0x94D049BB133111EB * mix1(salt % 1000)) & M64
    v = ((0x94D049BB133111EB * mix1(seed)) & M64) ^ B
    t = (v ^ (v >> 31)) & M64
    w = (0xBF58476D1CE4E5B9 * (t ^ (t >> 30))) & M64
    u = (w ^ (w >> 27)) & M64
    r = (((321982955 * u) & M64) ^ (((0x94D049BB133111EB * u) & M64) >> 31)) & M64
    return (r & 0xFFFF) % n


POOL = ['BP', 'BP2', 'BP3', 'BP49']
CLUES = ['Bunny', 'Heart', 'Moon', 'Spade', 'Club']
WANT = {
    417417: {'BP': 'Moon', 'BP2': 'Bunny', 'BP3': 'Club', 'BP49': 'Heart'},
    737737: {'BP': 'Heart', 'BP2': 'Moon', 'BP3': 'Spade', 'BP49': 'Club'},
}
COORD = 'SRR_MT02_OrderedClueFrequency_RichDistrict'
SEED = seed_of_object(COORD)
SALT_CRC = crc32_fname('Objective Actors')
D = 4


def take(mem, base, k, salt, swap):
    i = rs((base + k) & M32, len(mem), salt)
    v = mem[i]
    if swap:
        mem[i] = mem[-1]
        mem.pop()
    else:
        del mem[i]
    return v


def run(mode, base, swap_draw, swap_clue, clue_start, salt):
    rev = mode.endswith('rev')
    m = mode[:-3] if rev else mode
    pool = list(POOL)
    if rev:
        pool.reverse()
    if m == 'plain':
        mem = list(pool)
        order = [take(mem, base, i, salt, swap_draw) for i in range(D)]
    elif m == 'fy':
        mem = list(pool)
        for i in range(len(mem), 1, -1):
            j = rs((base + (len(mem) - i)) & M32, i, salt)
            mem[i - 1], mem[j] = mem[j], mem[i - 1]
        order = mem[:D]
    elif m == 'take':
        mem = list(pool)
        order = [take(mem, base, i, salt, swap_draw) for i in range(D)]
    else:
        raise ValueError(mode)
    cp = list(CLUES)
    clues = [take(cp, base, clue_start + i, salt, swap_clue) for i in range(D)]
    return order, clues


def clue_only(base, style, swap, start, salt):
    """只生成图案序列（对照「图案直接配给池顺序」的假设）。"""
    cp = list(CLUES)
    if style == 'fy':
        for i in range(len(cp), 1, -1):
            j = rs((base + (len(cp) - i)) & M32, i, salt)
            cp[i - 1], cp[j] = cp[j], cp[i - 1]
        return cp[:D]
    return [take(cp, base, start + i, salt, swap) for i in range(D)]


def main_clue_only():
    """假设：图案序列直接按「池顺序」或「倒序池」赋给 4 台，与抽序无关。"""
    span = int(sys.argv[1]) if len(sys.argv) > 1 else 13
    bases = {'coord': SEED, '+salt': (SEED + SALT_CRC) & M32}
    found = []
    for (btag, base), style, swap, start, order in product(
            bases.items(), ('take', 'fy'), (True, False), range(0, span),
            ('pool', 'poolrev')):
        ok = True
        for seed in (417417, 737737):
            cl = clue_only(base, style, swap, start, seed)
            keys = POOL if order == 'pool' else POOL[::-1]
            if dict(zip(keys, cl)) != WANT[seed]:
                ok = False
                break
        if ok:
            found.append((btag, style, swap, start, order))
            print('★ HIT(clue-only) base=%-6s style=%-5s %s start=%d 赋给=%s'
                  % (btag, style, 'swap' if swap else 'rm', start, order))
            for seed in (417417, 737737):
                print('     %d: %s' % (seed, clue_only(base, style, swap, start, seed)))
    if not found:
        print('clue-only: 无命中')


def main():
    bases = {'coord': SEED, '+salt': (SEED + SALT_CRC) & M32}
    modes = ('plain', 'plainrev', 'fy', 'fyrev')
    hits = []
    for (btag, base), mode, sd, sc, cs in product(
            bases.items(), modes, (True, False), (True, False), range(0, 13)):
        ok = True
        for seed in (417417, 737737):
            order, clues = run(mode, base, sd, sc, cs, seed)
            if dict(zip(order, clues)) != WANT[seed]:
                ok = False
                break
        if ok:
            hits.append((btag, mode, sd, sc, cs))
            print('★ HIT base=%-6s mode=%-9s draw=%s clue=%s start=%d'
                  % (btag, mode, 'swap' if sd else 'rm', 'swap' if sc else 'rm', cs))
            for seed in (417417, 737737):
                o, c = run(mode, base, sd, sc, cs, seed)
                print('     %d: %s' % (seed, list(zip(o, c))))
    total = 2 * len(modes) * 2 * 2 * 13
    if not hits:
        print('no hit（%d 种组合全部不匹配两个 seed）' % total)
    else:
        print('共 %d / %d 组合命中两个 seed' % (len(hits), total))


if __name__ == '__main__':
    main()
    print('---')
    main_clue_only()
