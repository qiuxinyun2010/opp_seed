"""从 FModel 导出的关卡 JSON 中提取 RBRoom / RBPuzzleRoomComponent 的名字与归属包。

用法: python room_actors.py <json 目录或文件> [关键字]
"""
import json
import os
import sys

kw = sys.argv[2] if len(sys.argv) > 2 else "RBRoom_"
target = sys.argv[1]
files = []
if os.path.isdir(target):
    files = [os.path.join(target, f) for f in os.listdir(target)
             if f.lower().endswith(".json") and "builtdata" not in f.lower()]
else:
    files = [target]

for path in files:
    try:
        data = json.load(open(path, "r", encoding="utf-8"))
    except Exception as exc:
        print("ERR", path, exc)
        continue
    if not isinstance(data, list):
        continue
    for obj in data:
        nm = obj.get("Name") or ""
        if kw.lower() not in nm.lower():
            continue
        outer = obj.get("Outer") or {}
        outer_name = outer.get("ObjectName") if isinstance(outer, dict) else None
        if not outer_name:
            continue
        print("%-28s %-46s %-24s <- %s" % (os.path.basename(path), nm,
                                           obj.get("Type"), outer_name))
