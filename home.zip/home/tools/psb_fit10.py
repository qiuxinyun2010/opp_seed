# -*- coding: utf-8 -*-
"""PSB_MT01 第十轮：只解「每区钥匙图案」。

三条实测（A/B/C 的钥匙图案）：
    378378 → 月亮 Moon(8) / 火焰 Fire(3) / 黑桃 Spade(5)
    565565 → 红心 Heart(4) / 梅花 Club(1) / 眼睛 Eye(7)
    111111 → 五角星 Star(9) / 兔子 Bunny(0) / 方块 Diamond(2)

模型：sec = 0,1,2 顺序抽 3 次，池 10 个保序删除
    idx = RandSeeded(base + i, |pool|)
扫描 base 的两种设法：纯常数 K / GetSeed(coord)+K。

命中即等于同时钉死「图案基」与 9 条图案约束（概率 ~1/720³），
之后尸体侧只要共享同一个 base 就能顺着算。
"""
import os
import sys

sys.path.insert(0, os.path.abspath(os.path.join(os.path.dirname(__file__), '..', '..', 'seed')))
import seedcore as sc  # noqa: E402

POOL = ['Bunny', 'Club', 'Diamond', 'Fire', 'Heart', 'Spade', 'Crown', 'Eye', 'Moon', 'Star']
COORD = 'PSB_MT01_B01_CorpseSearch_3'

SAMPLES = [
    (378378, ['Moon', 'Fire', 'Spade'], None),
    (565565, ['Heart', 'Club', 'Eye'], None),
    (111111, ['Star', 'Bunny', 'Diamond'], None),
]


def seq(base, seed, swap=False):
    salt = seed % 1000
    pool = list(POOL)
    out = []
    for i in range(3):
        j = sc.rand_seeded((base + i) & 0xFFFFFFFF, len(pool), salt)
        out.append(pool[j])
        if swap:
            pool[j] = pool[-1]
        pool.pop(j)
    return out


def main():
    try:
        sys.stdout.reconfigure(encoding='utf-8')
    except Exception:
        pass
    argv = sys.argv[1:]
    pure = '--pure' in argv
    nums = [a for a in argv if a.isdigit()]
    scan = int(nums[0]) if nums else (1 << 22)
    swap = '--swap' in argv
    lvl = sc.crc32_fname('PersistentLevel')
    coord = sc.seed_of_object(COORD, lvl)
    salt_crc = sc.crc32_fname('Objective Actors')
    r = sc.rand_seeded
    print('base=%s  swap=%s  K=0..%d'
          % ('K' if pure else 'GetSeed(coord)+K', swap, scan - 1))

    pre = [(seed, want) for seed, want, _ in SAMPLES]
    hits = []
    for K in range(scan):
        for base in ((K,) if pure else (K, (coord + K) & 0xFFFFFFFF,
                                        (coord + salt_crc + K) & 0xFFFFFFFF)):
            if seq(base, 378378, swap)[0] != 'Moon':
                continue
            ok = True
            for seed, want in pre:
                if seq(base, seed, swap) != want:
                    ok = False
                    break
            if ok:
                hits.append((K, base))
                print('★ K=%d base=0x%08X' % (K, base))
    print('完成，命中 %d' % len(hits))


if __name__ == '__main__':
    main()
