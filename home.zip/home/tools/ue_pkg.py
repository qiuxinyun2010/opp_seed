# -*- coding: utf-8 -*-
"""最小 UE4（4.25 时代）资产解析：头 + 名称表 + 导入/导出表。

只做"读结构"这一件事，够用来定位蓝图函数导出（Ubergraph）的字节码。

    python ue_pkg.py <uasset> <uexp>
"""
import struct
import sys


class R:
    def __init__(self, b):
        self.b = b
        self.p = 0

    def u8(self):
        v = self.b[self.p]
        self.p += 1
        return v

    def i32(self):
        v = struct.unpack_from('<i', self.b, self.p)[0]
        self.p += 4
        return v

    def u32(self):
        v = struct.unpack_from('<I', self.b, self.p)[0]
        self.p += 4
        return v

    def i64(self):
        v = struct.unpack_from('<q', self.b, self.p)[0]
        self.p += 8
        return v

    def u64(self):
        v = struct.unpack_from('<Q', self.b, self.p)[0]
        self.p += 8
        return v

    def fstr(self):
        n = self.i32()
        if n == 0:
            return ''
        if n > 0:
            s = self.b[self.p:self.p + n - 1].decode('latin1', 'replace')
            self.p += n
            return s
        n = -n
        s = self.b[self.p:self.p + 2 * (n - 1)].decode('utf-16-le', 'replace')
        self.p += 2 * n
        return s

    def fname(self):
        idx = self.i32()
        num = self.i32()
        return idx, num


def parse(path):
    d = open(path, 'rb').read()
    r = R(d)
    tag = r.u32()
    assert tag == 0x9E2A83C1, hex(tag)
    legacy = r.i32()
    ue3 = r.i32()
    ue4 = r.i32()
    lic = r.i32()
    out = {'legacy': legacy, 'ue3': ue3, 'ue4': ue4, 'lic': lic}
    if legacy <= -2:
        n = r.i32()
        for _ in range(max(0, n)):
            r.u32()      # guid?
            r.i32()
    total_header = r.i32()
    folder = r.fstr()
    flags = r.u32()
    name_count = r.i32()
    name_off = r.i32()
    out.update(total_header=total_header, folder=folder, flags=hex(flags),
               name_count=name_count, name_off=name_off)
    if ue4 >= 516:
        r.fstr()          # localization id
        r.i32()           # gatherable text count
        r.i32()           # gatherable text offset
    exp_count = r.i32()
    exp_off = r.i32()
    imp_count = r.i32()
    imp_off = r.i32()
    out.update(exp_count=exp_count, exp_off=exp_off,
               imp_count=imp_count, imp_off=imp_off)

    # 名称表
    names = []
    rr = R(d)
    rr.p = name_off
    for _ in range(name_count):
        names.append(rr.fstr())
        rr.p += 4      # hashes
    out['names'] = names

    # 导出表
    rr.p = exp_off
    exports = []
    for _ in range(exp_count):
        e = {}
        e['class'] = rr.i32()
        e['super'] = rr.i32()
        e['template'] = rr.i32()
        e['outer'] = rr.i32()
        e['name'] = rr.fname()
        e['flags'] = rr.u32()
        e['serial_size'] = rr.i64() if ue4 >= 511 else rr.i32()
        e['serial_offset'] = rr.i64() if ue4 >= 511 else rr.i32()
        e['forced'] = rr.i32()
        e['notforclient'] = rr.i32()
        e['notforserver'] = rr.i32()
        e['is_asset'] = rr.i32()
        exports.append(e)
    out['exports'] = exports

    rr.p = imp_off
    imports = []
    for _ in range(imp_count):
        imports.append({'class_pkg': rr.fname(), 'class_name': rr.fname(),
                        'outer': rr.i32(), 'name': rr.fname()})
    out['imports'] = imports
    return out


def nm(names, t):
    i, num = t
    s = names[i] if 0 <= i < len(names) else '?%d' % i
    return s if num == 0 else '%s_%d' % (s, num - 1)


def main():
    if len(sys.argv) < 2:
        print(__doc__)
        return
    a = parse(sys.argv[1])
    print('legacy=%d ue3=%d ue4=%d lic=%d' % (a['legacy'], a['ue3'], a['ue4'], a['lic']))
    print('folder=%r flags=%s names=%d@0x%X exports=%d@0x%X imports=%d@0x%X'
          % (a['folder'], a['flags'], a['name_count'], a['name_off'],
             a['exp_count'], a['exp_off'], a['imp_count'], a['imp_off']))
    print('--- 名称表（前 40） ---')
    for i, s in enumerate(a['names'][:40]):
        print('  [%3d] %s' % (i, s))
    print('--- 导入 ---')
    for i, im in enumerate(a['imports']):
        print('  [%3d] %s.%s outer=%d name=%s'
              % (i, nm(a['names'], im['class_pkg']), nm(a['names'], im['class_name']),
                 im['outer'], nm(a['names'], im['name'])))
    print('--- 导出 ---')
    for i, e in enumerate(a['exports']):
        cls = e['class']
        cls_name = nm(a['names'], a['imports'][-cls - 1]['name']) if cls < 0 and -cls - 1 < len(a['imports']) else str(cls)
        print('  [%2d] %-52s class=%-24s off=0x%-6X size=%-6d outer=%d'
              % (i, nm(a['names'], e['name']), cls_name,
                 e['serial_offset'], e['serial_size'], e['outer']))


if __name__ == '__main__':
    main()
