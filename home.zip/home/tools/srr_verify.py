# -*- coding: utf-8 -*-
"""用第一轮定下的「图案算法」反推 6/6 的选中机器顺序。

图案算法（srr_fit6.py 双 seed 定解）：
    base = GetSeed(协调器)                       # 不加盐名 CRC
    clue[i] = 逐个 RandSeeded(base + 503 + i, 剩余图案数) + RemoveAtSwap

若图案按「选中机器在池中的顺序」赋给，则已知图案序列 ⇔ 已知选中机器的池序排列，
于是可以反推出：哪 6 台被选中（已知）+ 它们被赋图案的先后（= 池序）。
再用这个顺序去对照 6/6 机器抽取算法。
"""
import sys

M32 = 0xFFFFFFFF
M64 = 0xFFFFFFFFFFFFFFFF

_T = []
for _i in range(256):
    _c = _i
    for _ in range(8):
        _c = ((_c >> 1) ^ 0xEDB88320) if (_c & 1) else (_c >> 1)
    _T.append(_c & M32)


def crc32_fname(text):
    crc = M32
    for ch in text:
        u = ord(ch) & 0xFFFF
        crc = _T[(crc ^ (u & 0xFF)) & 0xFF] ^ (crc >> 8)
        crc = _T[(crc ^ (u >> 8)) & 0xFF] ^ (crc >> 8)
        crc = _T[crc & 0xFF] ^ (crc >> 8)
        crc = _T[crc & 0xFF] ^ (crc >> 8)
    return (~crc) & M32


def seed_of_object(name):
    value = (crc32_fname(name) + crc32_fname('PersistentLevel')) & M32
    return value if value < 0x80000000 else (0x100000000 - value) & M32


def mix1(x):
    z = (0xBF58476D1CE4E5B9 * (x ^ (x >> 30))) & M64
    return z ^ (z >> 27)


def rs(seed, n, salt):
    if not n or not seed:
        return 0
    B = (0x94D049BB133111EB * mix1(salt % 1000)) & M64
    v = ((0x94D049BB133111EB * mix1(seed)) & M64) ^ B
    t = (v ^ (v >> 31)) & M64
    w = (0xBF58476D1CE4E5B9 * (t ^ (t >> 30))) & M64
    u = (w ^ (w >> 27)) & M64
    r = (((321982955 * u) & M64) ^ (((0x94D049BB133111EB * u) & M64) >> 31)) & M64
    return (r & 0xFFFF) % n


CLUE_OFFSET = 503

POOLS = {
    'School': ['BP23', 'BP24', 'BP25', 'BP27_3', 'BP26', 'BP29', 'BP28', 'BP16',
               'BP17', 'BP15', 'BP13', 'BP14', 'BP4', 'BP6', 'BP7', 'BP5',
               'BP19_22', 'BP19', 'BP21', 'BP20', 'BP22', 'BP11', 'BP12', 'BP10',
               'BP8', 'BP9'],
    'SasExit': ['BP30', 'BP31', 'BP33', 'BP32', 'BP35', 'BP34', 'BP38', 'BP39',
                'BP40', 'BP41', 'BP42', 'BP43', 'BP44', 'BP37', 'BP36', 'BP45',
                'BP46', 'BP47', 'BP48'],
    'RichDistrict': ['BP', 'BP2', 'BP3', 'BP49'],
}
CLUES = {
    'RichDistrict': ['Bunny', 'Heart', 'Moon', 'Spade', 'Club'],
    'School': ['Bunny', 'Heart', 'Moon', 'Spade', 'Club', 'Diamond'],
    'SasExit': ['Bunny', 'Heart', 'Moon', 'Spade', 'Club', 'Diamond'],
}
COORD = {
    'RichDistrict': 'SRR_MT02_OrderedClueFrequency_RichDistrict',
    'School': 'SRR_MT02_OrderedClueFrequency_School',
    'SasExit': 'SRR_MT02_OrderedClueFrequency_SasExit',
}
# 实测：机器 → 图案
PAIRS = {
    ('School', 417417): {'BP5': 'Bunny', 'BP6': 'Club', 'BP19': 'Moon',
                         'BP26': 'Heart', 'BP24': 'Diamond', 'BP29': 'Spade'},
    ('School', 737737): {'BP5': 'Spade', 'BP8': 'Diamond', 'BP11': 'Heart',
                         'BP21': 'Club', 'BP25': 'Moon', 'BP27_3': 'Bunny'},
    ('SasExit', 417417): {'BP45': 'Moon', 'BP43': 'Diamond', 'BP31': 'Heart',
                          'BP38': 'Club', 'BP36': 'Bunny', 'BP47': 'Spade'},
    ('SasExit', 737737): {'BP30': 'Diamond', 'BP33': 'Spade', 'BP37': 'Club',
                          'BP45': 'Heart', 'BP40': 'Moon', 'BP47': 'Bunny'},
    ('RichDistrict', 417417): {'BP': 'Moon', 'BP2': 'Bunny', 'BP3': 'Club',
                               'BP49': 'Heart'},
    ('RichDistrict', 737737): {'BP': 'Heart', 'BP2': 'Moon', 'BP3': 'Spade',
                               'BP49': 'Club'},
}


def clue_seq(key, seed, offset=CLUE_OFFSET):
    base = seed_of_object(COORD[key])
    cp = list(CLUES[key])
    n = len(cp)
    out = []
    for i in range(n):
        k = rs((base + offset + i) & M32, len(cp), seed)
        out.append(cp[k])
        cp[k] = cp[-1]
        cp.pop()
    return out


def main():
    print('图案算法：clue[i] = 逐个 RandSeeded(GetSeed(coord) + %d + i, 剩余) + RemoveAtSwap'
          % CLUE_OFFSET)
    for key in ('RichDistrict', 'School', 'SasExit'):
        for seed in (417417, 737737):
            seq = clue_seq(key, seed)
            want = PAIRS[(key, seed)]
            pool = POOLS[key]
            picks = sorted(want.keys(), key=lambda a: pool.index(a))
            got = dict(zip(picks, seq))          # 按池序赋
            ok = got == want
            print('\n%s @%d  %s' % (key, seed, '✔ 匹配' if ok else '✘ 不匹配'))
            print('   预测图案序列 %s' % seq)
            print('   池序机器     %s' % picks)
            if not ok:
                print('   实测         %s' % [want[a] for a in picks])


if __name__ == '__main__':
    main()
