# -*- coding: utf-8 -*-
"""在 exe 里搜 ASCII / UTF-16LE 串，并换算成 VA（给 REA 的 xrefs 用）。

用法：
    python srr_strva.py OrderedPanelObjectiveCoordinator
    python srr_strva.py Objective Actors --wide
"""
import struct
import sys

PATH = r"d:\workspace\outlast\TOTClient-Win64-Shipping.exe"
d = open(PATH, "rb").read()

pe = struct.unpack_from("<I", d, 0x3C)[0]
nsec = struct.unpack_from("<H", d, pe + 6)[0]
opt = pe + 24
magic = struct.unpack_from("<H", d, opt)[0]
image_base = (struct.unpack_from("<Q", d, opt + 24)[0] if magic == 0x20B
              else struct.unpack_from("<I", d, opt + 28)[0])
secoff = opt + struct.unpack_from("<H", d, pe + 20)[0]
SECS = []
for i in range(nsec):
    o = secoff + 40 * i
    name = d[o:o + 8].rstrip(b"\x00").decode("latin1")
    vsize, va, rawsize, rawptr = struct.unpack_from("<IIII", d, o + 8)
    SECS.append((name, va, vsize, rawptr, rawsize))


def off2va(off):
    for name, sva, vsize, rawptr, rawsize in SECS:
        if rawptr <= off < rawptr + min(vsize, rawsize):
            return image_base + sva + (off - rawptr)
    return None


def main():
    if len(sys.argv) < 2:
        print(__doc__)
        return
    text = sys.argv[1]
    wide = "--wide" in sys.argv or True
    for enc, tag in ((text.encode("latin1"), "ascii"),
                     (text.encode("utf-16-le"), "utf-16")):
        if tag == "utf-16" and not wide:
            continue
        bob = enc
        start = 0
        while True:
            i = d.find(bob, start)
            if i < 0:
                break
            va = off2va(i)
            tail = d[i + len(bob):i + len(bob) + 4]
            print("%-6s off=0x%08x va=%s tail=%r" %
                  (tag, i, ("0x%X" % va) if va else "?", tail))
            start = i + 1


if __name__ == "__main__":
    main()
