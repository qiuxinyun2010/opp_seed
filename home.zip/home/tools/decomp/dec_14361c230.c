/* line: 0, address: 0x14361c230 */ __int64 __fastcall sub_14361C230(__int64 a1)
/* line: 1 */ {
/* line: 2 */   __int64 v1; // r12
/* line: 3 */   __int64 result; // rax
/* line: 4 */   float v3; // xmm0_4
/* line: 5 */   __int64 **v4; // r13
/* line: 6 */   __int64 *v5; // rsi
/* line: 7 */   __int64 *v6; // r12
/* line: 8 */   int v7; // ecx
/* line: 9 */   unsigned __int64 v8; // rax
/* line: 10 */   int v9; // r13d
/* line: 11 */   __int64 *v10; // rbx
/* line: 12 */   __int64 *v11; // rbp
/* line: 13 */   unsigned int v12; // r13d
/* line: 14 */   __int64 v13; // rax
/* line: 15 */   __int64 *v14; // r13
/* line: 16 */   __int64 *v15; // r14
/* line: 17 */   __int64 *v16; // rax
/* line: 18 */   __int64 *v17; // rcx
/* line: 19 */   __int64 *v18; // r15
/* line: 20 */   unsigned int v19; // eax
/* line: 21 */   float v20; // xmm0_4
/* line: 22 */   __int64 *v21; // rax
/* line: 23 */   __int64 *v22; // rcx
/* line: 24 */   __int64 *v23; // rdi
/* line: 25 */   unsigned int v24; // eax
/* line: 26 */   float v25; // xmm0_4
/* line: 27 */   __int64 v26; // rax
/* line: 28 */   __int64 v27; // rcx
/* line: 29 */   __int64 v28; // rcx
/* line: 30 */   __int64 *v29; // rax
/* line: 31 */   __int64 **v30; // rcx
/* line: 32 */   __int64 **v31; // r13
/* line: 33 */   __int64 **v32; // r13
/* line: 34 */   int v33; // esi
/* line: 35 */   int v34; // ebx
/* line: 36 */   int v35; // ebp
/* line: 37 */   int v36; // edi
/* line: 38 */   int v37; // ebp
/* line: 39 */   unsigned int v38; // eax
/* line: 40 */   int v39; // r15d
/* line: 41 */   unsigned int v40; // eax
/* line: 42 */   __int64 v41; // rcx
/* line: 43 */   bool v42; // cc
/* line: 44 */   __int64 v43; // rax
/* line: 45 */   __int64 *v44; // rbx
/* line: 46 */   __int64 *v45; // r14
/* line: 47 */   unsigned int v46; // eax
/* line: 48 */   __int64 v47; // rax
/* line: 49 */   __int64 v48; // rsi
/* line: 50 */   int v49; // ebx
/* line: 51 */   int v50; // ebp
/* line: 52 */   int v51; // edi
/* line: 53 */   int v52; // ebx
/* line: 54 */   unsigned int v53; // eax
/* line: 55 */   int v54; // r15d
/* line: 56 */   unsigned int v55; // eax
/* line: 57 */   __int64 v56; // rcx
/* line: 58 */   __int64 v57; // rax
/* line: 59 */   unsigned int v58; // edi
/* line: 60 */   int v59; // ebx
/* line: 61 */   unsigned int v60; // eax
/* line: 62 */   unsigned int v61; // eax
/* line: 63 */   __int64 v62; // rdx
/* line: 64 */   __int64 v63; // r8
/* line: 65 */   __int64 v64; // rbx
/* line: 66 */   const void *v65; // r14
/* line: 67 */   __int64 v66; // rbx
/* line: 68 */   const void *v67; // r14
/* line: 69 */   __int64 v68; // r14
/* line: 70 */   unsigned int v69; // esi
/* line: 71 */   int v70; // edi
/* line: 72 */   int v71; // ebx
/* line: 73 */   _QWORD *v72; // rax
/* line: 74 */   int v73; // r8d
/* line: 75 */   _QWORD *v74; // r12
/* line: 76 */   __int64 v75; // rcx
/* line: 77 */   int v76; // eax
/* line: 78 */   __int64 v77; // rdx
/* line: 79 */   __int64 v78; // r8
/* line: 80 */   unsigned int v79; // r15d
/* line: 81 */   __int64 v80; // rbp
/* line: 82 */   __int64 v81; // rax
/* line: 83 */   __int64 v82; // r9
/* line: 84 */   __int64 v83; // rcx
/* line: 85 */   int v84; // eax
/* line: 86 */   __int64 v85; // r9
/* line: 87 */   unsigned int v86; // r13d
/* line: 88 */   __int64 v87; // rax
/* line: 89 */   __int64 v88; // rdx
/* line: 90 */   __int64 v89; // rdx
/* line: 91 */   unsigned int v90; // eax
/* line: 92 */   int v91; // ecx
/* line: 93 */   char *v92; // r9
/* line: 94 */   __int64 v93; // r10
/* line: 95 */   unsigned int v94; // eax
/* line: 96 */   __int64 v95; // rdx
/* line: 97 */   unsigned int v96; // eax
/* line: 98 */   int v97; // ecx
/* line: 99 */   char *v98; // r9
/* line: 100 */   __int64 v99; // r10
/* line: 101 */   unsigned int v100; // eax
/* line: 102 */   __int64 v101; // rdx
/* line: 103 */   const char *v102; // rdx
/* line: 104 */   const wchar_t *v103; // rbx
/* line: 105 */   const wchar_t *v104; // rdi
/* line: 106 */   __int64 v105; // rdx
/* line: 107 */   __int64 v106; // rdi
/* line: 108 */   unsigned int v107; // esi
/* line: 109 */   __int64 v108; // r14
/* line: 110 */   __int64 v109; // rbx
/* line: 111 */   __int64 v110; // r15
/* line: 112 */   __int64 v111; // rax
/* line: 113 */   __int64 v112; // rcx
/* line: 114 */   __int64 v113; // rdx
/* line: 115 */   int v114; // eax
/* line: 116 */   __int64 v115; // r13
/* line: 117 */   unsigned int v116; // ebp
/* line: 118 */   __int64 v117; // r12
/* line: 119 */   __int64 v118; // r9
/* line: 120 */   __int64 v119; // [rsp+0h] [rbp-4A8h] BYREF
/* line: 121 */   __int64 **v120; // [rsp+30h] [rbp-478h]
/* line: 122 */   __int64 v121; // [rsp+38h] [rbp-470h]
/* line: 123 */   __int64 v122; // [rsp+40h] [rbp-468h]
/* line: 124 */   unsigned int v123; // [rsp+4Ch] [rbp-45Ch]
/* line: 125 */   __int64 v124; // [rsp+50h] [rbp-458h]
/* line: 126 */   __int64 v125; // [rsp+58h] [rbp-450h]
/* line: 127 */   const wchar_t *v126; // [rsp+60h] [rbp-448h] BYREF
/* line: 128 */   int v127; // [rsp+68h] [rbp-440h]
/* line: 129 */   _QWORD v128[2]; // [rsp+70h] [rbp-438h] BYREF
/* line: 130 */   const wchar_t *v129; // [rsp+80h] [rbp-428h] BYREF
/* line: 131 */   int v130; // [rsp+88h] [rbp-420h]
/* line: 132 */   __int128 v131; // [rsp+90h] [rbp-418h] BYREF
/* line: 133 */   __int128 v132; // [rsp+A0h] [rbp-408h] BYREF
/* line: 134 */   __int128 v133; // [rsp+B0h] [rbp-3F8h] BYREF
/* line: 135 */   __int128 v134; // [rsp+C0h] [rbp-3E8h] BYREF
/* line: 136 */   char *v135; // [rsp+D0h] [rbp-3D8h] BYREF
/* line: 137 */   signed int v136; // [rsp+D8h] [rbp-3D0h]
/* line: 138 */   int v137; // [rsp+DCh] [rbp-3CCh]
/* line: 139 */   void *v138; // [rsp+E0h] [rbp-3C8h] BYREF
/* line: 140 */   int v139; // [rsp+E8h] [rbp-3C0h]
/* line: 141 */   int v140; // [rsp+ECh] [rbp-3BCh]
/* line: 142 */   __int128 v141; // [rsp+F0h] [rbp-3B8h] BYREF
/* line: 143 */   __int128 v142; // [rsp+100h] [rbp-3A8h] BYREF
/* line: 144 */   unsigned int v143; // [rsp+11Ch] [rbp-38Ch] BYREF
/* line: 145 */   __int128 v144; // [rsp+120h] [rbp-388h] BYREF
/* line: 146 */   _OWORD v145[48]; // [rsp+130h] [rbp-378h] BYREF
/* line: 147 */   __int64 v146; // [rsp+438h] [rbp-70h]
/* line: 148 */ 
/* line: 149, address: 0x14361c253 */   v1 = a1;
/* line: 150, address: 0x14361c268 */   result = sub_1402AE7F0(a1);
/* line: 151, address: 0x14361c286 */   if ( ((*(_BYTE *)(v1 + 92) & 1) == 0 || *(char *)(v1 + 91) < 0) && *(_BYTE *)(v1 + 248) != 3 )
/* line: 152, address: 0x14361c286 */     goto LABEL_4;
/* line: 153, address: 0x14361c2d1 */   v144 = 0;
/* line: 154, address: 0x14361c2de */   (*(void (__fastcall **)(__int64, __int128 *))(*(_QWORD *)v1 + 2048LL))(v1, &v144);
/* line: 155, address: 0x14361c2ec */   if ( SDWORD2(v144) < 2LL )
/* line: 156, address: 0x14361c2ec */     goto LABEL_66;
/* line: 157, address: 0x14361c2f2 */   v121 = v1;
/* line: 158, address: 0x14361c312 */   memset(&v145[1], 0, 0x2F0u);
/* line: 159, address: 0x14361c317 */   *(_QWORD *)&v145[0] = v144;
/* line: 160, address: 0x14361c323 */   *((_QWORD *)&v145[0] + 1) = v144 + 8LL * SDWORD2(v144) - 8;
/* line: 161, address: 0x14361c32b */   v3 = logf((float)SDWORD2(v144));
/* line: 162, address: 0x14361c33a */   LODWORD(v145[1]) = (int)(float)(v3 + v3);
/* line: 163, address: 0x14361c33c */   v4 = (__int64 **)v145;
/* line: 164, address: 0x14361c5a3 */   do
/* line: 165 */   {
/* line: 166, address: 0x14361c34c */     v5 = *v4;
/* line: 167, address: 0x14361c350 */     v6 = v4[1];
/* line: 168, address: 0x14361c354 */     v120 = v4;
/* line: 169, address: 0x14361c359 */     v7 = *((_DWORD *)v4 + 4);
/* line: 170, address: 0x14361c363 */     v8 = (unsigned __int64)((char *)v6 - (char *)v5) >> 3;
/* line: 171, address: 0x14361c367 */     v9 = v8 + 1;
/* line: 172, address: 0x14361c36b */     LODWORD(v122) = v7;
/* line: 173, address: 0x14361c371 */     if ( v7 )
/* line: 174 */     {
/* line: 175, address: 0x14361c377 */       v10 = v5;
/* line: 176, address: 0x14361c37a */       v11 = v6;
/* line: 177, address: 0x14361c381 */       while ( v9 > 8 )
/* line: 178 */       {
/* line: 179, address: 0x14361c387 */         v12 = (unsigned int)v9 >> 1;
/* line: 180, address: 0x14361c38a */         v13 = v5[v12];
/* line: 181, address: 0x14361c391 */         v5[v12] = *v5;
/* line: 182, address: 0x14361c395 */         *v5 = v13;
/* line: 183, address: 0x14361c398 */         v14 = v6 + 1;
/* line: 184, address: 0x14361c39d */         v15 = v5;
/* line: 185, address: 0x14361c3a4 */         while ( 1 )
/* line: 186 */         {
/* line: 187, address: 0x14361c3a4 */           v16 = v15 + 1;
/* line: 188, address: 0x14361c3a7 */           v17 = v15 + 1;
/* line: 189, address: 0x14361c3d1 */           do
/* line: 190 */           {
/* line: 191, address: 0x14361c3aa */             v15 = v17;
/* line: 192, address: 0x14361c3ad */             v18 = v16;
/* line: 193, address: 0x14361c3b3 */             if ( v17 > v6 )
/* line: 194, address: 0x14361c3b3 */               break;
/* line: 195, address: 0x14361c3ba */             v19 = sub_140503B80(*v17, 0);
/* line: 196, address: 0x14361c3c1 */             v20 = COERCE_FLOAT(sub_1413F02F0(v19));
/* line: 197, address: 0x14361c3c6 */             v17 = v15 + 1;
/* line: 198, address: 0x14361c3ca */             v16 = v18 + 1;
/* line: 199 */           }
/* line: 200, address: 0x14361c3d1 */           while ( v20 >= 0.5 );
/* line: 201, address: 0x14361c3d3 */           v21 = v14 - 1;
/* line: 202, address: 0x14361c3db */           v22 = v14 - 2;
/* line: 203, address: 0x14361c405 */           do
/* line: 204 */           {
/* line: 205, address: 0x14361c3de */             v14 = v21;
/* line: 206, address: 0x14361c3e1 */             v23 = v22;
/* line: 207, address: 0x14361c3e7 */             if ( v21 <= v5 )
/* line: 208, address: 0x14361c3e7 */               break;
/* line: 209, address: 0x14361c3ee */             v24 = sub_140503B80(*v5, 0);
/* line: 210, address: 0x14361c3f5 */             v25 = COERCE_FLOAT(sub_1413F02F0(v24));
/* line: 211, address: 0x14361c3fa */             v21 = v14 - 1;
/* line: 212, address: 0x14361c3fe */             v22 = v23 - 1;
/* line: 213 */           }
/* line: 214, address: 0x14361c405 */           while ( v25 >= 0.5 );
/* line: 215, address: 0x14361c407 */           v26 = *v14;
/* line: 216, address: 0x14361c40e */           if ( v15 > v14 )
/* line: 217, address: 0x14361c40e */             break;
/* line: 218, address: 0x14361c410 */           v27 = *v15;
/* line: 219, address: 0x14361c413 */           *v15 = v26;
/* line: 220, address: 0x14361c416 */           *v14 = v27;
/* line: 221 */         }
/* line: 222, address: 0x14361c41c */         v28 = *v5;
/* line: 223, address: 0x14361c41f */         *v5 = v26;
/* line: 224, address: 0x14361c422 */         *v14 = v28;
/* line: 225, address: 0x14361c426 */         LODWORD(v122) = v122 - 1;
/* line: 226, address: 0x14361c42a */         v29 = v14 - 1;
/* line: 227, address: 0x14361c43a */         if ( (char *)v23 - (char *)v10 >= (char *)v11 - (char *)v18 )
/* line: 228 */         {
/* line: 229, address: 0x14361c47c */           if ( v5 + 1 >= v14 )
/* line: 230 */           {
/* line: 231, address: 0x14361c499 */             v32 = v120;
/* line: 232 */           }
/* line: 233 */           else
/* line: 234 */           {
/* line: 235, address: 0x14361c47e */             v31 = v120;
/* line: 236, address: 0x14361c483 */             *v120 = v5;
/* line: 237, address: 0x14361c487 */             v31[1] = v29;
/* line: 238, address: 0x14361c48f */             *((_DWORD *)v31 + 4) = v122;
/* line: 239, address: 0x14361c493 */             v32 = v31 + 3;
/* line: 240 */           }
/* line: 241, address: 0x14361c4a1 */           if ( v6 <= v15 )
/* line: 242, address: 0x14361c4a1 */             goto LABEL_46;
/* line: 243, address: 0x14361c4a7 */           v120 = v32;
/* line: 244, address: 0x14361c4ac */           v23 = v6;
/* line: 245, address: 0x14361c4af */           v5 = v15;
/* line: 246 */         }
/* line: 247 */         else
/* line: 248 */         {
/* line: 249, address: 0x14361c43f */           if ( v6 > v15 )
/* line: 250 */           {
/* line: 251, address: 0x14361c441 */             v30 = v120;
/* line: 252, address: 0x14361c446 */             *v120 = v15;
/* line: 253, address: 0x14361c449 */             v30[1] = v6;
/* line: 254, address: 0x14361c451 */             *((_DWORD *)v30 + 4) = v122;
/* line: 255, address: 0x14361c458 */             v120 = v30 + 3;
/* line: 256 */           }
/* line: 257, address: 0x14361c464 */           if ( v5 + 1 >= v14 )
/* line: 258, address: 0x14361c464 */             goto LABEL_45;
/* line: 259, address: 0x14361c46a */           v18 = v5;
/* line: 260, address: 0x14361c46d */           v15 = v5;
/* line: 261, address: 0x14361c470 */           v6 = v14 - 1;
/* line: 262 */         }
/* line: 263, address: 0x14361c4b8 */         v8 = (unsigned __int64)((char *)v23 - (char *)v18) >> 3;
/* line: 264, address: 0x14361c4bc */         v9 = v8 + 1;
/* line: 265, address: 0x14361c4c0 */         v10 = v18;
/* line: 266, address: 0x14361c4c3 */         v11 = v23;
/* line: 267, address: 0x14361c4cb */         if ( !(_DWORD)v122 )
/* line: 268, address: 0x14361c4cb */           goto LABEL_33;
/* line: 269 */       }
/* line: 270, address: 0x14361c5b1 */       if ( v6 <= v5 )
/* line: 271 */       {
/* line: 272 */ LABEL_45:
/* line: 273, address: 0x14361c58f */         v32 = v120;
/* line: 274, address: 0x14361c58f */         goto LABEL_46;
/* line: 275 */       }
/* line: 276, address: 0x14361c5b7 */       v32 = v120;
/* line: 277, address: 0x14361c604 */       do
/* line: 278 */       {
/* line: 279, address: 0x14361c5bc */         v44 = v5;
/* line: 280, address: 0x14361c5c2 */         if ( v5 + 1 <= v6 )
/* line: 281 */         {
/* line: 282, address: 0x14361c5c4 */           v45 = v5 + 1;
/* line: 283, address: 0x14361c5c7 */           v44 = v5;
/* line: 284, address: 0x14361c5e9 */           do
/* line: 285 */           {
/* line: 286, address: 0x14361c5cf */             v46 = sub_140503B80(*v45, 0);
/* line: 287, address: 0x14361c5de */             if ( COERCE_FLOAT(sub_1413F02F0(v46)) < 0.5 )
/* line: 288, address: 0x14361c5de */               v44 = v45;
/* line: 289, address: 0x14361c5e2 */             ++v45;
/* line: 290 */           }
/* line: 291, address: 0x14361c5e9 */           while ( v45 <= v6 );
/* line: 292 */         }
/* line: 293, address: 0x14361c5eb */         v47 = *v44;
/* line: 294, address: 0x14361c5f2 */         *v44 = *v6;
/* line: 295, address: 0x14361c5f5 */         *v6-- = v47;
/* line: 296 */       }
/* line: 297, address: 0x14361c604 */       while ( v6 > v5 );
/* line: 298 */     }
/* line: 299 */     else
/* line: 300 */     {
/* line: 301, address: 0x14361c4d3 */       v15 = v5;
/* line: 302 */ LABEL_33:
/* line: 303, address: 0x14361c4db */       if ( (unsigned int)v8 <= 0x80000000 )
/* line: 304 */       {
/* line: 305, address: 0x14361c4ed */         v33 = (int)(v8 + ((unsigned int)(v8 - 1) >> 31) - 1) >> 1;
/* line: 306, address: 0x14361c56e */         do
/* line: 307 */         {
/* line: 308, address: 0x14361c4ef */           v34 = 2 * v33 + 1;
/* line: 309, address: 0x14361c4f9 */           if ( v34 < v9 )
/* line: 310 */           {
/* line: 311, address: 0x14361c4fb */             v35 = 2 * v33;
/* line: 312, address: 0x14361c4fe */             v36 = v33;
/* line: 313, address: 0x14361c565 */             do
/* line: 314 */             {
/* line: 315, address: 0x14361c500 */               v37 = v35 + 2;
/* line: 316, address: 0x14361c506 */               if ( v37 < v9 )
/* line: 317 */               {
/* line: 318, address: 0x14361c511 */                 v38 = sub_140503B80(v15[v34], 0);
/* line: 319, address: 0x14361c520 */                 if ( COERCE_FLOAT(sub_1413F02F0(v38)) >= 0.5 )
/* line: 320, address: 0x14361c522 */                   v34 = v37;
/* line: 321 */               }
/* line: 322, address: 0x14361c524 */               v39 = v34;
/* line: 323, address: 0x14361c530 */               v40 = sub_140503B80(v15[v34], 0);
/* line: 324, address: 0x14361c53f */               if ( COERCE_FLOAT(sub_1413F02F0(v40)) >= 0.5 )
/* line: 325, address: 0x14361c53f */                 break;
/* line: 326, address: 0x14361c544 */               v41 = v15[v36];
/* line: 327, address: 0x14361c54c */               v15[v36] = v15[v34];
/* line: 328, address: 0x14361c550 */               v15[v34] = v41;
/* line: 329, address: 0x14361c556 */               v35 = 2 * v34;
/* line: 330, address: 0x14361c558 */               v34 = 2 * v34 + 1;
/* line: 331, address: 0x14361c55f */               v36 = v39;
/* line: 332 */             }
/* line: 333, address: 0x14361c565 */             while ( v34 < v9 );
/* line: 334 */           }
/* line: 335, address: 0x14361c56a */           v42 = v33-- <= 0;
/* line: 336 */         }
/* line: 337, address: 0x14361c56e */         while ( !v42 );
/* line: 338 */       }
/* line: 339, address: 0x14361c578 */       if ( v9 < 2 )
/* line: 340, address: 0x14361c578 */         goto LABEL_45;
/* line: 341, address: 0x14361c57d */       v43 = *v15;
/* line: 342, address: 0x14361c585 */       *v15 = v15[(unsigned int)v9 - 1];
/* line: 343, address: 0x14361c588 */       v15[(unsigned int)v9 - 1] = v43;
/* line: 344, address: 0x14361c58d */       if ( v9 == 2 )
/* line: 345, address: 0x14361c58d */         goto LABEL_45;
/* line: 346, address: 0x14361c608 */       v48 = (unsigned int)v9 - 1LL;
/* line: 347, address: 0x14361c60b */       v32 = v120;
/* line: 348, address: 0x14361c6a4 */       do
/* line: 349 */       {
/* line: 350, address: 0x14361c610 */         v49 = 0;
/* line: 351, address: 0x14361c612 */         v50 = 1;
/* line: 352, address: 0x14361c617 */         v51 = 0;
/* line: 353, address: 0x14361c687 */         do
/* line: 354 */         {
/* line: 355, address: 0x14361c619 */           v52 = v49 + 2;
/* line: 356, address: 0x14361c622 */           if ( v48 > v52 )
/* line: 357 */           {
/* line: 358, address: 0x14361c62d */             v53 = sub_140503B80(v15[v50], 0);
/* line: 359, address: 0x14361c63c */             if ( COERCE_FLOAT(sub_1413F02F0(v53)) >= 0.5 )
/* line: 360, address: 0x14361c63e */               v50 = v52;
/* line: 361 */           }
/* line: 362, address: 0x14361c640 */           v54 = v50;
/* line: 363, address: 0x14361c64c */           v55 = sub_140503B80(v15[v50], 0);
/* line: 364, address: 0x14361c65b */           if ( COERCE_FLOAT(sub_1413F02F0(v55)) >= 0.5 )
/* line: 365, address: 0x14361c65b */             break;
/* line: 366, address: 0x14361c660 */           v56 = v15[v51];
/* line: 367, address: 0x14361c668 */           v15[v51] = v15[v50];
/* line: 368, address: 0x14361c66c */           v15[v50] = v56;
/* line: 369, address: 0x14361c673 */           v49 = 2 * v50;
/* line: 370, address: 0x14361c676 */           v50 = 2 * v50 + 1;
/* line: 371, address: 0x14361c681 */           v51 = v54;
/* line: 372 */         }
/* line: 373, address: 0x14361c687 */         while ( v48 > v50 );
/* line: 374, address: 0x14361c689 */         v57 = *v15;
/* line: 375, address: 0x14361c691 */         *v15 = v15[v48 - 1];
/* line: 376, address: 0x14361c694 */         v15[v48 - 1] = v57;
/* line: 377, address: 0x14361c69d */         v42 = (unsigned __int64)v48-- <= 2;
/* line: 378 */       }
/* line: 379, address: 0x14361c6a4 */       while ( !v42 );
/* line: 380 */     }
/* line: 381 */ LABEL_46:
/* line: 382, address: 0x14361c594 */     v4 = v32 - 3;
/* line: 383 */   }
/* line: 384, address: 0x14361c5a3 */   while ( v4 >= (__int64 **)v145 );
/* line: 385, address: 0x14361c6af */   v1 = v121;
/* line: 386 */ LABEL_66:
/* line: 387, address: 0x14361c6b4 */   v58 = sub_140503B80(v1, 0);
/* line: 388, address: 0x14361c6c0 */   v143 = v58;
/* line: 389, address: 0x14361c6c7 */   v59 = *(_DWORD *)(v1 + 6608);
/* line: 390, address: 0x14361c6d7 */   v145[0] = 0;
/* line: 391, address: 0x14361c6f1 */   v142 = 0;
/* line: 392, address: 0x14361c6f4 */   v60 = sub_1404FF400(v1 + 6848);
/* line: 393, address: 0x14361c708 */   sub_14361CE40(v59, v60, (__int64)v145, v58 + 924519, (__int64)&v142);
/* line: 394, address: 0x14361c723 */   v141 = 0;
/* line: 395, address: 0x14361c727 */   v61 = sub_1404FF400(v1 + 6648);
/* line: 396, address: 0x14361c73b */   result = sub_14361CE40(v59, v61, (__int64)&v141, v58 + 264069, (__int64)v145);
/* line: 397, address: 0x14361c740 */   v138 = nullptr;
/* line: 398, address: 0x14361c754 */   v65 = *(const void **)(v1 + 6616);
/* line: 399, address: 0x14361c75c */   v139 = *(_DWORD *)(v1 + 6624);
/* line: 400, address: 0x14361c74c */   v64 = v139;
/* line: 401, address: 0x14361c766 */   if ( v139 )
/* line: 402 */   {
/* line: 403, address: 0x14361c77c */     sub_14198C410(&v138, (unsigned int)v139, 0);
/* line: 404, address: 0x14361c78e */     result = (__int64)memcpy(v138, v65, 8 * v64);
/* line: 405 */   }
/* line: 406 */   else
/* line: 407 */   {
/* line: 408, address: 0x14361c84a */     v140 = 0;
/* line: 409 */   }
/* line: 410, address: 0x14361c793 */   v135 = nullptr;
/* line: 411, address: 0x14361c7a7 */   v67 = *(const void **)(v1 + 6632);
/* line: 412, address: 0x14361c7af */   v136 = *(_DWORD *)(v1 + 6640);
/* line: 413, address: 0x14361c79f */   v66 = v136;
/* line: 414, address: 0x14361c7b9 */   if ( v136 )
/* line: 415 */   {
/* line: 416, address: 0x14361c86a */     sub_1426367B0(&v135, (unsigned int)v136, 0);
/* line: 417, address: 0x14361c87c */     result = (__int64)memcpy(v135, v67, 8 * v66);
/* line: 418 */   }
/* line: 419 */   else
/* line: 420 */   {
/* line: 421, address: 0x14361c7bf */     v137 = 0;
/* line: 422 */   }
/* line: 423, address: 0x14361c7d3 */   if ( *(_BYTE *)(v1 + 7273) == 1 )
/* line: 424 */   {
/* line: 425, address: 0x14361c89c */     result = sub_14361CFA0(v1, (int *)&v144, (__int64)&v138, v58);
/* line: 426 */   }
/* line: 427, address: 0x14361c7e1 */   else if ( SDWORD2(v144) > 0 )
/* line: 428 */   {
/* line: 429, address: 0x14361c8b9 */     v134 = 0;
/* line: 430, address: 0x14361c8c4 */     v133 = 0;
/* line: 431, address: 0x14361c8d3 */     sub_1433CF240(&v133, &v144);
/* line: 432, address: 0x14361c8fb */     sub_1402C30C0(v1 + 1352, (__int64)&v133, *(unsigned int *)(v1 + 6608), (__int64)&v134, &v143);
/* line: 433, address: 0x14361c908 */     v132 = 0;
/* line: 434, address: 0x14361c90e */     sub_1402AF770((unsigned int *)(v1 + 6600), (__int64)&v132);
/* line: 435, address: 0x14361c913 */     v131 = 0;
/* line: 436, address: 0x14361c922 */     if ( DWORD2(v134) )
/* line: 437 */     {
/* line: 438, address: 0x14361c928 */       v68 = v134;
/* line: 439, address: 0x14361c938 */       v125 = v134 + 24LL * SDWORD2(v134);
/* line: 440, address: 0x14361c93d */       v121 = v1;
/* line: 441, address: 0x14361c94a */       v122 = v1 + 7256;
/* line: 442, address: 0x14361c95c */       v120 = (__int64 **)(v143 + 243551);
/* line: 443, address: 0x14361c967 */       v123 = v143 + 223551;
/* line: 444, address: 0x14361c96b */       v69 = v143;
/* line: 445, address: 0x14361c973 */       v124 = v143 + 951320;
/* line: 446, address: 0x14361c978 */       v70 = 0;
/* line: 447, address: 0x14361c97f */       while ( *(int *)(v68 + 16) <= 0 )
/* line: 448 */       {
/* line: 449 */ LABEL_116:
/* line: 450, address: 0x14361cc02 */         sub_141D249E0(&v131, v68);
/* line: 451, address: 0x14361cc12 */         v68 += 24;
/* line: 452, address: 0x14361cc1b */         if ( v68 == v125 )
/* line: 453 */         {
/* line: 454, address: 0x14361cc2c */           v1 = v121;
/* line: 455, address: 0x14361cc31 */           if ( DWORD2(v131) )
/* line: 456 */           {
/* line: 457, address: 0x14361cd64 */             v106 = v131;
/* line: 458, address: 0x14361cd6c */             v107 = v69 + 253526;
/* line: 459, address: 0x14361cd72 */             v108 = 8LL * SDWORD2(v131);
/* line: 460, address: 0x14361cd76 */             v109 = 0;
/* line: 461, address: 0x14361cdaa */             do
/* line: 462 */             {
/* line: 463, address: 0x14361cd78 */               v110 = *(_QWORD *)(v106 + v109);
/* line: 464, address: 0x14361cd7f */               if ( v110 )
/* line: 465 */               {
/* line: 466, address: 0x14361cd81 */                 v111 = sub_141DA2F50();
/* line: 467, address: 0x14361cd86 */                 v112 = *(_QWORD *)(v110 + 16);
/* line: 468, address: 0x14361cd8a */                 v113 = *(int *)(v111 + 56);
/* line: 469, address: 0x14361cdba */                 if ( (int)v113 <= *(_DWORD *)(v112 + 56)
/* line: 470 */                   && *(_QWORD *)(*(_QWORD *)(v112 + 48) + 8 * v113) == v111 + 48
/* line: 471 */                   && v139 > 0 )
/* line: 472 */                 {
/* line: 473, address: 0x14361cdbe */                   v114 = sub_1402D29E0(v107, v139);
/* line: 474, address: 0x14361cdca */                   if ( v139 > v114 )
/* line: 475 */                   {
/* line: 476, address: 0x14361cdd6 */                     v115 = *((_QWORD *)v138 + (unsigned int)v114);
/* line: 477, address: 0x14361cddf */                     v116 = v114;
/* line: 478, address: 0x14361cde6 */                     v117 = sub_14361D450(v122);
/* line: 479, address: 0x14361cdf6 */                     *(_QWORD *)(v117 + 64) = sub_14356C3C0(v121);
/* line: 480, address: 0x14361cdfb */                     *(_DWORD *)(v117 + 8) = -1;
/* line: 481, address: 0x14361ce04 */                     *(_QWORD *)(v117 + 16) = v115;
/* line: 482, address: 0x14361ce09 */                     *(_DWORD *)(v117 + 24) = 0;
/* line: 483, address: 0x14361ce12 */                     *(_QWORD *)(v117 + 32) = 0;
/* line: 484, address: 0x14361ce1b */                     v1 = v121;
/* line: 485, address: 0x14361ce30 */                     LOBYTE(v118) = 1;
/* line: 486, address: 0x14361ce33 */                     sub_1434BADB0(&v138, v116, 1, v118);
/* line: 487 */                   }
/* line: 488 */                 }
/* line: 489 */               }
/* line: 490, address: 0x14361cda1 */               ++v107;
/* line: 491, address: 0x14361cda3 */               v109 += 8;
/* line: 492 */             }
/* line: 493, address: 0x14361cdaa */             while ( v108 != v109 );
/* line: 494 */           }
/* line: 495, address: 0x14361cdaa */           goto LABEL_118;
/* line: 496 */         }
/* line: 497 */       }
/* line: 498, address: 0x14361c985 */       v71 = 0;
/* line: 499, address: 0x14361c98c */       while ( 1 )
/* line: 500 */       {
/* line: 501, address: 0x14361c98c */         v72 = (_QWORD *)sub_14361D450(v122);
/* line: 502, address: 0x14361c991 */         v73 = DWORD2(v132);
/* line: 503, address: 0x14361c99c */         if ( SDWORD2(v132) <= 0 )
/* line: 504, address: 0x14361c99c */           break;
/* line: 505, address: 0x14361c9a2 */         v74 = v72;
/* line: 506, address: 0x14361c9a5 */         v75 = v132;
/* line: 507, address: 0x14361c9b0 */         *v72 = *(_QWORD *)v132;
/* line: 508, address: 0x14361c9b4 */         v76 = 1;
/* line: 509, address: 0x14361c9bd */         if ( v73 != 1 )
/* line: 510 */         {
/* line: 511, address: 0x14361c9ca */           memmove((void *)v75, (const void *)(v75 + 8), 8LL * (unsigned int)(v73 - 1));
/* line: 512, address: 0x14361c9cf */           v76 = DWORD2(v132);
/* line: 513 */         }
/* line: 514, address: 0x14361c9d8 */         DWORD2(v132) = v76 - 1;
/* line: 515, address: 0x14361c9e7 */         sub_140474270(&v132);
/* line: 516, address: 0x14361c9ec */         *((_DWORD *)v74 + 2) = v70;
/* line: 517, address: 0x14361ca08 */         v79 = sub_1402D29E0((int)v120 + v71 + v70, *(_WORD *)(v68 + 8));
/* line: 518, address: 0x14361ca11 */         v80 = *(_QWORD *)(*(_QWORD *)v68 + 8LL * v79);
/* line: 519, address: 0x14361ca18 */         if ( !v80 )
/* line: 520, address: 0x14361ca18 */           goto LABEL_130;
/* line: 521, address: 0x14361ca1e */         v81 = sub_141DA2F50();
/* line: 522, address: 0x14361ca23 */         v83 = *(_QWORD *)(v80 + 16);
/* line: 523, address: 0x14361ca27 */         v77 = *(int *)(v81 + 56);
/* line: 524, address: 0x14361ca40 */         if ( (int)v77 > *(_DWORD *)(v83 + 56) || *(_QWORD *)(*(_QWORD *)(v83 + 48) + 8 * v77) != v81 + 48 )
/* line: 525, address: 0x14361ca40 */           goto LABEL_130;
/* line: 526, address: 0x14361ca52 */         LOBYTE(v82) = 1;
/* line: 527, address: 0x14361ca55 */         sub_1402B28C0(v68, v79, 1, v82);
/* line: 528, address: 0x14361ca67 */         v74[8] = sub_14356C3C0(v121);
/* line: 529, address: 0x14361ca7c */         v84 = sub_1402D29E0(v123 + v71 + v70, v139);
/* line: 530, address: 0x14361ca88 */         if ( v139 > v84 )
/* line: 531 */         {
/* line: 532, address: 0x14361ca8e */           v86 = v84;
/* line: 533, address: 0x14361ca9c */           v87 = *((_QWORD *)v138 + (unsigned int)v84);
/* line: 534, address: 0x14361caa0 */           v74[2] = v87;
/* line: 535, address: 0x14361caa5 */           v74[5] = v87;
/* line: 536, address: 0x14361cab5 */           if ( DWORD2(v145[0]) )
/* line: 537 */           {
/* line: 538, address: 0x14361cac3 */             v88 = 0;
/* line: 539, address: 0x14361cac8 */             while ( *(_DWORD *)(*(_QWORD *)&v145[0] + v88) != v71 )
/* line: 540 */             {
/* line: 541, address: 0x14361cace */               v88 += 4;
/* line: 542, address: 0x14361cad5 */               if ( 4LL * SDWORD2(v145[0]) == v88 )
/* line: 543, address: 0x14361cad5 */                 goto LABEL_100;
/* line: 544 */             }
/* line: 545, address: 0x14361cbb3 */             v96 = sub_1402D29E0(v69 + v71 + 850321, v136);
/* line: 546, address: 0x14361cbb8 */             v97 = v136;
/* line: 547, address: 0x14361cbc1 */             if ( v136 <= (int)v96 )
/* line: 548 */             {
/* line: 549 */ LABEL_119:
/* line: 550, address: 0x14361cc4c */               v102 = "N";
/* line: 551, address: 0x14361cc4c */               goto LABEL_120;
/* line: 552 */             }
/* line: 553, address: 0x14361cbc7 */             v98 = v135;
/* line: 554, address: 0x14361cbcf */             v99 = v96;
/* line: 555, address: 0x14361cbd6 */             v74[7] = *(_QWORD *)&v135[8 * v96];
/* line: 556, address: 0x14361cbdb */             v100 = v96 + 1;
/* line: 557, address: 0x14361cbdf */             v101 = v97 - v100;
/* line: 558, address: 0x14361cbe1 */             if ( v97 != v100 )
/* line: 559 */             {
/* line: 560, address: 0x14361cd47 */               memmove(&v98[8 * v99], &v98[8 * v100], 8LL * (int)v101);
/* line: 561, address: 0x14361cd4c */               v97 = v136;
/* line: 562 */             }
/* line: 563, address: 0x14361cbe9 */             v136 = v97 - 1;
/* line: 564, address: 0x14361cbf8 */             sub_142616B80(&v135, v101);
/* line: 565 */           }
/* line: 566 */ LABEL_100:
/* line: 567, address: 0x14361cae2 */           if ( DWORD2(v141) )
/* line: 568 */           {
/* line: 569, address: 0x14361caf4 */             v89 = 0;
/* line: 570, address: 0x14361caf9 */             while ( *(_DWORD *)(v141 + v89) != v71 )
/* line: 571 */             {
/* line: 572, address: 0x14361cafb */               v89 += 4;
/* line: 573, address: 0x14361cb02 */               if ( 4LL * SDWORD2(v141) == v89 )
/* line: 574, address: 0x14361cb02 */                 goto LABEL_109;
/* line: 575 */             }
/* line: 576, address: 0x14361cb16 */             v90 = sub_1402D29E0((int)v124 + v71, v136);
/* line: 577, address: 0x14361cb1b */             v91 = v136;
/* line: 578, address: 0x14361cb24 */             if ( v136 <= (int)v90 )
/* line: 579, address: 0x14361cb24 */               goto LABEL_119;
/* line: 580, address: 0x14361cb2a */             v92 = v135;
/* line: 581, address: 0x14361cb32 */             v93 = v90;
/* line: 582, address: 0x14361cb39 */             v74[4] = *(_QWORD *)&v135[8 * v90];
/* line: 583, address: 0x14361cb3e */             v94 = v90 + 1;
/* line: 584, address: 0x14361cb42 */             v95 = v91 - v94;
/* line: 585, address: 0x14361cb44 */             if ( v91 != v94 )
/* line: 586 */             {
/* line: 587, address: 0x14361cb57 */               memmove(&v92[8 * v93], &v92[8 * v94], 8LL * (int)v95);
/* line: 588, address: 0x14361cb5c */               v91 = v136;
/* line: 589 */             }
/* line: 590, address: 0x14361cb65 */             v136 = v91 - 1;
/* line: 591, address: 0x14361cb74 */             sub_142616B80(&v135, v95);
/* line: 592 */           }
/* line: 593 */ LABEL_109:
/* line: 594, address: 0x14361cb79 */           LOBYTE(v85) = 1;
/* line: 595, address: 0x14361cb8d */           sub_1434BADB0(&v138, v86, 1, v85);
/* line: 596 */         }
/* line: 597, address: 0x14361cb92 */         ++v70;
/* line: 598, address: 0x14361cb9a */         if ( ++v71 >= *(_DWORD *)(v68 + 16) )
/* line: 599, address: 0x14361cb9a */           goto LABEL_116;
/* line: 600 */       }
/* line: 601, address: 0x14361cd58 */       v102 = "O";
/* line: 602 */ LABEL_120:
/* line: 603, address: 0x14361cc53 */       sub_1419EE700(&v129, v102);
/* line: 604, address: 0x14361cc67 */       v103 = &FileName;
/* line: 605, address: 0x14361cc6e */       v104 = &FileName;
/* line: 606, address: 0x14361cc71 */       if ( v130 )
/* line: 607, address: 0x14361cc73 */         v104 = v129;
/* line: 608, address: 0x14361cc8b */       sub_1404BF640(&v126, v121, 0);
/* line: 609, address: 0x14361cc95 */       if ( v127 )
/* line: 610, address: 0x14361cc97 */         v103 = v126;
/* line: 611, address: 0x14361ccb1 */       sub_1419EE700(v128, L"[%s] %s", v103, v104);
/* line: 612, address: 0x14361ccb9 */       LOBYTE(v105) = 1;
/* line: 613, address: 0x14361ccbb */       sub_142681C10(v128, v105);
/* line: 614, address: 0x14361ccc6 */       if ( v128[0] )
/* line: 615, address: 0x14361ccc8 */         sub_141977980(v128[0], v77, v78);
/* line: 616, address: 0x14361ccd5 */       if ( v126 )
/* line: 617, address: 0x14361ccd7 */         sub_141977980(v126, v77, v78);
/* line: 618, address: 0x14361cce7 */       if ( v129 )
/* line: 619, address: 0x14361cce9 */         sub_141977980(v129, v77, v78);
/* line: 620 */     }
/* line: 621 */     else
/* line: 622 */     {
/* line: 623 */ LABEL_118:
/* line: 624, address: 0x14361cc37 */       sub_14361D4C0(v1);
/* line: 625, address: 0x14361cc42 */       sub_1400B8CC0(v1);
/* line: 626 */     }
/* line: 627 */ LABEL_130:
/* line: 628, address: 0x14361ccf9 */     if ( (_QWORD)v131 )
/* line: 629, address: 0x14361ccfb */       sub_141977980(v131, v77, v78);
/* line: 630, address: 0x14361cd0b */     if ( (_QWORD)v132 )
/* line: 631, address: 0x14361cd0d */       sub_141977980(v132, v77, v78);
/* line: 632, address: 0x14361cd1d */     if ( (_QWORD)v133 )
/* line: 633, address: 0x14361cd1f */       sub_141977980(v133, v77, v78);
/* line: 634, address: 0x14361cd2c */     result = sub_142B79430(&v134);
/* line: 635 */   }
/* line: 636, address: 0x14361c7f2 */   if ( v135 )
/* line: 637, address: 0x14361c7f4 */     result = sub_141977980(v135, v62, v63);
/* line: 638, address: 0x14361c804 */   if ( v138 )
/* line: 639, address: 0x14361c806 */     result = sub_141977980(v138, v62, v63);
/* line: 640, address: 0x14361c816 */   if ( (_QWORD)v141 )
/* line: 641, address: 0x14361c818 */     result = sub_141977980(v141, v62, v63);
/* line: 642, address: 0x14361c828 */   if ( *(_QWORD *)&v145[0] )
/* line: 643, address: 0x14361c82a */     result = sub_141977980(*(_QWORD *)&v145[0], v62, v63);
/* line: 644, address: 0x14361c83a */   if ( (_QWORD)v144 )
/* line: 645, address: 0x14361c840 */     result = sub_141977980(v144, v62, v63);
/* line: 646 */ LABEL_4:
/* line: 647, address: 0x14361c29a */   if ( ((unsigned __int64)&v119 ^ v146) != _security_cookie )
/* line: 648, address: 0x14361c2c5 */     __debugbreak();
/* line: 649, address: 0x14361c29c */   return result;
/* line: 650 */ }