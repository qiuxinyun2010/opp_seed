/* line: 0, address: 0x1402c30c0 */ __int64 __fastcall sub_1402C30C0(__int64 a1, __int64 a2, __int64 a3, __int64 a4, _DWORD *a5)
/* line: 1 */ {
/* line: 2 */   __int64 v5; // r14
/* line: 3 */   int v6; // ebp
/* line: 4 */   int v7; // esi
/* line: 5 */   __int64 v8; // rsi
/* line: 6 */   float v9; // xmm6_4
/* line: 7 */   _QWORD *v10; // rsi
/* line: 8 */   int v11; // edi
/* line: 9 */   _QWORD *v12; // r14
/* line: 10 */   __int64 v13; // rax
/* line: 11 */   __int64 v14; // rax
/* line: 12 */   __int64 v15; // rbx
/* line: 13 */   __int64 v16; // rax
/* line: 14 */   __int64 v17; // rax
/* line: 15 */   __int64 v18; // rcx
/* line: 16 */   __int64 v19; // rax
/* line: 17 */   __int64 v20; // rdx
/* line: 18 */   __int64 v21; // rcx
/* line: 19 */   __int64 v22; // rbx
/* line: 20 */   int v23; // r12d
/* line: 21 */   int v24; // ecx
/* line: 22 */   char *v25; // rax
/* line: 23 */   int v26; // edx
/* line: 24 */   _DWORD *v27; // r13
/* line: 25 */   __int64 v28; // r13
/* line: 26 */   __int64 v29; // rbx
/* line: 27 */   __int64 v30; // rbx
/* line: 28 */   __int64 v31; // r15
/* line: 29 */   __int64 v32; // rax
/* line: 30 */   __int64 v33; // rcx
/* line: 31 */   __int64 v34; // rcx
/* line: 32 */   __int64 v35; // r8
/* line: 33 */   __int64 v36; // r9
/* line: 34 */   __int64 v37; // r10
/* line: 35 */   __int64 v38; // r9
/* line: 36 */   const wchar_t *v39; // r8
/* line: 37 */   __int64 v40; // rdx
/* line: 38 */   __int64 v41; // r8
/* line: 39 */   __int64 v42; // rdx
/* line: 40 */   int v43; // r13d
/* line: 41 */   int v44; // eax
/* line: 42 */   int v45; // eax
/* line: 43 */   int v46; // ecx
/* line: 44 */   __int64 v47; // rax
/* line: 45 */   _BYTE *v48; // rdx
/* line: 46 */   _BYTE *v49; // rcx
/* line: 47 */   __int128 *v50; // r13
/* line: 48 */   int v51; // eax
/* line: 49 */   char *v52; // rcx
/* line: 50 */   int v53; // r15d
/* line: 51 */   __int64 v54; // rbp
/* line: 52 */   int v55; // r15d
/* line: 53 */   unsigned __int64 v56; // rcx
/* line: 54 */   int v57; // ecx
/* line: 55 */   int v58; // ecx
/* line: 56 */   char *v59; // rax
/* line: 57 */   char *v60; // rax
/* line: 58 */   __int64 v61; // rax
/* line: 59 */   __int64 v62; // rcx
/* line: 60 */   int i; // eax
/* line: 61 */   char *v64; // rcx
/* line: 62 */   int *v65; // rdx
/* line: 63 */   int v66; // r10d
/* line: 64 */   __int64 v67; // rax
/* line: 65 */   int v68; // ecx
/* line: 66 */   __int64 v69; // rdx
/* line: 67 */   unsigned __int64 v70; // r9
/* line: 68 */   int v71; // r10d
/* line: 69 */   __int64 v72; // r11
/* line: 70 */   int v73; // r8d
/* line: 71 */   __int64 v74; // r10
/* line: 72 */   unsigned __int64 v75; // r13
/* line: 73 */   char *v76; // r15
/* line: 74 */   char *v77; // r10
/* line: 75 */   unsigned int v78; // edx
/* line: 76 */   int v79; // r10d
/* line: 77 */   unsigned __int64 v80; // r11
/* line: 78 */   int v81; // edx
/* line: 79 */   int v82; // edx
/* line: 80 */   bool v83; // cc
/* line: 81 */   __int64 v84; // rdx
/* line: 82 */   __int64 v85; // r11
/* line: 83 */   int v86; // r9d
/* line: 84 */   int v87; // eax
/* line: 85 */   unsigned int v88; // ecx
/* line: 86 */   int v89; // eax
/* line: 87 */   _BYTE *v90; // rdx
/* line: 88 */   __int64 j; // rdx
/* line: 89 */   unsigned int *v92; // rcx
/* line: 90 */   __int64 v93; // r10
/* line: 91 */   int v94; // r11d
/* line: 92 */   __int64 v95; // r12
/* line: 93 */   unsigned __int64 v96; // rcx
/* line: 94 */   int v97; // r14d
/* line: 95 */   int v98; // r13d
/* line: 96 */   __int64 v99; // rsi
/* line: 97 */   __int64 v100; // rbx
/* line: 98 */   __int64 v101; // rsi
/* line: 99 */   __int64 v102; // rbp
/* line: 100 */   __int64 v103; // r14
/* line: 101 */   const void *v104; // r15
/* line: 102 */   int v105; // ecx
/* line: 103 */   unsigned __int64 v106; // rcx
/* line: 104 */   int v107; // ecx
/* line: 105 */   int v108; // ecx
/* line: 106 */   bool v109; // cc
/* line: 107 */   int v110; // edx
/* line: 108 */   __int64 v111; // rdx
/* line: 109 */   __int64 v112; // rdx
/* line: 110 */   __int64 v113; // r8
/* line: 111 */   void **v114; // rax
/* line: 112 */   const void **v115; // rcx
/* line: 113 */   __int64 v116; // rsi
/* line: 114 */   const void *v117; // rdi
/* line: 115 */   void **v118; // rbx
/* line: 116 */   __int64 v119; // rbx
/* line: 117 */   unsigned int v120; // edx
/* line: 118 */   unsigned int v121; // ecx
/* line: 119 */   unsigned __int64 v122; // rax
/* line: 120 */   int v123; // ecx
/* line: 121 */   int v124; // eax
/* line: 122 */   __int64 v125; // r8
/* line: 123 */   __int64 v126; // rax
/* line: 124 */   __int64 (__fastcall ***v127)(_QWORD); // rax
/* line: 125 */   __int64 v128; // rcx
/* line: 126 */   __int128 v129; // xmm0
/* line: 127 */   _QWORD *v130; // rdi
/* line: 128 */   int v131; // ebp
/* line: 129 */   __int64 v132; // r14
/* line: 130 */   unsigned __int64 v133; // rdx
/* line: 131 */   __int64 v134; // rcx
/* line: 132 */   unsigned int v135; // ebx
/* line: 133 */   unsigned __int64 v136; // rdx
/* line: 134 */   unsigned __int64 v137; // rax
/* line: 135 */   __int64 v138; // rsi
/* line: 136 */   __int64 v139; // r15
/* line: 137 */   _QWORD *v140; // rcx
/* line: 138 */   _QWORD *v141; // r14
/* line: 139 */   __int64 v142; // r15
/* line: 140 */   __int64 v143; // r12
/* line: 141 */   const void *v144; // r13
/* line: 142 */   int v145; // ebx
/* line: 143 */   int v146; // eax
/* line: 144 */   __int64 v147; // rcx
/* line: 145 */   unsigned int v148; // r10d
/* line: 146 */   int v149; // esi
/* line: 147 */   __int64 v150; // rcx
/* line: 148 */   float v151; // xmm4_4
/* line: 149 */   int v152; // eax
/* line: 150 */   __int64 v153; // rcx
/* line: 151 */   __int64 v154; // rax
/* line: 152 */   __int64 v155; // rsi
/* line: 153 */   _QWORD *v156; // rdi
/* line: 154 */   int v157; // eax
/* line: 155 */   unsigned int *v158; // rcx
/* line: 156 */   __int64 v159; // rdi
/* line: 157 */   int v160; // ebx
/* line: 158 */   __int64 v161; // r14
/* line: 159 */   unsigned __int64 v162; // rdx
/* line: 160 */   int v163; // ecx
/* line: 161 */   int v164; // ebp
/* line: 162 */   __int64 v165; // rcx
/* line: 163 */   int v166; // ecx
/* line: 164 */   unsigned __int64 v167; // rdx
/* line: 165 */   int v168; // ecx
/* line: 166 */   int v169; // ecx
/* line: 167 */   bool v170; // cc
/* line: 168 */   __int64 v171; // r9
/* line: 169 */   int v172; // edx
/* line: 170 */   __int64 result; // rax
/* line: 171 */   __int64 v174; // rdx
/* line: 172 */   __int64 v175; // [rsp+0h] [rbp-1A8h] BYREF
/* line: 173 */   int v176; // [rsp+20h] [rbp-188h]
/* line: 174 */   __int64 v177; // [rsp+28h] [rbp-180h]
/* line: 175 */   __int64 v178; // [rsp+30h] [rbp-178h]
/* line: 176 */   __int64 v179; // [rsp+80h] [rbp-128h]
/* line: 177 */   __int64 v180; // [rsp+88h] [rbp-120h]
/* line: 178 */   __int64 v181; // [rsp+90h] [rbp-118h]
/* line: 179 */   __int64 v182; // [rsp+98h] [rbp-110h]
/* line: 180 */   __int64 v183; // [rsp+A0h] [rbp-108h]
/* line: 181 */   __int64 v184; // [rsp+A8h] [rbp-100h]
/* line: 182 */   const wchar_t *v185; // [rsp+B0h] [rbp-F8h] BYREF
/* line: 183 */   int v186; // [rsp+B8h] [rbp-F0h]
/* line: 184 */   __int128 v187; // [rsp+C0h] [rbp-E8h] BYREF
/* line: 185 */   __int128 v188; // [rsp+D0h] [rbp-D8h] BYREF
/* line: 186 */   _BYTE v189[16]; // [rsp+E0h] [rbp-C8h] BYREF
/* line: 187 */   _BYTE *v190; // [rsp+F0h] [rbp-B8h]
/* line: 188 */   int v191; // [rsp+F8h] [rbp-B0h]
/* line: 189 */   _BYTE v192[12]; // [rsp+FCh] [rbp-ACh]
/* line: 190 */   char v193; // [rsp+108h] [rbp-A0h] BYREF
/* line: 191 */   char v194[8]; // [rsp+110h] [rbp-98h]
/* line: 192 */   int v195; // [rsp+118h] [rbp-90h]
/* line: 193 */   __int64 v196; // [rsp+128h] [rbp-80h]
/* line: 194 */ 
/* line: 195, address: 0x1402c30ec */   v5 = a4;
/* line: 196, address: 0x1402c30ef */   v6 = a3;
/* line: 197, address: 0x1402c30f2 */   v184 = a2;
/* line: 198, address: 0x1402c30fa */   v183 = a1;
/* line: 199, address: 0x1402c3114 */   v7 = *(_DWORD *)(a4 + 8);
/* line: 200, address: 0x1402c311a */   v180 = a4;
/* line: 201, address: 0x1402c3122 */   v179 = (unsigned int)a3;
/* line: 202, address: 0x1402c312a */   if ( v7 )
/* line: 203 */   {
/* line: 204, address: 0x1402c406d */     v130 = *(_QWORD **)a4;
/* line: 205, address: 0x1402c4070 */     v5 = v180;
/* line: 206, address: 0x1402c4078 */     v6 = v179;
/* line: 207, address: 0x1402c4093 */     do
/* line: 208 */     {
/* line: 209, address: 0x1402c4080 */       if ( *v130 )
/* line: 210, address: 0x1402c4088 */         sub_141977980(*v130, a2, a3);
/* line: 211, address: 0x1402c408d */       v130 += 3;
/* line: 212, address: 0x1402c4091 */       --v7;
/* line: 213 */     }
/* line: 214, address: 0x1402c4093 */     while ( v7 );
/* line: 215 */   }
/* line: 216, address: 0x1402c3130 */   *(_DWORD *)(v5 + 8) = 0;
/* line: 217, address: 0x1402c3138 */   if ( *(_DWORD *)(v5 + 12) )
/* line: 218, address: 0x1402c3144 */     sub_1400A8630(v5, 0);
/* line: 219, address: 0x1402c314b */   v190 = nullptr;
/* line: 220, address: 0x1402c3153 */   v191 = 0;
/* line: 221, address: 0x1402c315d */   v188 = 0;
/* line: 222, address: 0x1402c316f */   *(_QWORD *)v192 = 0xFFFFFFFF00000080uLL;
/* line: 223, address: 0x1402c3177 */   *(_DWORD *)&v192[8] = 0;
/* line: 224, address: 0x1402c317e */   *(_QWORD *)v194 = 0;
/* line: 225, address: 0x1402c3186 */   v195 = 0;
/* line: 226, address: 0x1402c318d */   v8 = v184;
/* line: 227, address: 0x1402c319c */   if ( !*(_DWORD *)(v184 + 8) )
/* line: 228, address: 0x1402c319c */     goto LABEL_183;
/* line: 229, address: 0x1402c31a5 */   v9 = (float)v6;
/* line: 230, address: 0x1402c31a9 */   v10 = *(_QWORD **)v184;
/* line: 231, address: 0x1402c31b0 */   v182 = *(_QWORD *)v184 + 8LL * *(int *)(v184 + 8);
/* line: 232, address: 0x1402c31b8 */   v11 = 0;
/* line: 233, address: 0x1402c332e */   do
/* line: 234 */   {
/* line: 235, address: 0x1402c31ba */     v12 = (_QWORD *)*v10;
/* line: 236, address: 0x1402c31cc */     if ( *(_BYTE *)(v183 + 1001) == 1 )
/* line: 237 */     {
/* line: 238, address: 0x1402c31d5 */       v13 = sub_1402A53F0(*v10);
/* line: 239, address: 0x1402c31dd */       if ( !v13 )
/* line: 240, address: 0x1402c31dd */         goto LABEL_48;
/* line: 241, address: 0x1402c31ed */       if ( !qword_146E7FC60 )
/* line: 242 */       {
/* line: 243, address: 0x1402c3e13 */         v119 = v13;
/* line: 244, address: 0x1402c3e16 */         sub_14035AFB0(
/* line: 245 */           (unsigned int)"/",
/* line: 246 */           (unsigned int)L"RBRoomAssociationComponent",
/* line: 247 */           (unsigned int)&qword_146E7FC60,
/* line: 248 */           (unsigned int)sub_142A28E40,
/* line: 249 */           576,
/* line: 250 */           16,
/* line: 251 */           0x10000000,
/* line: 252 */           0,
/* line: 253 */           (__int64)L"Engine",
/* line: 254 */           (__int64)sub_140021A80,
/* line: 255 */           (__int64)sub_142629270,
/* line: 256 */           (__int64)nullsub_2,
/* line: 257 */           (__int64)sub_14132A3D0,
/* line: 258 */           (__int64)sub_14035B3C0,
/* line: 259 */           0,
/* line: 260 */           0);
/* line: 261, address: 0x1402c3e1b */         v13 = v119;
/* line: 262 */       }
/* line: 263, address: 0x1402c31f9 */       v14 = (*(__int64 (__fastcall **)(__int64))(*(_QWORD *)v13 + 1584LL))(v13);
/* line: 264, address: 0x1402c3203 */       if ( !v14 )
/* line: 265, address: 0x1402c3203 */         goto LABEL_48;
/* line: 266, address: 0x1402c3209 */       v15 = v14;
/* line: 267, address: 0x1402c320c */       v16 = *(_QWORD *)(v14 + 536);
/* line: 268, address: 0x1402c3216 */       if ( !v16 )
/* line: 269, address: 0x1402c3216 */         goto LABEL_48;
/* line: 270, address: 0x1402c321c */       if ( !*(_QWORD *)(v16 + 1152) )
/* line: 271, address: 0x1402c321c */         goto LABEL_48;
/* line: 272, address: 0x1402c322a */       v17 = sub_141CB2D20();
/* line: 273, address: 0x1402c3232 */       if ( !v17 )
/* line: 274, address: 0x1402c3232 */         goto LABEL_48;
/* line: 275, address: 0x1402c3238 */       v18 = *(int *)(v17 + 1032);
/* line: 276, address: 0x1402c3238 */       if ( !*(_DWORD *)(v17 + 1032) )
/* line: 277, address: 0x1402c3238 */         goto LABEL_48;
/* line: 278, address: 0x1402c3248 */       v19 = *(_QWORD *)(v17 + 1024);
/* line: 279, address: 0x1402c3256 */       v20 = *(_QWORD *)(*(_QWORD *)(v15 + 536) + 1152LL);
/* line: 280, address: 0x1402c325d */       v21 = 8 * v18;
/* line: 281, address: 0x1402c3261 */       v22 = 0;
/* line: 282, address: 0x1402c3267 */       while ( *(_QWORD *)(v19 + 8 * v22) != v20 )
/* line: 283 */       {
/* line: 284, address: 0x1402c3269 */         ++v22;
/* line: 285, address: 0x1402c326c */         v21 -= 8;
/* line: 286, address: 0x1402c3270 */         if ( !v21 )
/* line: 287, address: 0x1402c3270 */           goto LABEL_48;
/* line: 288 */       }
/* line: 289, address: 0x1402c327a */       if ( (_DWORD)v22 == -1 )
/* line: 290 */       {
/* line: 291 */ LABEL_48:
/* line: 292, address: 0x1402c33c8 */         sub_1404BF640(&v185, v12, 0);
/* line: 293, address: 0x1402c33e3 */         v39 = &FileName;
/* line: 294, address: 0x1402c33ea */         if ( v186 )
/* line: 295, address: 0x1402c33ec */           v39 = v185;
/* line: 296, address: 0x1402c3403 */         sub_1419EE700(&v187, "C", v39, v38, v176, v177, v178);
/* line: 297, address: 0x1402c3413 */         if ( v185 )
/* line: 298, address: 0x1402c3415 */           sub_141977980(v185, v40, v41);
/* line: 299, address: 0x1402c3422 */         LOBYTE(v40) = 1;
/* line: 300, address: 0x1402c3424 */         sub_142681C10(&v187, v40);
/* line: 301, address: 0x1402c3434 */         if ( (_QWORD)v187 )
/* line: 302, address: 0x1402c343a */           sub_141977980(v187, v42, a3);
/* line: 303, address: 0x1402c343f */         goto LABEL_31;
/* line: 304 */       }
/* line: 305 */     }
/* line: 306 */     else
/* line: 307 */     {
/* line: 308, address: 0x1402c3339 */       v30 = v12[2];
/* line: 309, address: 0x1402c3340 */       if ( !v30 )
/* line: 310, address: 0x1402c3340 */         goto LABEL_48;
/* line: 311, address: 0x1402c3346 */       v31 = qword_146E71CD0;
/* line: 312, address: 0x1402c3350 */       if ( !qword_146E71CD0 )
/* line: 313 */       {
/* line: 314, address: 0x1402c3d60 */         sub_14035AFB0(
/* line: 315 */           (unsigned int)"/",
/* line: 316 */           (unsigned int)L"RBObjectiveRandomizable",
/* line: 317 */           (unsigned int)&qword_146E71CD0,
/* line: 318 */           (unsigned int)sub_1426E6990,
/* line: 319 */           40,
/* line: 320 */           8,
/* line: 321 */           268451841,
/* line: 322 */           0,
/* line: 323 */           (__int64)L"Engine",
/* line: 324 */           (__int64)sub_142DC3540,
/* line: 325 */           (__int64)sub_142629270,
/* line: 326 */           (__int64)nullsub_2,
/* line: 327 */           (__int64)sub_14124F3E0,
/* line: 328 */           (__int64)sub_14035B3C0,
/* line: 329 */           0,
/* line: 330 */           0);
/* line: 331, address: 0x1402c3d65 */         v31 = qword_146E71CD0;
/* line: 332, address: 0x1402c3d6f */         if ( !qword_146E71CD0 )
/* line: 333, address: 0x1402c3d6f */           goto LABEL_48;
/* line: 334 */       }
/* line: 335, address: 0x1402c335e */       if ( (*(_BYTE *)(v31 + 205) & 0x40) == 0 )
/* line: 336, address: 0x1402c335e */         goto LABEL_48;
/* line: 337, address: 0x1402c3360 */       v32 = qword_146F78498;
/* line: 338, address: 0x1402c336a */       if ( !qword_146F78498 )
/* line: 339 */       {
/* line: 340, address: 0x1402c3f31 */         sub_14035AFB0(
/* line: 341 */           (unsigned int)"/",
/* line: 342 */           (unsigned int)L"Interface",
/* line: 343 */           (unsigned int)&qword_146F78498,
/* line: 344 */           (unsigned int)ffxSetPrintMessageCallback,
/* line: 345 */           40,
/* line: 346 */           8,
/* line: 347 */           268451841,
/* line: 348 */           0,
/* line: 349 */           (__int64)L"Engine",
/* line: 350 */           (__int64)sub_141450A40,
/* line: 351 */           (__int64)sub_143A835E0,
/* line: 352 */           (__int64)nullsub_2,
/* line: 353 */           (__int64)sub_14035B3C0,
/* line: 354 */           (__int64)sub_14035B3C0,
/* line: 355 */           0,
/* line: 356 */           0);
/* line: 357, address: 0x1402c3f36 */         v32 = qword_146F78498;
/* line: 358 */       }
/* line: 359, address: 0x1402c3373 */       if ( v32 == v31 )
/* line: 360, address: 0x1402c3373 */         goto LABEL_48;
/* line: 361, address: 0x1402c3379 */       while ( 1 )
/* line: 362 */       {
/* line: 363, address: 0x1402c3379 */         v33 = *(unsigned int *)(v30 + 480);
/* line: 364, address: 0x1402c3381 */         if ( (int)v33 > 0 )
/* line: 365, address: 0x1402c3381 */           break;
/* line: 366 */ LABEL_40:
/* line: 367, address: 0x1402c3383 */         v30 = *(_QWORD *)(v30 + 64);
/* line: 368, address: 0x1402c338a */         if ( !v30 )
/* line: 369, address: 0x1402c338a */           goto LABEL_48;
/* line: 370 */       }
/* line: 371, address: 0x1402c3395 */       v34 = 16 * v33;
/* line: 372, address: 0x1402c3399 */       v35 = 0;
/* line: 373, address: 0x1402c339c */       while ( 1 )
/* line: 374 */       {
/* line: 375, address: 0x1402c339c */         v36 = *(_QWORD *)(*(_QWORD *)(v30 + 472) + v35);
/* line: 376, address: 0x1402c33a3 */         if ( v36 )
/* line: 377 */         {
/* line: 378, address: 0x1402c33a5 */           v37 = *(int *)(v31 + 56);
/* line: 379, address: 0x1402c33b7 */           if ( (int)v37 <= *(_DWORD *)(v36 + 56) && *(_QWORD *)(*(_QWORD *)(v36 + 48) + 8 * v37) == v31 + 48 )
/* line: 380, address: 0x1402c33b7 */             break;
/* line: 381 */         }
/* line: 382, address: 0x1402c33bd */         v35 += 16;
/* line: 383, address: 0x1402c33c4 */         if ( v34 == v35 )
/* line: 384, address: 0x1402c33c4 */           goto LABEL_40;
/* line: 385 */       }
/* line: 386, address: 0x1402c3686 */       LODWORD(v187) = 0;
/* line: 387, address: 0x1402c36a2 */       v61 = sub_141983CE0(v12[2], qword_146E71CD8, 1);
/* line: 388, address: 0x1402c36aa */       if ( v61 )
/* line: 389 */       {
/* line: 390, address: 0x1402c36c1 */         (*(void (__fastcall **)(_QWORD *, __int64, __int128 *))(*v12 + 544LL))(v12, v61, &v187);
/* line: 391, address: 0x1402c36c8 */         LODWORD(v22) = v187;
/* line: 392 */       }
/* line: 393 */       else
/* line: 394 */       {
/* line: 395, address: 0x1402c3fcc */         v126 = sub_140894860();
/* line: 396, address: 0x1402c3fd7 */         v127 = (__int64 (__fastcall ***)(_QWORD))sub_143AC6F90(v12, v126);
/* line: 397, address: 0x1402c3fdf */         if ( v127 )
/* line: 398, address: 0x1402c3fed */           LODWORD(v22) = (**v127)(v127);
/* line: 399 */         else
/* line: 400, address: 0x1402c40af */           LODWORD(v22) = 0;
/* line: 401, address: 0x1402c3fef */         v6 = v179;
/* line: 402 */       }
/* line: 403 */     }
/* line: 404, address: 0x1402c3282 */     if ( (int)v22 < 0 )
/* line: 405, address: 0x1402c3282 */       goto LABEL_48;
/* line: 406, address: 0x1402c3288 */     v23 = DWORD2(v188);
/* line: 407, address: 0x1402c3290 */     v24 = *(_DWORD *)&v192[8];
/* line: 408, address: 0x1402c329a */     if ( DWORD2(v188) == *(_DWORD *)&v192[8] )
/* line: 409, address: 0x1402c329a */       goto LABEL_55;
/* line: 410, address: 0x1402c32a0 */     v25 = *(char **)v194;
/* line: 411, address: 0x1402c32b3 */     if ( !*(_QWORD *)v194 )
/* line: 412, address: 0x1402c32b3 */       v25 = &v193;
/* line: 413, address: 0x1402c32be */     a3 = 0x7FFFFFFF;
/* line: 414, address: 0x1402c32c9 */     v26 = *(_DWORD *)&v25[4 * ((unsigned int)v22 & (v195 + 0x7FFFFFFF))];
/* line: 415, address: 0x1402c32cf */     if ( v26 == -1 )
/* line: 416, address: 0x1402c32cf */       goto LABEL_55;
/* line: 417, address: 0x1402c32e4 */     while ( 1 )
/* line: 418 */     {
/* line: 419, address: 0x1402c32e4 */       v27 = (_DWORD *)(v188 + 40LL * v26);
/* line: 420, address: 0x1402c32ec */       if ( *v27 == (_DWORD)v22 )
/* line: 421, address: 0x1402c32ec */         break;
/* line: 422, address: 0x1402c3444 */       v26 = v27[8];
/* line: 423, address: 0x1402c344b */       if ( v26 == -1 )
/* line: 424, address: 0x1402c344b */         goto LABEL_55;
/* line: 425 */     }
/* line: 426, address: 0x1402c32f5 */     if ( !v27 )
/* line: 427 */     {
/* line: 428 */ LABEL_55:
/* line: 429, address: 0x1402c3453 */       if ( *(_DWORD *)&v192[8] )
/* line: 430 */       {
/* line: 431, address: 0x1402c3f7d */         v23 = *(_DWORD *)&v192[4];
/* line: 432, address: 0x1402c3f8d */         v47 = *(int *)&v192[4];
/* line: 433, address: 0x1402c3f94 */         v125 = *(int *)(v188 + 40LL * *(int *)&v192[4] + 4);
/* line: 434, address: 0x1402c3f99 */         *(_DWORD *)&v192[4] = *(_DWORD *)(v188 + 40LL * *(int *)&v192[4] + 4);
/* line: 435, address: 0x1402c3fa3 */         --*(_DWORD *)&v192[8];
/* line: 436, address: 0x1402c3faa */         if ( v24 != 1 )
/* line: 437, address: 0x1402c3fb0 */           *(_DWORD *)(v188 + 40 * v125) = -1;
/* line: 438, address: 0x1402c3fb7 */         v6 = v179;
/* line: 439, address: 0x1402c3fbf */         a4 = (__int64)v189;
/* line: 440 */       }
/* line: 441 */       else
/* line: 442 */       {
/* line: 443, address: 0x1402c345e */         ++DWORD2(v188);
/* line: 444, address: 0x1402c346d */         if ( v23 >= SHIDWORD(v188) )
/* line: 445, address: 0x1402c347a */           sub_1400C32E0(&v188, (unsigned int)v23);
/* line: 446, address: 0x1402c347f */         v43 = v191;
/* line: 447, address: 0x1402c348a */         if ( v191 )
/* line: 448 */         {
/* line: 449, address: 0x1402c3494 */           v44 = v191 + 30;
/* line: 450, address: 0x1402c349a */           if ( v191 - 1 >= 0 )
/* line: 451, address: 0x1402c349a */             v44 = v191 - 1;
/* line: 452, address: 0x1402c349d */           v45 = v44 >> 5;
/* line: 453 */         }
/* line: 454 */         else
/* line: 455 */         {
/* line: 456, address: 0x1402c3c04 */           v45 = -1;
/* line: 457 */         }
/* line: 458, address: 0x1402c34a0 */         v46 = v191 + 1;
/* line: 459, address: 0x1402c34b6 */         if ( v191 / 32 == v45 )
/* line: 460 */         {
/* line: 461, address: 0x1402c34bc */           ++v191;
/* line: 462 */         }
/* line: 463 */         else
/* line: 464 */         {
/* line: 465, address: 0x1402c395a */           if ( *(int *)v192 <= v191 )
/* line: 466 */           {
/* line: 467, address: 0x1402c3e34 */             if ( (unsigned int)(v191 + 32) < 0xA0 )
/* line: 468 */             {
/* line: 469, address: 0x1402c3f42 */               v124 = 128;
/* line: 470 */             }
/* line: 471 */             else
/* line: 472 */             {
/* line: 473, address: 0x1402c3e3a */               v120 = (unsigned int)(v191 + 32) >> 5;
/* line: 474, address: 0x1402c3e43 */               v181 = v120;
/* line: 475, address: 0x1402c3e4b */               if ( (unsigned int)(*(_DWORD *)v192 + 31) < 0x20 )
/* line: 476 */               {
/* line: 477, address: 0x1402c46f7 */                 v121 = 4;
/* line: 478, address: 0x1402c46fc */                 if ( v120 >= 5 )
/* line: 479, address: 0x1402c46fc */                   v121 = (unsigned int)(v191 + 32) >> 5;
/* line: 480 */               }
/* line: 481 */               else
/* line: 482 */               {
/* line: 483, address: 0x1402c3e5c */                 v121 = v120 + ((3 * v120) >> 3) + 16;
/* line: 484 */               }
/* line: 485, address: 0x1402c3e6a */               v122 = (unsigned __int64)sub_141D8B630(4 * v121, 0) >> 2;
/* line: 486, address: 0x1402c3e70 */               v123 = 32 * v122;
/* line: 487, address: 0x1402c3e73 */               v83 = (int)v181 <= (int)v122;
/* line: 488, address: 0x1402c3e7a */               v124 = -32;
/* line: 489, address: 0x1402c3e7f */               if ( v83 )
/* line: 490, address: 0x1402c3e7f */                 v124 = v123;
/* line: 491 */             }
/* line: 492, address: 0x1402c3e89 */             *(_DWORD *)v192 = v124;
/* line: 493, address: 0x1402c3e98 */             sub_1400038F0(v189);
/* line: 494, address: 0x1402c3ea4 */             v46 = v191 + 1;
/* line: 495 */           }
/* line: 496, address: 0x1402c3960 */           v87 = v46 + 31;
/* line: 497, address: 0x1402c3965 */           if ( v46 >= 0 )
/* line: 498, address: 0x1402c3965 */             v87 = v46;
/* line: 499, address: 0x1402c3968 */           v191 = v46;
/* line: 500, address: 0x1402c3974 */           v88 = v46 - (v87 & 0xFFFFFFE0);
/* line: 501, address: 0x1402c3976 */           if ( v88 )
/* line: 502 */           {
/* line: 503, address: 0x1402c397c */             v89 = v87 >> 5;
/* line: 504, address: 0x1402c397f */             v90 = v190;
/* line: 505, address: 0x1402c3992 */             if ( !v190 )
/* line: 506, address: 0x1402c3992 */               v90 = v189;
/* line: 507, address: 0x1402c39a4 */             *(_DWORD *)&v90[4 * v89] = *(_DWORD *)&v90[4 * v89] << -(char)v88 >> -(char)v88;
/* line: 508 */           }
/* line: 509 */         }
/* line: 510, address: 0x1402c34c3 */         v47 = v23;
/* line: 511, address: 0x1402c34c6 */         v48 = v190;
/* line: 512, address: 0x1402c34d1 */         a4 = (__int64)v189;
/* line: 513, address: 0x1402c34d9 */         if ( !v190 )
/* line: 514, address: 0x1402c34d9 */           v48 = v189;
/* line: 515, address: 0x1402c34ec */         *(_DWORD *)&v48[4 * (v43 / 32)] &= __ROL4__(-2, v43);
/* line: 516 */       }
/* line: 517, address: 0x1402c34fa */       v49 = v190;
/* line: 518, address: 0x1402c3505 */       if ( !v190 )
/* line: 519, address: 0x1402c3505 */         v49 = v189;
/* line: 520, address: 0x1402c351c */       *(_DWORD *)&v49[4 * (v23 / 32)] |= 1 << v23;
/* line: 521, address: 0x1402c352c */       v50 = (__int128 *)(v188 + 40 * v47);
/* line: 522, address: 0x1402c3530 */       *(_DWORD *)v50 = v22;
/* line: 523, address: 0x1402c3534 */       *(__int128 *)((char *)v50 + 8) = 0;
/* line: 524, address: 0x1402c3539 */       *((_QWORD *)v50 + 3) = 0;
/* line: 525, address: 0x1402c3541 */       *((_DWORD *)v50 + 8) = -1;
/* line: 526, address: 0x1402c3559 */       v51 = DWORD2(v188) - *(_DWORD *)&v192[8];
/* line: 527, address: 0x1402c355e */       if ( DWORD2(v188) - *(_DWORD *)&v192[8] == 1 )
/* line: 528 */       {
/* line: 529, address: 0x1402c3902 */         v55 = 1;
/* line: 530, address: 0x1402c3908 */         v57 = v195;
/* line: 531 */       }
/* line: 532 */       else
/* line: 533 */       {
/* line: 534, address: 0x1402c3566 */         if ( DWORD2(v188) != *(_DWORD *)&v192[8] )
/* line: 535 */         {
/* line: 536, address: 0x1402c3568 */           v52 = *(char **)v194;
/* line: 537, address: 0x1402c357b */           if ( !*(_QWORD *)v194 )
/* line: 538, address: 0x1402c357b */             v52 = &v193;
/* line: 539, address: 0x1402c3591 */           v53 = *(_DWORD *)&v52[4 * ((unsigned int)v22 & (v195 + 0x7FFFFFFF))];
/* line: 540, address: 0x1402c3599 */           if ( v53 != -1 )
/* line: 541 */           {
/* line: 542, address: 0x1402c35aa */             while ( 1 )
/* line: 543 */             {
/* line: 544, address: 0x1402c35aa */               v54 = v188 + 40LL * v53;
/* line: 545, address: 0x1402c35b1 */               if ( *(_DWORD *)v54 == (_DWORD)v22 )
/* line: 546, address: 0x1402c35b1 */                 break;
/* line: 547, address: 0x1402c35b7 */               v53 = *(_DWORD *)(v54 + 32);
/* line: 548, address: 0x1402c35bf */               if ( v53 == -1 )
/* line: 549, address: 0x1402c35bf */                 goto LABEL_76;
/* line: 550 */             }
/* line: 551, address: 0x1402c3ffc */             v128 = *(_QWORD *)(v54 + 8);
/* line: 552, address: 0x1402c4003 */             if ( v128 )
/* line: 553, address: 0x1402c4005 */               sub_141977980(v128, 5LL * v53, 0x7FFFFFFF);
/* line: 554, address: 0x1402c400a */             v129 = *v50;
/* line: 555, address: 0x1402c4014 */             *(_OWORD *)(v54 + 16) = v50[1];
/* line: 556, address: 0x1402c4018 */             *(_OWORD *)v54 = v129;
/* line: 557, address: 0x1402c4027 */             sub_142695630(&v188, (unsigned int)v23);
/* line: 558 */ LABEL_199:
/* line: 559, address: 0x1402c3f52 */             v6 = v179;
/* line: 560, address: 0x1402c3f5a */             goto LABEL_87;
/* line: 561 */           }
/* line: 562 */         }
/* line: 563 */ LABEL_76:
/* line: 564, address: 0x1402c35c1 */         v55 = 1;
/* line: 565, address: 0x1402c35ca */         if ( (unsigned int)v51 >= 4 )
/* line: 566 */         {
/* line: 567, address: 0x1402c35d5 */           _BitScanReverse64(&v56, (v51 & 0xFFFFFFFE) + 15LL);
/* line: 568, address: 0x1402c35d9 */           v55 = 1 << v56;
/* line: 569 */         }
/* line: 570, address: 0x1402c35dc */         v57 = v195;
/* line: 571, address: 0x1402c35e5 */         v6 = v179;
/* line: 572, address: 0x1402c35ed */         if ( v51 <= 0 )
/* line: 573, address: 0x1402c35ed */           goto LABEL_81;
/* line: 574 */       }
/* line: 575, address: 0x1402c35fa */       if ( v57 && v57 >= v55 )
/* line: 576 */       {
/* line: 577 */ LABEL_81:
/* line: 578, address: 0x1402c3600 */         a4 = 0x7FFFFFFF;
/* line: 579, address: 0x1402c3609 */         v58 = v22 & (v57 + 0x7FFFFFFF);
/* line: 580, address: 0x1402c360b */         *((_DWORD *)v50 + 9) = v58;
/* line: 581, address: 0x1402c360f */         v59 = *(char **)v194;
/* line: 582, address: 0x1402c361a */         a3 = (__int64)&v193;
/* line: 583, address: 0x1402c3622 */         if ( !*(_QWORD *)v194 )
/* line: 584, address: 0x1402c3622 */           v59 = &v193;
/* line: 585, address: 0x1402c3635 */         *((_DWORD *)v50 + 8) = *(_DWORD *)&v59[4 * (v58 & (v195 + 0x7FFFFFFF))];
/* line: 586, address: 0x1402c3639 */         v60 = *(char **)v194;
/* line: 587, address: 0x1402c3644 */         if ( !*(_QWORD *)v194 )
/* line: 588, address: 0x1402c3644 */           v60 = &v193;
/* line: 589, address: 0x1402c3654 */         *(_DWORD *)&v60[4 * (v58 & (v195 + 0x7FFFFFFF))] = v23;
/* line: 590, address: 0x1402c3654 */         goto LABEL_86;
/* line: 591 */       }
/* line: 592, address: 0x1402c36d4 */       v195 = v55;
/* line: 593, address: 0x1402c36e7 */       if ( *(_QWORD *)v194 )
/* line: 594 */       {
/* line: 595, address: 0x1402c403b */         v62 = sub_1419A2460(v194[0], 0, 0);
/* line: 596, address: 0x1402c403e */         *(_QWORD *)v194 = v62;
/* line: 597, address: 0x1402c4046 */         v55 = v195;
/* line: 598, address: 0x1402c4051 */         if ( !v195 )
/* line: 599, address: 0x1402c4051 */           goto LABEL_86;
/* line: 600 */       }
/* line: 601 */       else
/* line: 602 */       {
/* line: 603, address: 0x1402c36ed */         v62 = 0;
/* line: 604 */       }
/* line: 605, address: 0x1402c36f3 */       if ( v55 == 1 )
/* line: 606 */       {
/* line: 607, address: 0x1402c36fc */         if ( v62 )
/* line: 608, address: 0x1402c3c44 */           *(_QWORD *)v194 = sub_1419A2460(v62, 0, 0);
/* line: 609 */       }
/* line: 610 */       else
/* line: 611 */       {
/* line: 612, address: 0x1402c3c18 */         if ( !v62 )
/* line: 613, address: 0x1402c3c1a */           LOBYTE(v62) = 0;
/* line: 614, address: 0x1402c3c24 */         *(_QWORD *)v194 = sub_1419A2460(v62, 4LL * v55, 0);
/* line: 615, address: 0x1402c3c2f */         if ( v55 <= 0 )
/* line: 616, address: 0x1402c3c2f */           goto LABEL_99;
/* line: 617 */       }
/* line: 618, address: 0x1402c3702 */       for ( i = 0; i != v55; ++i )
/* line: 619 */       {
/* line: 620, address: 0x1402c3704 */         v64 = *(char **)v194;
/* line: 621, address: 0x1402c3717 */         if ( !*(_QWORD *)v194 )
/* line: 622, address: 0x1402c3717 */           v64 = &v193;
/* line: 623, address: 0x1402c372d */         *(_DWORD *)&v64[4 * (i & (v195 + 0x7FFFFFFF))] = -1;
/* line: 624 */       }
/* line: 625 */ LABEL_99:
/* line: 626, address: 0x1402c373b */       a3 = (unsigned int)v191;
/* line: 627, address: 0x1402c3746 */       if ( v191 )
/* line: 628 */       {
/* line: 629, address: 0x1402c374c */         v65 = (int *)v190;
/* line: 630, address: 0x1402c375f */         if ( !v190 )
/* line: 631, address: 0x1402c375f */           v65 = (int *)v189;
/* line: 632, address: 0x1402c3763 */         v66 = *v65;
/* line: 633, address: 0x1402c3766 */         v67 = 0;
/* line: 634, address: 0x1402c3768 */         v68 = 0;
/* line: 635, address: 0x1402c3770 */         if ( !*v65 )
/* line: 636 */         {
/* line: 637, address: 0x1402c3918 */           v86 = v191 + 30;
/* line: 638, address: 0x1402c391e */           if ( v191 - 1 >= 0 )
/* line: 639, address: 0x1402c391e */             v86 = v191 - 1;
/* line: 640, address: 0x1402c3922 */           a4 = (unsigned int)(v86 >> 5);
/* line: 641, address: 0x1402c3926 */           v67 = 0;
/* line: 642, address: 0x1402c392b */           if ( (int)a4 <= 0 )
/* line: 643, address: 0x1402c392b */             a4 = 0;
/* line: 644, address: 0x1402c392f */           v68 = 0;
/* line: 645, address: 0x1402c3934 */           while ( a4 != v67 )
/* line: 646 */           {
/* line: 647, address: 0x1402c393a */             v68 += 32;
/* line: 648, address: 0x1402c393d */             v66 = v65[++v67];
/* line: 649, address: 0x1402c3948 */             if ( v66 )
/* line: 650, address: 0x1402c3948 */               goto LABEL_103;
/* line: 651 */           }
/* line: 652, address: 0x1402c3934 */           goto LABEL_86;
/* line: 653 */         }
/* line: 654 */ LABEL_103:
/* line: 655, address: 0x1402c3776 */         v69 = v66 & (unsigned int)-v66;
/* line: 656, address: 0x1402c3786 */         _BitScanReverse64(&v70, 2 * v69 + 1);
/* line: 657, address: 0x1402c378a */         a4 = (unsigned int)v70 ^ 0x3F;
/* line: 658, address: 0x1402c3794 */         v71 = v68 - a4 + 62;
/* line: 659, address: 0x1402c379b */         if ( v71 >= v191 )
/* line: 660, address: 0x1402c379b */           v71 = v191;
/* line: 661 */       }
/* line: 662 */       else
/* line: 663 */       {
/* line: 664, address: 0x1402c405c */         v67 = 0;
/* line: 665, address: 0x1402c405e */         LODWORD(v69) = 1;
/* line: 666, address: 0x1402c4063 */         v71 = 0;
/* line: 667, address: 0x1402c4066 */         v68 = 0;
/* line: 668 */       }
/* line: 669, address: 0x1402c379f */       v181 = v67;
/* line: 670, address: 0x1402c37aa */       if ( v71 < v191 )
/* line: 671 */       {
/* line: 672, address: 0x1402c37b0 */         LODWORD(a4) = -1;
/* line: 673, address: 0x1402c37b6 */         do
/* line: 674 */         {
/* line: 675, address: 0x1402c37b6 */           v72 = v188;
/* line: 676, address: 0x1402c37be */           v73 = v71;
/* line: 677, address: 0x1402c37c1 */           v74 = 5LL * v71;
/* line: 678, address: 0x1402c37d4 */           v75 = *(int *)(v188 + 8 * v74) & (unsigned __int64)(v195 - 1LL);
/* line: 679, address: 0x1402c37d7 */           *(_DWORD *)(v188 + 8 * v74 + 36) = v75;
/* line: 680, address: 0x1402c37dc */           v76 = *(char **)v194;
/* line: 681, address: 0x1402c37ef */           if ( !*(_QWORD *)v194 )
/* line: 682, address: 0x1402c37ef */             v76 = &v193;
/* line: 683, address: 0x1402c3805 */           *(_DWORD *)(v72 + 8 * v74 + 32) = *(_DWORD *)&v76[4 * (v75 & (v195 - 1LL))];
/* line: 684, address: 0x1402c380a */           v77 = *(char **)v194;
/* line: 685, address: 0x1402c3815 */           if ( !*(_QWORD *)v194 )
/* line: 686, address: 0x1402c3815 */             v77 = &v193;
/* line: 687, address: 0x1402c382a */           *(_DWORD *)&v77[4 * ((v195 - 1LL) & (int)v75)] = v73;
/* line: 688, address: 0x1402c3830 */           v78 = a4 & ~(_DWORD)v69;
/* line: 689, address: 0x1402c3833 */           a4 = (__int64)v190;
/* line: 690, address: 0x1402c3846 */           if ( !v190 )
/* line: 691, address: 0x1402c3846 */             a4 = (__int64)v189;
/* line: 692, address: 0x1402c384a */           a3 = (unsigned int)v191;
/* line: 693, address: 0x1402c3861 */           v79 = v78 & *(_DWORD *)(a4 + 4LL * (int)v181);
/* line: 694, address: 0x1402c3864 */           if ( v79 )
/* line: 695 */           {
/* line: 696, address: 0x1402c3866 */             v6 = v179;
/* line: 697 */           }
/* line: 698 */           else
/* line: 699 */           {
/* line: 700, address: 0x1402c38a9 */             v81 = v191 + 30;
/* line: 701, address: 0x1402c38b0 */             if ( v191 - 1 >= 0 )
/* line: 702, address: 0x1402c38b0 */               v81 = v191 - 1;
/* line: 703, address: 0x1402c38b4 */             v82 = v81 >> 5;
/* line: 704, address: 0x1402c38b7 */             v83 = (int)v181 < v82;
/* line: 705, address: 0x1402c38b9 */             if ( (int)v181 > v82 )
/* line: 706, address: 0x1402c38b9 */               v82 = v181;
/* line: 707, address: 0x1402c38bc */             if ( !v83 )
/* line: 708 */             {
/* line: 709, address: 0x1402c3f4f */               v53 = v23;
/* line: 710, address: 0x1402c3f4f */               goto LABEL_199;
/* line: 711 */             }
/* line: 712, address: 0x1402c38c5 */             v68 += 32;
/* line: 713, address: 0x1402c38c8 */             v84 = v82 - (__int64)(int)v181;
/* line: 714, address: 0x1402c38cf */             v85 = a4 + 4LL * (int)v181 + 4;
/* line: 715, address: 0x1402c38d3 */             a4 = 0;
/* line: 716, address: 0x1402c38d6 */             v6 = v179;
/* line: 717, address: 0x1402c38de */             while ( 1 )
/* line: 718 */             {
/* line: 719, address: 0x1402c38de */               v79 = *(_DWORD *)(v85 + 4 * a4);
/* line: 720, address: 0x1402c38e5 */               if ( v79 )
/* line: 721, address: 0x1402c38e5 */                 break;
/* line: 722, address: 0x1402c468f */               v68 += 32;
/* line: 723, address: 0x1402c4698 */               if ( v84 == ++a4 )
/* line: 724, address: 0x1402c4698 */                 goto LABEL_86;
/* line: 725 */             }
/* line: 726, address: 0x1402c38f0 */             v181 = (unsigned int)(a4 + v181 + 1);
/* line: 727, address: 0x1402c38f8 */             v78 = -1;
/* line: 728 */           }
/* line: 729, address: 0x1402c386e */           a4 = v78;
/* line: 730, address: 0x1402c3876 */           v69 = v79 & (unsigned int)-v79;
/* line: 731, address: 0x1402c3881 */           _BitScanReverse64(&v80, 2 * v69 + 1);
/* line: 732, address: 0x1402c388f */           v71 = v68 - (v80 ^ 0x3F) + 62;
/* line: 733 */         }
/* line: 734, address: 0x1402c37b6 */         while ( v71 < v191 );
/* line: 735 */       }
/* line: 736 */ LABEL_86:
/* line: 737, address: 0x1402c3658 */       v53 = v23;
/* line: 738 */ LABEL_87:
/* line: 739, address: 0x1402c365b */       v28 = v188 + 40LL * v53 + 8;
/* line: 740, address: 0x1402c3672 */       goto LABEL_28;
/* line: 741 */     }
/* line: 742, address: 0x1402c32fb */     v28 = (__int64)(v27 + 2);
/* line: 743 */ LABEL_28:
/* line: 744, address: 0x1402c32ff */     *(_DWORD *)(v28 + 20) = v22;
/* line: 745, address: 0x1402c3303 */     v29 = *(int *)(v28 + 8);
/* line: 746, address: 0x1402c330a */     *(_DWORD *)(v28 + 8) = v29 + 1;
/* line: 747, address: 0x1402c3312 */     if ( (int)v29 >= *(_DWORD *)(v28 + 12) )
/* line: 748, address: 0x1402c367c */       sub_1400011B0(v28, (unsigned int)v29);
/* line: 749, address: 0x1402c331c */     *(_QWORD *)(*(_QWORD *)v28 + 8 * v29) = v12;
/* line: 750, address: 0x1402c3320 */     ++v11;
/* line: 751 */ LABEL_31:
/* line: 752, address: 0x1402c3322 */     ++v10;
/* line: 753 */   }
/* line: 754, address: 0x1402c332e */   while ( v10 != (_QWORD *)v182 );
/* line: 755, address: 0x1402c39af */   v5 = v180;
/* line: 756, address: 0x1402c39b7 */   v8 = v184;
/* line: 757, address: 0x1402c39bf */   if ( !v11 )
/* line: 758 */   {
/* line: 759 */ LABEL_183:
/* line: 760, address: 0x1402c3c51 */     sub_1419EE700(
/* line: 761 */       &v187,
/* line: 762 */       L"Could not find valid objective types for grouping. Skipping groups",
/* line: 763 */       a3,
/* line: 764 */       a4,
/* line: 765 */       v176,
/* line: 766 */       v177,
/* line: 767 */       v178);
/* line: 768, address: 0x1402c3c6b */     LOBYTE(v111) = 1;
/* line: 769, address: 0x1402c3c6d */     sub_142681C10(&v187, v111);
/* line: 770, address: 0x1402c3c78 */     if ( (_QWORD)v187 )
/* line: 771, address: 0x1402c3c7a */       sub_141977980(v187, v112, v113);
/* line: 772, address: 0x1402c3c82 */     v114 = (void **)sub_143617840(v5);
/* line: 773, address: 0x1402c3c87 */     *((_DWORD *)v114 + 4) = v6;
/* line: 774, address: 0x1402c3c8d */     if ( v114 != (void **)v8 )
/* line: 775 */     {
/* line: 776, address: 0x1402c3c93 */       a3 = *((unsigned int *)v114 + 3);
/* line: 777, address: 0x1402c3c97 */       v115 = (const void **)v8;
/* line: 778, address: 0x1402c3c9a */       v116 = *(int *)(v8 + 8);
/* line: 779, address: 0x1402c3c9e */       v117 = *v115;
/* line: 780, address: 0x1402c3ca1 */       *((_DWORD *)v114 + 2) = v116;
/* line: 781, address: 0x1402c3ca6 */       if ( (unsigned int)a3 | (unsigned int)v116 )
/* line: 782 */       {
/* line: 783, address: 0x1402c3cb4 */         v118 = v114;
/* line: 784, address: 0x1402c3cb7 */         sub_140295F20(v114, (unsigned int)v116);
/* line: 785, address: 0x1402c3cc9 */         memcpy(*v118, v117, 8 * v116);
/* line: 786 */       }
/* line: 787 */       else
/* line: 788 */       {
/* line: 789, address: 0x1402c3d7a */         *((_DWORD *)v114 + 3) = 0;
/* line: 790 */       }
/* line: 791 */     }
/* line: 792, address: 0x1402c3cce */     goto LABEL_269;
/* line: 793 */   }
/* line: 794, address: 0x1402c39c8 */   v187 = 0;
/* line: 795, address: 0x1402c39de */   if ( DWORD2(v188) != *(_DWORD *)&v192[8] )
/* line: 796, address: 0x1402c39e8 */     sub_1400A8630(&v187, (unsigned int)(DWORD2(v188) - *(_DWORD *)&v192[8]));
/* line: 797, address: 0x1402c39f6 */   j = (__int64)v189;
/* line: 798, address: 0x1402c39fe */   if ( v191 )
/* line: 799 */   {
/* line: 800, address: 0x1402c3a04 */     v92 = (unsigned int *)v190;
/* line: 801, address: 0x1402c3a0f */     if ( !v190 )
/* line: 802, address: 0x1402c3a0f */       v92 = (unsigned int *)v189;
/* line: 803, address: 0x1402c3a13 */     a3 = *v92;
/* line: 804, address: 0x1402c3a16 */     v93 = 0;
/* line: 805, address: 0x1402c3a19 */     v94 = 0;
/* line: 806, address: 0x1402c3a22 */     if ( (_DWORD)a3 )
/* line: 807 */     {
/* line: 808 */ LABEL_148:
/* line: 809, address: 0x1402c3a28 */       v95 = (unsigned int)a3 & -(int)a3;
/* line: 810, address: 0x1402c3a39 */       _BitScanReverse64(&v96, 2 * v95 + 1);
/* line: 811, address: 0x1402c3a46 */       v97 = v94 - (v96 ^ 0x3F) + 62;
/* line: 812, address: 0x1402c3a4d */       if ( v97 >= v191 )
/* line: 813, address: 0x1402c3a4d */         v97 = v191;
/* line: 814, address: 0x1402c3a4d */       goto LABEL_150;
/* line: 815 */     }
/* line: 816, address: 0x1402c3bc7 */     a3 = (unsigned int)(v191 - 1);
/* line: 817, address: 0x1402c3bcb */     v110 = v191 + 30;
/* line: 818, address: 0x1402c3bd1 */     if ( (int)a3 >= 0 )
/* line: 819, address: 0x1402c3bd1 */       v110 = v191 - 1;
/* line: 820, address: 0x1402c3bd5 */     j = (unsigned int)(v110 >> 5);
/* line: 821, address: 0x1402c3bd8 */     v93 = 0;
/* line: 822, address: 0x1402c3bdd */     if ( (int)j <= 0 )
/* line: 823, address: 0x1402c3bdd */       j = 0;
/* line: 824, address: 0x1402c3be1 */     v94 = 0;
/* line: 825, address: 0x1402c3be7 */     while ( j != v93 )
/* line: 826 */     {
/* line: 827, address: 0x1402c3bed */       v94 += 32;
/* line: 828, address: 0x1402c3bf1 */       a3 = v92[++v93];
/* line: 829, address: 0x1402c3bfc */       if ( (_DWORD)a3 )
/* line: 830, address: 0x1402c3bfc */         goto LABEL_148;
/* line: 831 */     }
/* line: 832 */   }
/* line: 833 */   else
/* line: 834 */   {
/* line: 835, address: 0x1402c409b */     LODWORD(v95) = 1;
/* line: 836, address: 0x1402c40a1 */     v93 = 0;
/* line: 837, address: 0x1402c40a4 */     v97 = 0;
/* line: 838, address: 0x1402c40a7 */     v94 = 0;
/* line: 839 */ LABEL_150:
/* line: 840, address: 0x1402c3a54 */     if ( v97 < v191 )
/* line: 841 */     {
/* line: 842, address: 0x1402c3a5a */       v98 = -1;
/* line: 843, address: 0x1402c3a60 */       do
/* line: 844 */       {
/* line: 845, address: 0x1402c3a60 */         LODWORD(v182) = v94;
/* line: 846, address: 0x1402c3a68 */         v183 = v93;
/* line: 847, address: 0x1402c3a70 */         v99 = SDWORD2(v187);
/* line: 848, address: 0x1402c3a7b */         ++DWORD2(v187);
/* line: 849, address: 0x1402c3a89 */         if ( (int)v99 >= SHIDWORD(v187) )
/* line: 850, address: 0x1402c3f67 */           sub_140183D90(&v187, j);
/* line: 851, address: 0x1402c3a9b */         v100 = v187 + 24 * v99;
/* line: 852, address: 0x1402c3a9f */         v101 = v188;
/* line: 853, address: 0x1402c3aaa */         v102 = 5LL * v97;
/* line: 854, address: 0x1402c3aae */         *(_QWORD *)v100 = 0;
/* line: 855, address: 0x1402c3ab5 */         v103 = *(int *)(v101 + 40LL * v97 + 16);
/* line: 856, address: 0x1402c3aba */         v104 = *(const void **)(v101 + 8 * v102 + 8);
/* line: 857, address: 0x1402c3abf */         *(_DWORD *)(v100 + 8) = v103;
/* line: 858, address: 0x1402c3ac6 */         if ( v103 )
/* line: 859 */         {
/* line: 860, address: 0x1402c3ad5 */           sub_140295F20(v100, (unsigned int)v103);
/* line: 861, address: 0x1402c3ae7 */           memcpy(*(void **)v100, v104, 8 * v103);
/* line: 862 */         }
/* line: 863 */         else
/* line: 864 */         {
/* line: 865, address: 0x1402c3f71 */           *(_DWORD *)(v100 + 12) = 0;
/* line: 866 */         }
/* line: 867, address: 0x1402c3af8 */         *(_QWORD *)(v100 + 16) = *(_QWORD *)(v101 + 8 * v102 + 24);
/* line: 868, address: 0x1402c3aff */         v98 &= ~(_DWORD)v95;
/* line: 869, address: 0x1402c3b02 */         j = (__int64)v190;
/* line: 870, address: 0x1402c3b15 */         if ( !v190 )
/* line: 871, address: 0x1402c3b15 */           j = (__int64)v189;
/* line: 872, address: 0x1402c3b20 */         v93 = v183;
/* line: 873, address: 0x1402c3b28 */         a4 = (int)v183;
/* line: 874, address: 0x1402c3b2f */         v105 = v98 & *(_DWORD *)(j + 4LL * (int)v183);
/* line: 875, address: 0x1402c3b32 */         if ( v105 )
/* line: 876 */         {
/* line: 877, address: 0x1402c3b34 */           v94 = v182;
/* line: 878 */         }
/* line: 879 */         else
/* line: 880 */         {
/* line: 881, address: 0x1402c3b70 */           a3 = (unsigned int)(v191 - 1);
/* line: 882, address: 0x1402c3b74 */           v107 = v191 + 30;
/* line: 883, address: 0x1402c3b7a */           if ( (int)a3 >= 0 )
/* line: 884, address: 0x1402c3b7a */             v107 = v191 - 1;
/* line: 885, address: 0x1402c3b7e */           v108 = v107 >> 5;
/* line: 886, address: 0x1402c3b81 */           v109 = (int)v183 < v108;
/* line: 887, address: 0x1402c3b84 */           if ( (int)v183 > v108 )
/* line: 888, address: 0x1402c3b84 */             v108 = v183;
/* line: 889, address: 0x1402c3b90 */           if ( !v109 )
/* line: 890, address: 0x1402c3b90 */             break;
/* line: 891, address: 0x1402c3b99 */           v94 = v182 + 32;
/* line: 892, address: 0x1402c3b9d */           a3 = v108 - (__int64)(int)v183;
/* line: 893, address: 0x1402c3ba4 */           a4 = j + 4LL * (int)v183 + 4;
/* line: 894, address: 0x1402c3ba8 */           j = 0;
/* line: 895, address: 0x1402c3baa */           while ( 1 )
/* line: 896 */           {
/* line: 897, address: 0x1402c3baa */             v105 = *(_DWORD *)(a4 + 4 * j);
/* line: 898, address: 0x1402c3bb0 */             if ( v105 )
/* line: 899, address: 0x1402c3bb0 */               break;
/* line: 900, address: 0x1402c40b6 */             v94 += 32;
/* line: 901, address: 0x1402c40c0 */             if ( a3 == ++j )
/* line: 902, address: 0x1402c40c0 */               goto LABEL_221;
/* line: 903 */           }
/* line: 904, address: 0x1402c3bb9 */           v93 = (unsigned int)(j + v183 + 1);
/* line: 905, address: 0x1402c3bbc */           v98 = -1;
/* line: 906 */         }
/* line: 907, address: 0x1402c3b42 */         v95 = v105 & (unsigned int)-v105;
/* line: 908, address: 0x1402c3b4d */         _BitScanReverse64(&v106, 2 * v95 + 1);
/* line: 909, address: 0x1402c3b5a */         v97 = v94 - (v106 ^ 0x3F) + 62;
/* line: 910 */       }
/* line: 911, address: 0x1402c3a60 */       while ( v97 < v191 );
/* line: 912 */     }
/* line: 913 */   }
/* line: 914 */ LABEL_221:
/* line: 915, address: 0x1402c40c6 */   v131 = DWORD2(v187);
/* line: 916, address: 0x1402c40cf */   if ( SDWORD2(v187) <= 0 )
/* line: 917 */   {
/* line: 918, address: 0x1402c42cb */     v132 = v180;
/* line: 919 */   }
/* line: 920 */   else
/* line: 921 */   {
/* line: 922, address: 0x1402c40e6 */     v132 = v180;
/* line: 923, address: 0x1402c4295 */     do
/* line: 924 */     {
/* line: 925, address: 0x1402c40ee */       v133 = (unsigned __int64)a5;
/* line: 926, address: 0x1402c40f6 */       v134 = (unsigned int)*a5;
/* line: 927, address: 0x1402c40fb */       *a5 = v134 + 1;
/* line: 928, address: 0x1402c40fd */       v135 = 0;
/* line: 929, address: 0x1402c4113 */       if ( (_WORD)v131 && dword_146E2E5C4 )
/* line: 930 */       {
/* line: 931, address: 0x1402c411c */         if ( v134 )
/* line: 932 */         {
/* line: 933, address: 0x1402c413f */           a3 = 0xBF58476D1CE4E5B9uLL;
/* line: 934, address: 0x1402c4181 */           v137 = (0x94D049BB133111EBuLL
/* line: 935 */                 * ((0xBF58476D1CE4E5B9uLL * (v134 ^ ((unsigned int)v134 >> 30)))
/* line: 936 */                  ^ ((0xBF58476D1CE4E5B9uLL * (v134 ^ ((unsigned int)v134 >> 30))) >> 27)))
/* line: 937 */                ^ (0x94D049BB133111EBuLL
/* line: 938 */                 * ((0xBF58476D1CE4E5B9uLL * (dword_146E2E5C4 % 0x3E8u))
/* line: 939 */                  ^ ((0xBF58476D1CE4E5B9uLL * (dword_146E2E5C4 % 0x3E8u)) >> 27)))
/* line: 940 */                ^ (((0x94D049BB133111EBuLL
/* line: 941 */                   * ((0xBF58476D1CE4E5B9uLL * (v134 ^ ((unsigned int)v134 >> 30)))
/* line: 942 */                    ^ ((0xBF58476D1CE4E5B9uLL * (v134 ^ ((unsigned int)v134 >> 30))) >> 27)))
/* line: 943 */                  ^ (0x94D049BB133111EBuLL
/* line: 944 */                   * ((0xBF58476D1CE4E5B9uLL * (dword_146E2E5C4 % 0x3E8u))
/* line: 945 */                    ^ ((0xBF58476D1CE4E5B9uLL * (dword_146E2E5C4 % 0x3E8u)) >> 27)))) >> 31);
/* line: 946, address: 0x1402c419c */           v136 = 0x94D049BB133111EBuLL
/* line: 947 */                * ((0xBF58476D1CE4E5B9uLL * (v137 ^ (v137 >> 30)))
/* line: 948 */                 ^ ((0xBF58476D1CE4E5B9uLL * (v137 ^ (v137 >> 30))) >> 27));
/* line: 949, address: 0x1402c41a7 */           LOWORD(v137) = v136 ^ (v136 >> 31);
/* line: 950 */         }
/* line: 951 */         else
/* line: 952 */         {
/* line: 953, address: 0x1402c42b8 */           LODWORD(v137) = (int)(float)((float)((float)(rand() & 0x7FFF) / 32767.0) * 65535.0);
/* line: 954, address: 0x1402c42c3 */           if ( (int)v137 >= 65534 )
/* line: 955, address: 0x1402c42c3 */             LOWORD(v137) = -2;
/* line: 956 */         }
/* line: 957, address: 0x1402c41ab */         v133 = (unsigned __int16)((unsigned __int16)v137 % (unsigned __int16)v131);
/* line: 958, address: 0x1402c41ae */         v135 = (unsigned __int16)v133;
/* line: 959 */       }
/* line: 960, address: 0x1402c41b1 */       v138 = v187;
/* line: 961, address: 0x1402c41b9 */       v139 = *(int *)(v132 + 8);
/* line: 962, address: 0x1402c41c1 */       *(_DWORD *)(v132 + 8) = v139 + 1;
/* line: 963, address: 0x1402c41c9 */       if ( (int)v139 >= *(_DWORD *)(v132 + 12) )
/* line: 964, address: 0x1402c41ce */         sub_140183D90(v132, v133);
/* line: 965, address: 0x1402c41d9 */       v140 = (_QWORD *)v132;
/* line: 966, address: 0x1402c41dc */       v141 = (_QWORD *)(v138 + 24LL * v135);
/* line: 967, address: 0x1402c41e7 */       v142 = *v140 + 24 * v139;
/* line: 968, address: 0x1402c41eb */       *(_QWORD *)v142 = 0;
/* line: 969, address: 0x1402c41f2 */       v143 = *((int *)v141 + 2);
/* line: 970, address: 0x1402c41f6 */       v144 = (const void *)*v141;
/* line: 971, address: 0x1402c41f9 */       *(_DWORD *)(v142 + 8) = v143;
/* line: 972, address: 0x1402c4200 */       if ( v143 )
/* line: 973 */       {
/* line: 974, address: 0x1402c420f */         sub_140295F20(v142, (unsigned int)v143);
/* line: 975, address: 0x1402c4221 */         memcpy(*(void **)v142, v144, 8 * v143);
/* line: 976 */       }
/* line: 977 */       else
/* line: 978 */       {
/* line: 979, address: 0x1402c4593 */         *(_DWORD *)(v142 + 12) = 0;
/* line: 980 */       }
/* line: 981, address: 0x1402c422a */       *(_QWORD *)(v142 + 16) = v141[2];
/* line: 982, address: 0x1402c422e */       if ( *v141 )
/* line: 983, address: 0x1402c4236 */         sub_141977980(*v141, v133, a3);
/* line: 984, address: 0x1402c423d */       v145 = v131 + ~v135;
/* line: 985, address: 0x1402c423f */       if ( v145 )
/* line: 986 */       {
/* line: 987, address: 0x1402c4248 */         if ( v145 > 0 )
/* line: 988, address: 0x1402c4248 */           v145 = 1;
/* line: 989, address: 0x1402c4269 */         memcpy(v141, (const void *)(v138 + 24LL * (unsigned int)(v131 - v145)), 24LL * v145);
/* line: 990 */       }
/* line: 991, address: 0x1402c4270 */       DWORD2(v187) = v131 - 1;
/* line: 992, address: 0x1402c427f */       sub_140526130(&v187);
/* line: 993, address: 0x1402c4284 */       v131 = DWORD2(v187);
/* line: 994, address: 0x1402c428d */       v132 = v180;
/* line: 995 */     }
/* line: 996, address: 0x1402c4295 */     while ( SDWORD2(v187) > 0 );
/* line: 997 */   }
/* line: 998, address: 0x1402c42d3 */   v146 = *(_DWORD *)(v132 + 8);
/* line: 999, address: 0x1402c42e7 */   if ( (int)v179 <= 0 || v146 <= 0 )
/* line: 1000 */   {
/* line: 1001, address: 0x1402c458c */     v149 = v179;
/* line: 1002 */   }
/* line: 1003 */   else
/* line: 1004 */   {
/* line: 1005, address: 0x1402c42ed */     v147 = 1;
/* line: 1006, address: 0x1402c42f2 */     j = 16;
/* line: 1007, address: 0x1402c42f7 */     v148 = v179;
/* line: 1008, address: 0x1402c432c */     do
/* line: 1009 */     {
/* line: 1010, address: 0x1402c4302 */       ++*(_DWORD *)(*(_QWORD *)v132 + j);
/* line: 1011, address: 0x1402c4305 */       v149 = v148 - 1;
/* line: 1012, address: 0x1402c430d */       LOBYTE(a3) = v148 >= 2;
/* line: 1013, address: 0x1402c4311 */       v146 = *(_DWORD *)(v132 + 8);
/* line: 1014, address: 0x1402c4315 */       a4 = v146;
/* line: 1015, address: 0x1402c431b */       LOBYTE(a4) = v147++ < v146;
/* line: 1016, address: 0x1402c4322 */       j += 24;
/* line: 1017, address: 0x1402c4326 */       --v148;
/* line: 1018 */     }
/* line: 1019, address: 0x1402c432c */     while ( ((unsigned __int8)a4 & (unsigned __int8)a3) != 0 );
/* line: 1020 */   }
/* line: 1021, address: 0x1402c4330 */   if ( v149 > 0 )
/* line: 1022 */   {
/* line: 1023, address: 0x1402c4338 */     if ( v146 > 0 )
/* line: 1024 */     {
/* line: 1025, address: 0x1402c4341 */       v150 = 16;
/* line: 1026, address: 0x1402c4346 */       for ( j = 0; j < v146; ++j )
/* line: 1027 */       {
/* line: 1028, address: 0x1402c4360 */         a3 = *(_QWORD *)v132;
/* line: 1029, address: 0x1402c4371 */         v151 = (float)((float)*(int *)(*(_QWORD *)v132 + v150 - 8) / (float)v11) * v9;
/* line: 1030, address: 0x1402c4378 */         if ( v151 > 1.0 )
/* line: 1031 */         {
/* line: 1032, address: 0x1402c438a */           v152 = (int)(float)((float)((float)(v151 + -1.0) + (float)(v151 + -1.0)) + 0.5) >> 1;
/* line: 1033, address: 0x1402c438e */           if ( v149 < v152 )
/* line: 1034, address: 0x1402c438e */             v152 = v149;
/* line: 1035, address: 0x1402c4391 */           *(_DWORD *)(a3 + v150) += v152;
/* line: 1036, address: 0x1402c4395 */           v83 = v149 <= v152;
/* line: 1037, address: 0x1402c4395 */           v149 -= v152;
/* line: 1038, address: 0x1402c4397 */           if ( v83 )
/* line: 1039, address: 0x1402c4397 */             goto LABEL_262;
/* line: 1040, address: 0x1402c4399 */           v146 = *(_DWORD *)(v132 + 8);
/* line: 1041 */         }
/* line: 1042, address: 0x1402c43a0 */         a3 = v146;
/* line: 1043, address: 0x1402c43a3 */         v150 += 24;
/* line: 1044 */       }
/* line: 1045 */     }
/* line: 1046, address: 0x1402c43af */     if ( v149 != 1 )
/* line: 1047 */     {
/* line: 1048, address: 0x1402c46b5 */       sub_1419EE700(&v185, L"Math error too big when building randomization groups.", a3, a4, v176, v177, v178);
/* line: 1049, address: 0x1402c46bd */       LOBYTE(v174) = 1;
/* line: 1050, address: 0x1402c46bf */       sub_142681C10(&v185, v174);
/* line: 1051, address: 0x1402c46ca */       if ( v185 )
/* line: 1052, address: 0x1402c46cc */         sub_141977980(v185, j, a3);
/* line: 1053, address: 0x1402c46d1 */       v132 = v180;
/* line: 1054, address: 0x1402c46d9 */       v146 = *(_DWORD *)(v180 + 8);
/* line: 1055 */     }
/* line: 1056, address: 0x1402c43b7 */     if ( v146 )
/* line: 1057 */     {
/* line: 1058, address: 0x1402c43b9 */       v153 = *(_QWORD *)v132;
/* line: 1059, address: 0x1402c43c2 */       j = 24LL * v146;
/* line: 1060, address: 0x1402c43c6 */       v154 = 0;
/* line: 1061, address: 0x1402c43cd */       while ( 1 )
/* line: 1062 */       {
/* line: 1063, address: 0x1402c43cd */         a3 = (unsigned int)(v149 + *(_DWORD *)(v153 + v154 + 16));
/* line: 1064, address: 0x1402c43d5 */         if ( *(_DWORD *)(v153 + v154 + 8) >= (int)a3 )
/* line: 1065, address: 0x1402c43d5 */           break;
/* line: 1066, address: 0x1402c46e2 */         v154 += 24;
/* line: 1067, address: 0x1402c46e9 */         if ( j == v154 )
/* line: 1068, address: 0x1402c46e9 */           goto LABEL_262;
/* line: 1069 */       }
/* line: 1070, address: 0x1402c43db */       *(_DWORD *)(v153 + v154 + 16) = a3;
/* line: 1071 */     }
/* line: 1072 */   }
/* line: 1073 */ LABEL_262:
/* line: 1074, address: 0x1402c43e0 */   v155 = v187;
/* line: 1075, address: 0x1402c43ea */   if ( v131 )
/* line: 1076 */   {
/* line: 1077, address: 0x1402c43ec */     v156 = (_QWORD *)v187;
/* line: 1078, address: 0x1402c4402 */     do
/* line: 1079 */     {
/* line: 1080, address: 0x1402c43ef */       if ( *v156 )
/* line: 1081, address: 0x1402c43f7 */         sub_141977980(*v156, j, a3);
/* line: 1082, address: 0x1402c43fc */       v156 += 3;
/* line: 1083, address: 0x1402c4400 */       --v131;
/* line: 1084 */     }
/* line: 1085, address: 0x1402c4402 */     while ( v131 );
/* line: 1086 */   }
/* line: 1087, address: 0x1402c4407 */   if ( v155 )
/* line: 1088, address: 0x1402c440c */     sub_141977980(v155, j, a3);
/* line: 1089 */ LABEL_269:
/* line: 1090, address: 0x1402c4411 */   v195 = 0;
/* line: 1091, address: 0x1402c4427 */   if ( *(_QWORD *)v194 )
/* line: 1092, address: 0x1402c4545 */     sub_141977980(*(_QWORD *)v194, j, a3);
/* line: 1093, address: 0x1402c4435 */   v157 = v191;
/* line: 1094, address: 0x1402c443a */   if ( v191 )
/* line: 1095 */   {
/* line: 1096, address: 0x1402c4440 */     v158 = (unsigned int *)v190;
/* line: 1097, address: 0x1402c444b */     if ( !v190 )
/* line: 1098, address: 0x1402c444b */       v158 = (unsigned int *)v189;
/* line: 1099, address: 0x1402c444f */     a3 = *v158;
/* line: 1100, address: 0x1402c4452 */     LODWORD(v159) = 0;
/* line: 1101, address: 0x1402c4454 */     v160 = 0;
/* line: 1102, address: 0x1402c445c */     if ( (_DWORD)a3 )
/* line: 1103 */     {
/* line: 1104 */ LABEL_275:
/* line: 1105, address: 0x1402c4462 */       v161 = (unsigned int)a3 & -(int)a3;
/* line: 1106, address: 0x1402c4473 */       _BitScanReverse64(&v162, 2 * v161 + 1);
/* line: 1107, address: 0x1402c4477 */       j = (unsigned int)v162 ^ 0x3F;
/* line: 1108, address: 0x1402c447e */       v163 = v160 - j + 62;
/* line: 1109, address: 0x1402c4483 */       if ( v163 >= v191 )
/* line: 1110, address: 0x1402c4483 */         v163 = v191;
/* line: 1111, address: 0x1402c4483 */       goto LABEL_277;
/* line: 1112 */     }
/* line: 1113, address: 0x1402c454f */     a3 = (unsigned int)(v191 - 1);
/* line: 1114, address: 0x1402c4553 */     v172 = v191 + 30;
/* line: 1115, address: 0x1402c4559 */     if ( (int)a3 >= 0 )
/* line: 1116, address: 0x1402c4559 */       v172 = v191 - 1;
/* line: 1117, address: 0x1402c455d */     j = (unsigned int)(v172 >> 5);
/* line: 1118, address: 0x1402c4560 */     v159 = 0;
/* line: 1119, address: 0x1402c4564 */     if ( (int)j <= 0 )
/* line: 1120, address: 0x1402c4564 */       j = 0;
/* line: 1121, address: 0x1402c4567 */     v160 = 0;
/* line: 1122, address: 0x1402c456c */     while ( j != v159 )
/* line: 1123 */     {
/* line: 1124, address: 0x1402c456e */       v160 += 32;
/* line: 1125, address: 0x1402c4571 */       a3 = v158[++v159];
/* line: 1126, address: 0x1402c457c */       if ( (_DWORD)a3 )
/* line: 1127, address: 0x1402c457c */         goto LABEL_275;
/* line: 1128 */     }
/* line: 1129 */   }
/* line: 1130 */   else
/* line: 1131 */   {
/* line: 1132, address: 0x1402c45a0 */     LODWORD(v159) = 0;
/* line: 1133, address: 0x1402c45a2 */     LODWORD(v161) = 1;
/* line: 1134, address: 0x1402c45a8 */     v163 = 0;
/* line: 1135, address: 0x1402c45aa */     v160 = 0;
/* line: 1136 */ LABEL_277:
/* line: 1137, address: 0x1402c4488 */     if ( v163 < v191 )
/* line: 1138 */     {
/* line: 1139, address: 0x1402c448e */       v164 = -1;
/* line: 1140, address: 0x1402c44a2 */       do
/* line: 1141 */       {
/* line: 1142, address: 0x1402c44a2 */         v165 = *(_QWORD *)(v188 + 40LL * v163 + 8);
/* line: 1143, address: 0x1402c44aa */         if ( v165 )
/* line: 1144 */         {
/* line: 1145, address: 0x1402c44ac */           sub_141977980(v165, v188, a3);
/* line: 1146, address: 0x1402c44b1 */           v157 = v191;
/* line: 1147 */         }
/* line: 1148, address: 0x1402c44bb */         v164 &= ~(_DWORD)v161;
/* line: 1149, address: 0x1402c44be */         j = (__int64)v190;
/* line: 1150, address: 0x1402c44c9 */         if ( !v190 )
/* line: 1151, address: 0x1402c44c9 */           j = (__int64)v189;
/* line: 1152, address: 0x1402c44d4 */         v166 = v164 & *(_DWORD *)(j + 4LL * (int)v159);
/* line: 1153, address: 0x1402c44d6 */         if ( !v166 )
/* line: 1154 */         {
/* line: 1155, address: 0x1402c4503 */           a3 = (unsigned int)(v157 - 1);
/* line: 1156, address: 0x1402c4507 */           v168 = v157 + 30;
/* line: 1157, address: 0x1402c450d */           if ( (int)a3 >= 0 )
/* line: 1158, address: 0x1402c450d */             v168 = v157 - 1;
/* line: 1159, address: 0x1402c4511 */           v169 = v168 >> 5;
/* line: 1160, address: 0x1402c4514 */           v170 = (int)v159 < v169;
/* line: 1161, address: 0x1402c4516 */           if ( (int)v159 > v169 )
/* line: 1162, address: 0x1402c4516 */             v169 = v159;
/* line: 1163, address: 0x1402c4519 */           if ( !v170 )
/* line: 1164, address: 0x1402c4519 */             break;
/* line: 1165, address: 0x1402c4522 */           v160 += 32;
/* line: 1166, address: 0x1402c4525 */           a3 = v169 - (__int64)(int)v159;
/* line: 1167, address: 0x1402c452c */           v171 = j + 4LL * (int)v159 + 4;
/* line: 1168, address: 0x1402c4530 */           j = 0;
/* line: 1169, address: 0x1402c4532 */           while ( 1 )
/* line: 1170 */           {
/* line: 1171, address: 0x1402c4532 */             v166 = *(_DWORD *)(v171 + 4 * j);
/* line: 1172, address: 0x1402c4538 */             if ( v166 )
/* line: 1173, address: 0x1402c4538 */               break;
/* line: 1174, address: 0x1402c45b1 */             v160 += 32;
/* line: 1175, address: 0x1402c45ba */             if ( a3 == ++j )
/* line: 1176, address: 0x1402c45ba */               goto LABEL_306;
/* line: 1177 */           }
/* line: 1178, address: 0x1402c453c */           LODWORD(v159) = j + v159 + 1;
/* line: 1179, address: 0x1402c453e */           v164 = -1;
/* line: 1180 */         }
/* line: 1181, address: 0x1402c44de */         v161 = v166 & (unsigned int)-v166;
/* line: 1182, address: 0x1402c44e9 */         _BitScanReverse64(&v167, 2 * v161 + 1);
/* line: 1183, address: 0x1402c44ed */         j = (unsigned int)v167 ^ 0x3F;
/* line: 1184, address: 0x1402c44f4 */         v163 = v160 - j + 62;
/* line: 1185 */       }
/* line: 1186, address: 0x1402c44a2 */       while ( v163 < v157 );
/* line: 1187 */     }
/* line: 1188 */   }
/* line: 1189 */ LABEL_306:
/* line: 1190, address: 0x1402c45c0 */   DWORD2(v188) = 0;
/* line: 1191, address: 0x1402c45d3 */   if ( HIDWORD(v188) )
/* line: 1192, address: 0x1402c45df */     sub_14036C7C0(&v188, 0);
/* line: 1193, address: 0x1402c45e4 */   result = 0xFFFFFFFFLL;
/* line: 1194, address: 0x1402c45e9 */   *(_QWORD *)&v192[4] = 0xFFFFFFFFLL;
/* line: 1195, address: 0x1402c45f1 */   v191 = 0;
/* line: 1196, address: 0x1402c4607 */   if ( *(_DWORD *)v192 >= 0x81u )
/* line: 1197 */   {
/* line: 1198, address: 0x1402c466a */     *(_DWORD *)v192 = 128;
/* line: 1199, address: 0x1402c467a */     result = sub_1400038F0(v189);
/* line: 1200 */   }
/* line: 1201, address: 0x1402c4614 */   if ( v190 )
/* line: 1202, address: 0x1402c4681 */     result = sub_141977980(v190, j, a3);
/* line: 1203, address: 0x1402c4621 */   if ( (_QWORD)v188 )
/* line: 1204, address: 0x1402c4688 */     result = sub_141977980(v188, j, a3);
/* line: 1205, address: 0x1402c4635 */   if ( ((unsigned __int64)&v175 ^ v196) != _security_cookie )
/* line: 1206, address: 0x1402c4669 */     __debugbreak();
/* line: 1207, address: 0x1402c4637 */   return result;
/* line: 1208 */ }