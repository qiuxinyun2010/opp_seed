/* line: 0, address: 0x140503b80 */ __int64 __fastcall sub_140503B80(__int64 a1, unsigned int a2)
/* line: 1 */ {
/* line: 2 */   __int64 v2; // rsi
/* line: 3 */   __int64 v3; // rcx
/* line: 4 */   __int64 v4; // rdi
/* line: 5 */   __int64 v5; // r8
/* line: 6 */   int v6; // eax
/* line: 7 */   int v7; // eax
/* line: 8 */   int v8; // ecx
/* line: 9 */   __int64 v9; // r8
/* line: 10 */   __int64 v10; // rbx
/* line: 11 */   __int64 v11; // rax
/* line: 12 */   __int64 v12; // rcx
/* line: 13 */   __int64 v13; // rcx
/* line: 14 */   __int64 v14; // r9
/* line: 15 */   __int64 v15; // r10
/* line: 16 */   __int64 v16; // r11
/* line: 17 */   __int64 v17; // rax
/* line: 18 */   __int64 v18; // rax
/* line: 19 */   __int64 v19; // rcx
/* line: 20 */   int v20; // ebx
/* line: 21 */   int v21; // edi
/* line: 22 */   __int64 v22; // rdx
/* line: 23 */   __int64 v23; // rax
/* line: 24 */   __int64 v24; // r8
/* line: 25 */   __int64 v25; // r9
/* line: 26 */   __int64 v26; // r8
/* line: 27 */   __int64 v27; // rdx
/* line: 28 */   _DWORD *v28; // r8
/* line: 29 */   unsigned __int16 *v29; // rax
/* line: 30 */   unsigned __int16 v30; // r9
/* line: 31 */   unsigned __int16 *v31; // rax
/* line: 32 */   unsigned int v32; // edi
/* line: 33 */   unsigned int v33; // r9d
/* line: 34 */   __int64 v34; // rdx
/* line: 35 */   _DWORD *v35; // r8
/* line: 36 */   unsigned __int16 *v36; // rcx
/* line: 37 */   unsigned __int16 *v37; // rax
/* line: 38 */   unsigned __int16 v38; // r9
/* line: 39 */   unsigned __int16 *v39; // rax
/* line: 40 */   unsigned int v40; // ebx
/* line: 41 */   unsigned int v41; // r9d
/* line: 42 */   int v42; // ebx
/* line: 43 */   unsigned int v43; // esi
/* line: 44 */   __int64 v45; // rcx
/* line: 45 */   unsigned int v46; // ebx
/* line: 46 */   __int64 v47; // rdx
/* line: 47 */   _DWORD *v48; // r8
/* line: 48 */   unsigned __int16 *v49; // rax
/* line: 49 */   unsigned int v50; // ebx
/* line: 50 */   __int64 v51; // rcx
/* line: 51 */   __int64 v52; // rdx
/* line: 52 */   unsigned __int16 v53; // r9
/* line: 53 */   unsigned __int16 *v54; // rax
/* line: 54 */   unsigned int v55; // edi
/* line: 55 */   unsigned int v56; // r9d
/* line: 56 */   int v57; // edi
/* line: 57 */   __int64 v58; // rcx
/* line: 58 */   int v59; // eax
/* line: 59 */   __int64 v60; // rdi
/* line: 60 */   __int64 v61; // rbx
/* line: 61 */   __int64 v62; // rax
/* line: 62 */   __int64 v63; // rcx
/* line: 63 */   __int64 v64; // rcx
/* line: 64 */   __int64 v65; // r9
/* line: 65 */   __int64 v66; // r10
/* line: 66 */   __int64 v67; // r11
/* line: 67 */   __int64 v68; // rdi
/* line: 68 */   unsigned int v69; // ebx
/* line: 69 */   unsigned int v70; // ebx
/* line: 70 */   unsigned int v71; // ebx
/* line: 71 */   unsigned int v72; // ebp
/* line: 72 */   unsigned int v73; // ebx
/* line: 73 */   unsigned int v74; // ebp
/* line: 74 */   unsigned int v75; // ebx
/* line: 75 */   unsigned __int16 *v76; // rcx
/* line: 76 */   _BYTE v77[32]; // [rsp+0h] [rbp-C8h] BYREF
/* line: 77 */   unsigned __int16 *v78; // [rsp+88h] [rbp-40h] BYREF
/* line: 78 */   int v79; // [rsp+90h] [rbp-38h]
/* line: 79 */   __int64 v80; // [rsp+98h] [rbp-30h] BYREF
/* line: 80 */   __int64 v81; // [rsp+A0h] [rbp-28h]
/* line: 81 */ 
/* line: 82, address: 0x140503ba0 */   if ( a1 )
/* line: 83 */   {
/* line: 84, address: 0x140503ba6 */     v2 = a1;
/* line: 85, address: 0x140503ba9 */     while ( 1 )
/* line: 86 */     {
/* line: 87, address: 0x140503ba9 */       v3 = qword_1470F5A78;
/* line: 88, address: 0x140503bb3 */       if ( !qword_1470F5A78 )
/* line: 89 */       {
/* line: 90, address: 0x1405042aa */         v71 = a2;
/* line: 91, address: 0x1405042af */         sub_14035AFB0(
/* line: 92 */           (unsigned int)L"/Script/Engine",
/* line: 93 */           (unsigned int)L"Actor",
/* line: 94 */           (unsigned int)&qword_1470F5A78,
/* line: 95 */           (unsigned int)sub_142AC2920,
/* line: 96 */           560,
/* line: 97 */           8,
/* line: 98 */           268435460,
/* line: 99 */           0x1000000000LL,
/* line: 100 */           (__int64)L"Engine",
/* line: 101 */           (__int64)sub_140C2A0B0,
/* line: 102 */           (__int64)sub_142629270,
/* line: 103 */           (__int64)sub_1400456C0,
/* line: 104 */           (__int64)sub_14035B3C0,
/* line: 105 */           (__int64)sub_14035B3C0,
/* line: 106 */           0,
/* line: 107 */           0);
/* line: 108, address: 0x1405042b4 */         a2 = v71;
/* line: 109, address: 0x1405042b6 */         v3 = qword_1470F5A78;
/* line: 110 */       }
/* line: 111, address: 0x140503bb9 */       v4 = *(_QWORD *)(v2 + 16);
/* line: 112, address: 0x140503bbd */       v5 = *(int *)(v3 + 56);
/* line: 113, address: 0x140503bc1 */       v6 = *(_DWORD *)(v4 + 56);
/* line: 114, address: 0x140503bd9 */       if ( (int)v5 > v6 || *(_QWORD *)(*(_QWORD *)(v4 + 48) + 8 * v5) != v3 + 48 )
/* line: 115, address: 0x140503bd9 */         break;
/* line: 116, address: 0x140503bdf */       v7 = *(_DWORD *)(v2 + 376);
/* line: 117, address: 0x140503c24 */       if ( v7
/* line: 118 */         && (v8 = *(_DWORD *)(v2 + 372), v8 >= 0)
/* line: 119 */         && dword_146F7CD0C > v8
/* line: 120 */         && (v9 = *(_QWORD *)(qword_146F7CCF8 + 8LL * HIWORD(v8)) + 24 * (unsigned int)(unsigned __int16)v8) != 0
/* line: 121 */         && *(_DWORD *)(v9 + 16) == v7
/* line: 122 */         && (*(_BYTE *)(v9 + 11) & 0x30) == 0
/* line: 123 */         && *(_QWORD *)v9 )
/* line: 124 */       {
/* line: 125, address: 0x140504549 */         v75 = a2;
/* line: 126, address: 0x14050454b */         v17 = sub_141E4A060(v2);
/* line: 127, address: 0x140504550 */         a2 = v75;
/* line: 128 */       }
/* line: 129 */       else
/* line: 130 */       {
/* line: 131, address: 0x140503c2e */         v10 = qword_146E7DFC8;
/* line: 132, address: 0x14050413c */         if ( qword_146E7DFC8
/* line: 133 */           || (v69 = a2,
/* line: 134 */               sub_14035AFB0(
/* line: 135 */                 (unsigned int)&asc_14686E07E,
/* line: 136 */                 (unsigned int)L"RBRandomSeedGeneratorInterface",
/* line: 137 */                 (unsigned int)&qword_146E7DFC8,
/* line: 138 */                 (unsigned int)sub_1426BA0A0,
/* line: 139 */                 40,
/* line: 140 */                 8,
/* line: 141 */                 268451841,
/* line: 142 */                 0,
/* line: 143 */                 (__int64)L"Engine",
/* line: 144 */                 (__int64)sub_142DC3540,
/* line: 145 */                 (__int64)sub_142629270,
/* line: 146 */                 (__int64)nullsub_2,
/* line: 147 */                 (__int64)sub_14124F3E0,
/* line: 148 */                 (__int64)sub_14035B3C0,
/* line: 149 */                 0,
/* line: 150 */                 0),
/* line: 151 */               a2 = v69,
/* line: 152 */               (v10 = qword_146E7DFC8) != 0) )
/* line: 153 */         {
/* line: 154, address: 0x140503c45 */           if ( (*(_BYTE *)(v10 + 205) & 0x40) != 0 )
/* line: 155 */           {
/* line: 156, address: 0x140503c47 */             v11 = qword_146F78498;
/* line: 157, address: 0x140503c51 */             if ( !qword_146F78498 )
/* line: 158 */             {
/* line: 159, address: 0x140504348 */               v72 = a2;
/* line: 160, address: 0x14050434d */               sub_14035AFB0(
/* line: 161 */                 (unsigned int)"/",
/* line: 162 */                 (unsigned int)L"Interface",
/* line: 163 */                 (unsigned int)&qword_146F78498,
/* line: 164 */                 (unsigned int)ffxSetPrintMessageCallback,
/* line: 165 */                 40,
/* line: 166 */                 8,
/* line: 167 */                 268451841,
/* line: 168 */                 0,
/* line: 169 */                 (__int64)L"Engine",
/* line: 170 */                 (__int64)sub_141450A40,
/* line: 171 */                 (__int64)sub_143A835E0,
/* line: 172 */                 (__int64)nullsub_2,
/* line: 173 */                 (__int64)sub_14035B3C0,
/* line: 174 */                 (__int64)sub_14035B3C0,
/* line: 175 */                 0,
/* line: 176 */                 0);
/* line: 177, address: 0x140504352 */               a2 = v72;
/* line: 178, address: 0x140504354 */               v11 = qword_146F78498;
/* line: 179 */             }
/* line: 180, address: 0x140503c5a */             if ( v11 != v10 )
/* line: 181 */             {
/* line: 182, address: 0x140503c60 */               while ( 1 )
/* line: 183 */               {
/* line: 184, address: 0x140503c60 */                 v12 = *(unsigned int *)(v4 + 480);
/* line: 185, address: 0x140503c68 */                 if ( (int)v12 > 0 )
/* line: 186, address: 0x140503c68 */                   break;
/* line: 187 */ LABEL_20:
/* line: 188, address: 0x140503c6a */                 v4 = *(_QWORD *)(v4 + 64);
/* line: 189, address: 0x140503c71 */                 if ( !v4 )
/* line: 190, address: 0x140503c71 */                   goto LABEL_28;
/* line: 191 */               }
/* line: 192, address: 0x140503c7c */               v13 = 16 * v12;
/* line: 193, address: 0x140503c80 */               v14 = 0;
/* line: 194, address: 0x140503c83 */               while ( 1 )
/* line: 195 */               {
/* line: 196, address: 0x140503c83 */                 v15 = *(_QWORD *)(*(_QWORD *)(v4 + 472) + v14);
/* line: 197, address: 0x140503c8a */                 if ( v15 )
/* line: 198 */                 {
/* line: 199, address: 0x140503c8c */                   v16 = *(int *)(v10 + 56);
/* line: 200, address: 0x140503c9e */                   if ( (int)v16 <= *(_DWORD *)(v15 + 56) && *(_QWORD *)(*(_QWORD *)(v15 + 48) + 8 * v16) == v10 + 48 )
/* line: 201, address: 0x140503c9e */                     break;
/* line: 202 */                 }
/* line: 203, address: 0x140503ca4 */                 v14 += 16;
/* line: 204, address: 0x140503cab */                 if ( v13 == v14 )
/* line: 205, address: 0x140503cab */                   goto LABEL_20;
/* line: 206 */               }
/* line: 207, address: 0x140503f19 */               v50 = a2;
/* line: 208, address: 0x140503f20 */               v51 = v2;
/* line: 209, address: 0x140503f20 */               return sub_14268B040(v51, v2, v50);
/* line: 210 */             }
/* line: 211 */           }
/* line: 212 */         }
/* line: 213 */ LABEL_28:
/* line: 214, address: 0x140503caf */         v17 = *(_QWORD *)(v2 + 232);
/* line: 215, address: 0x140503cb9 */         if ( !v17 )
/* line: 216 */         {
/* line: 217, address: 0x140503cbf */           v18 = qword_147108770;
/* line: 218, address: 0x140503cc9 */           if ( !qword_147108770 )
/* line: 219 */           {
/* line: 220, address: 0x1405043f2 */             sub_14035AFB0(
/* line: 221 */               (unsigned int)L"/Script/Engine",
/* line: 222 */               (unsigned int)L"Level",
/* line: 223 */               (unsigned int)&qword_147108770,
/* line: 224 */               (unsigned int)ffxSetPrintMessageCallback,
/* line: 225 */               672,
/* line: 226 */               8,
/* line: 227 */               0x10000000,
/* line: 228 */               0x800000000LL,
/* line: 229 */               (__int64)L"Engine",
/* line: 230 */               (__int64)sub_1406CF710,
/* line: 231 */               (__int64)sub_142629270,
/* line: 232 */               (__int64)sub_1418291A0,
/* line: 233 */               (__int64)sub_14035B3C0,
/* line: 234 */               (__int64)sub_14035B3C0,
/* line: 235 */               0,
/* line: 236 */               0);
/* line: 237, address: 0x1405043f7 */             v18 = qword_147108770;
/* line: 238 */           }
/* line: 239, address: 0x140503ccf */           v19 = *(_QWORD *)(v2 + 32);
/* line: 240, address: 0x140503cd3 */           v20 = 0;
/* line: 241, address: 0x140503cd5 */           v21 = 0;
/* line: 242, address: 0x140503cdd */           if ( v19 )
/* line: 243 */           {
/* line: 244, address: 0x140503ce3 */             v22 = *(int *)(v18 + 56);
/* line: 245, address: 0x140503ce7 */             v23 = v18 + 48;
/* line: 246, address: 0x140503d11 */             do
/* line: 247 */             {
/* line: 248, address: 0x140503ceb */               v24 = *(_QWORD *)(v19 + 16);
/* line: 249, address: 0x140503cf3 */               if ( (int)v22 <= *(_DWORD *)(v24 + 56) )
/* line: 250 */               {
/* line: 251, address: 0x140503cf5 */                 v25 = *(_QWORD *)(v24 + 48);
/* line: 252, address: 0x140503cf9 */                 v26 = v19;
/* line: 253, address: 0x140503d00 */                 if ( *(_QWORD *)(v25 + 8 * v22) == v23 )
/* line: 254, address: 0x140503d00 */                   goto LABEL_36;
/* line: 255 */               }
/* line: 256, address: 0x140503d02 */               v26 = 0;
/* line: 257 */ LABEL_36:
/* line: 258, address: 0x140503d08 */               if ( v26 )
/* line: 259, address: 0x140503d08 */                 break;
/* line: 260, address: 0x140503d0a */               v19 = *(_QWORD *)(v19 + 32);
/* line: 261 */             }
/* line: 262, address: 0x140503d11 */             while ( v19 );
/* line: 263, address: 0x140503d16 */             if ( v26 )
/* line: 264 */             {
/* line: 265, address: 0x140503d28 */               v80 = *(_QWORD *)(v26 + 24);
/* line: 266, address: 0x140503d36 */               sub_141C49310(&v80, &v78);
/* line: 267, address: 0x140503d42 */               v29 = (unsigned __int16 *)&FileName;
/* line: 268, address: 0x140503d49 */               if ( v79 )
/* line: 269, address: 0x140503d49 */                 v29 = v78;
/* line: 270, address: 0x140503d4d */               v30 = *v29;
/* line: 271, address: 0x140503d4d */               if ( *v29 )
/* line: 272 */               {
/* line: 273, address: 0x140503d5b */                 v31 = v29 + 1;
/* line: 274, address: 0x140503d5f */                 v32 = -1;
/* line: 275, address: 0x140503d64 */                 v27 = 255;
/* line: 276, address: 0x140503d69 */                 v28 = dword_146CCCA80;
/* line: 277, address: 0x140503dc1 */                 do
/* line: 278 */                 {
/* line: 279, address: 0x140503d96 */                   v33 = dword_146CCCA80[HIBYTE(v30)
/* line: 280 */                                       ^ (unsigned __int8)(LOBYTE(dword_146CCCA80[(unsigned __int8)(v32 ^ v30)])
/* line: 281 */                                                         ^ BYTE1(v32))]
/* line: 282 */                       ^ ((dword_146CCCA80[(unsigned __int8)(v32 ^ v30)] ^ (v32 >> 8)) >> 8);
/* line: 283, address: 0x140503db1 */                   v32 = dword_146CCCA80[(unsigned __int8)(LOBYTE(dword_146CCCA80[(unsigned __int8)v33]) ^ BYTE1(v33))]
/* line: 284 */                       ^ ((dword_146CCCA80[(unsigned __int8)v33] ^ (v33 >> 8)) >> 8);
/* line: 285, address: 0x140503db5 */                   v30 = *v31++;
/* line: 286 */                 }
/* line: 287, address: 0x140503dc1 */                 while ( v30 );
/* line: 288, address: 0x140503dc3 */                 v21 = ~v32;
/* line: 289 */               }
/* line: 290 */               else
/* line: 291 */               {
/* line: 292, address: 0x140504147 */                 v21 = 0;
/* line: 293 */               }
/* line: 294, address: 0x140503dc8 */               if ( v78 )
/* line: 295, address: 0x140503dca */                 sub_141977980(v78, v27, v28);
/* line: 296 */             }
/* line: 297 */             else
/* line: 298 */             {
/* line: 299, address: 0x140504071 */               v21 = 0;
/* line: 300 */             }
/* line: 301 */           }
/* line: 302, address: 0x140503ddb */           v80 = *(_QWORD *)(v2 + 24);
/* line: 303, address: 0x140503de9 */           sub_141C49310(&v80, &v78);
/* line: 304, address: 0x140503df2 */           v36 = v78;
/* line: 305, address: 0x140503df5 */           v37 = (unsigned __int16 *)&FileName;
/* line: 306, address: 0x140503dfc */           if ( v79 )
/* line: 307, address: 0x140503dfc */             v37 = v78;
/* line: 308, address: 0x140503e00 */           v38 = *v37;
/* line: 309, address: 0x140503e00 */           if ( *v37 )
/* line: 310 */           {
/* line: 311, address: 0x140503e0a */             v39 = v37 + 1;
/* line: 312, address: 0x140503e0e */             v40 = -1;
/* line: 313, address: 0x140503e13 */             v34 = 255;
/* line: 314, address: 0x140503e18 */             v35 = dword_146CCCA80;
/* line: 315, address: 0x140503e70 */             do
/* line: 316 */             {
/* line: 317, address: 0x140503e45 */               v41 = dword_146CCCA80[HIBYTE(v38)
/* line: 318 */                                   ^ (unsigned __int8)(LOBYTE(dword_146CCCA80[(unsigned __int8)(v40 ^ v38)]) ^ BYTE1(v40))]
/* line: 319 */                   ^ ((dword_146CCCA80[(unsigned __int8)(v40 ^ v38)] ^ (v40 >> 8)) >> 8);
/* line: 320, address: 0x140503e60 */               v40 = dword_146CCCA80[(unsigned __int8)(LOBYTE(dword_146CCCA80[(unsigned __int8)v41]) ^ BYTE1(v41))]
/* line: 321 */                   ^ ((dword_146CCCA80[(unsigned __int8)v41] ^ (v41 >> 8)) >> 8);
/* line: 322, address: 0x140503e64 */               v38 = *v39++;
/* line: 323 */             }
/* line: 324, address: 0x140503e70 */             while ( v38 );
/* line: 325, address: 0x140503e72 */             v20 = ~v40;
/* line: 326 */           }
/* line: 327, address: 0x140503e74 */           v42 = v21 + v20;
/* line: 328, address: 0x140503e78 */           v43 = -v42;
/* line: 329, address: 0x140503e7a */           if ( v42 > 0 )
/* line: 330, address: 0x140503e7a */             v43 = v42;
/* line: 331, address: 0x140503e7a */           goto LABEL_55;
/* line: 332 */         }
/* line: 333, address: 0x140503fdc */         v60 = *(_QWORD *)(v17 + 16);
/* line: 334, address: 0x140503fe3 */         if ( v60 )
/* line: 335 */         {
/* line: 336, address: 0x140503fe9 */           v61 = qword_146E7DFC8;
/* line: 337, address: 0x1405041f1 */           if ( qword_146E7DFC8
/* line: 338 */             || (v70 = a2,
/* line: 339 */                 sub_14035AFB0(
/* line: 340 */                   (unsigned int)&asc_14686E07E,
/* line: 341 */                   (unsigned int)L"RBRandomSeedGeneratorInterface",
/* line: 342 */                   (unsigned int)&qword_146E7DFC8,
/* line: 343 */                   (unsigned int)sub_1426BA0A0,
/* line: 344 */                   40,
/* line: 345 */                   8,
/* line: 346 */                   268451841,
/* line: 347 */                   0,
/* line: 348 */                   (__int64)L"Engine",
/* line: 349 */                   (__int64)sub_142DC3540,
/* line: 350 */                   (__int64)sub_142629270,
/* line: 351 */                   (__int64)nullsub_2,
/* line: 352 */                   (__int64)sub_14124F3E0,
/* line: 353 */                   (__int64)sub_14035B3C0,
/* line: 354 */                   0,
/* line: 355 */                   0),
/* line: 356 */                 a2 = v70,
/* line: 357 */                 (v61 = qword_146E7DFC8) != 0) )
/* line: 358 */           {
/* line: 359, address: 0x140504000 */             if ( (*(_BYTE *)(v61 + 205) & 0x40) != 0 )
/* line: 360 */             {
/* line: 361, address: 0x140504006 */               v62 = qword_146F78498;
/* line: 362, address: 0x140504010 */               if ( !qword_146F78498 )
/* line: 363 */               {
/* line: 364, address: 0x14050452e */                 v74 = a2;
/* line: 365, address: 0x140504533 */                 sub_14035AFB0(
/* line: 366 */                   (unsigned int)"/",
/* line: 367 */                   (unsigned int)L"Interface",
/* line: 368 */                   (unsigned int)&qword_146F78498,
/* line: 369 */                   (unsigned int)ffxSetPrintMessageCallback,
/* line: 370 */                   40,
/* line: 371 */                   8,
/* line: 372 */                   268451841,
/* line: 373 */                   0,
/* line: 374 */                   (__int64)L"Engine",
/* line: 375 */                   (__int64)sub_141450A40,
/* line: 376 */                   (__int64)sub_143A835E0,
/* line: 377 */                   (__int64)nullsub_2,
/* line: 378 */                   (__int64)sub_14035B3C0,
/* line: 379 */                   (__int64)sub_14035B3C0,
/* line: 380 */                   0,
/* line: 381 */                   0);
/* line: 382, address: 0x140504538 */                 a2 = v74;
/* line: 383, address: 0x14050453a */                 v62 = qword_146F78498;
/* line: 384 */               }
/* line: 385, address: 0x140504019 */               if ( v62 != v61 )
/* line: 386 */               {
/* line: 387, address: 0x140504023 */                 while ( 1 )
/* line: 388 */                 {
/* line: 389, address: 0x140504023 */                   v63 = *(unsigned int *)(v60 + 480);
/* line: 390, address: 0x14050402b */                   if ( (int)v63 > 0 )
/* line: 391, address: 0x14050402b */                     break;
/* line: 392 */ LABEL_84:
/* line: 393, address: 0x14050402d */                   v60 = *(_QWORD *)(v60 + 64);
/* line: 394, address: 0x140504034 */                   if ( !v60 )
/* line: 395, address: 0x140504034 */                     goto LABEL_98;
/* line: 396 */                 }
/* line: 397, address: 0x140504042 */                 v64 = 16 * v63;
/* line: 398, address: 0x140504046 */                 v65 = 0;
/* line: 399, address: 0x140504049 */                 while ( 1 )
/* line: 400 */                 {
/* line: 401, address: 0x140504049 */                   v66 = *(_QWORD *)(*(_QWORD *)(v60 + 472) + v65);
/* line: 402, address: 0x140504050 */                   if ( v66 )
/* line: 403 */                   {
/* line: 404, address: 0x140504052 */                     v67 = *(int *)(v61 + 56);
/* line: 405, address: 0x140504064 */                     if ( (int)v67 <= *(_DWORD *)(v66 + 56) && *(_QWORD *)(*(_QWORD *)(v66 + 48) + 8 * v67) == v61 + 48 )
/* line: 406, address: 0x140504064 */                       break;
/* line: 407 */                   }
/* line: 408, address: 0x140504066 */                   v65 += 16;
/* line: 409, address: 0x14050406d */                   if ( v64 == v65 )
/* line: 410, address: 0x14050406d */                     goto LABEL_84;
/* line: 411 */                 }
/* line: 412, address: 0x140504078 */                 v68 = *(_QWORD *)(v2 + 232);
/* line: 413, address: 0x14050408a */                 v50 = a2;
/* line: 414, address: 0x14050408c */                 _security_check_cookie((unsigned __int64)v77 ^ v81);
/* line: 415, address: 0x140504091 */                 v51 = v68;
/* line: 416, address: 0x140503f34 */                 return sub_14268B040(v51, v2, v50);
/* line: 417 */               }
/* line: 418 */             }
/* line: 419 */           }
/* line: 420 */ LABEL_98:
/* line: 421, address: 0x1405041f7 */           v17 = *(_QWORD *)(v2 + 232);
/* line: 422 */         }
/* line: 423 */       }
/* line: 424, address: 0x1405041fe */       v2 = v17;
/* line: 425, address: 0x140504204 */       if ( !v17 )
/* line: 426, address: 0x140504204 */         goto LABEL_100;
/* line: 427 */     }
/* line: 428, address: 0x140503eaf */     v45 = qword_1470F6018;
/* line: 429, address: 0x140503eb9 */     if ( !qword_1470F6018 )
/* line: 430 */     {
/* line: 431, address: 0x140504489 */       v73 = a2;
/* line: 432, address: 0x14050448e */       sub_14035AFB0(
/* line: 433 */         (unsigned int)L"/Script/Engine",
/* line: 434 */         (unsigned int)L"ActorComponent",
/* line: 435 */         (unsigned int)&qword_1470F6018,
/* line: 436 */         (unsigned int)sub_142AC4340,
/* line: 437 */         184,
/* line: 438 */         8,
/* line: 439 */         268435457,
/* line: 440 */         0,
/* line: 441 */         (__int64)L"Engine",
/* line: 442 */         (__int64)sub_142AC49A0,
/* line: 443 */         (__int64)sub_142629270,
/* line: 444 */         (__int64)nullsub_2,
/* line: 445 */         (__int64)sub_14035B3C0,
/* line: 446 */         (__int64)sub_14035B3C0,
/* line: 447 */         0,
/* line: 448 */         0);
/* line: 449, address: 0x140504493 */       a2 = v73;
/* line: 450, address: 0x140504495 */       v45 = qword_1470F6018;
/* line: 451, address: 0x14050449c */       v4 = *(_QWORD *)(v2 + 16);
/* line: 452, address: 0x1405044a0 */       v6 = *(_DWORD *)(v4 + 56);
/* line: 453 */     }
/* line: 454, address: 0x140503ebf */     v46 = a2;
/* line: 455, address: 0x140503ec1 */     v47 = *(int *)(v45 + 56);
/* line: 456, address: 0x140503ed9 */     if ( (int)v47 <= v6 && *(_QWORD *)(*(_QWORD *)(v4 + 48) + 8 * v47) == v45 + 48 )
/* line: 457 */     {
/* line: 458, address: 0x140503eeb */       v80 = *(_QWORD *)(v2 + 24);
/* line: 459, address: 0x140503ef9 */       sub_141C49310(&v80, &v78);
/* line: 460, address: 0x140503f02 */       if ( v79 )
/* line: 461, address: 0x140503f04 */         v49 = v78;
/* line: 462 */       else
/* line: 463, address: 0x140503f39 */         v49 = (unsigned __int16 *)&FileName;
/* line: 464, address: 0x140503f40 */       v52 = v46;
/* line: 465, address: 0x140503f42 */       v53 = *v49;
/* line: 466, address: 0x140503f42 */       if ( *v49 )
/* line: 467 */       {
/* line: 468, address: 0x140503f50 */         v54 = v49 + 1;
/* line: 469, address: 0x140503f54 */         v55 = -1;
/* line: 470, address: 0x140503f5e */         v48 = dword_146CCCA80;
/* line: 471, address: 0x140503fb6 */         do
/* line: 472 */         {
/* line: 473, address: 0x140503f8b */           v56 = dword_146CCCA80[HIBYTE(v53)
/* line: 474 */                               ^ (unsigned __int8)(LOBYTE(dword_146CCCA80[(unsigned __int8)(v55 ^ v53)]) ^ BYTE1(v55))]
/* line: 475 */               ^ ((dword_146CCCA80[(unsigned __int8)(v55 ^ v53)] ^ (v55 >> 8)) >> 8);
/* line: 476, address: 0x140503fa6 */           v55 = dword_146CCCA80[(unsigned __int8)(LOBYTE(dword_146CCCA80[(unsigned __int8)v56]) ^ BYTE1(v56))]
/* line: 477 */               ^ ((dword_146CCCA80[(unsigned __int8)v56] ^ (v56 >> 8)) >> 8);
/* line: 478, address: 0x140503faa */           v53 = *v54++;
/* line: 479 */         }
/* line: 480, address: 0x140503fb6 */         while ( v53 );
/* line: 481, address: 0x140503fb8 */         v57 = ~v55;
/* line: 482 */       }
/* line: 483 */       else
/* line: 484 */       {
/* line: 485, address: 0x140504211 */         v57 = 0;
/* line: 486 */       }
/* line: 487, address: 0x140503fba */       v58 = *(_QWORD *)(v2 + 168);
/* line: 488 */     }
/* line: 489 */     else
/* line: 490 */     {
/* line: 491, address: 0x140504563 */       v80 = *(_QWORD *)(v2 + 24);
/* line: 492, address: 0x140504571 */       sub_141C49310(&v80, &v78);
/* line: 493, address: 0x14050457a */       if ( v79 )
/* line: 494, address: 0x14050457c */         v76 = v78;
/* line: 495 */       else
/* line: 496, address: 0x140504586 */         v76 = (unsigned __int16 *)&FileName;
/* line: 497, address: 0x140504594 */       v57 = sub_141CBDC30(v76, 0);
/* line: 498, address: 0x140504596 */       v58 = *(_QWORD *)(v2 + 32);
/* line: 499, address: 0x14050459a */       v52 = 0;
/* line: 500 */     }
/* line: 501, address: 0x140503fc6 */     v59 = v57 + sub_140503B80(v58, v52, v48);
/* line: 502, address: 0x140503fca */     v43 = -v59;
/* line: 503, address: 0x140503fcc */     if ( v59 > 0 )
/* line: 504, address: 0x140503fcc */       v43 = v59;
/* line: 505, address: 0x140503fcf */     v36 = v78;
/* line: 506 */ LABEL_55:
/* line: 507, address: 0x140503e80 */     if ( v36 )
/* line: 508, address: 0x140503e82 */       sub_141977980(v36, v34, v35);
/* line: 509 */   }
/* line: 510 */   else
/* line: 511 */   {
/* line: 512 */ LABEL_100:
/* line: 513, address: 0x14050420a */     v43 = 0;
/* line: 514 */   }
/* line: 515, address: 0x140503e99 */   if ( ((unsigned __int64)v77 ^ v81) != _security_cookie )
/* line: 516 */   {
/* line: 517, address: 0x140503ea9 */     _security_check_cookie((unsigned __int64)v77 ^ v81);
/* line: 518, address: 0x140503eae */     __debugbreak();
/* line: 519 */   }
/* line: 520, address: 0x140503e9d */   return v43;
/* line: 521 */ }