/* line: 0, address: 0x14268b040 */ __int64 __fastcall sub_14268B040(__int64 a1, __int64 a2, unsigned int a3)
/* line: 1 */ {
/* line: 2 */   __int64 v6; // rax
/* line: 3 */   __int64 result; // rax
/* line: 4 */   __int64 v8; // rax
/* line: 5 */   __int64 v9; // rax
/* line: 6 */   __int64 v10; // [rsp+0h] [rbp-58h] BYREF
/* line: 7 */   __int64 v11; // [rsp+20h] [rbp-38h] BYREF
/* line: 8 */   char v12; // [rsp+28h] [rbp-30h]
/* line: 9 */   unsigned int v13; // [rsp+2Ch] [rbp-2Ch]
/* line: 10 */   __int64 v14; // [rsp+30h] [rbp-28h]
/* line: 11 */ 
/* line: 12, address: 0x14268b061 */   v13 = 0;
/* line: 13, address: 0x14268b070 */   v6 = sub_141DD7F00(a1, qword_146E7DFD0);
/* line: 14, address: 0x14268b078 */   if ( v6 )
/* line: 15 */   {
/* line: 16, address: 0x14268b07f */     v11 = a2;
/* line: 17, address: 0x14268b082 */     v12 = a3;
/* line: 18, address: 0x14268b092 */     (*(void (__fastcall **)(__int64, __int64, __int64 *))(*(_QWORD *)a1 + 544LL))(a1, v6, &v11);
/* line: 19, address: 0x14268b099 */     result = v13;
/* line: 20 */   }
/* line: 21 */   else
/* line: 22 */   {
/* line: 23, address: 0x14268b0be */     v8 = sub_140819580();
/* line: 24, address: 0x14268b0c9 */     v9 = sub_143AC6F90(a1, v8);
/* line: 25, address: 0x14268b0d1 */     if ( v9 )
/* line: 26, address: 0x14268b0ff */       return (*(__int64 (__fastcall **)(__int64, __int64, _QWORD))(*(_QWORD *)v9 + 16LL))(v9, a2, a3);
/* line: 27, address: 0x14268b102 */     result = 0;
/* line: 28 */   }
/* line: 29, address: 0x14268b0ac */   if ( ((unsigned __int64)&v10 ^ v14) != _security_cookie )
/* line: 30, address: 0x14268b0bd */     __debugbreak();
/* line: 31, address: 0x14268b0ae */   return result;
/* line: 32 */ }