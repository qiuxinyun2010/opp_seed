/* line: 0, address: 0x1413f02f0 */ __int64 __usercall sub_1413F02F0@<xmm0>(unsigned int a1@<ecx>)
/* line: 1 */ {
/* line: 2 */   unsigned __int64 v1; // r9
/* line: 3 */   unsigned __int64 v2; // r8
/* line: 4 */   int v3; // eax
/* line: 5 */   __int64 result; // xmm0_8
/* line: 6 */   int v5; // ecx
/* line: 7 */ 
/* line: 8, address: 0x1413f02fc */   if ( !dword_146E2E5C4 )
/* line: 9, address: 0x1413f03da */     return 0;
/* line: 10, address: 0x1413f0304 */   if ( a1 )
/* line: 11 */   {
/* line: 12, address: 0x1413f035e */     v1 = (0x94D049BB133111EBuLL
/* line: 13 */         * ((0xBF58476D1CE4E5B9uLL * (a1 ^ (a1 >> 30))) ^ ((0xBF58476D1CE4E5B9uLL * (a1 ^ (a1 >> 30))) >> 27)))
/* line: 14 */        ^ (0x94D049BB133111EBuLL
/* line: 15 */         * ((0xBF58476D1CE4E5B9uLL * (dword_146E2E5C4 % 0x3E8u))
/* line: 16 */          ^ ((0xBF58476D1CE4E5B9uLL * (dword_146E2E5C4 % 0x3E8u)) >> 27)));
/* line: 17, address: 0x1413f0375 */     v2 = 0xBF58476D1CE4E5B9uLL * (v1 ^ (v1 >> 31) ^ ((v1 ^ (v1 >> 31)) >> 30));
/* line: 18, address: 0x1413f038e */     v3 = (321982955 * (v2 ^ (v2 >> 27))) ^ ((0x94D049BB133111EBuLL * (v2 ^ (v2 >> 27))) >> 31);
/* line: 19 */   }
/* line: 20 */   else
/* line: 21 */   {
/* line: 22, address: 0x1413f03c6 */     v5 = (int)(float)((float)((float)(rand() & 0x7FFF) / 32767.0) * 65535.0);
/* line: 23, address: 0x1413f03ca */     LOWORD(v3) = -2;
/* line: 24, address: 0x1413f03d5 */     if ( v5 < 65534 )
/* line: 25, address: 0x1413f03d5 */       LOWORD(v3) = v5;
/* line: 26 */   }
/* line: 27, address: 0x1413f0393 */   HIDWORD(result) = 0;
/* line: 28, address: 0x1413f039a */   *(float *)&result = (float)(unsigned __int16)v3 * 0.000015258789;
/* line: 29, address: 0x1413f03a2 */   return result;
/* line: 30 */ }