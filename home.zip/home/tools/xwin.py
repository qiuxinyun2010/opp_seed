# -*- coding: utf-8 -*-
"""打印一段 .text 的原始字节，并把 E8/E9 rel32 解析成目标地址（粗读指令流用）。

    python xwin.py 0x1402B1A60 0x1402B1BC0
    python xwin.py 0x1402B1A60 0x1402B1BC0 --16
"""
import struct
import sys
import os

_HERE = os.path.dirname(os.path.abspath(__file__))
sys.path.insert(0, _HERE)
import vaq


def main():
    lo = int(sys.argv[1], 16)
    hi = int(sys.argv[2], 16)
    per = 16 if '--16' in sys.argv else 8
    off = vaq.va2off(lo)
    data = vaq.d[off:off + (hi - lo)]
    i = 0
    while i < len(data):
        va = lo + i
        chunk = data[i:i + per]
        note = ''
        for j in range(len(chunk) - 4):
            if chunk[j] in (0xE8, 0xE9):
                rel = struct.unpack_from('<i', chunk, j + 1)[0]
                tgt = va + j + 5 + rel
                note = '  %s@+%d -> %X' % ('call' if chunk[j] == 0xE8 else 'jmp', j, tgt)
                break
        print('%08X  %s%s' % (va, ' '.join('%02x' % b for b in chunk), note))
        i += per


if __name__ == '__main__':
    main()
