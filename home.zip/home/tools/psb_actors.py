# -*- coding: utf-8 -*-
"""关卡 JSON 里 41 具尸体 actor 的真实顺序（= 排序器的输入顺序候选）。

用法： python tools/psb_actors.py           # 打印顺序
       python tools/psb_actors.py dump      # 写 tools/_actor_order.json
"""
import json, os, sys
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.abspath(__file__))))
sys.stdout.reconfigure(encoding='utf-8')

BASE = r'd:\workspace\outlast\pak\OPP\Content\Maps_json\PoliceStationBasement'
P = 'CorpseSearch_PS_Trial02_'
TYPES = ('CorpseSearch_PS_Trial02_AgainstWall_BP_C',
         'CorpseSearch_PS_Trial02_BP_C',
         'CorpseSearch_PS_Trial02_Desk_BP_C',
         'CorpseSearch_PS_Trial02_OnChair_BP_C',
         'CorpseSearch_PS_Trial02_WallThroat_BP_C')
OUT = os.path.join(os.path.dirname(os.path.abspath(__file__)), '_actor_order.json')


def load():
    objs = []
    for fn in ('PSB_MT01_B00.json', 'PSB_MT01_B01.json'):
        with open(os.path.join(BASE, fn), encoding='utf-8') as fp:
            for o in json.load(fp):
                o['__file'] = fn
                objs.append(o)
    return objs


def order(objs):
    byname = {}
    for o in objs:
        if str(o.get('Type')) in TYPES:
            byname[str(o.get('Name'))] = o
    # JSON 里的出现顺序
    seq = [str(o.get('Name')) for o in objs if str(o.get('Type')) in TYPES]
    return seq, byname


def main():
    objs = load()
    seq, byname = order(objs)
    import psb_mt01_static as S
    sec = {c['actor']: c['sector'] for c in S.CORPSES}
    print('JSON 顺序 %d 具；静态表 %d 具' % (len(seq), len(S.CORPSES)))
    print('%-4s %-4s %-28s %s' % ('#', '扇区', 'actor', 'Type'))
    for i, n in enumerate(seq):
        t = str(byname[n].get('Type')).replace(P, '')
        print('%-4d %-4s %-28s %s' % (i, sec.get(n, '?'), n.replace(P, ''), t))
    print('')
    print('JSON 顺序 == 静态表顺序 :', seq == [c['actor'] for c in S.CORPSES])
    print('JSON 顺序扇区串         :', ''.join(sec.get(n, '?') for n in seq[:30]))
    if len(sys.argv) > 1 and sys.argv[1] == 'dump':
        with open(OUT, 'w', encoding='utf-8') as fp:
            json.dump(seq, fp, ensure_ascii=False, indent=1)
        print('已写入 %s' % OUT)


if __name__ == '__main__':
    main()
