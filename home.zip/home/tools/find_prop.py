"""在 exe 中定位 UE4 属性名常量，换算 RVA/VA（image base 0x140000000）。"""
import struct
import sys

EXE = r"D:\workspace\outlast\TOTClient-Win64-Shipping.exe"
BASE = 0x140000000


def sections(path):
    data = open(path, "rb").read()
    pe = struct.unpack_from("<I", data, 0x3C)[0]
    nsec = struct.unpack_from("<H", data, pe + 6)[0]
    optsz = struct.unpack_from("<H", data, pe + 20)[0]
    opt = pe + 24
    image_base = struct.unpack_from("<Q", data, opt + 24)[0]
    sec = opt + optsz
    out = []
    for i in range(nsec):
        s = sec + i * 40
        name = data[s:s + 8].rstrip(b"\x00").decode(errors="replace")
        vsize, vaddr, rsize, raddr = struct.unpack_from("<IIII", data, s + 8)
        out.append((name, vaddr, vsize, raddr, rsize))
    return data, image_base, out


def main():
    targets = sys.argv[1:] or [
        "CluePanelOrderInfos", "PossibleClueNames", "OrderedClueActors",
        "DesiredCount", "PossibleClueData", "ClueDataName", "DecalLocationIndex",
    ]
    data, image_base, secs = sections(EXE)
    print("image_base=0x%X sections=%d" % (image_base, len(secs)))
    for t in targets:
        pat = t.encode() + b"\x00"
        hits = []
        start = 0
        while True:
            i = data.find(pat, start)
            if i < 0:
                break
            hits.append(i)
            start = i + 1
        print("\n== %s : %d hit(s)" % (t, len(hits)))
        for i in hits:
            for name, vaddr, vsize, raddr, rsize in secs:
                if raddr <= i < raddr + rsize:
                    print("   file=0x%X  sec=%s  rva=0x%X  va=0x%X" % (i, name, vaddr + (i - raddr), image_base + vaddr + (i - raddr)))
                    break
            else:
                print("   file=0x%X  (no section)" % i)


main()
