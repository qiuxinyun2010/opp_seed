# -*- coding: utf-8 -*-
"""PSB_MT01 图案抽取拟合（第二轮：通用形态扫描）。

形态：
  A. 无删除   idx_i = RandSeeded(K + i,        |pool|)
  B. 保序删除 idx_i = RandSeeded(K + i,        |pool| 递减)
  C. 无删除   idx_i = RandSeeded(K + 46541+i,  |pool|)      （CHJ_MT02 / MHS 的 clue 组偏移）
  D. 保序删除 idx_i = RandSeeded(K + 46541+i,  |pool|)
K 以 base（协调器/锁位的 GetSeed）+ 偏移的形式扫描。
"""
import os
import sys

sys.path.insert(0, os.path.abspath(os.path.join(os.path.dirname(__file__), '..', '..', 'seed')))
import seedcore as sc  # noqa: E402

M32 = 0xFFFFFFFF
POOL = ['Bunny', 'Club', 'Diamond', 'Fire', 'Heart', 'Spade', 'Eye', 'Star', 'Crown', 'Moon']

SAMPLES = [
    (111111, ['Star', 'Bunny', 'Diamond']),
    (565565, ['Heart', 'Club', 'Eye']),
]

LVL = 'PersistentLevel'
COORD = 'PSB_MT01_B01_CorpseSearch_3'
DESTS = ['KeyItemDestination_Device_Base_BP2',
         'KeyItemDestination_Device_Base_BP3',
         'KeyItemDestination_Device_Base_BP_2']
SCAN = 300000


def run(form, base, n=10):
    idxs = []
    pool_size = n
    for i in range(3):
        if form in ('C', 'D'):
            k = 46541 + i
        else:
            k = i
        idx = sc.rand_seeded((base + k) & M32, pool_size, None)
        idxs.append(idx)
        if form in ('B', 'D'):
            pool_size -= 1
    return idxs


def main():
    lvl = sc.crc32_fname(LVL)
    coord = sc.seed_of_object(COORD, lvl)
    bases = [('coord', coord), ('zero', 0)]
    for d in DESTS:
        bases.append((d, sc.seed_of_object(d, lvl)))

    for form in ('A', 'B', 'C', 'D'):
        for name, base0 in bases:
            hits = []
            for k in range(SCAN):
                ok = True
                for seed, want in SAMPLES:
                    salt = seed % 1000
                    pool = list(POOL)
                    got = []
                    for i in range(3):
                        off = 46541 + i if form in ('C', 'D') else i
                        idx = sc.rand_seeded((base0 + k + off) & M32, len(pool), salt)
                        got.append(pool.pop(idx) if form in ('B', 'D') else pool[idx])
                    if got != want:
                        ok = False
                        break
                if ok:
                    hits.append(k)
            if hits:
                print('form %s base %-38s hits=%s' % (form, name, hits[:12]))

    # 直接看几个「好看」的常量
    for const in (46541, 0, 1, 7168, 28088, 48688, 93405):
        for form in ('B',):
            for seed, want in SAMPLES:
                salt = seed % 1000
                print('%d salt=%d const=%d -> %s (want %s)'
                      % (seed, salt, const, run(form, const)[0:3], want))


if __name__ == '__main__':
    main()
