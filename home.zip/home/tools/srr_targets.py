# -*- coding: utf-8 -*-
"""假设「3 个目标」是从该轮 6 台里再抽的一个有序 3 元组（与机器抽取解耦）。

6 台的集合已知（实测），只需它们的排列顺序 —— 这里先试「池序」（按池中下标升序）。
目标在池序列表里的位置：
  轮2 School  417: [0,1,4]   737: [3,0,4]      （6 台）
  轮3 SasExit 417: [2,4,3]   737: [2,4,0]      （6 台）
  轮1 Rich    417: [0,1,2]   737: [1,2,3]      （4 台）

逐个无放回抽 3 个，两个 seed 同时 → 1/120² = 1/14400（轮1 是 1/24²=1/576）。
"""
import sys

M32 = 0xFFFFFFFF
M64 = 0xFFFFFFFFFFFFFFFF

_T = []
for _i in range(256):
    _c = _i
    for _ in range(8):
        _c = ((_c >> 1) ^ 0xEDB88320) if (_c & 1) else (_c >> 1)
    _T.append(_c & M32)


def crc32_fname(text):
    crc = M32
    for ch in text:
        u = ord(ch) & 0xFFFF
        crc = _T[(crc ^ (u & 0xFF)) & 0xFF] ^ (crc >> 8)
        crc = _T[(crc ^ (u >> 8)) & 0xFF] ^ (crc >> 8)
        crc = _T[crc & 0xFF] ^ (crc >> 8)
        crc = _T[crc & 0xFF] ^ (crc >> 8)
    return (~crc) & M32


def seed_of_object(name):
    value = (crc32_fname(name) + crc32_fname('PersistentLevel')) & M32
    return value if value < 0x80000000 else (0x100000000 - value) & M32


def mix1(x):
    z = (0xBF58476D1CE4E5B9 * (x ^ (x >> 30))) & M64
    return z ^ (z >> 27)


def rs(seed, n, salt):
    if not n or not seed:
        return 0
    B = (0x94D049BB133111EB * mix1(salt % 1000)) & M64
    v = ((0x94D049BB133111EB * mix1(seed)) & M64) ^ B
    t = (v ^ (v >> 31)) & M64
    w = (0xBF58476D1CE4E5B9 * (t ^ (t >> 30))) & M64
    u = (w ^ (w >> 27)) & M64
    r = (((321982955 * u) & M64) ^ (((0x94D049BB133111EB * u) & M64) >> 31)) & M64
    return (r & 0xFFFF) % n


sys.path.insert(0, '.')
import srr_mt02 as M

POOL = {k: M.COORDS[k]['pool'] for k in ('RichDistrict', 'School', 'SasExit')}
COORD = {k: M.COORDS[k]['actor'] for k in ('RichDistrict', 'School', 'SasExit')}

# 该轮的 6 台（4 台）/ 该轮的 3 个目标（按屏幕顺序）
PICKS = {
    ('RichDistrict', 417417): ['BP', 'BP2', 'BP3', 'BP49'],
    ('RichDistrict', 737737): ['BP', 'BP2', 'BP3', 'BP49'],
    ('School', 417417): ['BP24', 'BP26', 'BP29', 'BP6', 'BP5', 'BP19'],
    ('School', 737737): ['BP25', 'BP27_3', 'BP5', 'BP21', 'BP11', 'BP8'],
    ('SasExit', 417417): ['BP31', 'BP38', 'BP43', 'BP36', 'BP45', 'BP47'],
    ('SasExit', 737737): ['BP30', 'BP33', 'BP40', 'BP37', 'BP45', 'BP47'],
}
TARGET = {
    ('RichDistrict', 417417): ['BP', 'BP2', 'BP3'],
    ('RichDistrict', 737737): ['BP2', 'BP3', 'BP49'],
    ('School', 417417): ['BP24', 'BP26', 'BP5'],
    ('School', 737737): ['BP21', 'BP25', 'BP11'],
    ('SasExit', 417417): ['BP43', 'BP45', 'BP36'],
    ('SasExit', 737737): ['BP40', 'BP45', 'BP30'],
}
SALT_CRC = crc32_fname('Objective Actors')


def ordered_pool(key, seed):
    """按池下标升序排列该轮的机器。"""
    pool = POOL[key]
    return sorted(PICKS[(key, seed)], key=lambda a: pool.index(a))


def draw(seq, base, off, salt, swap=True):
    mem = list(seq)
    out = []
    for i in range(3):
        k = rs((base + off + i) & M32, len(mem), salt)
        out.append(mem[k])
        if swap:
            mem[k] = mem[-1]
            mem.pop()
        else:
            del mem[k]
    return out


def main():
    span = int(sys.argv[1]) if len(sys.argv) > 1 else 200000
    for key in ('School', 'SasExit', 'RichDistrict'):
        b0 = seed_of_object(COORD[key])
        for btag, base in (('coord', b0), ('+salt', (b0 + SALT_CRC) & M32)):
            for swap in (True, False):
                hits = []
                for off in range(span):
                    ok = True
                    for seed in (417417, 737737):
                        if draw(ordered_pool(key, seed), base, off, seed, swap) != TARGET[(key, seed)]:
                            ok = False
                            break
                    if ok:
                        hits.append(off)
                print('%-13s %-6s swap=%-5s 命中 offset: %s'
                      % (key, btag, swap, hits[:6] if hits else '无'))
                if hits:
                    o0 = hits[0]
                    for seed in (417417, 737737):
                        print('     %d 预测 %s 实测 %s'
                              % (seed, draw(ordered_pool(key, seed), base, o0, seed, swap),
                                 TARGET[(key, seed)]))


if __name__ == '__main__':
    main()
