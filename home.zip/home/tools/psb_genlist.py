# -*- coding: utf-8 -*-
"""导出 41 具尸体（扇区 + 名字，关卡 actor 顺序）给 C 扫描器。"""
import os, sys
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.abspath(__file__))))
sys.stdout.reconfigure(encoding='utf-8')
import psb_mt01_static as S

OUT = os.path.join(os.path.dirname(os.path.abspath(__file__)), '_corpses.txt')
with open(OUT, 'w', encoding='utf-8') as fp:
    for c in S.CORPSES:
        fp.write('%s %s\n' % (c['sector'], c['actor']))
print('已写入 %s（%d 行）' % (OUT, len(S.CORPSES)))
