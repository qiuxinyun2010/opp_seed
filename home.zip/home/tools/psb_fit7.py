# -*- coding: utf-8 -*-
"""PSB_MT01 第七轮：放宽 d 的搜索范围（到 2^20），并用「A 区两条约束」做第一层过滤。

约束（565565 实测，A 区 = 第一组时 v70 = 0）：
    真钥匙尸体 = A 区第 1 具（AgainstWall_BP3_8）   → RandSeeded(B+243551, 15) == 1
    图案       = Heart                          → RandSeeded(B+223551, 10) == 4
第二层：B/C 组完整模拟（含删除），核对
    B 区尸体 BP10_35（组内 0）、图案 Club
    C 区尸体 AgainstWall_BP9_2（组内 3）、图案 Eye
第三层：111111 的 A/B/C 图案 Star/Bunny/Diamond
"""
import os
import sys

sys.path.insert(0, os.path.abspath(os.path.join(os.path.dirname(__file__), '..', '..', 'seed')))
import seedcore as sc  # noqa: E402

POOL = ['Bunny', 'Club', 'Diamond', 'Fire', 'Heart', 'Spade', 'Crown', 'Eye', 'Moon', 'Star']
A_LIST = [0, 1, 2, 4, 8, 15, 16, 17, 18, 19, 22, 33, 34, 35, 40]
B_LIST = [9, 10, 21, 23, 24, 25, 26, 32, 36, 37]
C_LIST = [3, 5, 6, 7, 11, 12, 13, 14, 20, 27, 28, 29, 30, 31, 38, 39]
LISTS = {'A': A_LIST, 'B': B_LIST, 'C': C_LIST}

COORD = 'PSB_MT01_B01_CorpseSearch_3'
SCAN = 1 << 20


def simulate(seed, base, order, counts):
    salt = seed % 1000
    pool = list(POOL)
    v70 = 0
    key = {}
    for sec, cnt in zip(order, counts):
        g = list(LISTS[sec])
        if cnt > len(g):
            return None
        for v71 in range(cnt):
            if not pool:
                return None
            ci = sc.rand_seeded((base + 243551 + v71 + v70) & 0xFFFFFFFF, len(g), salt)
            g.pop(ci)
            pi = sc.rand_seeded((base + 223551 + v71 + v70) & 0xFFFFFFFF, len(pool), salt)
            pat = pool.pop(pi)
            if v71 == 0:
                key[sec] = (ci, pat)
            v70 += 1
    return key


def main():
    try:
        sys.stdout.reconfigure(encoding='utf-8')
    except Exception:
        pass
    lvl = sc.crc32_fname('PersistentLevel')
    coord = sc.seed_of_object(COORD, lvl)
    s1, s2 = 565565, 111111
    print('GetSeed(coord)=0x%08X  扫描 d=0..%d' % (coord, SCAN - 1))

    cfgs = []
    for order in (('A', 'B', 'C'), ('A', 'C', 'B')):
        for counts in ((3, 3, 3), (3, 3, 4), (3, 4, 3), (4, 3, 3)):
            cfgs.append((order, counts))

    cand = 0
    for d in range(SCAN):
        base = (coord + d) & 0xFFFFFFFF
        if sc.rand_seeded((base + 243551) & 0xFFFFFFFF, 15, s1 % 1000) != 1:
            continue
        if sc.rand_seeded((base + 223551) & 0xFFFFFFFF, 10, s1 % 1000) != 4:
            continue
        cand += 1
        for order, counts in cfgs:
            r1 = simulate(s1, base, order, counts)
            if not r1 or r1['A'][0] != 1 or r1['A'][1] != 'Heart':
                continue
            if r1['B'] != (0, 'Club') or r1['C'] != (3, 'Eye'):
                continue
            r2 = simulate(s2, base, order, counts)
            if not r2:
                continue
            if (r2['A'][1], r2['B'][1], r2['C'][1]) != ('Star', 'Bunny', 'Diamond'):
                continue
            print('  ★ 全部命中 d=%d (0x%X) order=%s counts=%s' % (d, d, order, counts))
    print('第一层通过 %d 个 d；完工' % cand)


if __name__ == '__main__':
    main()
