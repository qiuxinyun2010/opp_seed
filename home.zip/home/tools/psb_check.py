# -*- coding: utf-8 -*-
"""定向检查：候选组 = 各扇区全部尸体（15/16/10）时，实测之间有没有冲突。

用法： python tools/psb_check.py
"""
import sys, os
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.abspath(__file__))))
sys.path.insert(0, r'd:\workspace\outlast\opp_seed')
import seedcore as sc
import psb_mt01_static as S
import psb_model as pm

B, OK, OC = pm.B, pm.OFF_KEY, pm.OFF_CORPSE
GROUPS = pm.GROUPS
M32 = 0xFFFFFFFF
P = 'CorpseSearch_PS_Trial02_'

SIZES = {'A': 15, 'B': 10, 'C': 16}

# variant: (bp38, dia)  bp38=1 -> 378378 的 BP3_8 视作 AgainstWall_BP3_8
#                       dia='B'|'C' -> 565565 的「方块」尸体归到哪个扇区
def observations(variant):
    bp38, dia = variant
    o = {
        378378: {
            'A': {'Moon': P + 'AgainstWall_BP_2',
                  'Crown': P + ('AgainstWall_BP3_8' if bp38 else 'BP3_8'),
                  'Heart': P + 'AgainstWall_BP2_5'},
            'C': {'Spade': P + 'WallThroat_BP8_32',
                  'Eye': P + 'BP7_2',
                  'Club': P + 'OnChair_BP3_8'},
            'B': {'Fire': P + 'WallThroat_BP7_26',
                  'Diamond': P + 'Desk_BP_5',
                  'Bunny': P + 'Desk_BP2_2'},
        },
        565565: {
            'A': {'Heart': P + 'AgainstWall_BP3_8'},
            'B': {'Club': P + 'BP10_35'},
            'C': {},
        },
    }
    o[565565][dia]['Diamond'] = P + 'AgainstWall_BP5_2'
    return o


def run(variant, verbose=False):
    obs = observations(variant)
    cons = {s: {} for s in 'ABC'}
    conflicts = []
    for sd in sorted(obs):
        V = 0
        for sec, cnt in GROUPS:
            n = SIZES[sec]
            free = list(range(n))
            pool = list(pm.POOL)
            for j in range(cnt):
                ci = sc.rand_seeded((B + OC + V + j) & M32, len(free), sd % 1000)
                slot = free.pop(ci)
                ki = sc.rand_seeded((B + OK + V + j) & M32, len(pool), sd % 1000)
                pat = pool.pop(ki)
                act = obs[sd].get(sec, {}).get(pat)
                if act:
                    if slot in cons[sec] and cons[sec][slot] != act:
                        conflicts.append('%d %s slot %d: %s vs %s'
                                         % (sd, sec, slot,
                                            cons[sec][slot].replace(P, ''),
                                            act.replace(P, '')))
                    cons[sec][slot] = act
                V += 1
    print('variant=%s  冲突 %d 条  已定槽位 A=%d B=%d C=%d'
          % (variant, len(conflicts), len(cons['A']), len(cons['B']), len(cons['C'])))
    for c in conflicts:
        print('   冲突: ' + c)
    if verbose:
        for s in 'ABC':
            for k in sorted(cons[s]):
                print('   %s slot %2d -> %s' % (s, k, cons[s][k].replace(P, '')))
    print('')
    return len(conflicts)


if __name__ == '__main__':
    try:
        sys.stdout.reconfigure(encoding='utf-8')
    except Exception:
        pass
    for bp38 in (0, 1):
        for dia in ('B', 'C'):
            run((bp38, dia))
