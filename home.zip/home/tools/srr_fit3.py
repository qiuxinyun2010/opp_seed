# -*- coding: utf-8 -*-
"""SRR_MT02 交叉验证器：用第一轮（RichDistrict）的「机器 ↔ 图案」配对反推算法。

第一轮是唯一同时记录了 4 台机器 + 各自图案的样本：
    BP  = 月亮 Moon,  BP2 = 兔子 Bunny,  BP3 = 梅花 Club,  BP49 = 红心 Heart
PossibleClueNames = [Bunny, Heart, Moon, Spade, Club]，只用了其中 4 个
→ 图案本身也是「无放回抽 4 个」，约束强度 4! × P(5,4) = 2880，命中即强信号。
"""
import sys
from itertools import product

M32 = 0xFFFFFFFF
M64 = 0xFFFFFFFFFFFFFFFF

_T = []
for _i in range(256):
    _c = _i
    for _ in range(8):
        _c = ((_c >> 1) ^ 0xEDB88320) if (_c & 1) else (_c >> 1)
    _T.append(_c & M32)


def crc32_fname(text):
    crc = M32
    for ch in text:
        u = ord(ch) & 0xFFFF
        crc = _T[(crc ^ (u & 0xFF)) & 0xFF] ^ (crc >> 8)
        crc = _T[(crc ^ (u >> 8)) & 0xFF] ^ (crc >> 8)
        crc = _T[crc & 0xFF] ^ (crc >> 8)
        crc = _T[crc & 0xFF] ^ (crc >> 8)
    return (~crc) & M32


def seed_of_object(name):
    value = (crc32_fname(name) + crc32_fname('PersistentLevel')) & M32
    return value if value < 0x80000000 else (0x100000000 - value) & M32


def rs(seed, n, level_seed=417417):
    if not n or not level_seed or not seed:
        return 0
    a = (0xBF58476D1CE4E5B9 * ((seed ^ (seed >> 30)) & M64)) & M64
    a ^= a >> 27
    b = (0xBF58476D1CE4E5B9 * (level_seed % 1000)) & M64
    b ^= b >> 27
    v = (((0x94D049BB133111EB * a) & M64) ^ ((0x94D049BB133111EB * b) & M64)) & M64
    t = (v ^ (v >> 31)) & M64
    w = (0xBF58476D1CE4E5B9 * (t ^ (t >> 30))) & M64
    u = (w ^ (w >> 27)) & M64
    r = (((321982955 * u) & M64) ^ (((0x94D049BB133111EB * u) & M64) >> 31)) & M64
    return (r & 0xFFFF) % n


POOL_RICH = ['BP', 'BP2', 'BP3', 'BP49']
CLUES = ['Bunny', 'Heart', 'Moon', 'Spade', 'Club']
WANT = {'BP': 'Moon', 'BP2': 'Bunny', 'BP3': 'Club', 'BP49': 'Heart'}
COORD = 'SRR_MT02_OrderedClueFrequency_RichDistrict'
SEED = seed_of_object(COORD)
SALT = crc32_fname('Objective Actors')


def pick(mem, base, k, swap):
    """从 mem 里按 RandSeeded(base + k, len(mem)) 取一个并移除。"""
    i = rs((base + k) & M32, len(mem))
    v = mem[i]
    if swap:
        mem[i] = mem[-1]
        mem.pop()
    else:
        del mem[i]
    return v


def run(mode, base, swap_draw, swap_clue, clue_start):
    if mode == 'plain':
        mem = list(POOL_RICH)
        order = [pick(mem, base, i, swap_draw) for i in range(4)]
    elif mode == 'fy':
        mem = list(POOL_RICH)
        for i in range(len(mem), 1, -1):
            j = rs((base + (len(mem) - i)) & M32, i)
            mem[i - 1], mem[j] = mem[j], mem[i - 1]
        order = mem[:4]
    elif mode == 'rev':
        mem = list(POOL_RICH)[::-1]
        order = [pick(mem, base, i, swap_draw) for i in range(4)]
    else:
        raise ValueError(mode)
    pool = list(CLUES)
    clues = [pick(pool, base, clue_start + i, swap_clue) for i in range(4)]
    return order, clues


def main():
    print('GetSeed(%s) = 0x%08X   saltCrc = 0x%08X' % (COORD, SEED, SALT))
    bases = {'coord': SEED, '+salt': (SEED + SALT) & M32}
    ok = []
    for (btag, base), mode, sd, sc, cs in product(
            bases.items(), ('plain', 'fy', 'rev'), (True, False),
            (True, False), range(0, 13)):
        order, clues = run(mode, base, sd, sc, cs)
        got = dict(zip(order, clues))
        if got == WANT:
            ok.append((btag, mode, 'swap' if sd else 'rm',
                       'swap' if sc else 'rm', cs, order, clues))
    if ok:
        for r in ok:
            print('HIT  base=%-6s draw=%-5s/%s clue=%s start=%d  order=%s clues=%s'
                  % (r[0], r[1], r[2], r[3], r[4], r[5], r[6]))
    else:
        print('no hit（%d 种组合全不匹配）' % (2 * 3 * 2 * 2 * 13))
    # 顺带打印几种代表组合，便于人工比对
    for btag in ('coord', '+salt'):
        for mode in ('plain', 'fy', 'rev'):
            o, c = run(mode, bases[btag], True, True, 4)
            print('  ref base=%-6s %-5s order=%s clues=%s' % (btag, mode, o, c))


if __name__ == '__main__':
    main()
