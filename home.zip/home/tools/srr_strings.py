# -*- coding: utf-8 -*-
"""从 exe 里捞候选「盐名」字符串（盐名形如 "Xxx Actors" / "Objective Xxx"）。

用法：python tools\srr_strings.py [关键词...]
"""
import re
import sys

EXE = r"d:\workspace\outlast\TOTClient-Win64-Shipping.exe"
DEFAULT = ('Actors', 'Objective', 'Frequency', 'Clue', 'Tuner', 'Panel')


def main():
    kws = [k.lower() for k in sys.argv[1:]] or [k.lower() for k in DEFAULT]
    with open(EXE, 'rb') as f:
        data = f.read()
    seen = set()
    for m in re.finditer(rb'[\x20-\x7e]{4,48}', data):
        s = m.group().decode('ascii')
        low = s.lower()
        if not any(k in low for k in kws):
            continue
        if s in seen:
            continue
        seen.add(s)
        print('0x%X  %s' % (m.start(), s))


if __name__ == '__main__':
    main()
