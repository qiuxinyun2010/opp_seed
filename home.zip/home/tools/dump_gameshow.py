"""打印 RBGameShowObjectiveCoordinator 类协调器的关键配置（用于 FPI_MT02）。

用法:
    python dump_gameshow.py <关卡json> [actor名关键字]
"""
import json
import sys

path = sys.argv[1]
kw = sys.argv[2] if len(sys.argv) > 2 else 'GameShowObjectiveCoordinator'

data = json.load(open(path, encoding='utf-8'))
objs = [o for o in data if o.get('Type') == 'RBGameShowObjectiveCoordinator']
print('coordinator count:', len(objs))
for o in objs:
    if kw and kw.lower() not in o['Name'].lower():
        continue
    p = o.get('Properties') or {}
    print('=' * 60)
    print('actor :', o['Name'])
    secs = p.get('SectionDefinitions') or []
    print('sections:', len(secs))
    for i, s in enumerate(secs):
        room = s['Room']['SubPathString'].split('.')[-1]
        mv = (s.get('MaxFakeFlipboards') or {}).get('DefaultValues') or {}
        print('  %2d %-36s %-18s fakeEasy=%s fakeNormal=%s'
              % (i, room, s.get('Name'), mv.get('EasyLocalValue'), mv.get('NormalLocalValue')))
    syms = [t['ObjectName'].split("'")[1] for t in (p.get('SymbolTextures') or [])]
    print('symbols(%d):' % len(syms))
    for i, t in enumerate(syms):
        print('  %2d %s' % (i, t))
    for k in ('NumRounds', 'TotalTrialRounds', 'CompletedTrialRoundsAtStart',
              'NumActiveConsoles', 'DelayBetweenRounds', 'DelayBeforeRoundRetry'):
        print('%-28s %s' % (k, json.dumps(p.get(k), ensure_ascii=False)[:220]))
