# -*- coding: utf-8 -*-
"""按「vtable 基址 + 字节偏移」取虚函数地址。

    python vt_slot.py 0x145A05440 0x6E8 0x800 0x8F8 0x900
    python vt_slot.py 0x145A05440 --range 0x600 0x980
"""
import struct
import sys
import os

_HERE = os.path.dirname(os.path.abspath(__file__))
sys.path.insert(0, _HERE)
import vaq


def qword(va):
    return struct.unpack_from('<Q', vaq.d, vaq.va2off(va))[0]


def main():
    base = int(sys.argv[1], 16)
    args = sys.argv[2:]
    if args and args[0] == '--range':
        lo, hi = int(args[1], 16), int(args[2], 16)
        for off in range(lo, hi + 1, 8):
            q = qword(base + off)
            if q:
                print('  +0x%03X [idx %3d] %X' % (off, off // 8, q))
        return
    for a in args:
        off = int(a, 16)
        q = qword(base + off)
        print('  +0x%03X [idx %3d] -> %X' % (off, off // 8, q))


if __name__ == '__main__':
    main()
