# -*- coding: utf-8 -*-
"""标定 GetSeed 的层级常量 L，并验证「图案 → 尸体」整条链。

候选 L：
  1) 由 B=0xCD055621 反解（若 B = GetSeed(协调器) + k）
  2) 若干层级/包名的 crc32：PersistentLevel / PSB_MT01_B00 / PSB_MT01_B01 / ...

用法： python tools/psb_fit_L.py
"""
import sys, os
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.abspath(__file__))))
from psb_sort import (crc32_fname, seed_of_object, rand_seeded, hi16,
                      intro_sort, P, M32)
import psb_mt01_static as S
import psb_mt01 as M

B, OK, OC = M.B, M.OFF_KEY, M.OFF_CORPSE
GROUPS = M.GROUPS
COORD = 'PSB_MT01_B01_CorpseSearch_3'

OBS = {
    378378: {
        'A': {'Moon': P + 'AgainstWall_BP_2', 'Heart': P + 'AgainstWall_BP2_5'},
        'B': {'Fire': P + 'WallThroat_BP7_26', 'Diamond': P + 'Desk_BP_5',
              'Bunny': P + 'Desk_BP2_2'},
        'C': {'Spade': P + 'WallThroat_BP8_32', 'Eye': P + 'BP7_2',
              'Club': P + 'OnChair_BP3_8'},
    },
    565565: {
        'A': {'Heart': P + 'AgainstWall_BP3_8'},
        'B': {'Club': P + 'BP10_35'},
        'C': {'Eye': P + 'AgainstWall_BP9_2'},
    },
}
# 378378 里「王冠」那具记成 BP3_8，也可能是 AgainstWall_BP3_8
CROWN = {0: P + 'BP3_8', 1: P + 'AgainstWall_BP3_8'}
# 565565 里「方块」那具的扇区存疑
DIAMOND = (P + 'AgainstWall_BP5_2', ('B', 'C'))

CORPSES = list(S.CORPSES)                       # 静态表顺序 = 关卡 actor 顺序
SECTOR = {c['actor']: c['sector'] for c in CORPSES}
NAMES = [c['actor'] for c in CORPSES]


def candidates():
    out = {}
    C = crc32_fname(COORD)
    for k in range(0, 33):
        T = (B - k) & M32
        for form, L in (('+%d' % k, (T - C) & M32),
                        ('-%d' % k, ((-T) & M32) - C & M32)):
            out.setdefault(L, []).append('B%s' % form)
    for nm in ('PersistentLevel', 'PSB_MT01_B00', 'PSB_MT01_B01',
               'PoliceStationBasement', 'PSB_MT01_B00_C', 'PSB_MT01_B01_C',
               'PSB_MT01_B00_C_5', 'Level', 'World'):
        out.setdefault(crc32_fname(nm), []).append('crc(%s)' % nm)
    out.setdefault(0, []).append('0')
    return out


def order_for(L, salt):
    """返回 {扇区: [演员名]}（排序后的顺序，按扇区过滤）。"""
    seeds = [seed_of_object(n, L) for n in NAMES]
    arr = list(range(len(NAMES)))
    intro_sort(arr, lambda i: hi16(seeds[i], salt))
    out = {s: [] for s in 'ABC'}
    for i in arr:
        out[SECTOR[NAMES[i]]].append(NAMES[i])
    return out


def simulate(L, seed, bp38=1, dia_sec='B'):
    """返回 [(sec, j, pattern, actor)]。"""
    salt = seed % 1000
    groups = order_for(L, salt)
    pool = list(M.POOL)
    rows = []
    V = 0
    for sec, cnt in GROUPS:
        g = list(groups[sec])
        for j in range(cnt):
            pick = rand_seeded((B + OC + V + j) & M32, len(g), salt)
            actor = g.pop(pick)
            ki = rand_seeded((B + OK + V + j) & M32, len(pool), salt)
            pat = pool.pop(ki)
            rows.append((sec, j, pat, actor))
            V += 1
    return rows


def score(L, bp38=1, dia_sec='B'):
    ok = bad = 0
    detail = []
    for seed in sorted(OBS):
        obs = {s: dict(d) for s, d in OBS[seed].items()}
        obs['A'].setdefault('Crown', CROWN[bp38])
        obs[dia_sec]['Diamond'] = DIAMOND[0]
        got = {(s, p): a for s, j, p, a in simulate(L, seed)}
        for sec, m in obs.items():
            for pat, actor in m.items():
                g = got.get((sec, pat))
                if g is None:
                    continue
                if g == actor:
                    ok += 1
                else:
                    bad += 1
                    detail.append('%d %s %s: 算=%s 实测=%s'
                                  % (seed, sec, pat, g.replace(P, ''), actor.replace(P, '')))
    return ok, bad, detail


def main():
    try:
        sys.stdout.reconfigure(encoding='utf-8')
    except Exception:
        pass
    cands = candidates()
    print('候选 L 共 %d 个' % len(cands))
    best = []
    for L, why in sorted(cands.items(), key=lambda kv: -len(kv[1])):
        for bp38 in (1, 0):
            for dia in ('B', 'C'):
                ok, bad, det = score(L, bp38, dia)
                best.append((ok - 3 * bad, ok, bad, L, bp38, dia, why, det))
    best.sort(key=lambda r: -r[0])
    print('%-12s %-6s %-4s %-3s %-3s  %s' % ('L', '来源', '对', '错', 'bp38', '方块归属'))
    for sc, ok, bad, L, bp38, dia, why, det in best[:15]:
        print('0x%08X  %-10s %-4d %-4d %-4d %s' % (L, why[0][:10], ok, bad, bp38, dia))
    sc, ok, bad, L, bp38, dia, why, det = best[0]
    print('')
    print('最优 L=0x%08X（%s）  对 %d 错 %d  王冠=%s  方块∈%s'
          % (L, '/'.join(why), ok, bad, CROWN[bp38].replace(P, ''), dia))
    for d in det[:12]:
        print('   ' + d)


if __name__ == '__main__':
    main()
