"""从 FModel 导出的关卡 JSON 里按对象名打印 Properties。

用法:
    python dump_props.py <json> <名字关键字> [--full] [--refs]
"""
import json
import sys

path, kw = sys.argv[1], sys.argv[2]
full = '--full' in sys.argv
refs = '--refs' in sys.argv
limit = 4000 if full else 2500

data = json.load(open(path, encoding='utf-8'))
if isinstance(data, dict):
    data = [data]

for obj in data:
    name = obj.get('Name') or ''
    if kw.lower() not in name.lower():
        continue
    outer = (obj.get('Outer') or {}).get('ObjectName')
    print('=' * 70)
    print('Name : %s' % name)
    print('Type : %s' % obj.get('Type'))
    if outer:
        print('Outer: %s' % outer)
    props = obj.get('Properties')
    if not refs:
        text = json.dumps(props, ensure_ascii=False, indent=2) if props is not None else '(no Properties)'
        print(text[:limit])
        if len(text) > limit:
            print('... (%d chars total)' % len(text))
    else:
        # 只打印引用别的对象的属性名与目标
        def walk(node, prefix=''):
            if isinstance(node, dict):
                if 'ObjectName' in node and len(node) <= 3:
                    print('%-46s -> %s' % (prefix, node['ObjectName']))
                    return
                for k, v in node.items():
                    walk(v, prefix + k + '.')
            elif isinstance(node, list):
                for i, v in enumerate(node):
                    walk(v, '%s[%d].' % (prefix, i))
            else:
                print('%-46s = %s' % (prefix, node))
        walk(props or {})
