@echo off
call "C:\Program Files\Microsoft Visual Studio\2022\Community\VC\Auxiliary\Build\vcvars64.bat"
cl /nologo /O2 /openmp /Fe:scan_srr2.exe scan_srr2.c
echo EXIT=%ERRORLEVEL%
