# -*- coding: utf-8 -*-
"""假设：屏幕上 3 个 = 从「该轮图案序列」里再逐个无放回抽 3 个。

第一轮（RichDistrict）的图案序列已由双 seed 定解（GetSeed+503，逐个抽取+RemoveAtSwap，
按池序赋），是唯一一条可靠的序列。屏幕抽取若紧接其后，偏移应在 503+4=507 附近。

约束：两个 seed 同时给出各自的 3 个 → 1/(4·3·2)^2 = 1/576，只测 ~30 个偏移
→ 期望假阳性 0.05，命中即可信。
"""
import sys

M32 = 0xFFFFFFFF
M64 = 0xFFFFFFFFFFFFFFFF

_T = []
for _i in range(256):
    _c = _i
    for _ in range(8):
        _c = ((_c >> 1) ^ 0xEDB88320) if (_c & 1) else (_c >> 1)
    _T.append(_c & M32)


def crc32_fname(text):
    crc = M32
    for ch in text:
        u = ord(ch) & 0xFFFF
        crc = _T[(crc ^ (u & 0xFF)) & 0xFF] ^ (crc >> 8)
        crc = _T[(crc ^ (u >> 8)) & 0xFF] ^ (crc >> 8)
        crc = _T[crc & 0xFF] ^ (crc >> 8)
        crc = _T[crc & 0xFF] ^ (crc >> 8)
    return (~crc) & M32


def seed_of_object(name):
    value = (crc32_fname(name) + crc32_fname('PersistentLevel')) & M32
    return value if value < 0x80000000 else (0x100000000 - value) & M32


def mix1(x):
    z = (0xBF58476D1CE4E5B9 * (x ^ (x >> 30))) & M64
    return z ^ (z >> 27)


def rs(seed, n, salt):
    if not n or not seed:
        return 0
    B = (0x94D049BB133111EB * mix1(salt % 1000)) & M64
    v = ((0x94D049BB133111EB * mix1(seed)) & M64) ^ B
    t = (v ^ (v >> 31)) & M64
    w = (0xBF58476D1CE4E5B9 * (t ^ (t >> 30))) & M64
    u = (w ^ (w >> 27)) & M64
    r = (((321982955 * u) & M64) ^ (((0x94D049BB133111EB * u) & M64) >> 31)) & M64
    return (r & 0xFFFF) % n


CLUES5 = ['Bunny', 'Heart', 'Moon', 'Spade', 'Club']
COORD = 'SRR_MT02_OrderedClueFrequency_RichDistrict'
BASE = seed_of_object(COORD)
CLUE_OFFSET = 503

# 第一轮的屏幕实测（3 个图案，按顺序）
WANT = {417417: ['Moon', 'Bunny', 'Club'], 737737: ['Moon', 'Spade', 'Club']}


def clue_seq(seed, offset=CLUE_OFFSET):
    pool = list(CLUES5)
    out = []
    for i in range(len(pool)):
        k = rs((BASE + offset + i) & M32, len(pool), seed)
        out.append(pool[k])
        pool[k] = pool[-1]
        pool.pop()
    return out


def screen_of(seq, off, salt, swap=True):
    pool = list(seq)
    out = []
    for i in range(3):
        k = rs((BASE + off + i) & M32, len(pool), salt)
        out.append(pool[k])
        if swap:
            pool[k] = pool[-1]
            pool.pop()
        else:
            del pool[k]
    return out


def main():
    lo = int(sys.argv[1]) if len(sys.argv) > 1 else 495
    hi = int(sys.argv[2]) if len(sys.argv) > 2 else 530
    for seed in (417417, 737737):
        print('seed %d 图案序列 = %s' % (seed, clue_seq(seed)))
        print('        屏幕实测 = %s' % WANT[seed])
    for off in range(lo, hi):
        for swap in (True, False):
            ok = all(screen_of(clue_seq(s), off, s, swap) == WANT[s]
                     for s in (417417, 737737))
            if ok:
                print('★ off=%d swap=%s' % (off, swap))
                for s in (417417, 737737):
                    print('   %d 预测 %s' % (s, screen_of(clue_seq(s), off, s, swap)))
    print('（扫完 %d..%d，未列出的即无命中）' % (lo, hi))


if __name__ == '__main__':
    main()
