# -*- coding: utf-8 -*-
"""PSB_MT01 图案模型（来自 sub_14361C230 反编译 + 全空间反解出的 B）。

    B       = 0xCD055621        # GetSeed(协调器) 经 sub_1402C30C0 写回后的值
    组序    = A(3) -> C(4) -> B(3), 共 10 具
    每具图案 = pool[ RandSeeded(B + 223551 + V + j, |pool|, salt=S%1000) ]，抽后保序 RemoveAt
    真钥匙  = 该组第一具（j == 0）

用法： python tools/psb_model.py [seed...]
"""
import sys, os
sys.path.insert(0, r'd:\workspace\outlast\opp_seed')
import seedcore as sc

B = 0xCD055621
OFF_KEY = 223551
OFF_CORPSE = 243551

POOL = ['Bunny', 'Club', 'Diamond', 'Fire', 'Heart',
        'Spade', 'Crown', 'Eye', 'Moon', 'Star']
ZH = {'Bunny': '兔子', 'Club': '梅花', 'Diamond': '方块', 'Fire': '火焰', 'Heart': '红心',
      'Spade': '黑桃', 'Crown': '王冠', 'Eye': '眼睛', 'Moon': '月亮', 'Star': '五角星'}

# 组序： (扇区, 该组条目数)
GROUPS = [('A', 3), ('C', 4), ('B', 3)]


def simulate(seed, base=B, off=OFF_KEY):
    """返回 [(sector, [(j, V, pattern)])]，按抽取顺序。"""
    salt = seed % 1000
    pool = list(POOL)
    out = []
    V = 0
    for sec, cnt in GROUPS:
        rows = []
        for j in range(cnt):
            idx = sc.rand_seeded((base + off + V + j) & 0xFFFFFFFF, len(pool), salt)
            p = pool.pop(idx)
            rows.append((j, V, p))
            V += 1
        out.append((sec, rows))
    return out


def keys(seed):
    d = {}
    for sec, rows in simulate(seed):
        d[sec] = rows[0][2]
    return d


def render(seed):
    lines = ['seed=%d  salt=%d' % (seed, seed % 1000)]
    for sec, rows in simulate(seed):
        key = rows[0][2]
        lines.append('  Sector %s  (%d 具)' % (sec, len(rows)))
        for j, V, p in rows:
            lines.append('     j=%d V=%2d  %-8s %s %s'
                         % (j, V, p, ZH[p], '← 钥匙' if j == 0 else ''))
    return '\n'.join(lines)


SAMPLES = {
    111111: {'A': 'Star', 'B': 'Bunny', 'C': 'Diamond'},
    565565: {'A': 'Heart', 'B': 'Club', 'C': 'Eye'},
    378378: {'A': 'Moon', 'B': 'Fire', 'C': 'Spade'},
}
# 378378 每区实测全部图案（集合）
FULL = {
    'A': {'Heart', 'Crown', 'Moon'},
    'B': {'Diamond', 'Fire', 'Bunny'},
    'C': {'Eye', 'Spade', 'Club'},
}


def selftest():
    bad = total = 0
    def chk(label, ok):
        nonlocal bad, total
        total += 1
        bad += 0 if ok else 1
        print('  %-40s %s' % (label, 'OK' if ok else 'FAIL'))
    for seed, want in SAMPLES.items():
        got = keys(seed)
        for sec in 'ABC':
            chk('%d Sector %s 钥匙 = %s' % (seed, sec, ZH[want[sec]]),
                got[sec] == want[sec])
    sim = dict((s, set(p for _, _, p in r)) for s, r in simulate(378378))
    for sec in 'ABC':
        chk('378378 Sector %s 全部图案集合' % sec, FULL[sec] <= sim[sec])
    print('自检：%d/%d 通过' % (total - bad, total))
    return bad == 0


if __name__ == '__main__':
    try:
        sys.stdout.reconfigure(encoding='utf-8')
    except Exception:
        pass
    args = [int(x) for x in sys.argv[1:]]
    if not args:
        print(selftest.__doc__ or '')
        selftest()
    else:
        for s in args:
            print(render(s))
            print('')
