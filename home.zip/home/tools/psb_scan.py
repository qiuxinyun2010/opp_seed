# -*- coding: utf-8 -*-
"""PSB_MT01 关卡 JSON 探查器。

用法：
    python psb_scan.py kinds                 # actor 类型统计
    python psb_scan.py find <正则>           # 名字匹配
    python psb_scan.py props <Name>          # 打印某对象的 Properties
    python psb_scan.py corpses               # 41 个尸体生成点（类型/房间/父级）
    python psb_scan.py coord                 # 协调器属性
"""
import json
import os
import re
import sys

ROOT = os.path.abspath(os.path.join(os.path.dirname(__file__), '..', '..', '..'))
BASE = os.path.join(ROOT, 'pak', 'OPP', 'Content', 'Maps_json', 'PoliceStationBasement')

FILES = ['PSB_MT01_B00.json', 'PSB_MT01_B01.json']


def load(names=None):
    out = []
    for fn in names or FILES:
        p = os.path.join(BASE, fn)
        with open(p, encoding='utf-8') as fp:
            for o in json.load(fp):
                if isinstance(o, dict):
                    o['__file'] = fn
                    out.append(o)
    return out


def short_path(o):
    return '%s' % o.get('ObjectName')


def main():
    try:
        sys.stdout.reconfigure(encoding='utf-8')
    except Exception:
        pass
    cmd = sys.argv[1] if len(sys.argv) > 1 else 'kinds'
    objs = load()
    if cmd == 'kinds':
        import collections
        c = collections.Counter(o.get('Type') for o in objs)
        for k, v in c.most_common():
            print('%5d %s' % (v, k))
    elif cmd == 'find':
        pat = re.compile(sys.argv[2], re.I)
        for o in objs:
            if pat.search(str(o.get('Name'))):
                print('%-6s %-52s %s' % (o['__file'][-7:-5], o.get('Type'), o.get('Name')))
    elif cmd == 'props':
        want = sys.argv[2]
        for o in objs:
            if str(o.get('Name')) == want or str(o.get('Name')).startswith(want):
                print('=== %s %s (%s)' % (o.get('Type'), o.get('Name'), o['__file']))
                print(json.dumps(o.get('Properties', {}), ensure_ascii=False, indent=2))
    elif cmd == 'corpses':
        for o in objs:
            if o.get('Type') in ('CorpseSearch_PS_Trial02_BP_C',
                                 'CorpseSearch_PS_Trial02_AgainstWall_BP_C',
                                 'CorpseSearch_PS_Trial02_WallThroat_BP_C',
                                 'CorpseSearch_PS_Trial02_OnChair_BP_C',
                                 'CorpseSearch_PS_Trial02_Desk_BP_C'):
                p = o.get('Properties', {})
                print('%-45s %s' % (o.get('Type'), o.get('Name')))
                print('   props=%s' % json.dumps(p, ensure_ascii=False)[:600])
    elif cmd == 'coord':
        for o in objs:
            if 'QuestItemCoord' in str(o.get('Type')) or 'QuestItemCoord' in str(o.get('Name')):
                print('=== %s %s' % (o.get('Type'), o.get('Name')))
                print(json.dumps(o.get('Properties', {}), ensure_ascii=False, indent=2))
    else:
        print(__doc__)


if __name__ == '__main__':
    main()
