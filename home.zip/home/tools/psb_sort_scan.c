/* PSB_MT01：标定 GetSeed 的层级常量 L（全 2^32），顺带验证「图案 → 尸体」整条链。
 *
 * 模型（来自 sub_14361C230 反编译）：
 *   组序/条目 A(3) C(4) B(3)，共 10 具
 *   图案 = pool[ RandSeeded(0xCD055621 + 223551 + V + j, |pool|, salt) ]  保序删除
 *   尸体 = group[ RandSeeded(0xCD055621 + 243551 + V + j, |group|, salt) ] 保序删除
 *   group 的初始顺序 = 41 具尸体经 UE IntroSort 洗牌后、按扇区过滤
 *   IntroSort 的比较器： pred(a,b) = (RandSeeded16(GetSeed(a)) >= 0x8000)   ← 只看 a
 *   GetSeed(corpse)  = | crc32(name) + L |      L = 所属 ULevel 的 seed（待扫）
 *
 * 用法: psb_sort_scan.exe <corpses.txt> [阈值(默认7)]
 */
#include <stdio.h>
#include <stdint.h>
#include <stdlib.h>
#include <string.h>
#include <math.h>
#include <omp.h>

#define NC 41
static char  GSEC[NC];
static char  GNAME[NC][80];
static uint32_t GCRC[NC];
static int   GN = 0;

/* ---------- FName 的 CRC32（sub_141CBDC30） ---------- */
static uint32_t TBL[256];
static void mk_table(void) {
    uint32_t i; int k;
    for (i = 0; i < 256; i++) { uint32_t c = i;
        for (k = 0; k < 8; k++) c = (c & 1) ? ((c >> 1) ^ 0xEDB88320u) : (c >> 1);
        TBL[i] = c; }
}
static uint32_t crc32_fname(const char *s) {
    uint32_t crc = 0xFFFFFFFFu;
    const unsigned char *p;
    for (p = (const unsigned char *)s; *p; p++) {
        uint32_t u = *p;
        crc = TBL[(crc ^ (u & 0xFF)) & 0xFF] ^ (crc >> 8);
        crc = TBL[(crc ^ (u >> 8)) & 0xFF] ^ (crc >> 8);
        crc = TBL[crc & 0xFF] ^ (crc >> 8);
        crc = TBL[crc & 0xFF] ^ (crc >> 8);
    }
    return ~crc;
}

/* ---------- RandSeeded / hi16（sub_1402D29E0 / sub_1413F02F0） ---------- */
static inline uint64_t mix64(uint32_t seed, uint32_t salt) {
    uint64_t a = 0xBF58476D1CE4E5B9ull * (uint64_t)(seed ^ (seed >> 30)); a ^= a >> 27;
    uint64_t b = 0xBF58476D1CE4E5B9ull * (uint64_t)(salt % 1000u);        b ^= b >> 27;
    uint64_t v5 = (0x94D049BB133111EBull * a) ^ (0x94D049BB133111EBull * b);
    uint64_t t = v5 ^ (v5 >> 31);
    uint64_t v6 = 0xBF58476D1CE4E5B9ull * (t ^ (t >> 30));
    uint64_t u = v6 ^ (v6 >> 27);
    return (((uint64_t)(uint32_t)(321982955u * (uint32_t)u)) ^
            ((0x94D049BB133111EBull * u) >> 31)) & 0xFFFFFFFFull;
}
static inline uint32_t rand_seeded(uint32_t s, uint32_t n, uint32_t salt) {
    if (!n || !s) return 0;
    return (uint32_t)(((uint16_t)mix64(s, salt)) % n);
}
static inline int hi16(uint32_t s, uint32_t salt) {
    if (!s) return 0;
    return ((uint16_t)mix64(s, salt)) >= 0x8000u ? 1 : 0;
}

/* ---------- UE IntroSort（逐行复刻 0x14361C34C~0x14361C6A4） ---------- */
static void intro_sort(int *a, int n, const unsigned char *hot) {
    int stk[512][3];
    int sp = 0;
    float lgf;
    if (n < 2) return;
    lgf = (float)log((double)n);
    stk[0][0] = 0; stk[0][1] = n - 1; stk[0][2] = (int)(lgf + lgf);
    while (sp >= 0) {
        if (sp >= 500) { fprintf(stderr, "SORTSTACK sp=%d n=%d\n", sp, n); return; }
        {
        int v5 = stk[sp][0], v6 = stk[sp][1], v122 = stk[sp][2];
        int v9 = v6 - v5 + 1, v8 = v9 - 1;
        int v32 = sp;
        int do_heap = 0, do_small = 0;
        int v15 = v5;
        if (v122) {
            int v10 = v5, v11 = v6, v18 = v5, v23 = v6;
            while (v9 > 8) {
                int mid = v5 + (v9 >> 1), tmp, v14 = v6 + 1, v26 = 0;
                tmp = a[v5]; a[v5] = a[mid]; a[mid] = tmp;
                v15 = v5;
                for (;;) {
                    int p = v15 + 1;
                    for (;;) {
                        v15 = p; v18 = p;
                        if (p > v6) break;
                        { int tt = hot[a[p]]; p++; if (!tt) break; }
                    }
                    for (;;) {
                        int nxt = v14 - 1;
                        v14 = nxt; v23 = nxt - 1;
                        if (nxt <= v5) break;
                        if (!hot[a[v5]]) break;
                    }
                    v26 = a[v14];
                    if (v15 > v14) break;
                    tmp = a[v15]; a[v15] = a[v14]; a[v14] = tmp;
                }
                tmp = a[v5]; a[v5] = v26; a[v14] = tmp;
                v122 -= 1;
                {
                    int v29 = v14 - 1;
                    if ((v23 - v10) >= (v11 - v18)) {
                        if (v5 + 1 < v14) {
                            stk[sp][0] = v5; stk[sp][1] = v29; stk[sp][2] = v122;
                            sp++; v32 = sp;
                        }
                        if (v6 <= v15) break;
                        v23 = v6; v5 = v15;
                    } else {
                        if (v6 > v15) {
                            stk[sp][0] = v15; stk[sp][1] = v6; stk[sp][2] = v122;
                            sp++; v32 = sp;
                        }
                        if (v5 + 1 >= v14) break;
                        v18 = v5; v15 = v5; v6 = v14 - 1;
                    }
                }
                v8 = v23 - v18; v9 = v8 + 1; v10 = v18; v11 = v23;
                if (!v122) { do_heap = 1; break; }
            }
            if (!do_heap) {
                if (v6 > v5) do_small = 1;
            }
        } else {
            do_heap = 1;
        }
        if (do_heap) {
            v15 = v5;
            if ((uint32_t)v8 <= 0x80000000u) {
                int v33 = (int)((uint32_t)(v8 + ((((uint32_t)(v8 - 1)) >> 31)) - 1));
                v33 >>= 1;
                for (;;) {
                    int v34 = 2 * v33 + 1;
                    if (v34 < v9) {
                        int v35 = 2 * v33, v36 = v33;
                        for (;;) {
                            int v37 = v35 + 2;
                            if (v37 < v9 && hot[a[v15 + v34]]) v34 = v37;
                            { int v39 = v34;
                              if (hot[a[v15 + v34]]) break;
                              { int tt = a[v15 + v36]; a[v15 + v36] = a[v15 + v34]; a[v15 + v34] = tt; }
                              v35 = 2 * v34; v34 = 2 * v34 + 1; v36 = v39;
                              if (!(v34 < v9)) break; }
                        }
                    }
                    { int v42 = (v33 <= 0); v33 -= 1; if (v42) break; }
                }
            }
            if (v9 >= 2) {
                int tt = a[v15]; a[v15] = a[v15 + v9 - 1]; a[v15 + v9 - 1] = tt;
                if (v9 != 2) {
                    int v48 = v9 - 1;
                    for (;;) {
                        int v49 = 0, v50 = 1, v51 = 0;
                        for (;;) {
                            int v52 = v49 + 2;
                            if (v48 > v52 && hot[a[v15 + v50]]) v50 = v52;
                            { int v54 = v50;
                              if (hot[a[v15 + v50]]) break;
                              { int tt2 = a[v15 + v51]; a[v15 + v51] = a[v15 + v50]; a[v15 + v50] = tt2; }
                              v49 = 2 * v50; v50 = 2 * v50 + 1; v51 = v54;
                              if (!(v48 > v50)) break; }
                        }
                        { int tt3 = a[v15]; a[v15] = a[v15 + v48 - 1]; a[v15 + v48 - 1] = tt3; }
                        { int v42 = (v48 <= 2); v48 -= 1; if (v42) break; }
                    }
                }
            }
        } else if (do_small) {
            int guard = 0;
            while (v6 > v5) {
                if (++guard > 4096) { fprintf(stderr, "SMALLLOOP runaway\n"); break; }
                int v44 = v5;
                if (v5 + 1 <= v6) {
                    int v45 = v5 + 1;
                    for (;;) {
                        if (!hot[a[v45]]) v44 = v45;
                        v45++;
                        if (v45 > v6) break;
                    }
                }
                { int tt = a[v44]; a[v44] = a[v6]; a[v6] = tt; }
                v6--;
            }
        }
        sp = v32 - 1;
        }
    }
}

/* ---------- 关卡数据 ---------- */
#define B     0xCD055621u
#define OKOFF 223551u
#define OCOFF 243551u
/* 图案池顺序 = QuestItemClasses */
static const char *POOL[10] = {"Bunny","Club","Diamond","Fire","Heart",
                               "Spade","Crown","Eye","Moon","Star"};
static const char GSEC_ORDER[3] = {'A','C','B'};
static const int  GCNT[3] = {3, 4, 3};

static int idx_of_actor(const char *nm) {
    int i;
    for (i = 0; i < GN; i++) if (!strcmp(GNAME[i], nm)) return i;
    return -1;
}
static int idx_of_pool(const char *nm) {
    int i;
    for (i = 0; i < 10; i++) if (!strcmp(POOL[i], nm)) return i;
    return -1;
}

/* 观测：(扇区, 图案下标, 尸体下标) */
typedef struct { char sec; int pat; int act; } Obs;
static Obs OBS378[9]; static int NOBS378 = 0;
static Obs OBS565[4]; static int NOBS565 = 0;
static int AMB378 = -1, AMB378_ALT = -1;   /* 378378 的「王冠」两解 */
static int AMB565 = -1;                    /* 565565 的「方块」尸体 */
static char AMB565_PAT = 0;

/* 组：[扇区][成员] —— 每个线程一份，否则 OpenMP 下会互相踩 */
__declspec(thread) static int GRP[3][NC];
__declspec(thread) static int GRP_N[3];

static void compute_hot(uint32_t L, uint32_t salt, unsigned char *hot) {
    int i;
    for (i = 0; i < NC; i++) {
        uint32_t v = (GCRC[i] + L) & 0xFFFFFFFFu;
        uint32_t sd = (v < 0x80000000u) ? v : ((0u - v) & 0xFFFFFFFFu);
        hot[i] = (unsigned char)hi16(sd, salt);
    }
}

static void build_groups_h(const unsigned char *raw, int inv, int model) {
    unsigned char hot[NC];
    int i, s, k;
    for (i = 0; i < NC; i++) hot[i] = (unsigned char)(raw[i] ^ inv);
    for (s = 0; s < 3; s++) GRP_N[s] = 0;
    if (model == 0) {                       /* 全局洗牌后按扇区过滤 */
        int a[NC];
        for (i = 0; i < NC; i++) a[i] = i;
        intro_sort(a, NC, hot);
        for (i = 0; i < NC; i++) {
            int c = a[i];
            GRP[GSEC[c] - 'A'][GRP_N[GSEC[c] - 'A']++] = c;
        }
    } else {                                /* 各扇区分别洗牌 */
        int a[NC], n;
        for (s = 0; s < 3; s++) {
            char want = (char)('A' + s);
            n = 0;
            for (i = 0; i < NC; i++) if (GSEC[i] == want) a[n++] = i;
            intro_sort(a, n, hot);
            for (k = 0; k < n; k++) GRP[s][k] = a[k];
            GRP_N[s] = n;
        }
    }
}

static void build_groups(uint32_t L, int salt, int model, int inv) {
    unsigned char raw[NC];
    compute_hot(L, (uint32_t)salt, raw);
    build_groups_h(raw, inv, model);
}

/* 返回 [(sec,j,pat,actor)] 写入 out；out 10 行 4 列 */
static void simulate(int salt, int out[10][4]) {
    int pool[10], np = 10, V = 0, g, j;
    for (j = 0; j < 10; j++) pool[j] = j;
    for (g = 0; g < 3; g++) {
        int sec = GSEC_ORDER[g] - 'A';
        int mem[NC], mn = GRP_N[sec], i;
        for (i = 0; i < mn; i++) mem[i] = GRP[sec][i];
        for (j = 0; j < GCNT[g]; j++) {
            uint32_t pick = rand_seeded((uint32_t)(B + OCOFF + V + j), (uint32_t)mn, (uint32_t)salt);
            int act = mem[pick], i2;
            for (i2 = (int)pick; i2 < mn - 1; i2++) mem[i2] = mem[i2 + 1];
            mn--;
            {
                uint32_t ki = rand_seeded((uint32_t)(B + OKOFF + V + j), (uint32_t)np, (uint32_t)salt);
                int pat = pool[ki];
                for (i2 = (int)ki; i2 < np - 1; i2++) pool[i2] = pool[i2 + 1];
                np--;
                out[V][0] = sec; out[V][1] = j; out[V][2] = pat; out[V][3] = act;
            }
            V++;
        }
    }
}

static int score(const int out[10][4], const Obs *obs, int nobs) {
    int i, k, hit = 0;
    for (k = 0; k < nobs; k++) {
        int sec = obs[k].sec - 'A';
        for (i = 0; i < 10; i++)
            if (out[i][0] == sec && out[i][2] == obs[k].pat) {
                if (out[i][3] == obs[k].act) hit++;
                break;
            }
    }
    return hit;
}

int main(int argc, char **argv) {
    FILE *fp;
    char line[256];
    long long hits = 0;
    double t0;
    int thresh = (argc > 2) ? atoi(argv[2]) : 7;
    long long lim = (argc > 3) ? atoll(argv[3]) : 4294967296LL;
    int n378;

    mk_table();
    if (argc > 1 && argv[1][0] == 't') {          /* 自检：打印某个 L 的排序与抽取 */
        uint32_t L = (argc > 2) ? (uint32_t)strtoul(argv[2], 0, 16) : 0x4C09CC22u;
        int out[10][4], i, model = 0, inv = 0;
        fp = fopen("_corpses.txt", "r");
        while (fgets(line, sizeof(line), fp) && GN < NC) {
            char nm[80]; char sc;
            if (sscanf(line, " %c %79s", &sc, nm) == 2) {
                GSEC[GN] = sc; snprintf(GNAME[GN], sizeof(GNAME[GN]), "%s", nm);
                GCRC[GN] = crc32_fname(nm); GN++;
            }
        }
        fclose(fp);
        build_groups(L, 378, model, inv);
        printf("T L=0x%08X seed=378 model=%d inv=%d\n", L, model, inv);
        for (i = 0; i < 3; i++) {
            int k; printf("  sec %c:", "ABC"[i]);
            for (k = 0; k < GRP_N[i]; k++)
                printf(" %s", GNAME[GRP[i][k]] + 24);
            printf("\n");
        }
        simulate(378, out);
        for (i = 0; i < 10; i++)
            printf("  V=%d sec=%c j=%d pat=%s actor=%s\n", i, "ABC"[out[i][0]],
                   out[i][1], POOL[out[i][2]], GNAME[out[i][3]] + 24);
        return 0;
    }
    fp = fopen(argc > 1 ? argv[1] : "_corpses.txt", "r");
    if (!fp) { fprintf(stderr, "cannot open corpses file\n"); return 1; }
    while (fgets(line, sizeof(line), fp) && GN < NC) {
        char nm[80]; char sc;
        if (sscanf(line, " %c %79s", &sc, nm) == 2) {
            char full[128];
            GSEC[GN] = sc;
            snprintf(GNAME[GN], sizeof(GNAME[GN]), "%s", nm);
            snprintf(full, sizeof(full), "%s", nm);
            GCRC[GN] = crc32_fname(full);
            GN++;
        }
    }
    fclose(fp);
    fprintf(stderr, "loaded %d corpses\n", GN);

    {   /* 观测 */
        struct { const char *sec, *pat, *act; } o378[] = {
            {"A","Moon","AgainstWall_BP_2"}, {"A","Heart","AgainstWall_BP2_5"},
            {"B","Fire","WallThroat_BP7_26"}, {"B","Diamond","Desk_BP_5"},
            {"B","Bunny","Desk_BP2_2"},
            {"C","Spade","WallThroat_BP8_32"}, {"C","Eye","BP7_2"},
            {"C","Club","OnChair_BP3_8"},
        };
        struct { const char *sec, *pat, *act; } o565[] = {
            {"A","Heart","AgainstWall_BP3_8"},
            {"B","Club","BP10_35"},
            {"C","Eye","AgainstWall_BP9_2"},
        };
        size_t i;
        for (i = 0; i < sizeof(o378)/sizeof(o378[0]); i++) {
            char full[128];
            snprintf(full, sizeof(full), "CorpseSearch_PS_Trial02_%s", o378[i].act);
            OBS378[NOBS378].sec = o378[i].sec[0];
            OBS378[NOBS378].pat = idx_of_pool(o378[i].pat);
            OBS378[NOBS378].act = idx_of_actor(full);
            NOBS378++;
        }
        for (i = 0; i < sizeof(o565)/sizeof(o565[0]); i++) {
            char full[128];
            snprintf(full, sizeof(full), "CorpseSearch_PS_Trial02_%s", o565[i].act);
            OBS565[NOBS565].sec = o565[i].sec[0];
            OBS565[NOBS565].pat = idx_of_pool(o565[i].pat);
            OBS565[NOBS565].act = idx_of_actor(full);
            NOBS565++;
        }
        AMB378 = idx_of_actor("CorpseSearch_PS_Trial02_BP3_8");
        AMB378_ALT = idx_of_actor("CorpseSearch_PS_Trial02_AgainstWall_BP3_8");
        AMB565 = idx_of_actor("CorpseSearch_PS_Trial02_AgainstWall_BP5_2");
        AMB565_PAT = (char)idx_of_pool("Diamond");
        n378 = NOBS378;
        fprintf(stderr, "obs378=%d obs565=%d amb=%d/%d %d\n",
                NOBS378, NOBS565, AMB378, AMB378_ALT, AMB565);
    }

    t0 = omp_get_wtime();
    {
        long long xx;
#pragma omp parallel for schedule(dynamic, 65536) reduction(+:hits)
        for (xx = 0; xx < lim; xx++) {
            uint32_t L = (uint32_t)xx;
            int model, inv;
            int best = -1, bm = 0, bi = 0;
            int out[10][4];
            unsigned char h378[NC];
            compute_hot(L, 378, h378);
            for (model = 0; model < 2; model++) {
                for (inv = 0; inv < 2; inv++) {
                    int sc;
                    build_groups_h(h378, inv, model);
                    simulate(378, out);
                    sc = score(out, OBS378, n378);
                    if (sc > best) { best = sc; bm = model; bi = inv; }
                }
            }
            if (best < thresh) continue;
            {
                int sc2, i, sec, pat, act;
                build_groups(L, 378, bm, bi);
                simulate(378, out);
                /* 王冠那条（两解） */
                {
                    int c1 = -1, c2 = -1;
                    for (i = 0; i < 10; i++)
                        if (out[i][0] == 0 && out[i][2] == idx_of_pool("Crown")) c1 = out[i][3];
                    if (c1 >= 0) { }
                    (void)c2;
                }
                build_groups(L, 565, bm, bi);
                simulate(565, out);
                sc2 = score(out, OBS565, NOBS565);
                hits++;
#pragma omp critical
                {
                    printf("L=0x%08X model=%d inv=%d  s378=%d s565=%d\n", L, bm, bi, best, sc2);
                    fflush(stdout);
                }
            }
        }
    }
    printf("RESULT thresh=%d hits=%lld  %.1fs\n", thresh, hits, omp_get_wtime() - t0);
    return 0;
}
