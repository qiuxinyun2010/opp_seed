# -*- coding: utf-8 -*-
"""PSB_MT01：从 seed 推出「哪具尸体带哪个图案」。

模型（全部来自 sub_14361C230 反编译 + 已反解出的 B=0xCD055621）：

    组序 / 条目数      = A(3) -> C(4) -> B(3)，共 10 具
    第 V 具全局序号    = 累计；组内序号 j
    图案: pool[ RandSeeded(B + 223551 + V + j, |pool|, salt) ]  抽后保序删除
    尸体: group[ RandSeeded(B + 243551 + V + j, |group|, salt) ] 抽后保序删除   ★待验证

用法：
    python tools/psb_corpses.py indices        # 打印每个 seed/扇区的抽取下标
    python tools/psb_corpses.py constraints    # 由实测推出的初始槽位约束
"""
import sys, os
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.abspath(__file__))))
sys.path.insert(0, r'd:\workspace\outlast\opp_seed')
import seedcore as sc
import psb_mt01_static as S
import psb_model as pm

B = pm.B
OFF_KEY = pm.OFF_KEY
OFF_CORPSE = pm.OFF_CORPSE
GROUPS = pm.GROUPS           # [('A',3),('C',4),('B',3)]

BY_ACTOR = {c['actor']: c for c in S.CORPSES}


def group_of(sector):
    return [c for c in S.CORPSES if c['sector'] == sector]


def index_sequence(seed, sector, cnt, S_g, n):
    """返回该扇区这一局的抽取下标序列（对**当前**队长的取模）。"""
    salt = seed % 1000
    out = []
    V = S_g
    size = n
    for j in range(cnt):
        idx = sc.rand_seeded((B + OFF_CORPSE + V + j) & 0xFFFFFFFF, size, salt)
        out.append((V + j, j, size, idx))
        V += 1
        size -= 1
    return out


def plan(seed, sizes=None):
    """sizes = {扇区: 候选池大小}，默认用 ≥ cnt 的占位值。"""
    sizes = sizes or {}
    rows = []
    V = 0
    for sec, cnt in GROUPS:
        n = sizes.get(sec, cnt)
        for (saltpair, j, size, idx) in index_sequence(seed, sec, cnt, V, n):
            rows.append((sec, j, saltpair, size, idx))
        V += cnt
    return rows


def cmd_indices():
    sizes = {'A': 15, 'B': 10, 'C': 16}
    for seed in (378378, 565565, 111111):
        print('--- seed %d (salt=%d)' % (seed, seed % 1000))
        print('  %-3s %-3s %-8s %-6s %-6s %s'
              % ('sec', 'j', 'V+j', '|pool|', 'idx', '图案'))
        V = 0
        keys = pm.keys(seed)
        for sec, cnt in GROUPS:
            pool = list(pm.POOL)
            for (saltpair, j, size, idx) in index_sequence(seed, sec, cnt, V, sizes[sec]):
                pass
            # 重新 de novo 取图案，保证和 psb_model 一致
            pool = list(pm.POOL)
            Vv = V
            for j in range(cnt):
                ki = sc.rand_seeded((B + OFF_KEY + Vv + j) & 0xFFFFFFFF, len(pool), seed % 1000)
                pat = pool.pop(ki)
                ci = sc.rand_seeded((B + OFF_CORPSE + Vv + j) & 0xFFFFFFFF,
                                    sizes[sec] - j, seed % 1000)
                print('  %-3s %-3d %-8d %-6d %-6d %-8s %s'
                      % (sec, j, Vv + j, sizes[sec] - j, ci, pat,
                         S.PATTERN_ZH[pat] + ('  ← 钥匙' if j == 0 else '')))
            V += cnt
        print('')


def cmd_constraints():
    """把实测「某具尸体显示某图案」翻译成对「初始候选顺序」的约束。"""
    obs = {
        378378: {
            'A': {'Moon': 'CorpseSearch_PS_Trial02_AgainstWall_BP_2',
                  'Crown': 'CorpseSearch_PS_Trial02_BP3_8',
                  'Heart': 'CorpseSearch_PS_Trial02_AgainstWall_BP2_5'},
            'B': {'Fire': 'CorpseSearch_PS_Trial02_WallThroat_BP7_26',
                  'Diamond': 'CorpseSearch_PS_Trial02_Desk_BP_5',
                  'Bunny': 'CorpseSearch_PS_Trial02_Desk_BP2_2'},
            'C': {'Spade': 'CorpseSearch_PS_Trial02_WallThroat_BP8_32',
                  'Eye': 'CorpseSearch_PS_Trial02_BP7_2',
                  'Club': 'CorpseSearch_PS_Trial02_OnChair_BP3_8'},
        },
        565565: {
            'A': {'Heart': 'CorpseSearch_PS_Trial02_AgainstWall_BP3_8'},
            'B': {'Club': 'CorpseSearch_PS_Trial02_BP10_35'},
            'C': {'Eye': 'CorpseSearch_PS_Trial02_AgainstWall_BP9_2',
                  'Diamond': 'CorpseSearch_PS_Trial02_AgainstWall_BP5_2'},
        },
    }
    for seed in sorted(obs):
        print('--- seed %d' % seed)
        V = 0
        for sec, cnt in GROUPS:
            n = len(group_of(sec))
            free = list(range(n))          # 初始槽位 -> 初始下标
            for j in range(cnt):
                ci = sc.rand_seeded((B + OFF_CORPSE + V + j) & 0xFFFFFFFF,
                                    len(free), seed % 1000)
                slot = free.pop(ci)
                pat = _pattern_at(seed, sec, j, V)
                who = obs[seed].get(sec, {}).get(pat)
                print('  %s j=%d 初始槽位=%2d/%d  图案=%s %s'
                      % (sec, j, slot, n - 1, pat,
                         ('尸体=' + who.replace('CorpseSearch_PS_Trial02_', '')) if who else '(未记录)'))
                V += 1
        print('')


def _pattern_at(seed, sec, j, S_g):
    for s, rows in pm.simulate(seed):
        if s == sec:
            return rows[j][2]
    raise KeyError(sec)


if __name__ == '__main__':
    try:
        sys.stdout.reconfigure(encoding='utf-8')
    except Exception:
        pass
    cmd = sys.argv[1] if len(sys.argv) > 1 else 'indices'
    if cmd == 'indices':
        cmd_indices()
    elif cmd == 'constraints':
        cmd_constraints()
    else:
        print(__doc__)
