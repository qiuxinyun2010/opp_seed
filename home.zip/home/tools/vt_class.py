# -*- coding: utf-8 -*-
"""打印某个 vtable 槽附近的整段表，并标出与「用到 0x24B0/0x24C0 的函数」重合的槽。

用来判断哪些函数与某个已知成员函数同属一个类（同表相邻槽）。
"""
import struct
import sys
import os

_HERE = os.path.dirname(os.path.abspath(__file__))
sys.path.insert(0, _HERE)
import vaq

CAND = {
    0x1435DEE10: 'DEE10(+0x19E8)',
    0x143625200: '625200(+0x19E8)',
    0x14373BE80: '73BE80(+0x19E8)',
    0x143745BC0: '745BC0(+0x19E8)',
    0x14358E4A0: 'sync(world)',
    0x14358EA00: 'collect(tuners/screens)',
    0x14358ED80: 'ED80',
    0x14358EF70: 'EF70',
    0x14359BAD0: 'BAD0',
    0x143683220: '83220',
    0x1436B2100: 'B2100(add entry)',
    0x143704E30: '704E30',
    0x143704ED0: '704ED0',
    0x143704F80: '704F80',
}


def main():
    lo = int(sys.argv[1], 16) if len(sys.argv) > 1 else 0x145A05440
    hi = int(sys.argv[2], 16) if len(sys.argv) > 2 else 0x145A063F8
    target = int(sys.argv[3], 16) if len(sys.argv) > 3 else 0x145A061C8
    print('=== 表区 %X..%X，共 %d 槽；目标槽 %X (= idx %d)'
          % (lo, hi, (hi - lo) // 8 + 1, target, (target - lo) // 8))
    hits = []
    for i in range((hi - lo) // 8 + 1):
        a = lo + 8 * i
        q = struct.unpack_from('<Q', vaq.d, vaq.va2off(a))[0]
        if q in CAND:
            hits.append((i, a, q))
    print('--- 与候选函数重合的槽 ---')
    for i, a, q in hits:
        print('  idx=%3d %X -> %X  %-22s %s'
              % (i, a, q, CAND[q], '  <== 目标槽' if a == target else ''))
    print('--- 目标槽前后 12 个非零槽 ---')
    for i in range(max(0, (target - lo) // 8 - 12), min((hi - lo) // 8 + 1,
                                                        (target - lo) // 8 + 13)):
        a = lo + 8 * i
        q = struct.unpack_from('<Q', vaq.d, vaq.va2off(a))[0]
        if q:
            print('  idx=%3d %X -> %X%s'
                  % (i, a, q, '  <== 目标' if a == target else ''))


if __name__ == '__main__':
    main()
