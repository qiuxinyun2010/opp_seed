# RE_METHOD — 关卡随机化逆向的可复用方法（以 RES_MT02 为例）

本文件是**方法论与函数速查**，不是单关结论。单关结论看各自的 `<关卡>.md`。
下一次分析新关卡时，按 §1 的链条走、按 §4 的坑表自查、按 §3 抄原语。

---

## 1. 五步定位链

```text
关卡 JSON / pak                       ← 从 co-op 关卡目录导出（tools/ 下有 extract_*.py）
  → 协调器 actor 名 + 类名             e.g. MT02_CollectingJewels_Tuto / A...Coordinator_BP_C
  → 类的构造函数 ctor                  → 成员偏移从 ctor 里读（+92 / +14128 / +14472 …）
  → 虚表槽                             → vtable 里每个槽是一个行为（选房 / 选 spawner / 分类型）
  → 目标函数 → 反编译 → 随机原语与常量
```

要点：

1. **先读 ctor**。`ctor.c` 给出全部成员偏移与默认值（`bAlternatePricesUniformly` 之类），
   比在目标函数里猜 `*(a1+14208)` 是什么快一个数量级。
2. **虚表槽要一次列全**。同一个类里"收集 spawner（`+0x944`）"和"按开关启用 spawner（`+0x950`）"
   是相邻两个槽，选数量/选位置的逻辑往往在第三个槽，别看到第一个像就收工。
3. **常量反查归属**。看到 `v8 + 438361` 这种魔数，用「常数→函数」反查它属于谁
   （`66066` 就是 `ARBMinigameRoomsObjectiveCoordinator` 的，属于另一个类，误用会全盘错）。
4. 取代码三条路：REA MCP（`procedure_pseudo_code`）→ IDA headless（`tools/ida_query.py`）
   → capstone 兜底（`tools/dis_va.py`）。**provider 掉线不要卡住**，直接切下一条。

## 2. 随机原语的唯一权威实现

所有关卡共用一套（交付实现见 `opp_seed/seedcore.py`，分析用的旧副本在 `release/seed/seedcore.py`）：

| 名字 | 语义 |
|---|---|
| `RandSeeded(seed, n)` | `splitmix64(seed) & 0xFFFF` 再 `% n`；**盐来自全局** `g_salt % 1000`，不是参数 |
| `RandRangeInt(seed, lo, hi)` | 区间整数（含端点） |
| `RandFraction(seed)` | `[0,1)` 浮点，排序键常用 |
| `GetSeed(actor)` | `|crc32(class/name) + crc32(outer)|`，**只与名字有关，与关卡种子无关** |
| 盐 `salt` | `关卡种子 % 1000`。所以 `S` 与 `S+1000` 结果完全一样（写进各关文档） |

推论（很省事）：**同一关固定名字的对象，其 seed 跨局不变**；
关卡种子只通过 `salt` 和少数 `seed + 常数` 的调用点进入。

## 3. 三种"抽取"形态，先判形态再拟合

| 形态 | 代码特征 | 后果 |
|---|---|---|
| 长度递减 | `RandSeeded(v4+k, len(arr))` + 每轮 `RemoveAt` | 形成**排列**，后位不受已选影响 |
| 长度不变 | `RandSeeded(v4+k, 常量)` | 可重复选中；要额外去重 |
| 区间抽签 | `RandRangeInt(v4+k, 0, len(slots)-1)` + `slots.pop(r)` | 抽的是**配额桶**，不是位置 |

RES_MT02 主轴段是第三种（类别桶），教学段是第一种（51 全量排列）。
**判错的代价**：把「长度递减」当「长度不变」→ 位置全错但类别对，容易误判"几乎成功"。

## 4. 坑表（每一条都真实踩过）

| # | 坑 | 症状 | 正确做法 |
|---|---|---|---|
| 1 | `v42 = len(arr)` 只读一次，循环里不递减，递减的是 `RemoveAt` 后的 `len` | 把 51 当成 "上游预选的 6" | 循环上界看**谁在减**；`RemoveAt` 是条件调用时更要小心 |
| 2 | 循环计数器复位位置 | 分区循环 `counter` 从 2 起算 → 人偶 + 类别全错 | 在 `goto`/`while` 入口处重读 `counter = 0`，别沿用上一段的值 |
| 3 | `RemoveAt` 条件化 | 纯 shift/swap/fixed 三种模型全不成立 | 先反编译 `if (!sub_xxx(sp)) RemoveAt`，`sub_xxx` 往往是 `IsA + vtable` 的静态判定 |
| 4 | 排序"看起来"是按关卡顺序 | 命中率 ~2/6 | 比较器要反编译确认（多为名字大小写折叠升序），并按同一折叠规则排序 |
| 5 | 把 `GetSeed` 当成含关卡种子 | 搜 2^32 全灭 | `GetSeed` 纯名字 CRC；联合两局时它不变 |
| 6 | 幻数归属搞错（`66066`） | 结构对、数值全错 | 常数→函数反查，确认是同一类 |
| 7 | 只看一局就调参 | 过拟合到 6/6 但换局崩 | 双样本 join：两局**同时**成立的才留 |
| 8 | 把「记录歧义」当误差调参 | 越调越偏 | 歧义用「A 或 B」表达，单点异常单独记录（RES_MT02 的 `BP_139`） |

## 5. 拟合/搜索套路

1. **先枚举模型，再枚举种子**。模型（shift/swap/fixed/桶抽）+ 顺序（正/倒/排序名）
   + 基种子（CRC 组合）三层，逐层剪枝，不要一上来扫 2³²。
2. **向量化全扫**：numpy 分块 2²²，`mix16` 一次算一块，用样本做 join。
   一次全 2³² 扫描 ≈ 分钟级，比反复猜模型便宜。
3. **join 优于打分**：A 局 6 个 + B 局 4 个已知，取交集后**唯一解**才算闭环
   （PSB_MT01 的 `B=0xCD055621` 就是这么定的）。
4. **证伪要留档**：失败模型写进文档「已证伪」表（含脚本名），避免下次重复试。
5. **能绕就绕**：如果实战只需要"答案"而不需要"机制"，找出等价的替代路径
   （SRR_MT02 第 2/3 轮即如此：不必反推是哪 6 台）。

## 6. 验证纪律

* 预测器必须带 `--selftest`，且样本来自真实对局（写进 `<关卡>.md`）。
* 样本有歧义就保留「或」，**不要**为了提高命中率把它算成确定值。
* 单点异常（如 `BP_139` 两局都恰好相反）单独列，不参与调参；
  它往往指向"点位上有两个几乎重合的对象"或"记录错位"。
* 结论分三档标注：✅ 已闭环（实测全中）/ 🟡 部分 / 🔴 未解，README 与 `<关卡>.md` 保持一致。

## 7. 关键函数速查（RES_MT02 本轮核对过的，其他关通常同族）

| VA | 语义 | 备注 |
|---|---|---|
| `0x1402D29E0` | `RandSeeded(seed, n)` | 盐来自全局 `g_salt % 1000` |
| `0x140503B80` | `GetSeed(actor, 0)` | 纯名字 CRC 链 |
| `0x14018C680` | `Algo::Introsort` | 参数：首/尾/谓词 |
| `0x1402C6910` | 排序比较器 | actor 名字、大小写折叠升序 |
| `0x141C9CE10` | `TArray::RemoveAll(.., nullptr)` | 清空容器 |
| `0x140474200` | `TArray::RemoveAt(idx, n, shrink)` | 抽取后移除就是它 |
| `0x143993600` | "是否保留该 spawner" 判定 | `IsA(Interface) + vtbl+0x220`，**静态** |
| `0x1433B5BC0` | 教学段 `assign_class_by_spawner` | 51 全量排列 + `k % 2` 交替类别 |
| `0x1433B4F12` / `0x1433B505C` | 分区循环 / 房间轮流 | 有 `--trace` 可对照 |
| `0x1433B6CC0` / `0x1433B6B80` | 收集全部 spawner / 按列表开关 | vtable `+0x944/+0x950` |
| `0x1435DA9D0` | `ARBMinigameRoomsObjectiveCoordinator` | `66066` 常量属于它，勿混用 |

证据原文在 `release/coop/RES_MT02/evidence/*.c`（反编译存档），
取代码/反汇编工具在 `release/home/tools/`（`ida_query.py` / `pe_scan.py` / `dis_va.py`），
零散反编译按地址存 `tools/decomp/dec_<VA>.c`，需要引用时先查这里。

## 8. 环境备注

* REA MCP 的 `ida` provider 会掉线（`Not connected` / `-32001`）：重开 IDA 插件（`Ctrl+Alt+M`），
  或直接走 headless `idat` / capstone。
* PowerShell 控制台按 GBK 显示，中文乱码不代表脚本错；脚本里用 UTF-8 写文件、
  或 `sys.stdout.reconfigure(encoding='utf-8')`。
* 分析产物一律留在 `release/home/`，不要改动 `release/coop/` 里的原始导出。
