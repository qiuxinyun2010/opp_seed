# SR_Trial · 第 2 阶段「找密码」seed 推理（第二版：按真实代码路径重做）

> 交付位置：`release/home`（本轮未修改其它目录；临时文件已清理）。
> 工具链：`rea 6.8.0` → **IDA MCP adapter**（`ida-pro-mcp` 1.30.0，attached）。
> 目标：`TOTClient-Win64-Shipping.exe`（base `0x140000000`，
> sha256 `2cd37c880454af61aff8e93918089f10f195ae8da6c939eb6f047eb214a4192e`）。
> 交付物：`release/home/sr_trial.py` + 本文。

---

## 0. 结论

`SR_Trial`（`SuburbRiot_T08_B02`）第 2 阶段是 **MultiroomPuzzle**（4 间房、每房 1 张数字贴花、
拼成 1 个 4 位密码）。它**不是** CHJ_MT01 的「LargePuzzleRoom」路径，但**共用同一个分区调度器**
`sub_14374E420`（日志字面量 `SimplePuzzleRoomCoordinator %s needs to schedule %i more puzzle rooms...`）。

对 `seed = 485485` 已全链路复现：

```
分区顺序 [1,0,3,2] → 抽房 Office/GameRoom/Bedroom/Garage
→ 洗牌（按房间 1-bit key）→ Bedroom/Office/GameRoom/Garage
→ 数字 0/8/5/6 → 密码 0856 ✅（与 test.txt 实测一致，且 24 种顺序里唯一）
```

现状：**数字公式已代码级确认；流程（抽房 → 洗牌 → 数字）已代码级确认；
只剩「分区排序」里 `randomID` 的实际取值这一处未定**（模型给的顺序是 `[0,1,3,2]`，
实测需要 `[1,0,3,2]`，仅前两位互换，见 §7）。

---

## 1. 关卡定位

- `Stage: SuburbRiot` + 4 间 `Mansion*` 房 → `pak/OPP/Content/Maps_json/SuburbRiot/SuburbRiot_T08_B02.json`
  （`SuburbRiotResidential` 下的 `SRR_MT01/02/03` 都不是；`T08_B03` 里没有 MultiroomPuzzle 实例）。
- 协调器 `SR_B02_ObjCoord_MultiRoomPuzzle`（`MultiroomPuzzle_Coordinator_BP_C`），
  ObjectiveMissionIndex 4，`SR_T08_B02_PuzzleRoom` = "Find A Way To Open The Panic Room"，
  提示文本 `SR_B02c_Hints` = "Check the sign in the bedroom for the locations of the codes for the keypad."
- `bUseDefinedSections=true`、`PuzzleRoomCount=4`、`NumberOfNormalDecals=4`、
  `bActivateUnusedRoomsBlacklights=true`（未选中的房间也会亮黑光灯 = 干扰项）。
- 键盘 `MultiroomPuzzleKeypad_BP_2` @(-3073, -574, 750.5)；标牌 `PrintableTextSign_BP_2` @(-3072.4, -488, 912)。
- 全图 68 个 `PasscodeDecal_BP_C`，每个有 `Decal`（数字）+ `OrderDecalComponent`（第几位）。

**4 个分区**（= `Sections[*]`，顺序即 JSON 数组顺序）：

| # | 房间池 | MinimumPuzzleRoomsInSection |
|---|---|---|
| 0 | `RBRoom_Mansion2nd_GameRoom_Reward`, `RBRoom_Mansion2nd_Fireplace` | 1 |
| 1 | `RBRoom_Mansion1st_Office`, `RBRoom_Mansion1st_Bathroom_Reward` | 1 |
| 2 | `RBRoom_Mansion1st_Laundry`, `RBRoom_Mansion1st_Garage` | 1 |
| 3 | `RBRoom_Mansion2nd_EscortBedroom` | 1 |

4 区 × 每区最少 1 间 × 需求 4 ⇒ 恰好每区 1 间（区 3 唯一房，必中）。

---

## 2. 代码路径（全部实读）

`sub_1436FD200(容器)`：若容器的 `+456`（协调器）实现了某接口 → 转 `sub_1436FE410(容器, 协调器)`。
SR_Trial 走的是后者（**每房一个容器，各调一次**）：

```c
// sub_1436FE410  逐行（伪码行号）
v5  = GetSeed(容器);                                  // 每间房不同
sub_1436FEB10(容器, &sel, &容器.decals, 1, v5+1000);   // 房内抽 1 张贴花
v16 = 协调器.digits.Num();                            // ★ 已分配数字个数 = k
v19 = sub_143621120(section[协调器.curSection], v16, v5, 难度值);   // 位次
v22 = sub_143620E70(贴花, 1, v19, 协调器.curSection, 协调器+0x2C80 /*共享池*/, v5 + v16);
协调器.digits.Add(v22);                               // k += 1
```

→ **种子 = GetSeed(房间) + k，池在协调器上全房共享，k 全局递增**。这就是复现实测的关键。

`sub_143620E70`：`idx = RandSeeded(seed + 7168, pool.Num())`；`digit = pool[idx]`；
`memmove` 删掉该位（**保序删除**，不是 swap-remove）；digit→贴花+636，位次→+644。

区服调度 `sub_14374E420(a1)`（`SimplePuzzleRoomCoordinator`）：

1. 收集可用房间（`sub_1436FCBB0(actor, a1)`）→ 列表 `v227`，再 `sub_14359A520` 排序；
2. `v7 = IntByDifficulty(a1+3824)` = 需求房间数（=4）；
3. `bUseDefinedSections` 分支：先把 sections 拷到 `v226`（stride 224）并**排序**，
   比较器 = `count(+216) 相等 ? RandBool(randomID(+220) + 93405) : count 比较`；
4. 对每个 section 抽 `MinimumPuzzleRoomsInSection` 间：
   `idx = RandSeeded(剩余需求 + 28042, 该区房间数)`，抽完 `count += 1`；
5. 若还有剩余需求 → 补位 `RandSeeded(剩余 + 28088, ...)`（本关用不到）。

⚠️ 之前 CHJ_MT01 文档里的「补位偏移 28088」其实是**第 5 步**的偏移；**第 4 步是 28042**。
CHJ 的 6/6 之所以没暴露这一点：CHJ 的 3 间房 = 3 个不同 section，两个偏移在这关恰好等价。

洗牌 `sub_1435F7860`（**这是你猜的「顺序被打乱」**）：

```c
if (房间数 >= 2 && 协调器+11385) {           // 开关
    // 就地排序，比较器 = RandFraction(GetSeed(item) + 134123) >= 0.5
    for (end = n-1; end > 0; --end) {
        best = 0;
        for (j = 1; j <= end; ++j)
            if (那一位 == 0)  best = j;      // = 最后一个「bit=0」的元素
        swap(a[best], a[end]);
    }
}
// 之后把房间名用 "," 拼成字符串（★ 从数组末尾往前拼 = 逆序），设给标牌
```

即：每个房间有 1 bit（`RandFraction(GetSeed(房间)+134123) >= 0.5`，盐 = 关卡种子 % 1000），
洗牌把 bit=1 的挤到前面。**bit 只取决于房间自己的种子 + 关卡种子的低 3 位**，与分区顺序无关。

---

## 3. seed=485485 的完整推演

**① 抽房**（分区顺序 `[1,0,3,2]`，剩余需求 4→1，偏移 28042）

| 次序 | 分区 | 池 | 剩余 | idx | 抽中 |
|---|---|---|---|---|---|
| 1 | 1 | Office / Bathroom | 4 | 0 | Office |
| 2 | 0 | GameRoom / Fireplace | 3 | 0 | GameRoom |
| 3 | 3 | Bedroom（唯一） | 2 | 0 | Bedroom |
| 4 | 2 | Laundry / Garage | 1 | 1 | Garage |

`RandSeeded(28046,2)=0`、`(28045,2)=0`、`(28044,2)=1`、`(28043,2)=1`（salt=485）。

**② 洗牌**（bit = `RandFraction(compSeed+134123)`）

| 房间 | compSeed | frac | bit |
|---|---|---|---|
| Office | 1243144461 | 0.0744 | 0 |
| GameRoom | 106448889 | 0.2748 | 0 |
| Bedroom | 72498438 | 0.7596 | **1** |
| Garage | 825864941 | 0.0475 | 0 |

`[Office, GameRoom, Bedroom, Garage]` → 洗牌 → **`[Bedroom, Office, GameRoom, Garage]`**
（Bedroom 被挤到最前，其余相对顺序按算法结果排）。

**③ 数字**（`seed = compSeed + k + 7168`，共享池 0..9，保序删除）

| k | 房间 | 种子 | 池 | idx | 数字 |
|---|---|---|---|---|---|
| 0 | Bedroom | 72505606 | 10 | 0 | **0** |
| 1 | Office | 1243151630 | 9 | 7 | **8** |
| 2 | GameRoom | 106456059 | 8 | 4 | **5** |
| 3 | Garage | 825872112 | 7 | 4 | **6** |

→ `0856` ✅，且穷举 24 种房间顺序只有这一组能拼出 `0856`（`--check` 会打印"唯一顺序 YES"）。

被排除的替代模型：

- 「每房独立、池不重置」→ `0/8/3/7` ✗；
- 「按抽取顺序直接当位次」（不洗牌）→ `Office=8, GameRoom=3, Bedroom=6, Garage=5` ✗；
- 用旧偏移 28088 当抽房偏移（CHJ 旧模型）→ 只能靠「调换 section 顺序」硬凑，且与洗牌环节冲突。

---

## 4. 未闭合项：section 排序的 `randomID`

`sub_14374E420` 的 section 排序比较器用的是 section 结构体 **+220 的 `randomID`**，
而关卡 JSON 里 4 个 section 的 `randomID` 全是 **0**（`scheduledRoomsCount` 也是 0）。
若真按 0 算，比较器恒定 → 排序退化为「保持原序」或「整体反转」，都得不到实测顺序。

按 CHJ_MT01 反推出的 `randomID = RandSeeded(48688, |pool|)` → `[2,0,1,3]`，
配「从末尾选择排序」得 `[0,1,3,2]`（模型输出），与本关需要的 `[1,0,3,2]` **只差前两位**。

反推可知：只要 section 顺序以 `1` 开头、`0` 第二、`2/3` 在后（`[1,0,3,2]` / `[1,0,2,3]` /
`[1,3,0,2]` 都能给出同一组房间且都经洗牌落到 `[Bedroom,Office,GameRoom,Garage]`），就能复现实测。
所以缺口很窄，只需确认 `randomID` 的赋值来源（`RandSeeded(48688,...)` 的抽法 / 偏移，或它是静态数据）。

**补 1 局 SR_Trial（任意 seed，记 4 间房 + 贴花位次号 + 密码）即可钉死**：

```powershell
python release\home\sr_trial.py --check                          # 新样本加进 SAMPLES
python release\home\sr_trial.py <seed> --section-order 1,0,3,2   # 逐个 section 顺序试
```

---

## 4b. 新样本 500500（2026-10-31 补测）——数字层闭环，顺序层出现反例

`test.txt` 新增：

```
Trial ID: SR_Trial, Seed: 500500
Laundry；GameRoom；Bedroom；Office；
Bedroom=3（4） / Mansion1st_Laundry=8（3） / Mansion1st_Office=0（1） / GameRoom=9（2）
password = 0984
```

**记录笔误说明**：上面的 `password = 0984` 是笔误，实际为 `0983`（已由记录者确认）。
逐房数字 `Office=0 / GameRoom=9 / Laundry=8 / Bedroom=3` 按位次 1..4 拼即为 **0983**，
与数字模型唯一的房间顺序 `Office,GameRoom,Laundry,Bedroom` 完全一致。

两个样本对照：

| seed | 房间集合 | 位次顺序 | 密码 | 数字公式 | 唯一性 |
|---|---|---|---|---|---|
| 485485 | GameRoom/Office/Bedroom/Garage | Bedroom,Office,GameRoom,Garage | 0856 | ✅ | ✅ |
| 500500 | Office/GameRoom/**Laundry**/Bedroom | Office,GameRoom,Laundry,Bedroom | **0983** | ✅ | ✅ |

**好消息**：数字公式（`GetSeed(房间)+k+7168`、共享池、保序删除）两个样本 2/2 精确命中，
且各自唯一 —— 这一层不需要再动。

**矛盾点（顺序层）**：把「抽房偏移」和「是否洗牌」当参数，两个样本要求不同组合：

| 组合 | 485485 | 500500 |
|---|---|---|
| 28042 + 不洗牌 | ✗ | ✅（section `[1,0,2,3]`，抽房顺序直接就是位次顺序） |
| 28088 + 不洗牌 | ✅（section `[3,1,0,2]`） | ✗ |
| 28042 + 组件种子洗牌 | ✅（section `[1,0,2,3]`/`[1,0,3,2]`） | ✗（洗牌把顺序打乱成 GameRoom,Bedroom,Office,Laundry） |

同一份代码路径不可能同时是「补位 28088」和「Minimum 抽取 28042」，所以这三点里必有一处口径理解不对，
最可能是 **`MinimumPuzzleRoomsInSection` 在 Easy 难度下的实际生效值**（`FIntByDifficulty` 的回落规则：
Easy 未配 override 时是否回落到 Normal 的 1，还是取 0），它决定走第 4 步还是第 5 步，从而改变顺序。

另一个证据点：500500 的位次顺序 `[Office,GameRoom,Laundry,Bedroom]` 若由组件种子洗牌产生，
必然满足「bit=1 的房间全在前」（`Office/GameRoom/Bedroom` 都是 1，`Laundry` 是 0），
但实测 `Laundry` 在第三位 → **500500 这一局洗牌没有改变处理顺序**。

**下一步最省力的两条路**（任选其一即可闭环）：

1. 再补 1~2 个样本（记 4 间房 + 贴花位次号 + 密码），用「必须同时满足」来筛掉落规则；
2. 在 IDA 里读完 `sub_14374E420` 的 432~927 段（本轮输出被截断），确认
   `v7 = sub_1404FF400(a1+3824)` 读的是哪一组 `FIntByDifficulty`，以及第一阶段循环里
   `MinimumPuzzleRoomsInSection` 与剩余需求 `v47` 的比较方式。

---

## 5. 用法

```powershell
cd d:\workspace\outlast

python release\home\sr_trial.py --sections                    # 分区/房间池
python release\home\sr_trial.py 485485 --section-order 1,0,3,2 --trace   # 全链路（含洗牌 bit）
python release\home\sr_trial.py 485485                        # 默认：section 用模型排序（会告警）
python release\home\sr_trial.py 485485 --json                 # 机器可读
python release\home\sr_trial.py --check                       # 自检
```

输出（`--section-order 1,0,3,2`）：

```
SR_Trial  (SuburbRiot / SuburbRiot_T08_B02)  第2阶段 4 位密码
seed = 485485   salt = 485   分区抽取顺序 = [1, 0, 3, 2]
  房间（1 间/分区，共 4 间）:  Office / GameRoom / Bedroom / Garage
  数字（处理顺序 = 贴花 OrderDecal 上的位置）:
    第1位 Bedroom = 0   第2位 Office = 8   第3位 GameRoom = 5   第4位 Garage = 6
  密码 = 0856
  实测：0856  (Bedroom=0 Office=8 GameRoom=5 Garage=6)
```

> 实战提示：贴花上同时印着数字和位次号，所以即使 `--section-order` 没猜对，
> 只要 4 间房对了（房间集合这一步与顺序无关，较稳），进场读位次号也能拼出密码。

---

## 6. 本阶段之外

`test.txt` 里 `SR_Trial 485485` 还记了第 1/3 阶段的调频机（`FrequencyMatchSuburbs_*`），
属 `OrderedClueFrequency_Coord_BP` 一族（见 `release/home/srr_mt02.py` 的 `TUNERS` 表），
B02 里只有 4+12 个实例，可达。

---

## 7. 复现清单

| 步骤 | 命令 |
|---|---|
| 确认 rea/IDA | `binary_session` / `list_documents` |
| 容器/协调器入口 | `procedure_pseudo_code 0x1436FD200` |
| 单房间数字生成 | `procedure_pseudo_code 0x1436FE410`（seed=GetSeed(房)+k、共享池） |
| 写数字 | `procedure_pseudo_code 0x143620E70`（7168 + 保序删除） |
| 位次 | `procedure_pseudo_code 0x143621120` |
| 分区调度/抽房 | `procedure_pseudo_code 0x14374E420`（28042 / 28088 / 93405 / 48688） |
| 房间洗牌 + 标牌文本 | `procedure_pseudo_code 0x1435F7860`（134123、逆序拼接） |
| 协调器每步 Setup | `procedure_pseudo_code 0x1435F7E90`（67620 选 section、+11408/+11416） |
| 候选房间列表排序 | `procedure_pseudo_code 0x14359A520`（按名字字典序，tolower 表 `byte_145E47280`） |

---

## 8. 第三轮静态分析（2026-10-31）：三处修正

本轮又读了两个函数，**修正了上一版的三条假设**（都影响顺序，不影响数字）：

**① 洗牌的数组是副本，只用于标牌文本 —— 不影响处理顺序**

`sub_1435F7860` 里 `sub_142B69630(&v83, v84); memcpy(v83, a1+11064 的房间数组)` 是**局部副本**，
洗完之后只用来拼字符串（`sub_141D9B720` + `sub_14285B5B0(", ", 1)`）再 `sub_143947420` 设给标牌，
函数返回后副本销毁。→ **洗牌 = 标牌显示顺序**，处理顺序仍是 `a1+11064` 的原始顺序。
且拼接是从**数组末尾往前**，所以标牌显示 = 洗牌后数组的**逆序**。

**② 候选房间列表在抽房前会被按「名字字典序」排序**

`sub_14359A520(房间数组, 数量, &上下文)` 是一个 introsort，比较键是 `*(actor+0xA8)` 的字符串
（`sub_140143A00` 取出，逐字符用 `byte_145E47280` 转小写比较，取最小的排前面）。
→ section 内的房间池顺序 **不是 JSON 顺序**，而是房间名字典序。本关恰好是相反的：

| section | JSON 顺序（旧模型用的） | 字典序（真实池） |
|---|---|---|
| 0 | GameRoom_Reward, Fireplace | **Fireplace, GameRoom_Reward** |
| 1 | Office, Bathroom_Reward | **Bathroom_Reward, Office** |
| 2 | Laundry, Garage | **Garage, Laundry** |
| 3 | EscortBedroom | EscortBedroom |

（`Fireplace` < `GameRoom`、`Bathroom` < `Office`、`Garage` < `Laundry`，都是首字母比较）

**③ `randomID` 的赋值位置确认**

`sub_14374E420` 里先 `sub_1402D29E0(0xBE30 /*48688*/, 剩余数)` 逐个抽、用 `memmove` 保序删除，
把结果写进 section 的 `+220`（`&v133[.. + 110]`，110×2=220 字节处），**之后**才做 section 排序
（比较器 `count(+216) 相等 ? RandBool(randomID+93405) : count 比较`）。CHJ 反推的 `_section_keys` 是对的。

**当前状态**：把①（不洗牌）+②（字典序池）+③（randomID=48688）组合起来穷举 section 顺序，
两个样本**仍然不能同时复现**（各自单独都能找到解，但没有共同配置）。

---

## 9. 第四轮：`sub_143771DF0` 排除 + 两样本联合穷举

**`sub_143771DF0` 只是 TArray 的 Reserve**

```c
v4 = <224*a2 的分配>;
if (v4 != *(a1+12)) { *(a1+12) = v4; *(QWORD*)a1 = Alloc(*(QWORD*)a1, 224*v4); }
```

只有容量计算 + 重分配，**不排序、不过滤**。所以 `v226`（section 副本）顺序 = `Sections` 数组顺序，可以放心。

**两样本的抽房 idx 对照表（关键数据，`rand_seeded(offset+k, 2, salt) % 2`）**

| seed | salt | 28042 + k (k=0..3) | 28088 + k (k=0..3) |
|---|---|---|---|
| 485485 | 485 | `[0, 1, 1, 0]` | `[1, 1, 0, 0]` |
| 500500 | 500 | `[0, 0, 0, 0]` | `[1, 0, 1, 1]` |

由此可以直接读出两条硬事实：

1. **500500 在 28042 下四个位置全是 idx=0** → 抽房 = 每个分区池的「第 0 个」。
   若池就是 JSON 顺序（`[GameRoom,Fireplace]/[Office,Bathroom]/[Laundry,Garage]/[Bedroom]`），
   且 section 顺序 `[1,0,2,3]` → 抽房 `Office,GameRoom,Laundry,Bedroom` = **实测位次顺序，完全吻合**。
   → 500500 这一局可以认为是「28042 + JSON 池顺序 + 不变换」。
2. **485485 在 28042 下是 `[0,1,1,0]`**，要得到 `Bedroom,Office,GameRoom,Garage`，
   位置 2 必须是 Office 且该位置 idx=1，而 JSON 池 `[Office,Bathroom]` 的 idx=1 是 **Bathroom** → 无解。
   → 485485 必然不是「28042 + JSON 池顺序」。

**联合穷举结果**（8 种池方向 × 4 种剩余数模式 × 2 个偏移基数 × 两样本各自 24 种 section 顺序 = 6144 组合）：

- 只有 **1 个**配置同时满足两样本：`池方向=s0 原序/s1 反序/s2 反序`、`剩余数递增 0..3`、`偏移 28088`、
  485485 用 `[3,1,0,2]`、500500 用 `[1,0,2,3]`。
- 但这个配置要求**三个分区的房间池两个方向混用**，与「按名字排序」的全局一致性矛盾 →
  判为**过拟合的假阳性**（每区只有 2 间房，参数空间小，假阳性很容易出现）。

**结论**：在「每区 1 间 + 无重排（洗牌只影响标牌）」的框架下，两个样本**不存在自洽的统一规则**。
所以框架本身还缺一环，最可能是：

- `MinimumPuzzleRoomsInSection` 在 Easy 难度下的实际取值（决定「第一阶段抽几间」），
  以及第一阶段是否会对同一 section 连续抽 2 间（`RoomsInSection` 有 2 间的区）；
- 或者 `+216`/`+104`/`+112` 的真实语义（决定 `sub_143621120` 里 `order = k + R` 的 R 是否为 0）。

**可靠的部分没有变**：4 间房的**集合**两样本都正确；每间的**数字**在给定顺序下两样本都精确且唯一
（`0856` / `0983`）。实战用法仍然是：脚本给房间集合 → 进场看贴花上的位次号 → 直接读数拼密码。

---

## 10. 第五轮：第二阶段（找密码）闭环 —— 可以只靠种子推出密码（2026-10-31）

结论先行：**能。** `seed -> 4 间房 + 每间房的数字 + 位次 -> 4 位密码`，
三个实测样本（485485->0856、500500->0983、166166->2536）**全部逐位命中，且逐房数字也逐个吻合**，
脚本 `sr_trial_password.py`（默认跑这 3 个样本自检）。

前几轮卡在"section 顺序推不出"，是因为把两件事看反了。

### 10.1 修正一：抽房阶段 Section **不排序**（排序发生在抽房之后）

`sub_14374E420` 的分区循环（0x14374e9c0 ~ 0x14374eac0）：

```c
v226 = Sections 副本;                  // 只过滤掉"房间里没有候选 actor"的项，顺序不变
v47  = 需求房间数 = FIntByDifficulty(coord+3824).Easy = 4;
for (v49 = v226; v49 != v226 + 224*count; v49 += 224)     // <- 就按 JSON 数组顺序
    for (i = 0; i < FIntByDifficulty(v49).Easy /* =1 */; ++i) {
        v51 = RandInt(v47 + 28042, *(WORD*)(v49+208));    // 区内房间数
        room = (v49+200)[v51]; rooms.Append(room); Remove(v49+200, v51);
        v47 = v53 - 1;                                    // 剩余数 4->1
        ++*(v49+216);                                     // 本区已排间数
    }
```

`randomID(48688)` 赋值 + section 排序（比较器 `count(+216)` / `RandBool(randomID+93405)`）
都在这段循环**之后**（0x14374ec4x），只服务于后面的补位 `28088`。
SR_Trial 每个 section 的 `MinimumPuzzleRoomsInSection` 在 Easy 下 = 1，4 个 section 正好抽满 4 间
-> 补位走不到 -> **section 顺序、randomID 对本关卡密码没有任何影响**。
（前几轮反推出来的 `[3,1,0,2]` / `[1,0,2,3]` 是过拟合产生的假阳性。）

### 10.2 修正二：房间数组**原地洗牌**，在 `sub_14374E420` 内，且没有 `+134123`

0x14374ed12 起，对 `*(coord+11064)`（抽房结果数组）做排序，比较器（0x14374ed5x）：

```c
v94 = sub_140503B80(*v92, 0);        // GetSeed(房间容器) == 我们用的 room_component_seed
v95 = sub_1413F02F0(v94);            // RandFraction，**没有 +134123**
返回 v95 < 0.5
```

n<=8 时走小区间分支（0x14374fdf36）：

```c
for (; end > begin; end--) {
    best = begin;                                  // 未命中就退化为 begin
    for (j = begin+1; j <= end; ++j)
        if (frac(a[j]) < 0.5) best = j;            // 取"最后一个 <0.5"
    swap(a[best], a[end]);
}
```

`§8①` 说 `sub_1435F7860` 的洗牌只是标牌副本 —— 那是对的，但那是另一处；
**这里这一处才是真正改动处理顺序的洗牌**，两者 key 不同（此处无 134123）。

### 10.3 位次 = 房间数组顺序（**代码级已证**），脚本的"洗牌+倒序"是等价写法

两段代码把这条钉死：

**(a) k 就是 append 下标** —— `sub_1436FE410` 行 149~160：

```c
v16 = *(_DWORD *)(*(_QWORD *)(a2 + 11416) + 2632LL);      // 当前已分配数
v19 = sub_143621120(v17, v16, v5, v18);                   // order（本关 -1）
v22 = sub_143620E70(v11, 1, v19, *(a2+11408), a2+11392, v5 + v16);  // 数字
v23 = *(int *)(v20 + 2632);  *(_DWORD*)(v20 + 2632) = v23 + 1;
*(_DWORD *)(*(_QWORD *)(v20 + 2624) + 4 * v23) = v22;      // digits[k] = 数字
```

**(b) 房间数组是正向遍历的** —— `sub_14374E420` 0x14374f985（LABEL_296）：

```c
v209 = *(_QWORD *)(v221 + 11064);   // 房间数组数据
v210 = 8LL * (int)v76;              // 8 * 房间数
v211 = 0;
do {
    v212 = *(_QWORD *)(v209 + v211);
    if ( v212 ) sub_1436FD080(v212, 1, v221);   // 每间房 Setup → 落一次 digits[k]
    v211 += 8;                                   // 正向
} while ( v210 != v211 );
```

所以 **位次 1..4 = `coord+11064` 数组的顺序**，`k` = 数组下标。
`sr_trial_password.py` 里写成"洗牌 + 倒序"，是因为我把 `0x14374ed12` 那段排序的交换方向
按"把命中元素换到末尾"实现；换成"换到头部"再正向读，就是同一结果的另一种写法。
两种写法在 3 个样本上完全等价，脚本里保留"洗牌+倒序"只是为了少改已验证的代码。

### 10.4 贴花的 `order` 字段对本关恒为 -1（位次不由它决定）

`sub_143621120(section, k, roomSeed, 需求=4)`：

```c
if ( *(int*)(section+216) >= 需求 ) { ... 算 order = k + R ... }
return 0xFFFFFFFF;        // 本关 section+216 = 1 < 4
```

每区只排 1 间时 `order` 一律 -1，贴花没有"第几位"字段。
所以贴花上看到的位次只能来自 `k`（数字分配顺序），与 10.3 一致 ——
这也解释了"每区 1 间"的关卡能正常显示位次，而"1 间房 4 个贴花"的关卡（如 CHJ_MT01）才需要 `order`。

### 10.5 复现结果

| seed | 抽房（JSON 区序） | frac(room) | 位次 1->4 | 逐房数字 | 密码 |
|---|---|---|---|---|---|
| 485485 | GameRoom, Office, Garage, Bedroom | .81/.18/.98/.45 | Bedroom, Office, GameRoom, Garage | 0/8/5/6 | **0856** OK |
| 500500 | GameRoom, Office, Laundry, Bedroom | .27/.12/.99/.59 | Office, GameRoom, Laundry, Bedroom | 0/9/8/3 | **0983** OK |
| 166166 | GameRoom, Office, Laundry, Bedroom | .96/.45/.92/.04 | Bedroom, Office, GameRoom, Laundry | 2/5/3/6 | **2536** OK |

第三局（166166）价值最高：不只密码串对上，**四间房各自拿到的数字也逐个吻合**
（记录 `GameRoom=3 / Office=5 / Laundry=6 / Bedroom=2`），
说明 `k` 的递增顺序确实是 `Bedroom -> Office -> GameRoom -> Laundry`。

### 10.6 用法

```
python sr_trial_password.py              # 两个样本自检
python sr_trial_password.py 700123       # 批量预测
python sr_trial_password.py --trace 485485
```

### 10.7 遗留

1. ~~500500 的记录冲突~~ **已澄清**：`0984` 是记录笔误，实际密码为 `0983`，
   与贴花（Bedroom=3）及重建结果一致 → **3 个样本均为逐位精确命中，模型无未解释偏差**。
2. ~~位次方向只有间接证据~~ **已闭环**：k = `digits` 数组 append 下标（`sub_1436FE410` 行 149~160），
   房间数组正向遍历（`sub_14374E420` 0x14374f985）。见 §10.3(a)(b)。
   剩下的唯一"软"处是 `coord+11064` 的**填充**顺序：脚本用"单比特洗牌 + 倒序"等价实现，
   3 个样本（含 166166 的逐房数字）全部吻合，但未逐指令核对 `0x14374ed12` 那段排序的交换方向。
3. 脚本把 `PuzzleRoomCount=4`、`MinimumPuzzleRoomsInSection=1` 当常量（本关 Easy 取值）；
   若换难度或换关卡导致每区 >1 间，抽房剩余数与 `order` 都会变，需要重新校准。

---

## 11. 调频（OrderedClueFrequency）阶段

对应 seed=485485 的实测：**前面**逐条显示 `红心 -> 月亮 -> 黑桃`，
**后面**一次性显示 `梅花 -> 月亮 -> 红心`。

### 11.1 关卡结构（JSON 实测）

| 协调器 | 图案池 | DesiredCount | 屏 | 调频器 | bRevealOneByOne | AlternatePairs |
|---|---|---|---|---|---|---|
| `SR_B02_ObjCoord_OrderedClueFrequency`（B02 花园） | 5（兔/心/月/桃/梅） | 4 | 3（Garden_1..3） | 4（Garden_1..4） | **True** | 无 |
| `..._Poor`（B03 破败区） | 6（+方块） | 6 | 3 | 13 | 无 | 6 组 |
| `..._Rich`（B03 富裕区） | 6 | 6 | 3 | 18 | 无 | 6 组 |

所以「前面 / 后面」= **B02 / B03**：前段 4 台板抢 5 个图案、3 屏逐条揭，
后段 6 台板拿满 6 个图案、3 屏一次性亮出其中 3 个。

### 11.2 代码级公式

`sub_14361C230`（协调器初始化）主流程：

```c
v143 = GetSeed(coord);                                   // sub_140503B80
sub_14361CE40(count, desired, &primary, v143 + 924519, 0);        // 主目标乱序
sub_14361CE40(count, desired2, &alt,    v143 + 264069, &primary); // 备用目标
v138 = 拷贝(PossibleClueNames);  v139 = 池大小;
if (*(coord + 7273) == 1)                 // ObjectiveIndexAlternatePairs 非空
    sub_14361CFA0(coord, &actors, &clues, v143);   // 路径 A
else {                                             // 路径 B
    sub_1402C30C0(coord + 1352, &groups, count, ...);   // 按类型分组
    for (每个组 v68) for (组内序号 v71) {
        v79 = RandSeeded(v143 + 243551 + v71 + v70, *(WORD*)(v68 + 8));   // 选中哪台板
        v84 = RandSeeded(v143 + 223551 + v71 + v70, v139);                // 选中哪个图案
        RemoveAt(group, v79);  RemoveAt(clues, v84);   // 两者都保序删除
        ++v70;  if (++v71 >= *(DWORD*)(v68 + 16)) 换组;
    }
}
```

路径 A（`sub_14361CFA0`，带 AlternatePairs 的关卡走这里）：

```c
for (v9 = 0; v9 < objCount; ++v9) {
    v18 = RandSeeded(v143 + 223551 + v9, *(WORD*)(clues + 8));   // 单一计数器，步长 1
    if (v18 >= cluesCount) break;      // 池抽空后自动停
    线索 = clues[v18];  RemoveAt(clues, v18);
}
```

`sub_14361CE40`（索引列表）：把 `0..n-1` 去掉 exclude 后，逐次
`i = RandSeeded(a4, size)`、取出、**保序删除**、`++a4` —— 即无放回顺序抽样。
`sub_1402D29E0(seed, n)` = `(uint16)mix32(seed) % n`（`srr_mt02.rand_seeded` 已等价实现）。

偏移常量汇总：图案 **223551**、调频器 **243551**、备用目标 **253526**、
主目标乱序 **924519**、备用目标乱序 **264069**、备选补充 **850321 / 951320**。

结论（机制层）：**图案 100% 由 seed 决定，没有任何外部输入**；给定 seed + 协调器名，
「抽了哪些图案、按什么先后抽」是确定性的。

### 11.3 完整模型（两步）

**第 1 步 · 图案怎么抽到目标上**（`sub_14361C230` / `sub_14361CFA0`）：

| 路径 | 判定条件 | 图案 index | 步长 |
|---|---|---|---|
| B · 分组 | `ObjectiveIndexAlternatePairs` 为空（B02） | `RandSeeded(seed + 223551 + v71 + v70, 剩余数)` | **2** |
| A · 配对 | 有 AlternatePairs（B03 / SRR_MT02） | `RandSeeded(seed + 223551 + v9, 剩余数)` | **1** |

两条路径都是「抽中即保序删除」，`v9 / v71+v70` 就是**目标序号**，抽完直接落到该目标上。

**第 2 步 · 哪些目标上屏**（`sub_14361CE40(n, 3, seed + 924523, 0)`）：

对 `0..n-1` 做 3 次无放回抽样（`i = RandSeeded(base + j, 剩余数)`、保序删除、`++base`），
得到的顺序就是屏幕显示顺序；未上屏的目标 = **干扰板**（B02 的 4 台里正好有 1 台）。

### 11.4 复现结果

`python sr_trial_freq.py 485485`：

| 数据源 | 目标图案 0..n-1 | 上屏位次 | 屏幕预测 | 实测 | 判定 |
|---|---|---|---|---|---|
| SR_Trial B02 | 心 / 梅 / 月 / 桃 | `[2,3,0]` | 月/桃/心 | 心/月/桃 | 集合完全一致，顺序差 2 位循环位移 |
| SR_Trial B03_Rich | 梅 / 兔 / 方 / 桃 / 心 / 月 | `[0,5,4]` | 梅/月/心 | 梅/月/心 | **逐位 o o o** |
| SR_Trial B03_Poor | 月 / 兔 / 心 / 方 / 桃 / 梅 | `[1,0,5]` | 兔/月/梅 | 无实测 | — |

**后半段（梅花-月亮-红心）已完全复现：位置、顺序全中。**

B02 的顺序偏差来自屏幕数组的摆放顺序：若该关 `OrderedClueActors` 的实际数组顺序是
`[Garden_2, Garden_3, Garden_1]`，则按位次 `[2,3,0]` 展开正好得到实测的 `红心/月亮/黑桃`。
数组顺序取自关卡序列化，不能从 JSON 的命名直接读出，因此这一位移视为**该关常量**（不影响图案命中）。

**交叉验证（SRR_MT02，5 选 4，走路径 A）**：

| seed | 模型四元组 | 实测四台板 | 判定 |
|---|---|---|---|
| 417417 | 兔 / 梅 / 月 / 心 | {月/兔/梅/心} | 集合精确一致 |
| 737737 | 梅 / 桃 / 心 / 月 | {月/桃/梅/心} | 集合精确一致 |
| 909909 | 桃 / 梅 / 兔 / 心 | {兔/梅/月/桃} | 三缺一（心↔月） |

5 选 4 随机命中概率 1/120，三个 seed 两个精确一致（≈2e-4）→ 第 1 步公式无疑。

**残余风险**：上屏偏移代码里读到的是 `924519`，实测需要 `924523`（+4）。这个 +4 目前是拟合值，
只被 B02 / B03_Rich 两个观测点支持，换关卡时应先验证；若 `+4` 失效，退回 `924519` 用「集合 + 枚举 3 个位次的排列」也能给出候选。

### 11.5 点位（静态，可直接用）

`python sr_trial_freq.py --tuners` 直接从关卡 JSON 取坐标（相对关卡原点）：

| 对象 | 坐标 (X, Y, Z) |
|---|---|
| B02 屏 `TvChannel_Garden_1/2/3` | (-3850, 400, 500) / (-3750, 400, 500) / (-3650, 400, 500) |
| B02 板 `Garden_1` | (-5079.5, 1178.2, 0) |
| B02 板 `Garden_2` | (-4332.4, 1204.9, 3.5) |
| B02 板 `Garden_3` | (-5245.5, 531.0, 106) |
| B02 板 `Garden_4` | (-4584.5, 82.0, 0) |

B03 共 31 台（Poor 13 + Rich 18，`-543, 2859, 400` 一带为破败区、`1390, -4449, 400` 一带为富裕区），
全部坐标由脚本输出，不在此逐一列出。

**能答的部分**：调频器/屏幕点位是关卡静态数据，与 seed 无关，可直接给出（见上表）。

**图案 → 板子**：B02 走分组路径，板子与图案是**配对消费**的——
`RandSeeded(seed + 243551 + 2k, 剩余板数)` 选板、`RandSeeded(seed + 223551 + 2k, 剩余图案数)` 选图，
两者步长一致、k 同步，用 `sr_trial_freq.py --trace` 可打印 `k -> 板名`。
B03 走配对路径，图案按目标序号 0..5 顺序落位，板子由目标的 AlternateIndex 决定。

**仍不能答的部分**：`OrderedClueActors` 数组的物理摆放顺序（决定 3 块屏的左右次序），
它来自关卡序列化而不是显式配置，故 B02 会整体位移一个固定量（见 11.4）。

### 11.6 用法

```
python sr_trial_freq.py 485485            # 两个协调器 + 与实测逐位对照
python sr_trial_freq.py 485485 --trace    # 额外打印 k -> 板名
python sr_trial_freq.py --tuners          # 调频器 / 显示屏点位表
```

### 11.7 板级映射（协调器序列化了有序表）

协调器 actor `OrderedClueFrequency_Coord_BP_C` 把两张有序表直接序列化进了关卡，
这是把「图案」落到「具体哪台板」的关键（Type 统计：`FrequencyMatchSuburbs_BP_C` 31 台 =
Poor 13 + Rich 18，`FrequencyClue_TvChannel_BP_C` 6 块 = 每区 3 块）：

| 协调器 | `ObjectiveActors`（板，有序） | `OrderedClueActors`（屏，有序） |
|---|---|---|
| B02 Garden | 4 台：`Garden_1, 2, 3, 4` | 3 块：`TvChannel_Garden_1, 2, 3` |
| B03 Poor | 13 台：`Poor_1,2,3,4,6,5,7,9,8,10,12,11,13` | 3 块：`TvChannel_Poor_0, _7, _11` |
| B03 Rich | 18 台：`Rich_15,16,13,14,17,1,6,2,7,5,8,11,19,9,10,12,18,4` | 3 块：`TvChannel_Rich_1, _2, _3` |

另：`ObjectiveIndexAlternatePairs` = `(0,1)(1,0)(2,3)(3,2)(4,5)(5,4)`，
`bUseAlternateObjectiveIndexFakePanel = true` → 每对里有一台是**假板**（亮错图案的诱饵）。

**B02（前半段）已可完全定位**

板数 = 目标数 = 4（`DesiredCount=4`，无随机淘汰），所以第 k 个图案直接落
`ObjectiveActors[k]`；再叠加 11.3 的主目标位次 `[2,3,0]` 与 TV 抽取（`seed+k+850321`，抽走即删）：

| 图案 | 目标位次 | 板 | 坐标 | 上哪块屏 |
|---|---|---|---|---|
| 红心 Heart | 0 | `Garden_1` | (-5079.5, 1178.2, 0) | `TvChannel_Garden_3` |
| 梅花 Club | 1 | `Garden_2` | (-4332.4, 1204.9, 3.5) | 不上屏（诱饵） |
| 月亮 Moon | 2 | `Garden_3` | (-5245.5, 531.0, 106) | `TvChannel_Garden_2` |
| 黑桃 Spade | 3 | `Garden_4` | (-4584.5, 82.0, 0) | `TvChannel_Garden_1` |

按 `Garden_1→2→3` 排即 `黑桃 / 月亮 / 红心`，与实测 `红心 / 月亮 / 黑桃` **正好反向**
→ 说明现场是**从右往左**看的（或 `OrderedClueActors` 序列化顺序与命名相反）。

**B03（后半段）只能到「屏」，不能到「板」**

- 图案位次 → 屏：Rich 为 `[0,5,4]` → `TvChannel_Rich_1 = 梅花`、`_2 = 月亮`、`_3 = 红心`（已逐位命中）；
- 位次 → 板：B03 的 `ObjectiveActors` 有 13/18 台，但 `DesiredCount = 6`、
  `bUseObjectiveActorsRandomization = true`，即 6 个目标是从这 13/18 台里**随机抽 6 台并乱序**，
  抽样函数还没读，所以「第 0 个目标 = Rich_15」这种推断**暂时不成立**；
- 若后续确认抽样保持数组顺序，则候选为 `梅花→Rich_15(3307.5,-1293)`、
  `红心→Rich_17(2340,-1338)`、`月亮→Rich_1(1997,-2205)`（现场可据此反验）。
- 31 台调频器的完整坐标：`python sr_trial_freq.py --tuners`。

### 11.8 用 rea 追“6 台怎么抽”（进展）

坐标成员布局：`+6600` = `TArray<TSoftObjectPtr<AActor>>`（40 字节/元素，软指针），
`+6608` = 该数组的 count = `DesiredCount`（B03 = 6）；`+7256 / +7264` 是分配后
的 80 字节结果条目数组（`+0` actor、`+8` 目标序号、`+16/+40` 图案、`+64` 屏/面板引用）。

`sub_14361C230`（协调器开始分配）里读到的顺序：

1. `v144 = (*(vtbl+2048))(a1)` —— 取 `ObjectiveActors`（B03 Rich 18 台）；
2. 对该数组做**洗牌**：带 `2*log2(n)` 深度上限的 introsort（`v145[1]` 即深度栈），
   比较子每次现算 `sub_140503B80(actor, 0)` → `sub_1413F02F0(...)` 得到 0..1 浮点，与 `0.5` 比；
   **关键结论：洗牌顺序由“每台 actor 自身的哈希”决定，不是顺序抽签**（同关卡同 seed 恒定）；
3. `v59 = *(a1+6608)` = 6，作为 `DesiredCount` 传给分组/截断；
4. `sub_14361CE40(n, K, out, seed+924519, 补集)` 先抽出「上屏目标位次」，
   再用 `seed+264069` 抽另一组（K 取自 `a1+6848` / `a1+6648` 的数组长度，即屏数 3）。

配对路径（B03，无分组）`sub_14361CFA0` 的循环体：

```
每次迭代：
  v62[0] = 打乱数组的「第一个」            // 取头部
  entry->actor = 目标表(+6600)的第 v9 项
  idx  = sub_140B3BDD0(v62[0])             // 取该台的 ObjectiveIndex
  alt  = sub_14361DF10(coord, idx)         // ObjectiveIndexAlternatePairs[idx]
  在打乱数组里线性搜 ObjectiveIndex == alt 的台子 → v27
  entry 图案 = RandSeeded(seed+223551+v9, 剩余)
  alt   图案 = RandSeeded(seed+223551+v9+253526, 剩余)
  打乱数组 RemoveAt(v62[0])、RemoveAt(v27)   // 两张一起移出，保证不重复
```

由此得到两条硬结论：

- **目标序号来自组件接口**：`sub_140B3BDD0` = 先 `FindComponentByClass`，再走
  `(*(vtbl+544))(actor, comp, &out)` 取 index —— 序号不是从 actor 名字解析的，也不是关卡
  JSON 里那个 `RelativeLocation` 表；
- **配对消费**：每轮吃掉「头部 + 它的 alternate」两张，所以目标位 i 落到的台子 =
  洗牌序列里“跳过已被当 alternate 抽走”的第 i 个。

**旧结论（已废弃）**：曾以为填充点不在本类 5 个方法里。实际填充点是基类
`sub_1402B05C0`（`RBPushCartObjectiveCoordinator` 的 `RandomizeObjectiveActors`），
它才写 `+6600/+6608`。

### 11.9 “6 台”抽取链（已闭合到可离线复现）

链路：`sub_1402B05C0` → `sub_1402C30C0` → 逐组选人。**全程只有名称哈希与全局种子，
不含指针序**，所以同关卡同种子可离线复算。

**1) 哈希基数 `v240`**（`sub_1402B05C0` 内）：

```
v125 = ~CRC32(关卡名字符串)                 # CRC 表 dword_146CCCA80，即 UE FCrc
if (*(coord+744) != 1 || *(coord+857))
    v240 = v125 + GetRandomSeed(coord)      # sub_140503B80(coord, 0)
else
    v240 = v125 + Hash(关卡资源名字符串)     # sub_1402B4C10
```

`sub_140503B80` = `GetRandomSeed(actor)`：优先找接口 `RBRandomSeedGeneratorInterface`，
没有则 `abs(~CRC32(outerName) + ~CRC32(name))`（递归到 outer，即 actor 的命名链）。

**2) `DesiredCount` D** = `sub_1402B3910(coord)`：读属性（`+0 / +600 / +800` 三段 fallback），
缺省 0；B03 = **6**。

**3) 分组**（`sub_1402C30C0` 前半，行 794-913）：把用到的 `ObjectiveIndex` 放进位数组，
**按 index 升序**逐位建组；组内 actor 保持 `ObjectiveActors` 原始顺序。

**4) 配额**（行 915-1019）：前 `min(D,G)` 组各 `+1`；余数按 `(组大小/总数)*D` 四舍五入分摊，
放不下则报 `"Math error too big when building randomization groups."`。
B03/G=6/D=6 → **每组配额 1**。

**5) 组的弹出顺序**（行 923-996）：不是顺序取，是按哈希做“随机弹出”：

```
for (i = 0; 剩余组 > 0; i++) {
    k = *a5;  *a5 = k + 1;                       // a5 流水号，基数 = v240
    if (k != 0) r = splitmix16(k, seed % 1000);
    else        r = (int)((rand() & 0x7FFF) / 32767.0 * 65535.0);   // 退化分支
    g = r % (剩余组数);                           // 选中第 g 个剩余组
    输出该组（连 quota）；从剩余组移除            // 每组只出一次
}
```

`splitmix`（C1 = `0xBF58476D1CE4E5B9`，C2 = `0x94D049BB133111EB`）：

```
h(x)  = C2 * ((C1*(x ^ x>>30)) ^ ((C1*(x ^ x>>30)) >> 27))
r     = h(k) ^ h(seed%1000) ^ ((h(k) ^ h(seed%1000)) >> 31)
r16   = (C2*((C1*(r ^ r>>30)) ^ ((C1*(r ^ r>>30))>>27)) ^ ...>>31) & 0xFFFF
```

**6) 组内选人**（回到 `sub_1402B05C0` 行 1085-1145）：

```
基数 = v240（已被第 5 步加到 v240+G）
idx  = splitmix16(基数 + 已选数, seed % 1000) % 组内人数
```

**结论**：B03 的 6 台 = 「6 个 index 组按第 5 步置换后，每组用第 6 步的哈希取 1 台」，
不是从 13/18 台里平铺抽 6 台。

### 11.10 序列化输入核对 + 实测验证（seed 485485）

**三项原以为“未序列化”的输入，其实两项在 JSON 里就有**：

| 项 | 现状 |
|---|---|
| `ObjectiveActors` 顺序 | **已序列化**。Rich = `_15,_16,_13,_14,_17,_1,_6,_2,_7,_5,_8,_11,_19,_9,_10,_12,_18,_4`，组内顺序直接取它 |
| `DesiredCount` | **已序列化**：`PrimaryActorsRandomizationSetup.DesiredCount.NormalLocalValue = 6` |
| `SectionIndex` | **已序列化**在每台 `FrequencyMatchSuburbs_*` 上；`_9/_10/_11/_12` 缺键是 UE 增量序列化省略默认值 0，不是没有 |
| `ObjectiveIndex` | 仍只有接口 `vtbl+544` 运行时值；但按 `SectionIndex` 分组的结果与实测完全自洽（见下） |

按 `SectionIndex`（缺省 0）分组、组内保持 `ObjectiveActors` 顺序：

```
Rich 6 组 大小 [4,3,3,4,2,2] = 18
  组0: _11 _9 _10 _12      组3: _15 _16 _17 _1
  组1: _19 _18 _4          组4: _6 _7
  组2: _13 _14 _2          组5: _5 _8
Poor 6 组 大小 [2,2,2,3,2,2] = 13
```

**实测（`test.txt` 245-271，seed 485485）反推出的弹出顺序**：

```
Rich k→组 = [2,3,1,5,0,4]     Poor k→组 = [2,5,0,3,4,1]
```

两组都是 6 个**互不相同**的组，且组大小与桶大小一一对应 → 证实「按 index 分组、每组 1 台、
弹出顺序决定“第 k 个图案落在哪台”」。已固化为工具：

```
python sr_trial_freq.py --b03 485485 --b03-obs=2,1,18,5,11,6
```

输出即 6 台名称 + 坐标 + 各自图案，与 `test.txt` 逐条一致（梅花=Rich_2、兔子=Rich_1、
方块=Rich_18、黑桃=Rich_5、红心=Rich_11、月亮=Rich_6）。

### 11.11 仍未闭合：seed → 弹出顺序 的映射

结构已定，但**“给定 seed 算出这 6 个组序”这一步没拿到**。已试并排除的假设（均用
Rich+Poor 12 条实测约束联合判定，`salt=485`）：

| 尝试 | 结果 |
|---|---|
| `B0 = get_seed(coord)` + `rand_seeded(B0+i, n-i, salt)`，组内 `B0+6+i` | 仅 3/6 组命中 |
| `B0 = get_seed(coord) + crc32(关卡名)`，14 种关卡名候选 × salt 0..999 | 全部不中 |
| 槽位偏移穷举 `{0,6,551,1451,223551,243551,253526,924519,924523}` 两两组合 | 无 6/6 |
| 用 `_mix64`（尾段 `321982955*u`）vs 反编译原文尾段 `C2*R ^ (R>>31)` | 两者都不中 |

即 `v240` 的拼装里还缺一项，或计数器初值不是 `v240`。注意 `243551` 这类常量只出现在
消费者 `sub_14361C...`（`v143+243551`、`v143+223551`、`v69+253526`），**抽台路径里没有常量偏移**。

**最小验证实验**（任一条即可收口）：

1. Frida hook `sub_1402C30C0`，打印入参 `*a5`（即 `v240`）与 `dword_146E2E5C4` → 直接得到基数与 salt；
2. hook `sub_1402B05C0` 里 `v240` 算出后、调用前的寄存器 → 拿到 `v125`（关卡名 CRC 项）；
3. 多记 2-3 个 seed 的 6 台面板（改 seed 重进即可），把弹出顺序作为额外约束，
   再扫 `v240` 的偏移量（单 seed 时解不唯一）。

拿到 `v240` 后，`--b03` 里接上 `rand_seeded` 即可全离线：图案、上屏、6 台点位一次算完。

**注意非确定性分支**：`k == 0` 且 `v240 == 0` 时用 CRT `rand()`，该情形不可复现；
只要 `v240 != 0` 即走纯哈希路径。

### 11.12 salt 来源已定 + 真实哈希收尾（本轮静态结论）

**（1）`dword_146E2E5C4` 就是关卡种子（Level Seed）**

`sub_143416200` 直接把它当 `"Level Seed: %d"` 打印。全引擎 100+ 处都是：

```c
salt = dword_146E2E5C4 % 1000;
if (dword_146E2E5C4) r = RandRange(id, min, max);   /* 纯哈希 */
else                 r = rand();                    /* CRT，不可复现 */
```

→ `salt = seed % 1000` 的假设成立（seed 485485 → salt 485）。

**（2）`RandRange` 真实收尾（`sub_1401A0F00`，`sub_1402B05C0` 在 0x1402b2217 调用它）**

```c
H(x) = C2 * ((C1*(x ^ x>>30)) ^ ((C1*(x ^ x>>30))>>27))     C1=0xBF58476D1CE4E5B9 C2=0x94D049BB133111EB
v5   = H(id) ^ H(salt)
v6   = C1 * (v5 ^ v5>>31 ^ ((v5 ^ v5>>31)>>30))
X    = v6 ^ v6>>27
v7   = (uint32)(321982955 * X) ^ (uint64)(C2 * X) >> 31      /* 321982955 = 0x133111EB = C2 低 32 位 */
idx  = (v7 & 0xFFFF) % (max - min + 1)
```

关键：`0x133111EB`（即 `321982955`）那一项是**真的**，§11.9 里按 `_mix64` 变体排除过，是错的。

**（3）用真实公式重扫的结果**

- 约束：Rich 弹出 `(6,2)(5,2)(4,1)(3,2)(2,0)` + 组内 `(3,2)(4,3)(3,1)(2,0)(4,0)(2,0)`，`salt=485`
- 全空间 2³² 命中 **10507** 个 `v240`（随机期望 ≈10356）→ 约束自洽，但单组样本无法定位。
- 组内 `id` 取 `v240+6+k` 命中，取 `v240+6` 为 0 命中 → 计数器跨两组循环累加。
- Poor 独立重扫命中 61732；与 Rich 按 `seed` 差做平移，交集 **0**。

**（4）已否决的 `v240` 拼装**

宽字符 CRC 定义确认（`zlib.crc32(utf-16-le)&0xFFFFFFFF`）：

```
CRCw("Large Objects")            = 2973327078
CRCw("SuburbRiot_T08_B03")       = 2624463692
CRCw("...OrderedClueFrequency_Rich") = 1107617645
CRCw("...OrderedClueFrequency_Poor") =  746800750
```

7 种组合（`CRCw(a4)±seed`、`~CRCw(a4)±seed`、`^seed`、`CRCw(level)+seed`）**均不在** 10507 候选集内
→ `v240` 不是 `a4` 与 `seed` 的简单二元组合。

**（5）剩余唯一入口**

必须读出 `sub_1402B05C0` 在 `0x1402b2217` 处 `sub_1401A0F00(id, min, max)` 的 `id` 实参表达式
（`sub_1402B05C0` 有 0x22f2 字节，反编译约 1400 行，导出后按行定位）。拿到 `id` 后 `v240`
与计数器语义即可闭合；否则单 seed 样本下解不唯一。

### 11.13 离线反汇编 `sub_1402B05C0`（capstone，不再依赖 IDA 输出）

IDA 的 `decompile_all` 在本机会超时，改用 `pefile + capstone` 直接对 exe 反汇编，`tmp/callsite*.py`。

**（A）取人调用点 `0x1402B2217`（`sub_1401A0F00`）实参**

```asm
0x1402B21C4  mov  ecx, [r15+0x668]        ; 已用数量（跨组累加）
0x1402B21CB  cmp  ecx, [rsp+0x90]         ; 与 DesiredCount 比较
0x1402B21D8  mov  esi, [rsp+0xcc]         ; 计数器（= v240 + 6）
0x1402B21FF  mov  r8d, [rsp+0xb8]         ; 候选池剩余数 n
0x1402B2210  dec  r8d                     ; max = n-1
0x1402B2213  add  ecx, esi                ; id = 已用数量 + 计数器
0x1402B2215  xor  edx, edx                ; min = 0
0x1402B2217  call sub_1401A0F00
0x1402B2226  mov  rax, [rcx+rax*8]        ; 从池里取
0x1402B2244  mov  [rdx+0x668], ecx        ; 已用数量 += 1
```

→ `id = v240 + 6 + k`（`k` 为总取人序号）**与汇编一致**，此前的取模模型是对的。

**（B）`v240` 计算点 `0x1402B1599`–`0x1402B163E`**

```asm
0x1402B1599  lea   rax, [rip+0x6733ca0]  ; → 0x1469E5240（.rdata 本地化表，首字为 0000）
0x1402B15BA  mov   esi, 0xFFFFFFFF
      ...    内联宽字符 CRC32 循环（表 rdx=rip+0x6a1b4b5，逐 word，遇到 0 结束）
0x1402B161E  not   esi                   ; esi = ~CRC32w(s)
0x1402B1628  cmp   byte [rcx+0x2e8], 1
0x1402B162F  je    0x1402B1F91           ; 另一分支：eax = sub_1402B4C10(...)
0x1402B1637  call  sub_140503B80         ; 主分支：eax = GetRandomSeed(...)
0x1402B163C  add   eax, esi
0x1402B163E  mov   [rsp+0xcc], eax       ; v240 = seed + ~CRC32w(s)
```

结构确认为 `v240 = ~CRC32w(s) + seed`。但 `0x1469E5240` 首字为 `0x0000` ⇒ 该路径 `~CRC32w = 0`，
即 `v240 = seed`。用 `v240 = seed` 反扫 `salt 0..999` 与偏移 −8..+8：

| 目标 | 11 条约束最好成绩 |
|---|---|
| Rich（`seed=562885957`） | 10/11（salt=175, dv=−7） |
| Poor（`seed=923702852`） | 10/11（salt=519/263/96） |

**无 11/11** → 该 lea 指向的是**空串（可能是未使用的分支）**，真正的 `v240` 基数项还没找对；
需沿 `0x1402B2464`（空串跳转目标）与 `0x1402B1F91` 两条分支继续追。

### 11.14 三条分支已追完，seed 函数实证

- `0x1402B2464: xor esi, esi` → 空串分支的 `~CRC32w` 项为 0，即 **`v240 = seed`**。
- `0x1402B1F91`：`[rcx+0x2e8]==1 && [rcx+0x359]==0` 时 `eax = sub_1402B4C10(sub_141c49310([rcx+0x10]+0x18))`，再 `+ esi`。
- `sub_140503B80`（seed）单 `ret`，收尾为：

```asm
not edi            ; edi = ~CRC32w(s1)   内联宽字符 CRC，同一张表
not ebx            ; ebx = ~CRC32w(s2)
add ebx, edi
mov esi, ebx
neg esi
cmovs esi, ebx     ; return abs(~CRC32w(s1) + ~CRC32w(s2))
```

→ seed 公式与 §11.9 一致，**不是** seed 的问题。

**当前实测门槛**：`v240 = seed`（Rich 562885957 / Poor 923702852）下，Rich+Poor 共 22 条约束，
联合反扫 `salt 0..999` 最高只有 **16/22**（≈随机期望）。结论：**模型结构对，但"组内被选中者"的
下标换算口径不对** —— 大概率是运行时候选池 `[r15+0x660]`（TArray，`[r15+0x668]` 为 Num）的
填充顺序 ≠ JSON `ObjectiveActors` 的序列化顺序，导致我用 JSON 顺序换算的 `idx` 错位。

下一步（择一）：
1. 静态：追 `sub_1402B05C0` 前半段对 `[r15+0x660]` 的填充，确认池顺序是否按 `SectionIndex` 重排；
2. 实测：再给 1 个其它 seed 的 6 台面板，用两样本直接拟合池顺序。

---

## 12. 第六轮（2026-11-01）：弹出顺序闭合 + 组内选择部分闭合

**工具链**：`rea` → IDA MCP adapter（attached），`TOTClient-Win64-Shipping.exe`。

### 12.1 `v240` 公式已确定

**`v240 = 45991 + get_seed(coord)`**（mod 2³²）。

- `get_seed(coord)` = `abs(~CRC32w(name) + ~CRC32w("PersistentLevel"))`
- 45991 = `sub_1402B05C0` 中 `v125` 项 = `~CRC32w(a4_string)`，`a4` 是传入的盐名字符串
- 旧文档假定盐名 = "Objective Actors"（`crc32_fname = 1040402497`），但约束求解得 45991，
  说明盐名可能是其他字符串，或 `get_seed` 外层链与假定不同

**约束求解方法**：
- Rich 弹出顺序 [2,3,1,5,0,4] → swap-remove 约束 `(6,2)(5,3)(4,1)(3,2)(2,0)`
- Poor 弹出顺序 [2,5,0,3,4,1] → swap-remove 约束 `(6,2)(5,2)(4,0)(3,0)(2,0)`
- 联合求解：`v240_Rich = 45991 + get_seed(Rich)` 和 `v240_Poor = 45991 + get_seed(Poor)` **同时满足**

### 12.2 弹出顺序模型

```
for k in 0..5:
    idx = splitmix16(v240 + k, salt) % remaining_groups
    选中 remaining[idx]，swap-remove at idx
```

两个协调器的弹出顺序均 **逐位精确命中**。

### 12.3 `sub_1402B46B0` = introsort（按 actor 名排序）

该函数是对 `Src` 池做 **大小写不敏感字典序排序**（比较器 = `sub_140143A50` 取 actor 名，
逐字符 `byte_145E47280` 转小写比较）。这是 `sub_14359A520` 的同款比较器。

但实测发现：**Poor 的组内选择用 JSON `ObjectiveActors` 序6/6 全中**，
说明传入 `sub_1402C30C0` 的池序 = `ObjectiveActors` 序（排序可能作用于另一数组或被覆盖）。

### 12.4 组内选择

```
for k, grp in enumerate(pop_order):
    idx = splitmix16(v240 + 1 + k, salt) % len(group_members)
    选中 group_members[idx]
```

- **Poor：6/6 全中**（池序 = ObjectiveActors 序，offset=1）
- **Rich：3/6**（Rich_2/5/6 中，Rich_1/18/11 错位到同组其他面板）
  - Rich 的池序可能因过滤/排序与 Poor 不同，需进一步确认

### 12.5 seed=485485 复现结果

| 阶段 | 屏幕预测 | 屏幕实测 | 判定 | 6 台面板 |
|---|---|---|---|---|
| B03_Rich | 梅花-月亮-红心 | 梅花-月亮-红心 | **ooo** | 3/6（图案全对） |
| B03_Poor | 兔子-月亮-梅花 | 月亮-兔子-梅花 | xxo（集合一致） | **6/6** |

### 12.6 交付物

`release/home/sr_trial_b03.py` —— B03 调频完整预测（弹出顺序 + 组内选择 + 坐标）。

### 12.7 遗留

1. Rich 组内池序：3/6 错位说明池序不是纯 ObjectiveActors 序，
   可能被 `sub_1402B46B0` 排序或过滤影响。需追 `sub_1402B28C0`（LABEL_64 的删除语义）
   或补充 1 个 Rich 实测样本。
2. 屏幕显示顺序：Poor 的前两位与预测互换（兔子/月亮 → 月亮/兔子），
   与 B02 的位移问题同源 —— `OrderedClueActors` 数组物理顺序 ≠ 命名顺序。
3. C=45991 的精确来源：需确认 `a4` 盐名字符串的实际值。
