# MHS_MT01「黑帮据点 · 找到 3 个投影房间并输入 3 位密码」

> **第三轮（2026-10-29）：闭环。** 新增实测 seed=707707，补上最后一块 ——
> **TrainDepot 的候选池不是 10 个而是 8 个**，被 `bLimitOneObjectivePerRoom`
> 剔掉了 `_8` / `_9`。至此 `python mhs_mt01.py --selftest` =
> **code 11/11 · pick 12/12 · pattern 4/4 · room 8/10**。
>
> 前两轮的产物在 `release/coop/MHS_MT01/` 与 `release/MHS_MT01/`（只读参考）。
> 本轮全部产物只落在 `release/home/`。

---

## 0. 一句话结论

```
pool = 该区 10 个投影符号，按【关卡 actor 顺序】= 全名字典序 _1,_10,_2,_3…_9
       ★ 若该区 CodeProjectorsRandomizationSetup.bLimitOneObjectivePerRoom = true
         （本关只有 TrainDepot）：与前面任一候选「共房间」的候选被 RemoveAt，
         保留靠前的那个 → TrainDepot 10 → 8（剔掉 _8、_9）

base   = crc32_fname("Projection Actors") + GetSeed(协调器)   # 通用引擎 sub_1402B05C0
idx    = RandSeeded(base + 0, len(pool))                      # DesiredCount=1，只抽一次
图案   = RandSeeded(46541, |PossibleClueGroups|)              # DrugLab/Shipyard 恒骷髅/三角
密码   = Draw( GetSeed(symbol) + GetSeed(coordinator) )        # 池 0..9 逐位交换删除
        RandSeeded 内部掺关卡种子 salt = S % 1000
```

三个区**互相独立**（各自的协调器、各自的候选池），一局就是 3 次独立抽取 + 3 次独立算码。

---

## 1. 第三轮补上的那块：TrainDepot 的池是 8 个

### 1.1 症状

前两轮 DrugLab / Shipyard 的抽取 4/4 命中，TrainDepot 却只有 1/3。
密码主链一直是对的（这说明「反推出的生效符号」可信），错的只是「抽到哪个符号」。

| seed | TrainDepot 密码 | 密码反推出的生效符号 | 前两轮模型（池=10） |
|---|---|---|---|
| 759759 | （遗漏） | `_2`（由房间记忆定） | `_4` ❌ |
| 884884 | 245 | `_7` | `_5` ❌ |
| 771771 | 015 | `_5` | `_5` ✅ |
| 707707 | 863 | `_2` | `_6` ❌ |

### 1.2 差异就在协调器配置里

把三个协调器的 `CodeProjectorsRandomizationSetup` 摊开对比（
`paks/MAP/Maps/MobsterHideoutSyndicate/MHS_LD_MT01_B00.json`）：

| 协调器 | `bLimitOneObjectivePerRoom` | `bUseOtherCoordoActorsForDistance` |
|---|---|---|
| `MT01_Projections_Coordinator_BP_DrugLab` | —（false） | —（false） |
| `MT01_Projections_Coordinator_BP_Shipyard` | —（false） | —（false） |
| `MT01_Projections_Coordinator_BP_TrainDepot_1` | **true** | **true** |

只有 TrainDepot 开了这两条 —— 和「只有 TrainDepot 抽不准」完全对得上。
三个协调器都带 `bOverrideDistanceBetweenSame/DifferentObjectives=true` 但**没给距离值**，
所以距离分支实际是空转的（见 §3），真正生效的是「每房间至多一个」。

### 1.3 池是怎么从 10 变 8 的

枚举 C(10,8)=45 个 8 元子集，只有 **1 个**能让三条 TrainDepot 实测同时命中：

```
['1', '10', '2', '3', '4', '5', '6', '7']      ← 剔掉 _8、_9
```

而这两条剔除正好就是房间去重（保留池里靠前的那个）：

| 候选 | 所在房间 | 判定 |
|---|---|---|
| `_1` | `RBRoom_Train_Bridge_02` | 保留 |
| `_9` | `RBRoom_Train_Bridge_02` | ❌ 与 `_1` 同房间 |
| `_7` | `RBRoom_Train_2ndFloor_Cooridor_01` + **`RBRoom_Train_Room_03`** | 保留 |
| `_8` | `RBRoom_Train_2ndFloor_Room01` + **`RBRoom_Train_Room_03`** | ❌ 与 `_7` 同房间 |

注意 `_7` / `_8` 各自都落在两个房间 hull 里，主房间分别是 `Cooridor_01` / `Room01`
（看起来不冲突），但它们**共同落在 `RBRoom_Train_Room_03`**，所以按「共任一房间」判重。

第 4 条样本 759759 用 8 元池算出 `_2` → `RBRoom_TrainDepot2_StairBridge_Master`，
正好对上玩家那条「不确定，在这一块区域内很多编号很接近」的记忆 —— 4/4。

---

## 2. 直接可用

```powershell
cd d:\workspace\outlast\release\home

python mhs_mt01.py 707707            # ★ 3 行：图案 / 房间 / 密码 / actor / 坐标
python mhs_mt01.py 707707 --json
python mhs_mt01.py --pool            # 三个区的抽取池（TrainDepot 带剔除标记）
python mhs_mt01.py --list            # 30 个候选：贴图 / 坐标 / 房间
python mhs_mt01.py --codes 884884    # 该 seed 下 30 个候选各自的 3 位密码
python mhs_mt01.py --find 884884 806 # 密码 → 房间（反向查）
python mhs_mt01.py --selftest        # code 11/11 pick 12/12 room 8/10 pattern 4/4
```

```
$ python mhs_mt01.py 707707
MHS_MT01  seed=707707  salt=707
图案                 房间                                    密码  投影符号 actor                            坐标
Skull 骷髅           RBRoom_DrugLub_2F_Hallway_Master      384   MT01_ProjectionSymbol_BP_DrugLab_9      1246,-2159,450
TriangleCircle 三角  RBRoom_Casino_Ext_Stairs_2F_Bridge    102   MT01_ProjectionSymbol_BP_Shipyard_6     4624,767,453
Spiral 螺旋          RBRoom_TrainDepot2_StairBridge_Master  863   MT01_ProjectionSymbol_BP_TrainDepot_2   639,2154,250
```

对照实测 `骷髅 384 / 螺旋 Train Depot2 Stair Bridge Master 863 / 三角 102` —— **三条全中**。

Python API：

```python
import mhs_mt01 as m
m.predict(707707)                      # dict: zones[3] = {zone,pattern,room,code,symbol,loc,...}
m.pick_of('TrainDepot', 707707)        # (idx, row, pool)   pool 长度 8
m.pool_of('TrainDepot')                # (kept, dropped)
m.pick_base('TrainDepot')              # 0x465DB951
m.code_of('MT01_ProjectionSymbol_BP_DrugLab_9', 'DrugLab', 707707)   # '384'
m.find_by_code(707707, '863')          # [('TrainDepot','2','RBRoom_TrainDepot2_StairBridge_Master')]
```

---

## 3. 代码侧读数（REA → IDA）

| 用途 | 地址 | 备注 |
|---|---|---|
| 投影协调器前置派发 | `0x1436E7F70` | 显式列表非空 → `"Projection Actors"` |
| 列表拷贝（保序） | `0x1433F86E0` | |
| 显式列表 → 引擎 | `0x1402AF490` | 软引用解析 + `IsA(AActor)` + 线性去重，**不排序** |
| 通用抽取引擎 | `0x1402B05C0` | base / 建组 / 抽取 / 距离 |
| **候选有效性 + 距离 + 房间剔除** | `0x1402B3C30` | ★ 本轮重点，见下 |
| `RBProjectionCodeCoordinator` 主随机化 | `0x1436E95F0` | 选 clue 组 / 算密码 / 真假投影循环 |
| 三位密码 `Draw` | `0x1436EA3D0` | 池 0..9，交换删除 |
| `GetSeed` / `crc32_fname` / `RandSeeded` | `0x140503B80` / `0x141CBDC30` / `0x1402D29E0` | 同 `release/seed/seedcore.py` |
| 宽串 `"Projection Actors"` | `0x14665E230` | 本关投影器的盐名 |

`sub_1402B3C30(a1=coord, a2, a3, a4, a5=候选池)` 的结构（本轮新读）：

```c
// 距离阈值 v5 由 DistanceBetweenDifferentObjectives 决定；本关三个协调器都
// bOverride=true 但没给值 → v5 <= 0 → 跳过下面整段距离过滤
if (v5 > 0.0) {
    ... v13 = 垂直容差（IntByDifficulty → RBSettings_Gameplay +4116 兜底）...
    if (v5*v5 > dx*dx + dy*dy && (v13 < 0 || v13 >= fabs(dz)))
        RemoveAt(pool, i);                     // 距离太近 → 剔除
}
// v5 <= 0 时走这个循环：
do {
    v53 = sub_1402A53F0(pool[v15]);
    if (v53 && (sub_1407F9240(v53)
             || (a3[2] && IsA(a3[2], ...) && sub_140B3BE80(a3, v54))))
        sub_1402B28C0(pool, v15, 1);           // RemoveAt，保序
} while (v15-- > 0);
```

`sub_140B3BE80(coord, candidate)` 就是「这个候选和已保留的撞房间吗」的判定
（`bLimitOneObjectivePerRoom` 的开关就在 `a1 + 1003` 那一段之后读）。
**所以它不是 SMC_MT02 那种「离已选目标太近就重抽」，而是抽签前先把池按房间去重** ——
`RandSeeded` 是对**去重后的**池取的模，池大小从 10 变 8，下标自然全变。

### 3.1 引擎里两处关键行

```c
// 0x1402b163e
if ( *(BYTE*)(coord + 744) != 1 || *(BYTE*)(coord + 857) )
     v246 = v129 + sub_140503B80(coord, 0);      // v129 = crc32_fname("Projection Actors")
else v246 = v129 + sub_1402B4C10(...);           // 少数协调器走名字哈希，本关不走

// 0x1402b17fe ~ 0x1402b18c3
v150 = group->count;                             // ★ 剔除后的池大小（8 或 10）
v153 = v145 + v151;                              // v145 = base
v135 = (uint16)hash(v153) % v150;                // ← RandSeeded 内联
RemoveAtSwap(group->pool, v135);
```

### 3.2 三个区的 base（常量，与 seed 无关）

| 区 | `base = crc32_fname("Projection Actors") + GetSeed(coord)` | 池 |
|---|---|---|
| DrugLab | `0x71C108E5` | 10 |
| Shipyard | `0x56028464` | 10 |
| TrainDepot | `0x465DB951` | **8** |

`crc32_fname("Projection Actors") = 0x46A2C2E0`。

---

## 4. 验证

| 项 | 结果 | 说明 |
|---|---|---|
| **密码主链** | **11/11** | 四条 seed 的全部密码 |
| **抽取（哪个符号生效）** | **12/12** | DrugLab 4/4、Shipyard 4/4、TrainDepot 4/4 |
| **图案家族** | **4/4** | TrainDepot 螺旋/五角星/太阳/螺旋 |
| 房间 | 8/10 | 两条失败见下 |

房间唯二对不上的，都是「密码与房间指向不同 actor」的记录问题，不是模型问题：

- `884884 / TrainDepot`：密码 `245` 唯一指向 `_7`（`Cooridor_01`），但记的 `Room01`
  属于 `_8` —— 而 `_8` 已被房间去重剔出池子，根本不可能被抽中。
- `771771 / Shipyard`：密码 `123` 在全关 30 个候选里唯一命中 `_1`（`Shipyard_Stairs`），
  而 `Shipyard_02` 里的 `_5` 密码是 `589`。已排除假码（`k=0..15`）。

`--selftest` 里 pick 是 12/12 而不是 11/11，因为 759759/TrainDepot 虽没记密码，
但房间记忆 `TrainDepot2_StairBridge_Master` 足以定到 `_2`，也算一条。

---

## 5. 参数与边界

- 只有 **Easy / 1P** 的样本（759759 / 884884 / 771771 / 707707 四条）。
  `DesiredCount` 走 `IntByDifficulty`，2P/3P 未验证。
- `salt = S % 1000`：**`S` 与 `S+1000` 的全部结果（房间 + 密码）完全一样**。
- base 与关卡 seed 无关 → `idx` 只由 `S % 1000` 决定；末三位相同的 seed 会落在同一个房间。
- 房间来自 `release/map/out/MobsterHideoutSyndicate/plan.json` 的 hull 判定（94 个房间）；
  脚本已把结果**固化进 `STATIC` 表**，运行时不依赖 `paks/` 和 `release/map/`。
- 一个符号可能落在多个房间 hull 里（例如 `_7` 同时是 `Cooridor_01` 和 `Room_03`）。
  展示用的「主房间」取 z 跨度最接近的那个；**判重用的是全部房间的交集**。
- 3 个 `DistanceBetween*Objectives` 都是 `bOverride=true` 且无值 → 距离过滤空转。
  若以后遇到给了具体距离的关卡，`sub_1402B3C30` 前半段就会生效（同 SMC_MT02）。

---

## 6. 已排除的假设（省下一个人重走）

1. 密码不是「按房间名算」的 —— 密码挂在**投影符号 actor** 上。
2. 池顺序不是 `SpecificCodeProjectors` 的 JSON 数组原序（1..10），是关卡 actor 顺序（字典序）。
3. 盐名不是 `"Objective Actors"`（列表为空时的回退分支），也不是 `"Code Projectors"`。
4. `Icon-01b/03b/04b` 只是每区统一的贴图族，不能用来把 TrainDepot 的 10 个符号分到
   Spiral/Pentagram/Sun 三组。
5. TrainDepot 抽不准**不是**距离重抽（`v5 <= 0`，距离分支没进），是抽签**前**的房间去重。
6. `_8` / `_9` 被剔**不是**因为 `excludeList` —— 那是世界道具（栅栏/吊钩/声波陷阱）列表，
   `_1/_4/_7/_8` 都有，`_7` 却留在池里。
7. 抽取次数就是 1（`DesiredCount=1`），没有补抽；`bSplitByObjectiveType` 未设置 → 单组。

---

## 7. 下一步

1. ✅ **已接进 `release/seed/seed.py`**（2026-10-29）：`python seed.py MHS_MT01 707707`，
   `--trace` 看抽取池与去重；`--selftest` 里新增了 11 条密码 + 12 条抽取断言。
   数据搬到 `release/seed/data/mhs_mt01.json`（候选表加了「落在哪些房间 hull 里」和
   每区的 `limit_one_per_room`），样本在 `data/samples.json` 的
   `mhs_mt01` / `mhs_mt01_pick`。
2. 想支持 2P/3P，需要确认 `CodeProjectorsRandomizationSetup.DesiredCount` 的
   `IntByDifficulty` 在 Easy 之外取哪一档。
3. 再要一条 seed 盯一下 TrainDepot 的图案（太阳只出现过 1 次）。

---

## 8. 本轮环境与文件

| 项 | 结果 |
|---|---|
| REA | ✅ MCP server `rea` 在线 |
| REA → IDA | ✅ provider `ida`（`IDA MCP adapter` v1，mode=attached）；IDA 侧 `ida-pro-mcp 1.30.0` |
| 目标 | `D:\workspace\outlast\TOTClient-Win64-Shipping.exe`，base `0x140000000`，sha256 `2cd37c88…a4192e` |
| 本轮新反编译 | `0x1402B3C30`（候选有效性 / 距离 / 房间剔除全文） |
| 注意 | `binary_overview` 对 119 MB 的 exe 会 `-32001` 超时；直接用 `procedure_pseudo_code` 单点取 |

| 路径 | 作用 |
|---|---|
| `mhs_mt01.py` | ★ 交付脚本：固化静态表 + 房间去重 + 抽取 + 密码 + 图案 + CLI/自检 |
| `MHS_MT01.md` | 本文档 |
| `tools/gen_table.py` | 从 `paks/` + `plan.json` 重新生成 `STATIC` 表 |
| `tools/probe_rooms.py` | 符号 → 房间探针（含「落在哪些 hull 里」） |

数据源：
`paks/MAP/Maps/MobsterHideoutSyndicate/MHS_LD_MT01_B00.json`（关卡对象树）、
`release/map/out/MobsterHideoutSyndicate/plan.json`（房间 hull）、
`TOTClient-Win64-Shipping.exe.i64`（IDA）。
引擎读数参照 `release/coop/SMC_MT02/SMC_MT02.md`。
