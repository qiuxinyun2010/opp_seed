# -*- coding: utf-8 -*-
"""PSO_MT01 钥匙生成探针。当前用于复现/验证原生随机链路。"""
import argparse
import json
import math
import os
import sys

HERE = os.path.dirname(os.path.abspath(__file__))
ROOT = os.path.abspath(os.path.join(HERE, '..', '..'))
sys.path.insert(0, os.path.join(ROOT, 'opp_seed'))
import seedcore as sc  # noqa: E402

B00 = os.path.join(ROOT, 'pak', 'OPP', 'Content', 'Maps_json',
                   'PoliceStationOffices', 'PSO_MT01_B00.json')
MAPJSON = os.path.join(ROOT, 'opp_seed', 'ui', 'data', 'maps', 'PSO_MT01.json')
GROUP_COORDINATOR = 'PSO_MT01_B01_Group2'
SECTION_PREFIX = 'PSO_MT01_B01_SimpleQuestItem_Section'
SECTION_SALT = 'Concurrent Coordinators'
ITEM_SEED_STEP = 243551


def _load():
    with open(B00, encoding='utf-8') as f:
        exports = json.load(f)
    with open(MAPJSON, encoding='utf-8') as f:
        map_data = json.load(f)
    return exports, map_data


_EXPORTS, _MAP = _load()
ROOMS = {r['id']: r['raw'] for r in _MAP['rooms']}
INFO = {p['actor']: p for p in _MAP['points'] if p.get('key') == 'key_spawn'}

GROUP_ROOMS = {}
for _item in _EXPORTS:
    if _item.get('Type') != 'RBRoomGroup':
        continue
    names = set()
    for value in _item.get('Properties', {}).values():
        if not isinstance(value, list):
            continue
        for row in value:
            if not isinstance(row, dict):
                continue
            text = row.get('SubPathString') or row.get('ObjectName', '')
            names.add(text.rsplit('.', 1)[-1])
    GROUP_ROOMS[_item['Name']] = names

ROOM_GROUP = {}
for _group, _members in GROUP_ROOMS.items():
    for _room in _members:
        ROOM_GROUP.setdefault(_room, _group)

POOLS = {}
for _item in _EXPORTS:
    name = str(_item.get('Name', ''))
    if name.startswith(SECTION_PREFIX):
        POOLS[name[-1]] = [str(row['SubPathString']).rsplit('.', 1)[-1]
                           for row in _item['Properties']['SpecificItemSpawners']]

SAMPLES = [
    {'seed': 519519, 'players': 1, 'section': 'C',
     'actor': 'PoliceStation_Office_QuestItemSpawner_BP_Child_105'},
    {'seed': 329329, 'players': 1, 'section': 'A',
     'actor': 'PoliceStation_Office_QuestItemSpawner_BP_Child_40'},
    {'seed': 876876, 'players': 1, 'section': 'B',
     'actor': 'PoliceStation_Office_QuestItemSpawner_BP_Child_27'},
    {'seed': 235235, 'players': 1, 'section': 'A',
     'actor': 'PoliceStation_Office_QuestItemSpawner_BP_Child_40'},
]


def group_of(actor):
    return ROOM_GROUP.get(ROOMS[INFO[actor]['room']], '<none>')


def get_seed(name):
    return sc.seed_chain(['PersistentLevel', name])


def section_order(level_seed):
    """Group2 的区段抽取「候选」模型。

    ⚠️ 已证伪：在只有 519519 / 329329 两条样本时命中 2/2，加入 876876 /
    235235 后降到 2/4（即巧合水平）。保留它是为了复现与对照，不要当结论用。
    """
    base = (sc.crc32_fname(SECTION_SALT) + get_seed(GROUP_COORDINATOR)) & sc.M32
    pool = list('ABCD')
    out = []
    while pool:
        index = sc.rand_seeded((base + len(out)) & sc.M32, len(pool), level_seed)
        out.append(pool.pop(index))
    return base, out


class SectionModel:
    """`sub_14361C230` 的候选重排和区内抽取模型。"""

    def __init__(self, level_seed, seed_mode='chain'):
        self.level_seed = level_seed
        self.seed_mode = seed_mode
        self._seeds = {}

    def seed_of(self, actor):
        key = (self.seed_mode, actor)
        if key not in self._seeds:
            if self.seed_mode == 'chain':
                value = get_seed(actor)
            elif self.seed_mode == 'absolute':
                value = sc.seed_of_object(actor)
            elif self.seed_mode == 'crc':
                value = sc.crc32_fname(actor)
            else:
                raise ValueError('unknown seed mode: %s' % self.seed_mode)
            self._seeds[key] = value
        return self._seeds[key]

    def frac(self, actor):
        return (sc._mix64(self.seed_of(actor) & sc.M32,
                          self.level_seed) & 0xFFFF) / 65536.0

    def _small(self, a, lo, hi):
        while hi > lo:
            pick = lo
            for i in range(lo + 1, hi + 1):
                if self.frac(a[i]) < 0.5:
                    pick = i
            a[pick], a[hi] = a[hi], a[pick]
            hi -= 1

    def _heap(self, a, lo, hi):
        def preferred(actor):
            return self.frac(actor) >= 0.5

        n = hi - lo + 1
        for root in range((n - 2) // 2, -1, -1):
            parent = root
            while 2 * parent + 1 < n:
                child = 2 * parent + 1
                if child + 1 < n and preferred(a[lo + child]):
                    child += 1
                if preferred(a[lo + child]):
                    break
                a[lo + parent], a[lo + child] = a[lo + child], a[lo + parent]
                parent = child
        for end in range(n - 1, 0, -1):
            a[lo], a[lo + end] = a[lo + end], a[lo]
            parent = 0
            while 2 * parent + 1 < end:
                child = 2 * parent + 1
                if child + 1 < end and preferred(a[lo + child]):
                    child += 1
                if preferred(a[lo + child]):
                    break
                a[lo + parent], a[lo + child] = a[lo + child], a[lo + parent]
                parent = child

    def _sort(self, a, lo, hi, depth):
        n = hi - lo + 1
        while n > 8:
            if depth == 0:
                self._heap(a, lo, hi)
                return
            mid = lo + (n >> 1)
            a[mid], a[lo] = a[lo], a[mid]
            upper = hi + 1
            lower = lo
            while True:
                lower += 1
                while lower <= hi and self.frac(a[lower]) >= 0.5:
                    lower += 1
                upper -= 1
                while upper > lo and self.frac(a[lo]) >= 0.5:
                    upper -= 1
                if lower > upper:
                    break
                a[lower], a[upper] = a[upper], a[lower]
            a[lo], a[upper] = a[upper], a[lo]
            left = upper - lo
            right = hi - lower + 1
            depth -= 1
            if left >= right:
                if left > 1:
                    self._sort(a, lo, upper - 1, depth)
                lo = lower
            else:
                if right > 1:
                    self._sort(a, lower, hi, depth)
                hi = upper - 1
            n = hi - lo + 1
        if hi > lo:
            self._small(a, lo, hi)

    def shuffled(self, raw):
        arr = list(raw)
        self._sort(arr, 0, len(arr) - 1,
                   int(2.0 * math.log(float(len(arr)))))
        return arr

    def predict(self, letter):
        arr = self.shuffled(POOLS[letter])
        groups = []
        for actor in arr:
            group = group_of(actor)
            if group not in groups:
                groups.append(group)
        base = get_seed(SECTION_PREFIX + letter)
        first = sc.rand_seeded(base, len(groups), self.level_seed)
        chosen_group = groups[first]
        members = [actor for actor in arr if group_of(actor) == chosen_group]
        item_seed = (base + len(groups) + ITEM_SEED_STEP) & sc.M32
        index = sc.rand_seeded(item_seed, len(members), self.level_seed)
        actor = members[index]
        return {
            'section': letter,
            'actor': actor,
            'room': ROOMS[INFO[actor]['room']],
            'coordinates': INFO[actor]['p'],
            'groups': [g.rsplit('RBRoomGroup', 1)[-1] for g in groups],
            'chosen_group': chosen_group.rsplit('RBRoomGroup', 1)[-1],
            'group_index': first,
            'actor_index': index,
            'group_pool_size': len(members),
        }


def predict(level_seed, players=1):
    players = max(1, min(4, int(players)))
    section_base, order = section_order(level_seed)
    model = SectionModel(level_seed)
    sections = order[:players]
    keys = [model.predict(letter) for letter in sections]
    return {
        'level': 'PSO_MT01',
        'seed': level_seed,
        'salt': level_seed % 1000,
        'players': players,
        'section_seed_base': section_base,
        'section_order': order,
        'keys': keys,
        'confidence': {
            'section_selection': 'falsified-2-of-4-samples',
            'key_spawner': 'experimental-not-yet-validated',
        },
    }


def variants(level_seed):
    """未验证的对照结果：候选池顺序 / 重排的几种可能。"""
    base, order = section_order(level_seed)
    rows = []
    for letter in order:
        explicit = POOLS[letter]
        model = SectionModel(level_seed)
        for label, members in (('raw-reversed', list(reversed(explicit))),
                               ('intro', model.shuffled(explicit))):
            groups = []
            for actor in members:
                group = group_of(actor)
                if group not in groups:
                    groups.append(group)
            section_seed = get_seed(SECTION_PREFIX + letter)
            chosen = groups[sc.rand_seeded(section_seed, len(groups), level_seed)]
            pool = [a for a in members if group_of(a) == chosen]
            item_seed = (section_seed + len(groups) + ITEM_SEED_STEP) & sc.M32
            index = sc.rand_seeded(item_seed, len(pool), level_seed)
            actor = pool[index]
            rows.append({'section': letter, 'variant': label, 'actor': actor,
                         'room': ROOMS[INFO[actor]['room']],
                         'coordinates': INFO[actor]['p']})
    return {'seed': level_seed, 'section_order': order, 'variants': rows}


def selftest(verbose=True):
    section_hits = 0
    actor_hits = 0
    for sample in SAMPLES:
        result = predict(sample['seed'], sample['players'])
        key = result['keys'][0]
        section_ok = key['section'] == sample['section']
        actor_ok = key['actor'] == sample['actor']
        section_hits += int(section_ok)
        actor_hits += int(actor_ok)
        if verbose:
            print('seed=%d section=%s/%s actor=%s/%s' % (
                sample['seed'], key['section'], sample['section'],
                key['actor'], sample['actor']))
    if verbose:
        print('section %d/%d; actor %d/%d' % (
            section_hits, len(SAMPLES), actor_hits, len(SAMPLES)))
    return section_hits == len(SAMPLES) and actor_hits == len(SAMPLES)


def main(argv=None):
    parser = argparse.ArgumentParser(description='PSO_MT01 钥匙位置探针')
    parser.add_argument('seed', nargs='?', type=int)
    parser.add_argument('--players', type=int, default=1)
    parser.add_argument('--json', action='store_true')
    parser.add_argument('--all-sections', action='store_true')
    parser.add_argument('--variants', action='store_true')
    parser.add_argument('--selftest', action='store_true')
    args = parser.parse_args(argv)

    if args.selftest or args.seed is None:
        return 0 if selftest() else 1

    if args.variants:
        print(json.dumps(variants(args.seed), ensure_ascii=False, indent=2))
        return 0

    result = predict(args.seed, args.players)
    if args.all_sections:
        model = SectionModel(args.seed)
        result['all_sections'] = [model.predict(letter) for letter in 'ABCD']
    if args.json:
        print(json.dumps(result, ensure_ascii=False, indent=2))
        return 0

    print('PSO_MT01 seed=%d salt=%d players=%d' % (
        result['seed'], result['salt'], result['players']))
    print('section order:', ' '.join(result['section_order']))
    for key in result['keys']:
        print('Key-%s: %s' % (key['section'], key['actor']))
        print('  room=%s coordinates=%s' % (key['room'], key['coordinates']))
    print('confidence:', result['confidence'])
    return 0


if __name__ == '__main__':
    try:
        sys.stdout.reconfigure(encoding='utf-8')
    except Exception:
        pass
    sys.exit(main())
