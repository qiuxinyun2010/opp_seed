# FPI_MT02 分析：数图案（Game Show）

> 关卡：`FPI_MT02`（游乐场 · **Survive the Game Show**）
> 地图：`FunParkIllusion` ｜ 关卡资产：`FPI_MT02_B00`
> 状态：**规则/结构已完全摸清；`seed → 本局答案` 仍在攻坚**（本文记录到哪一步、下一步怎么做）

---

## 0. 现状速览

| 项 | 状态 |
|---|---|
| 关卡结构（3 阶段、2 回合、讲台数） | ✅ 确认 |
| 房间池 18 间、每间 4 块翻板 | ✅ 确认 |
| 图案池 9 + 空白 | ✅ 确认 |
| 面板：图案轮 0..9、数字轮 0..9 | ✅ 确认（`IntMax=9`） |
| **每房答案 ≤ 9（机器只能输 1 位）** | ✅ 确认 |
| 权威样本 | 2 组（seed 189189 / 346346），见 §4 |
| **seed → 房间 / 图案 / 数字** | ❌ 未解出（§6、§7） |

---

## 1. 关卡结构

协调器是原生类 **`RBGameShowObjectiveCoordinator`**，本关 2 个实例：

| actor | 作用 | 分区 | NumRounds | NumActiveConsoles |
|---|---|---|---|---|
| `MT02_GameShowObjectiveCoordinator_Tuto` | 教学（第 1 阶段） | 1（`RBRoom_Circus` / Hourglass） | 1 | 1 |
| `MT02_GameShowObjectiveCoordinator` | 正式（第 2、3 阶段） | 18 | 2 | 1P=2 / 2P=3 / 3P=4（默认 4） |

- `TotalTrialRounds = 3`、`CompletedTrialRoundsAtStart = 1` → 教学打完才进正式回合。
- 正式部分 `NumRounds = 2` = 视频里的「第 2 关 / 第 3 关」，每回合抽 `NumActiveConsoles` 间房（1P → 2 间）。
- 回合间 `DelayBetweenRounds = 8s`，答错 `6s` 后重试。
- 讲台 `PodiumKeypad_FPI_MT02_Player_1..4`，另有 `PodiumTV`×8、`PodiumShell`×4。
- 翻板 `Flipboard_FPI_MT02_BP_C` 共 **76** 块 = 18 房 × 4 + 教学 4；每块带
  `FlipIcon_FPI_MT02_BP_C`（图案轮）+ `FlipNumber_FPI_MT02_BP_C`（数字轮），两者都 **`IntMax = 9`**：
  即每块板能翻出 **0..9 的图案索引**（9 = Blank）和 **0..9 的单个数字**。
- 因为键盘只能输 1 位 → **每间房的答案 = 该房内所有目标图案数字之和 ≤ 9**。
- `MaxFakeFlipboards`（`IntByDifficulty`）：Easy=0、Normal=3。语义待定（见 §6）。

---

## 2. 房间池（`SectionDefinitions`，顺序即代码顺序）

| # | actor | 显示名 | 翻板前缀 |
|---|---|---|---|
| 0 | `RBRoom_RabbitTortur` | Rabbit Torture | `Flipboard_Torture` |
| 1 | `RBRoom_RabbitHole_CarrotsStorage` | Carrots Storage | `Flipboard_Carrots` |
| 2 | `RBRoom_RabbitHole_Bedroom_Master` | Rabbit Bedroom | `Flipboard_DirtBedroom` |
| 3 | `RBRoom_RabbitHole_DinnerTable` | Rabbit Dinner | `Flipboard_Diner` |
| 4 | `RBRoom15_9` | Kitchen Storage | `Flipboard_Storage` |
| 5 | `RBRoom_QueenTrone` | Queen Throne | `Flipboard_Trone` |
| 6 | `RBRoom_CreepyHands` | Wall Of Hands | `Flipboard_Hand` |
| 7 | `RBRoom_Library` | Library | `Flipboard_Library` |
| 8 | `RBRoom_Storm` | Storm | `Flipboard_Storm` |
| 9 | `RBRoom_UpsideDownStorm` | Upside Storm | `Flipboard_UpsideStorm` |
| 10 | `RBRoom_UpsideDown_Church` | Upside Church | `Flipboard_UpsideChurch` |
| 11 | `RBRoom_SpaceConsoleStation` | **Space Station** | `Flipboard_SpaceStation` |
| 12 | `RBRoom_UpsideUp_Church` | Church | `Flipboard_Church` |
| 13 | `RBRoom_ShowRoom_Master` | Showroom | `Flipboard_ShowRoom` |
| 14 | `RBRoom_Eyes` | **Wall Of Eyes** | `Flipboard_Eye` |
| 15 | `RBRoom_Tesseract` | Illusion Cube | `Flipboard_FloatingCube` |
| 16 | `RBRoom_DinningIllusion` | Illusion Dinner | `Flipboard_Illusion` |
| 17 | `RBRoom_DarkMannequin` | **Child Dorm** | `Flipboard_DarkChild` |
| — | `RBRoom_Circus` | Hourglass（**教学**） | `Flipboard_GameRoom_Tuto` |

## 3. 图案表（`SymbolTextures`，索引 = 游戏内部 ID）

| 0 | 1 | 2 | 3 | 4 | 5 | 6 | 7 | 8 | 9 |
|---|---|---|---|---|---|---|---|---|---|
| Apple | Book | BrushTeeth | Cleaning | Dumbbells | Sharing | Sleep | WashHands | Water | **Blank** |

> 之前把 `Sharing` 看成「bear（熊）」——玩家第二次记录已更正为 `sharing`，与此表一致。

---

## 4. 权威样本

```
# A: seed 189189, Easy, 1P
1(Hourglass)      bear(=Sharing)               = 9
2 space-station   + Dumbbells  = 4+1           = 5
2 wall of eyes    + Sharing    = 1+3+1         = 5
3 carrots_storage + Apple      = 1+2+1         = 4
3 child dorm      + Book       = 4+2           = 6

# B: seed 346346, Easy, 1P
1(Hourglass)      bear(=Sharing)               = 9
2 rabbit_dinner   + Sharing    = 3+2           = 5
2 wall of hands   + Water      = 2+7           = 9
3 upside_storm    + Dumbbells  = 1+2+1         = 4
3 illusion_dinner + Water      = 4+3+2         = 9
```

抽取出的约束：

| 观测量 | 结论 |
|---|---|
| 每回合房间数 | 2（= `NumActiveConsoles[1P]`）✅ |
| 每间房的板数 | 4 块固定，其中 **2 或 3 块**出现目标图案（其余空白/其他图案） |
| 每块板数字 | 1..7（0..9 都可能，`IntMax=9`） |
| 每房答案 | 4,5,5,6 / 4,5,9,9 → **恒为 1 位（≤9）** ✅ 与键盘限制一致 |
| 教学关 | 两个不同 seed 都是 **9**（且两次都是「bear」）→ 见 §6 的关键假设 |
| 图案重复 | seed B 里 `Water` 在同一局的两回合各出现一次 → 图案可重复 |

---

## 5. 引擎侧事实（已定位，供下次接着挖）

| 项 | 值 |
|---|---|
| 类 | `RBGameShowObjectiveCoordinator`（原生，`/Script/OPP`） |
| UClass 懒加载 | `sub_1407FAB20` → `sub_14035AFB0(...)`，对象 **6200 (0x1838)** 字节，结果存 `qword_146E601F0` |
| 类 init（注册 UFUNCTION） | `sub_1429E5510` → `sub_14048DA90(class, &off_145C05950, 4)` |
| UFUNCTION 表 | `off_145C05950`：`Cheat_CompleteRound`／`DebugGameShowPrepareRound`／`DebugPrepareRoundForPlayers_Server`／`GetSymbolTextures` |
| Shipping 里的调试函数 | 前三个的实现是 **空桩**（`0x1426325B0` 只有一条 `c3`）→ 真正流程是普通成员函数 |
| 结构体 | `FRBGameShowSection`（Room/Name/MaxFakeFlipboards，属性表在 `0x145C04F80` 附近，名字指针按 0x28 步长排列） |
| 相关属性名（名字池） | `FlipboardsBySection` / `FlipboardsBySection_Key` / `FlipboardActors` / `FlipboardClass` / `SymbolIndex` / `Answer` |
| 类名宽串 | `L"RBGameShowObjectiveCoordinator"` 被链接器折进 `L"ARBGameShowObjectiveCoordinator"` 尾部（`0x1466E5170`），所以直接搜 `RBGameShow...` 搜不到 |
| 随机源判断 | 该类**不在** `sub_140503B80`(GetSeed) 与 `sub_1402D29E0`(RandSeeded) 的调用者交集里 → 更可能走 `FRandomStream` 连续抽（`sub_1407D2720` / `sub_1437E5100`） |

**已做过的失败尝试**（别重复）：

1. 套用 CHJ_MT01 的「18 分区排序 + 取前 2」→ 两个样本都不匹配（`tools/probe_fpi.py`）。
2. 常量族 `idx_j = RandSeeded(C + k·j, pool, salt=S%1000)`，C 扫满 2^18×6 种组合 → 0 命中（`tools/fit_fpi_rooms.py`）。

---

## 6. 模型假设与已排除项

### 6.1 玩家的判断（已采纳）

> 「如果同一间房每次数字都一样，玩家只要记表就行了，游戏就太简单了」→ **内容应当随 seed 变化**。

这推翻了早期的「内容固定 per room」猜测。早期证据（教学关两个种子都是 9）改按下面解释：

**教学关是固定脚本**（1 分区 / 1 回合 / 1 讲台，`CompletedTrialRoundsAtStart = 1`），
两次都看到 `Sharing = 9` 只能说明**教学关不参与随机**，不能推及正式回合。

### 6.2 按 CHJ_MT01 的先例，seed 很可能只通过 `S % 1000` 进入

CHJ_MT01 里房间种子是**名字链**（与关卡种子无关），关卡种子只作为 `RandSeeded` 内部的盐 `S % 1000`。
若 FPI_MT02 同样如此，则：

```
内容(房间, S) = f( GetSeed(房间), S % 1000 )      // 只跟末三位有关
```

**这是一条很便宜的判定实验**：找两个末三位相同的种子（例如 `189189` 和 `190189`），
两次同房间的图案/数字若完全一样 → 模型成立，剩下就是解常数，和 CHJ_MT01 同一套打法；
若不一样 → 关卡种子是整串进入的，模型要换。

### 6.3 已经排除的模型（用现有 8 条观测，判定=全部成立）

`tools/fit_fpi_symbol.py` 扫过：

| 维度 | 取值 |
|---|---|
| base | `GetSeed(房间)`、房间 CRC 不加 abs、`GetSeed(协调器)`、分区序号、0 |
| 抽法 | `RandSeeded(n=9/10)`、`RandSeeded(9)+1`、`FRandomStream.RandRange(9)`、`RandRange(9)+1`、`SelectSubset(10,1)` |
| 常数 K | 0 .. 524287 全扫 |
| 盐 | `S % 1000` |

→ **0 命中**。

结论：内容不是「以房间/协调器种子为基、加一个常量偏移、单次抽取」得到的。
最可能是**连续多次抽取**（先抽板数或先抽数字，图案在后面），或者用了别的入口
（例如先把候选列表洗牌再取第 k 个）。

同理，房间选择也不是 CHJ 那套分区排序（`tools/probe_fpi.py`），
也不是 `RandSeeded(C + k·j, pool)` 形态（`tools/fit_fpi_rooms.py`，C 扫满 2^18）。

---

## 7. 下一步

### 7.1 采样成本可以压到很低

不用打完整关，只要：

1. **开场看 4 台讲台**：哪 2 台亮、显示的房间名 → 给出「每回合抽哪 2 间房」（几十秒）；
2. **随便进 1 间房**看 4 块板：哪些板有图案、数字多少 → 给出该房内容。

照现有格式贴进 `home/test.txt` 即可，**不用改代码**：

```powershell
cd release\home\tools
python samples.py ..\test.txt        # 解析 + 校验（认不出的房间/图案会报出来）
python fit_fpi_symbol.py             # 用最新样本重跑拟合
```

`samples.py` 有别名表（`space-station` / `wall of eyes` / `bear=sharing` …），写宽松一点也能认。

### 7.2 数据优先级

| 优先级 | 数据 | 能解决什么 |
|---|---|---|
| ⭐⭐⭐ | 两个 **末三位相同** 的种子（各记 1 间房） | 判定 §6.2，决定走「解常数」还是「啃代码」 |
| ⭐⭐ | 每回合讲台显示的 2 个房间名（3~5 局） | 锁死「选房」模型（4~10 条约束很短） |
| ⭐ | 同房间在不同 seed 的完整记录 | 交叉验证内容模型 |

### 7.3 代码侧（如果数据路线卡住）

1. 用 `FlipboardsBySection`（运行时 TMap：分区 → 翻板列表）作锚点：找到属性偏移后，
   搜「写这个 TMap 的函数」= 回合准备函数，里面必然有 `RandSeeded`/`RandRange` 和盐。
2. 该类没有静态属性名字表（`xrefs` 到属性名返回空），需从对象构造（`sub_14035AFB0` 内部调用）
   或 vtable 入手；可参照 `FRBGameShowSection` 的属性表格式（`0x145C04F80` 附近，0x28 步长，+0x08 是名字指针）。
3. 拿到函数后按 CHJ_MT01 的方式写进 `seedcore`，再把 `seed.py` 里 `LEVELS['FPI_MT02']['sections']`
   换成真实实现即可（接口已经留好）。

---

## 8. 数据来源与脚本

| 用途 | 路径 |
|---|---|
| 协调器属性（18 分区/图案/回合） | `pak/OPP/Content/Maps_json/FunParkIllusion/FPI_MT02_B00.json` |
| 房间 actor 表 | `pak/OPP/Content/Maps_json/FunParkIllusion/FunParkIllusion_LD_Room.json` |
| 样本 | `home/test.txt` |
| 打印协调器配置 | `python home/tools/dump_gameshow.py <json> [关键字]` |
| 打印任意对象属性 | `python home/tools/dump_props.py <json> <名字关键字> [--refs]` |
| **解析 test.txt 样本** | `python home/tools/samples.py ..\test.txt` |
| **图案/总答案拟合** | `python home/tools/fit_fpi_symbol.py [test.txt] [扫描上限]` |
| 套 CHJ 选房算法试算 | `python home/tools/probe_fpi.py` |
| 扫选房常数 | `python home/tools/fit_fpi_rooms.py` |
