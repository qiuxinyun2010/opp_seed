# -*- coding: utf-8 -*-
"""SR_Trial 调频（OrderedClueFrequency）阶段推演 —— 完整模型。

两个协调器：
  B02  SR_B02_ObjCoord_OrderedClueFrequency        池 5 / 目标 4 / 屏 3 / bRevealOneByOne=True
  B03  ..._Poor (13 板)  ..._Rich (18 板)          池 6 / 目标 6 / 屏 3 / 一次显示

模型（代码级，见 SR_TRIAL.md 11.2 / 11.4）：
  1) 图案抽取（按「目标序号」k 依次抽，抽中即保序删除）
       路径 B（无 AlternatePairs，如 B02）: index = RandSeeded(seed + 223551 + 2*k, 剩余数)
       路径 A（有 AlternatePairs，如 B03）: index = RandSeeded(seed + 223551 + 1*k, 剩余数)
  2) 上屏目标（主目标列表，sub_14361CE40）
       primary = 对 0..n-1 做 3 次无放回抽样, index = RandSeeded(seed + 924523 + j, 剩余数)
     屏幕按 primary 顺序显示对应目标的图案；未上屏的目标 = 干扰板。

用法：
  python sr_trial_freq.py 485485
  python sr_trial_freq.py 485485 --trace
  python sr_trial_freq.py --tuners
"""
import json
import os
import sys

_HERE = os.path.dirname(os.path.abspath(__file__))
if _HERE not in sys.path:
    sys.path.insert(0, _HERE)

import srr_mt02 as rb  # crc32_fname / get_seed / rand_seeded / M32

M32 = rb.M32
CLUE_OFFSET = 223551     # 图案抽取
TUNER_OFFSET = 243551    # 调频器抽取（分组路径）
PRIMARY_OFFSET = 924523  # 主目标（上屏）列表；代码读出 924519，实测需 +4
ALT_SLOT_OFFSET = 253526

POLY5 = ['Bunny', 'Heart', 'Moon', 'Spade', 'Club']
POLY6 = POLY5 + ['Diamond']

ZH = {'Bunny': '兔子', 'Heart': '红心', 'Moon': '月亮',
      'Spade': '黑桃', 'Club': '梅花', 'Diamond': '方块'}

COORDS = {
    'B02': {
        'name': 'SR_B02_ObjCoord_OrderedClueFrequency',
        'pool': POLY5, 'targets': 4, 'screens': 3, 'path': 'group',
    },
    'B03_Poor': {
        'name': 'SR_B02_ObjCoord_OrderedClueFrequency_Poor',
        'pool': POLY6, 'targets': 6, 'screens': 3, 'path': 'alt',
    },
    'B03_Rich': {
        'name': 'SR_B02_ObjCoord_OrderedClueFrequency_Rich',
        'pool': POLY6, 'targets': 6, 'screens': 3, 'path': 'alt',
    },
}

JSON_DIR = os.path.join(os.path.dirname(os.path.dirname(_HERE)),
                        'pak', 'OPP', 'Content', 'Maps_json', 'SuburbRiot')
LEVEL_JSON = {'B02': 'SuburbRiot_T08_B02.json', 'B03': 'SuburbRiot_T08_B03.json'}

# 实测（seed 485485）
RECORDED = {
    485485: {'B02': ['Heart', 'Moon', 'Spade'],
             'B03_Rich': ['Club', 'Moon', 'Heart'],
             'B03_Poor': None},
}


# ---------------------------------------------------------------- 图案抽取
def step_of(key):
    return 2 if COORDS[key]['path'] == 'group' else 1


def patterns(key, seed):
    """按目标序号 0..n-1 抽出的图案（抽中即保序删除）。"""
    c = COORDS[key]
    pool = list(c['pool'])
    B = rb.get_seed(c['name'])
    salt = seed % 1000
    st = step_of(key)
    out = []
    for k in range(c['targets']):
        if not pool:
            break
        i = rb.rand_seeded((B + CLUE_OFFSET + st * k) & M32, len(pool), salt)
        out.append(pool.pop(i))
    return out


def primary_positions(key, seed, count=3):
    """上屏的目标序号（按显示先后）。等价 sub_14361CE40(n, count, seed+924523, 0)。"""
    c = COORDS[key]
    B = rb.get_seed(c['name'])
    salt = seed % 1000
    pool = list(range(c['targets']))
    out = []
    for j in range(count):
        if not pool:
            break
        i = rb.rand_seeded((B + PRIMARY_OFFSET + j) & M32, len(pool), salt)
        out.append(pool.pop(i))
    return out


def screens(key, seed):
    """返回 (屏幕图案序列, 全部目标的图案, 上屏目标位次)。"""
    pat = patterns(key, seed)
    pos = primary_positions(key, seed)
    return [pat[p] for p in pos], pat, pos


def tuner_order(key, seed):
    """调频器（板子）被抽中的顺序（仅分组路径有意义）。"""
    c = COORDS[key]
    B = rb.get_seed(c['name'])
    salt = seed % 1000
    st = step_of(key)
    pool = list(range(len(_tuners(key))))
    out = []
    for k in range(c['targets']):
        if not pool:
            break
        i = rb.rand_seeded((B + TUNER_OFFSET + st * k) & M32, len(pool), salt)
        out.append(pool.pop(i))
    return out


# ---------------------------------------------------------------- 静态点位
_CACHE = {}


def _num(name):
    tail = name.rsplit('_', 1)[-1]
    return int(tail) if tail.isdigit() else 0


def _load(key):
    if key in _CACHE:
        return _CACHE[key]
    block = 'B02' if key == 'B02' else 'B03'
    path = os.path.join(JSON_DIR, LEVEL_JSON[block])
    with open(path, 'r', encoding='utf-8', errors='replace') as f:
        objs = json.load(f)
    tuners, screens_ = [], []
    for c in objs:
        if not isinstance(c, dict):
            continue
        rl = (c.get('Properties') or {}).get('RelativeLocation')
        if not rl:
            continue
        owner = (c.get('Outer') or {}).get('ObjectName', '')
        owner = owner.rsplit('.', 1)[-1].rstrip("'")
        xyz = (rl.get('X'), rl.get('Y'), rl.get('Z'))
        if key == 'B02' and 'FrequencyMatchSuburbs_Garden_' in owner:
            tuners.append((owner, xyz))
        elif key == 'B03_Poor' and 'FrequencyMatchSuburbs_Poor_' in owner:
            tuners.append((owner, xyz))
        elif key == 'B03_Rich' and 'FrequencyMatchSuburbs_Rich_' in owner:
            tuners.append((owner, xyz))
        elif 'FrequencyClue_TvChannel' in owner:
            tag = {'B02': 'TvChannel_Garden', 'B03_Poor': 'TvChannel_Poor',
                   'B03_Rich': 'TvChannel_Rich'}[key]
            if tag in owner:
                screens_.append((owner, xyz))
    tuners.sort(key=lambda t: _num(t[0]))
    screens_.sort(key=lambda t: _num(t[0]))
    _CACHE[key] = (tuners, screens_)
    return _CACHE[key]


def _tuners(key):
    return _load(key)[0]


# ---------------------------------------------------------------- 输出
def show(seed, trace=False):
    print('seed = %d   (salt = seed %% 1000 = %d)' % (seed, seed % 1000))
    for key in ('B02', 'B03_Poor', 'B03_Rich'):
        c = COORDS[key]
        pat = patterns(key, seed)
        shown, _, pos = screens(key, seed)
        print()
        print('  [%s] %s   路径=%s 步长=%d' % (
            key, c['name'], c['path'], step_of(key)))
        print('    目标图案 0..%d : %s' % (len(pat) - 1, ' / '.join(
            '%d:%s' % (i, s) for i, s in enumerate(pat))))
        print('    上屏位次      : %s' % pos)
        print('    屏幕预测      : %s' % ' / '.join(ZH.get(s, s) for s in shown))
        rec = RECORDED.get(seed, {}).get(key)
        if rec:
            same_set = set(shown) == set(rec)
            mark = ''.join('o' if a == b else 'x' for a, b in zip(shown, rec))
            print('    实测          : %s   逐位 %s   集合 %s'
                  % (' / '.join(ZH.get(s, s) for s in rec), mark,
                     '一致' if same_set else '不一致'))
        if trace and c['path'] == 'group':
            names = [t[0] for t in _tuners(key)]
            print('    板子抽取顺序  : %s' % ', '.join(
                'k%d=%s' % (k, names[i]) for k, i in enumerate(tuner_order(key, seed))))


# ------------------------------------------- B03 分组路径（见 SR_TRIAL.md 11.9）
_B03 = {}


def b03_data(key):
    """(ObjectiveActors 顺序, 面板->SectionIndex, 面板->坐标)。缺省 SectionIndex=0。"""
    if key in _B03:
        return _B03[key]
    path = os.path.join(JSON_DIR, LEVEL_JSON['B03'])
    with open(path, 'r', encoding='utf-8', errors='replace') as f:
        objs = json.load(f)
    sec, xyz = {}, {}
    coord = COORDS[key]['name']
    oa = []
    for c in objs:
        if not isinstance(c, dict):
            continue
        name = c.get('Name') or ''
        props = c.get('Properties') or {}
        if name.startswith('FrequencyMatchSuburbs_'):
            sec[name] = props.get('SectionIndex') or 0
        if name == coord:
            oa = [e['SubPathString'].rsplit('.', 1)[-1]
                  for e in props['ObjectiveActors']]
        rl = props.get('RelativeLocation')
        owner = (c.get('Outer') or {}).get('ObjectName', '').rsplit('.', 1)[-1].rstrip("'")
        if rl and owner.startswith('FrequencyMatchSuburbs_'):
            xyz[owner] = (rl.get('X'), rl.get('Y'), rl.get('Z'))
    _B03[key] = (oa, sec, xyz)
    return _B03[key]


def b03_groups(key):
    """按 SectionIndex 升序分好的组；组内保持 ObjectiveActors 顺序。"""
    oa, sec, _ = b03_data(key)
    g = {}
    for n in oa:
        g.setdefault(sec[n], []).append(n)
    return [g[k] for k in sorted(g)]


def b03_show(key, seed, perm=None, obs=None):
    """perm: 目标号 k -> 组序号（弹出顺序）；obs: 实测面板号, 用来反推 perm。"""
    c = COORDS[key]
    pat = patterns(key, seed)
    groups = b03_groups(key)
    _, sec, xyz = b03_data(key)
    print('  [%s] 组数=%d  组大小=%s' % (key, len(groups), [len(g) for g in groups]))
    for gi, g in enumerate(groups):
        print('    组%d: %s' % (gi, ', '.join(
            '%s(s%d)' % (n.rsplit('_', 1)[-1], sec[n]) for n in g)))
    if obs:
        perm = []
        for o in obs:
            cand = [i for i, g in enumerate(groups)
                    if any(n.endswith('_%d' % o) for n in g)]
            perm.append(cand[0] if cand else None)
        if None in perm or len(set(perm)) != len(perm):
            print('    实测反推失败: perm=%s (面板号与分组不匹配或重复)' % perm)
            perm = None
        else:
            print('    实测反推弹出顺序 = %s' % perm)
    if perm is None:
        print('    (未给置换：图案已可按位次算出，面板需先定弹出顺序)')
        for k, p in enumerate(pat):
            print('      k=%d 图案=%-7s 组=?  面板=?' % (k, ZH.get(p, p)))
        return
    for k, gi in enumerate(perm):
        g = groups[gi]
        hit = [n for n in g if obs and n.endswith('_%d' % obs[k])] or g
        name = hit[0]
        x, y, z = xyz.get(name, (float('nan'),) * 3)
        print('      k=%d 图案=%-7s 组%-2d %-34s (%8.1f, %7.1f, %7.1f)'
              % (k, ZH.get(pat[k], pat[k]), gi, name, x, y, z))


def show_tuners():
    for key in ('B02', 'B03_Poor', 'B03_Rich'):
        tuners, scr = _load(key)
        print('=' * 78)
        print('%s   调频器 %d 台 / 显示屏 %d 块' % (key, len(tuners), len(scr)))
        for n, (x, y, z) in tuners:
            print('   %-42s (%9.1f, %9.1f, %8.1f)' % (n, x, y, z))
        for n, (x, y, z) in scr:
            print('   %-42s (%9.1f, %9.1f, %8.1f)  <- 屏' % (n, x, y, z))


def main(argv):
    if '--tuners' in argv:
        show_tuners()
        return 0
    obs = None
    for i, a in enumerate(argv):
        if a.startswith('--b03-obs='):
            obs = [int(v) for v in a.split('=', 1)[1].split(',') if v.strip()]
    seeds = [int(a) for a in argv if a.isdigit()]
    if '--b03' in argv:
        s = seeds[0] if seeds else 485485
        print('seed = %d   (salt = %d)' % (s, s % 1000))
        for key in ('B03_Rich', 'B03_Poor'):
            b03_show(key, s, obs=obs if key == 'B03_Rich' else None)
        print()
        return 0
    if not seeds:
        seeds = [485485]
    for i, s in enumerate(seeds):
        if i:
            print()
        show(s, trace='--trace' in argv)
    print()
    print('说明：B02 实测顺序是预测顺序的循环位移（差 2 位），因为该关 TV 数组的')
    print('      摆放顺序与 Garden_1..3 命名顺序不一致；图案集合完全一致。')
    return 0


if __name__ == '__main__':
    sys.exit(main(sys.argv[1:]))
