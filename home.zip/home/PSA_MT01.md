# PSA_MT01：图案钥匙、钥匙房、录像盘与最短开门链

关卡：警察局阁楼 `PoliceStationAttic` · 「打开图案锁房，取回录像盘」
配套脚本：`home/psa_mt01.py`（本目录，可独立运行）

---

## 0. 本次结论（seed = 958958）

旧脚本 `release/coop/PSA_MT01/PSA_MT01.py` 对 958958 抛异常，原因是**漏了一个静态生成点**，
不是算法错。补上后 958958 与实测 8/8 吻合（见 §7）。

最短钥匙链：**红心 → 火焰 → 兔子 → 录像盘**

| 步骤 | 图案 | 钥匙生成点 actor | 钥匙在哪个房间拿到 | 打开哪个房间 |
|---|---|---|---|---|
| 起始 | 红心 | `PSA_MT01_KeySpawner_FirstKey_1` | 起始区域 | `RBRoom_ReelStorage` |
| 1 | 火焰 | `PSA_MT01_KeySpawner_ClassRoom_2` (307.3, 624.8, 1087.9) | `RBRoom_ReelStorage` | `RBRoom_ShootingRange` |
| 2 | 兔子 | `PSA_MT01_KeySpawner_ShootingRange_2` (-3895.9, -534.4, 139.3) | `RBRoom_ShootingRange` | `RBRoom_CafeteriaBreakRoom_17` |
| 3 | 录像盘 | `DiaporamaWheel_LargeObject_BP7_18` (-1426.3, 420.8, 407.5) | — | `RBRoom_CafeteriaBreakRoom_17` |

完整 7 节点树：

| 节点 | 门图案 | 房间 | 房内内容 |
|---:|---|---|---|
| 1 | 红心 | `RBRoom_ReelStorage` | 火焰、黑桃 |
| 2 | 火焰 | `RBRoom_ShootingRange` | 兔子、梅花 |
| 3 | 黑桃 | `RBRoom_Morgue_Master` | 眼睛、月亮 |
| 4 | 兔子 | `RBRoom_CafeteriaBreakRoom_17` | **录像盘** |
| 5 | 梅花 | `RBRoom_Generator` | 空 |
| 6 | 眼睛 | `RBRoom_OfficeBathroom_24`（= `RBRoom_ChiefOfficeSideRoom_22`） | 空 |
| 7 | 月亮 | `RBRoom_ChiefOffice_27` | 空 |

```powershell
cd d:\workspace\outlast\release\home
python psa_mt01.py 958958            # 最短链 + 7 把钥匙点位 + 录像盘
python psa_mt01.py 958958 --tree     # 7 节点树
python psa_mt01.py 958958 --trace    # 房间抽取的重抽过程
python psa_mt01.py 958958 --json
python psa_mt01.py --spawners        # 15 个钥匙房 × 2 个生成点全表
python psa_mt01.py --selftest        # 26/26（219219 + 958958）
```

---

## 1. REA / IDA 状态（本次已连上）

* `rea` MCP server 可用，provider = `ida` / `IDA MCP adapter`，上游 `ida-pro-mcp 1.30.0`。
* **必须先把 IDA 开起来**：未启动时所有调用都报 `[WinError 10061] 目标计算机积极拒绝`。
  启动方式（插件在 `%APPDATA%\Hex-Rays\IDA Pro\plugins\mcp-plugin.py`，监听 `127.0.0.1:13337`）：

  ```powershell
  Start-Process "C:\Program Files\IDA Professional 9.3\ida.exe" `
      -ArgumentList '"D:\workspace\outlast\TOTClient-Win64-Shipping.exe.i64"' -WindowStyle Minimized
  # 等 20~30 秒，netstat 看到 127.0.0.1:13337 LISTENING 即可
  ```
* 连上后：目标 `TOTClient-Win64-Shipping.exe`，SHA-256
  `2cd37c880454af61aff8e93918089f10f195ae8da6c939eb6f047eb214a4192e`，image base `0x140000000`。
* provider 不支持 `current_document`；`binary_overview` 这次 MCP 侧超时（数据库大），
  直接用 `procedure_pseudo_code 0x1435820D0` 正常。

---

## 2. 旧脚本为什么在 958958 上炸

```
RuntimeError: room RBRoom_Morgue_Master has no remaining exported key-spawner actor
```

钥匙树里**节点 1..3 是中间节点**，要各自再生成 2 把钥匙，所以「被选中的房间」必须至少有
2 个钥匙生成点。停尸房 `RBRoom_Morgue_Master` 在旧表里只有 1 个
`PSA_MT01_KeySpawner_Morgue_1`。

真实原因是**静态数据不全**，不是运行时有隐藏 slot：

* 全图共 **31** 个 `PSA_MT01_QuestItemSpawner_BP` actor = 15 个钥匙房 × 2 + 1 个起始钥匙；
* 其中 30 个在 `PSA_MT01_B00` 子关卡，**只有 `PSA_MT01_KeySpawner_Morgue_2` 在
  `PSA_LD_Items` 子关卡**（`pak/OPP/Content/Maps_json/PoliceStationAttic/PSA_LD_Items.json`，
  `SceneComp.RelativeLocation = -794.6382, 2209.8171, 139.12964`）；
* 旧点位缓存 `release/seed/ui/data/cache/PoliceStationAttic.points.PSA_MT01.json`
  的 `stamp` 只列了 `PSA_MT01_B00.json` / `PSA_MT01_B01.json` 两个文件 → 漏掉整个
  `PSA_LD_Items`。

补上后全 999 个 salt 扫描：**0 失败**（旧表有 118/999 ≈ 11.8% 的 seed 会命中这个缺口）。

---

## 3. 关键地址（IDA）

| 地址 | 作用 |
|---|---|
| `0x1435820D0` | `RBKeyLockedRoomsCoordinator` 主流程：建 7 节点树 / 选录像盘叶子 |
| `0x143582F60` | 为当前节点选「图案 + 生成点」 |
| `0x143583800` | 从父房生成点池抽 1 个并 swap-remove；seed = `320239 + node` |
| `0x143582F60` 内 | 图案池抽取，seed = `38322 + node` |
| `0x143583530` | 选下一个钥匙房，seed = `38342 + node + attempt`，带距离过滤 |
| `0x14270F020` | `RandSeeded(seed, count)` 原始 seeded hash |
| `0x140474200` | 生成点数组 swap-remove |
| `0x143582C4D` | 录像盘叶子抽取（常量被编译器折叠，见 §4.3） |

`0x143583800` 反编译确认（`sub_14270F020(a2 + 320239, 0) % Count` 后 `RemoveAt`）：

```c
v5 = *(a1 + 8);                                   // Count
if (dword_146E2E5C4 != 0 && (_WORD)v5 != 0)
    v6 = (uint16)(sub_14270F020(a2 + 320239, 0) % (uint16)v5);
if (v5 <= v6) return 0;
v9 = *(*a1 + 8 * v6);
sub_140474200(a1, v6, 1, a4);                     // RemoveAtSwap
return v9;
```

---

## 4. 算法

### 4.1 图案（10 → 8 → 7）

```
pool = [Bunny, Club, Crown, Diamond, Eye, Fire, Heart, Moon, Spade, Star]
while len(pool) > 8: swap_remove(pool, RandSeeded(45834++, len(pool)))
for node in 1..7:    symbol[node] = swap_remove(pool, RandSeeded(38322 + node, len(pool)))
```

958958：弃 `Diamond`、`Star`，剩 `Crown` 不用；7 个节点依次
`Heart, Fire, Spade, Bunny, Club, Eye, Moon`。

### 4.2 房间（节点 2..7）

```
rooms[1] = RBRoom_ReelStorage                     # 根房固定
candidates = 其余 14 个 RBRoom，按内部名 casefold 升序
for node in 2..7:
    parent = rooms[node // 2]
    spawn   = swap_remove(parent.spawners, RandSeeded(320239 + node, len(spawners)))
    temp = copy(candidates)
    for attempt in 0..19:
        room = temp[RandSeeded(38342 + node + attempt, len(temp))]
        if dist3d(spawn.p, room.BrushRoot) >= 2000: accept; break
        swap_remove(temp, room)
    candidates.remove(selected); rooms[node] = selected
```

* 距离用的是 **RBRoom 的 Brush 根坐标**（`PSA_LD_Rooms.json` 里 `BrushComponent0` 的位置），
  不是录像盘/钥匙箱坐标，也不是房间多边形中心。
* 候选池的初始顺序必须 **casefold 升序**；特别是
  `RBRoom_ChiefOffice_27` < `RBRoom_ChiefOfficeSideRoom_22`（按 casefold 比较，
  与 Python 默认大小写敏感排序不同）。

958958 的重抽：节点 3 先抽到 `RBRoom_DetectiveOffices03_50`（1263.1，拒）→
`RBRoom_CafeteriaBreakRoom_17`（1839.4，拒）→ `RBRoom_Morgue_Master`（2025.9，收）。

### 4.3 录像盘（4 个叶子里选 1）

```
film_node = [4, 5, 6, 7][RandSeeded(98639, 4)]
```

`0x143582C4D` 处这段被编译器折叠成了常量 `0xF1F56F239AC38BC2`：

```
v65 = mix(seed % 1000)
v66 = mix( ((K*v65) ^ ((K*v65)>>31) ^ 0xF1F56F239AC38BC2) ^ (…)>>30 )
idx = ((4587 * (v66 ^ (v66>>27))) ^ ((K*(v66 ^ (v66>>27)))>>31)) % 4
       K = 0x94D049BB133111EB,  mix(x) = ((0xBF58476D1CE4E5B9*x) mod 2^64) ^ (x>>27)
```

反解方式：`0xF1F56F239AC38BC2 == ((K * mix(s)) ^ ((K * mix(s)) >> 31))`，
在 `[0, 2^21)` 内**唯一解 s = 98639**（已数值验证；注意不是 `K*mix(s)` 直接等于常量，
还差一次 `^ (z>>31)`，第一次反解时漏了这一步所以解不出来）。
`4587` 是 `321982955 (0x133111EB)` 的低 16 位，与通用 `RandSeeded` 完全一致。

958958：`RandSeeded(98639, 4) = 0` → 节点 4。

### 4.4 最短链

录像盘所在叶子的钥匙依赖链（不含固定的起始红心/眼睛钥匙）：

```
path = [film_node, film_node//2, ..., 2]   # 剔除节点 1
```

---

## 5. 静态数据

| 数据 | 来源 |
|---|---|
| 15 个 RBRoom + Brush 根坐标 | `pak/OPP/Content/Maps_json/PoliceStationAttic/PSA_LD_Rooms.json`（15 个 `RBKeyLockedRoomComponent`） |
| 31 个钥匙生成点 | `PSA_MT01_B00.json`（30）+ **`PSA_LD_Items.json`（1：Morgue_2）** |
| 14 个录像盘 | `PSA_MT01_B00.json`（`DiaporamaWheel_LargeObject_BP*`，已核对 14/14 都在 B00） |

房间显示别名：`RBRoom_ChiefOfficeSideRoom_22` → `RBRoom_OfficeBathroom_24`，
`RBRoom_Infirmary_7` → `RBRoom_3`（玩家/点位图用的是别名）。

**教训（可复用）**：点位提取不能只扫 `_B00/_B01`。
`PoliceStationAttic` 一共 7 个关卡 JSON（`PSA_Persistent` / `PSA_LD_Rooms` /
`PSA_LD_Items` / `PSA_LD_IA` / `PSA_MT01_B00` / `PSA_MT01_B01` / `PSA_SND`），
其它关卡提取点位时应当全扫，或至少按 `Class` 名在所有关卡 JSON 里做一次全局计数核对。

---

## 6. 已验证 / 未验证

### 6.1 已验证（26/26）

`python psa_mt01.py --selftest`：`seed=219219` 15 项 + `seed=958958` 11 项，全部命中。
219219 的 7 个房间 + 6 个生成点 + 录像盘与 `release/coop/PSA_MT01/PSA_MT01.md` 完全一致
（说明补点没有改动原有结论）。

### 6.2 生成点池内顺序

池内顺序 = **actor 序号升序**（`X_1` 在前，`X_2` 在后）。由 6 条独立实测交叉确认：

| seed | 节点 | `RandSeeded(320239+n,2)` | 命中 | 实测 |
|---|---|---|---|---|
| 219219 | 2 | 0 | `ClassRoom_1` | 方块 = `ClassRoom_1` ✓ |
| 219219 | 4 | 1 | `ShootingRange_2` | 王冠 = `ShootingRange_2` ✓ |
| 219219 | 6 | 1 | `Basement_2` | 火焰 = `Basement_2` ✓ |
| 958958 | 2 | 1 | `ClassRoom_2` | 火焰 = `ClassRoom_2` ✓ |
| 958958 | 4 | 1 | `ShootingRange_2` | 兔子 = `ShootingRange_2` ✓ |
| 958958 | 5 | 0 | `ShootingRange_1` | 梅花 = `ShootingRange_1` ✓ |

停尸房的 `Morgue_1 / Morgue_2` 顺序按同一规则推定（两条都在同一房间，只影响
「眼睛/月亮分别在哪个具体柜子」，**不影响房间分配，也不影响最短链**）。
958958 中节点 6、7 都是死胡同叶子，所以本次不受影响。

### 6.3 与实测记录的一处冲突

`test.txt` 里 958958 有两行互相矛盾：

```
RBRoom_ChiefOffice_27=月亮房        ← 与模型一致（节点 7 = 月亮 → ChiefOffice_27）
月亮房=RBRoom_CafeteriaBreakRoom_17 ← 与上一行冲突
```

模型给出的是：月亮 → `RBRoom_ChiefOffice_27`，**兔子** → `RBRoom_CafeteriaBreakRoom_17`
（录像盘所在房）。同局的另外 8 条记录全部吻合，且模型是确定性推演，
因此判断第二行是把「录像盘所在的房间」误记成了「月亮房」。
如需复核：看 `RBRoom_CafeteriaBreakRoom_17` 门上画的是兔子还是月亮。

### 6.4 仍然只覆盖 Easy / 1P

核心随机只依赖 `种子 % 1000`；人数/难度是否改变候选初始化仍缺样本。
