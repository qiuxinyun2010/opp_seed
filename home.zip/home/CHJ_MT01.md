# 谜题房种子分析：从 seed 推出 3 个密码房 + 每间 4 位密码

> 本文是给另一个会话 / 另一个人的**交接文档**，自包含。
> 结论已经过 6 个实测样本交叉验证（2 个关卡种子 × 3 个房间，全部命中）。
> 目前只完整覆盖 **`CHJ_MT01`（法院 · 让正义天平倾斜）**，但方法可以直接搬到别的关卡。

一句话结论：

```
salt      = S % 1000
actorSeed = | crc("PersistentLevel") + crc(房间 actor 名) |
compSeed  = | crc("RBPuzzleRoomComponent_0") + actorSeed |
digit_i   = pool[ RandSeeded(compSeed + i + 7168, |pool|) ]     pool 每间重置 0..9，保序抽走
密码       = digit_0 digit_1 digit_2 digit_3
```

其中 `crc` 是 **每个 16 位字符走 4 步** 的 CRC32（见 §2，这是整件事的关键坑）。

---

## 1. 直接可用的东西

```powershell
cd d:\workspace\outlast\release\home

python seed.py --list                     # 已支持 / 待做的关卡
python seed.py CHJ_MT01 592592            # 推理一局：房间 + 密码
python seed.py CHJ_MT01 592592 --trace    # 附带分区抽取过程
python seed.py CHJ_MT01 592592 --json     # 机器可读（屏幕）
python seed.py CHJ_MT01 592592 --out r.json   # 机器可读（UTF-8 文件）
python seed.py --selftest                 # 6/6 自检
```

> `home/seed.py` 会自动把上一层的 `release/` 加进 `sys.path`，所以从任意目录调用都行
> （例如 `python release\home\seed.py CHJ_MT01 592592`）。

```python
# 在 release/ 下执行（seedcore.py 在那里）
import seedcore as sc
sc.predict(592592)                                  # [(房间, 密码), ...]
sc.passcode(592592, 'RBRoom_West_Bureau')
sc.room_component_seed('RBRoom_West_Bureau')
sc.pick_rooms(592592)                               # 只算房间
```

```
$ python seed.py CHJ_MT01 592592
CHJ_MT01  法院 · 让正义天平倾斜  (CourthouseJudicial)
seed = 592592   salt = 592
  [1] RBRoom_West_PrivateOffice      密码 2671
  [2] RBRoom_East_Museum             密码 4815
  [3] RBRoom_West_Blueprints         密码 2351
```

---

## 2. 关键修正：`GetSeed` 的字符串 CRC 是「每字符 4 步」

`sub_140503B80`（GetSeed）里对 FName 求 CRC 的函数是 **`sub_141CBDC30`**。
反汇编（`0x141CBDC30`，64 字节）显示：**每个 16 位字符走 4 步**标准 CRC32。

```
0x141cbdc4e  movzx r10d, r9w        ; 当前字符
             ... table[(crc^lo)]     ; 第 1 步：低字节
             ... table[(crc^hi)]     ; 第 2 步：高字节
             ... table[crc & 0xFF]   ; 第 3 步：0x00
             ... table[crc & 0xFF]   ; 第 4 步：0x00   ← 之前一直漏掉这一步
```

等价于把每个字符按 **4 字节 `[lo, hi, 0x00, 0x00]`** 喂进 CRC32；
表就是标准表 `dword_146CCCA80`（已从文件读出：`table[1] = 0x77073096`，poly `0xEDB88320`）。

| | 实现 | 对不对 |
|---|---|---|
| 旧 | `zlib.crc32(s.encode('utf-16-le'))`（每字符 2 步） | ❌ |
| 新 | `seedcore.crc32_fname()`（每字符 4 步） | ✅ |

**影响很大**：`puzzleroom.md §9` 里那一整批「X 的 2³² 全扫」都是在错误的 CRC 上跑的，
“0 命中”并不能说明“名字链不成立”，反而误导了后续所有推理（包括“必须存在蓝图接口注入”的猜测）。

正确的 Python 实现（`release/seedcore.py`，无第三方依赖）：

```python
_T = []
for i in range(256):
    c = i
    for _ in range(8):
        c = ((c >> 1) ^ 0xEDB88320) if (c & 1) else (c >> 1)
    _T.append(c & 0xFFFFFFFF)

def crc32_fname(s):          # sub_141CBDC30
    crc = 0xFFFFFFFF
    for ch in s:
        u = ord(ch) & 0xFFFF
        crc = _T[(crc ^ (u & 0xFF)) & 0xFF] ^ (crc >> 8)
        crc = _T[(crc ^ (u >> 8)) & 0xFF] ^ (crc >> 8)
        crc = _T[crc & 0xFF] ^ (crc >> 8)
        crc = _T[crc & 0xFF] ^ (crc >> 8)
    return (~crc) & 0xFFFFFFFF
```

> 备注：`sub_141CBDC30` 的形态（把 16 位字符当 4 字节处理）看起来像 UE 里
> `FCrc::MemCrc32(&ch, 4, crc)` 的产物，但不必纠结来源，按汇编照抄即可。

---

## 3. 为什么房间种子是「纯名字链」

`sub_140503B80(obj)` 的判定顺序：

1. **快路径**：`obj->Class` 上有 `GenerateRandomSeedForObject` 这个 UFunction → ProcessEvent。
   → 全游戏只有 2 个资产引用该接口名：`Brick_Weapon_BP`、`Variator_MannequinTrap_Setup_BP`
   （都是“自随机”道具，与谜题房无关）。整包 grep `RBRandomSeedGeneratorInterface` 也只有这两个。
   **所以谜题房走不到这条路。**
2. **慢路径**：`GetInterfaceAddress(obj, RBRandomSeedGeneratorInterface)` → 无实现者，落到名字兜底。
3. **名字兜底**（就是实际走的）：
   - 是 `AActor` → `actorSeed = | crc(关卡名) + crc(actor 名) |`（**只加两个名字，不递归到 world/package**）
   - 是 `UActorComponent` → `seed = | crc(组件名) + GetSeed(Owner, +0xA8) |`
   - 其它对象（Level/World/Package）才会继续往上递归

于是：

```
actorSeed = | crc("PersistentLevel") + crc("RBRoom_West_Bureau") |
compSeed  = | crc("RBPuzzleRoomComponent_0") + actorSeed         |
```

**已知常数**（换 CRC 后必须重算，别再沿用旧值）：

| 项 | 值 |
|---|---|
| `crc("PersistentLevel")` | `0x4C09CC22` = **1275710498** ← 之前一直在扫的未知量 X |
| `crc("RBPuzzleRoomComponent_0")` | `0xB404A0E8` = 3020202216 |
| `RBRoom_West_Bureau` compSeed | 527499485 |
| `RBRoom_West_Maintenance` compSeed | 178251051 |
| `RBRoom_East_JudgesOffice` compSeed | 892275145 |
| `RBRoom_West_PrivateOffice` compSeed | 102891051 |
| `RBRoom_East_Museum` compSeed | 325444180 |
| `RBRoom_West_Blueprints` compSeed | 1272857067 |

> 注意：`compSeed` 与关卡种子**无关**（同一个房间在任何一局里 compSeed 都一样），
> 关卡种子只通过 `salt = S % 1000` 进入公式。所以 S 和 S+1000、S+2000… 只要 `%1000` 相同，
> 房间和密码完全一样。

---

## 4. 4 位密码的生成（`sub_1436FE410` → `sub_143620E70` → `sub_1402D29E0`）

每个房间 4 个贴花，逐个调用：

```c
v5  = GetSeed(room);                              // compSeed
v16 = pad->Digits.Num();                          // 已经填了几个 = i (0..3)
v19 = sub_143621120(orderSet, v16, v5, n);        // 金字塔层号 order = i + RandRange(v5+11332, 0, slots-n)
v22 = sub_143620E70(decal, 1, v19, sectionIdx, coord+0x2C80 /*pool*/, v5 + v16);
      // 内部： idx = RandSeeded(v5+v16 + 7168, pool.Num()); digit = pool[idx]; 保序移除
pad->Digits[i] = v22;
```

- 数字池每间房重置为 `0..9`（`sub_1436FD200` 里 10 次 append 可对照），所以同一间房 4 位**不重复**。
- `RandSeeded(seed, N)`（`sub_1402D29E0`）内部会**混入 `dword_146E2E5C4 % 1000` 作为盐**，
  这就是“房间种子不变、密码却随局变化”的原因。
- `order_i = i + R`（R 对所有 i 相同）→ 层号单调递增 → **玩家按金字塔层读出来的顺序 = 抽取顺序**，
  所以密码字符串就是 `digit_0..digit_3`，不需要排序。

---

## 5. 验证

| 关卡种子 | 房间 | 预测 | 实测 |
|---|---|---|---|
| 987987 | `RBRoom_West_Bureau` | 3894 | 3894 ✅ |
| 987987 | `RBRoom_West_Maintenance` | 7481 | 7481 ✅ |
| 987987 | `RBRoom_East_JudgesOffice` | 7319 | 7319 ✅ |
| 592592 | `RBRoom_West_PrivateOffice` | 2671 | 2671 ✅ |
| 592592 | `RBRoom_East_Museum` | 4815 | 4815 ✅ |
| 592592 | `RBRoom_West_Blueprints` | 2351 | 2351 ✅ |

`seed = 828828`：房间已对上（Maintenance / JudgesOffice / Courtroom_1，与实测一致），
密码预测 `0391 / 7216 / 2984`，**待游戏内核对**（这个样本的密码当时没记）。

---

## 6. 文件索引

| 路径 | 作用 | 谁生成的 |
|---|---|---|
| `release/home/seed.py` | **入口**：`关卡 + seed → 房间/密码`，`--list/--json/--trace/--selftest` | AI |
| `release/home/tools/scan_x.c` | 2³² 全扫器（OpenMP，约 2 秒/次），就是它抓到 `X=0x4C09CC22` | AI |
| `release/home/tools/pe_read.py` | PE 节表 VA→文件偏移，用来读 `dword_146CCCA80` 那张表 | AI |
| `release/home/tools/room_actors.py` | 从 FModel 导出的关卡 JSON 里扒 actor / 组件名与归属 | AI |
| `release/seedcore.py` | 底层算法：`crc32_fname` / `rand_seeded` / `pick_rooms` / `passcode` / `predict` | 原有（本次改了 CRC） |
| `release/puzzleroom.md` | 完整逆向过程（§17 是本次结论；§9 的扫描结论已被 §2 推翻） | 原有 |
| `release/LEVELS.md` | 64 个关卡的中英名对照（找 `CHJ_MT01` 等编号用） | 原有 |
| `release/test.txt` | 实测样本记录 | 原有 |

> 早期那批“错误 CRC / 缺盐”的对照脚本（`chain_test*.py`、`crc_check.py`、`verify_model.py`）、
> 以及 `uecrc.py` / `verify_solution.py`（已被 `seedcore.crc32_fname` 和 `seed.py --selftest` 取代）
> 已经删掉，避免下次再踩同一个坑。

数据来源：

- 房间/组件名：`pak/OPP/Content/Maps_json/CourthouseJudicial/CHJ_LD_Rooms.json`
  （`RBRoom_*` actor + 其上的 `RBPuzzleRoomComponent_0`，共 13 间）
- 房间分区池：`CHJ_LD_MT01_B00.json` 里协调器 `MT01_LargePuzzleRoom_ObjCoord_BP_FullMap2`
  的 `Sections[*].RoomsInSection`（顺序即代码顺序，**不能排序**）
- 二进制：`TOTClient-Win64-Shipping.exe`（IDA MCP 已接好；基址 `0x140000000`）

---

## 7. 复现 / 排错步骤

### 7.1 想自己确认 CRC（5 分钟）

1. IDA 里 `0x141CBDC30` 看反汇编 → 数一下每个字符走了几次 `xor reg, [r8+...]`（4 次）。
2. `python release/home/tools/pe_read.py 0x146CCCA80 32` → 确认表是标准 CRC32（`table[1]=0x77073096`）。
3. `python -c "import sys;sys.path.insert(0,'release');import seedcore;print(hex(seedcore.crc32_fname('PersistentLevel')))"`
   → 应该是 `0x4c09cc22`。

### 7.2 想重新扫 X（1 分钟）

```powershell
cd d:\workspace\outlast\release\home\tools

# 编译（需要 VS2022；在 VS 的 x64 Developer PowerShell 里直接 cl 即可）
cl /nologo /O2 /openmp /Fe:scan_x.exe scan_x.c

# 参数：hash mode count base [c0 c1 c2] [房名前缀] [组件名] [model]
#   hash: 0=3步 1=2步 2=1步 3=大写+3步 4=大写+2步 5=4步(正确)
#   mode: 0=|CC+|cR+X||  1=|cR+X|  2=|CC+cR+X|  3=CC+|cR+X|
.\scan_x.exe 5 0 4294967296 0
# 输出 HIT X=1275710498 (0x4c09cc22)
```

> `scan_x.c` 里内置的约束是 `seed=987987` 的三个房间，换样本时改文件顶部
> `ROOMS[]` / `CODES[]`（或从命令行传 `c0 c1 c2`）即可。

判定标准：一次扫描的**误报期望 ≈ 2³² / 5040³ ≈ 0.03**，
所以“命中 1 个”基本就是真解（`5040 = 10×9×8×7`，即 4 位数不重复的排列数）。

### 7.3 常见坑

| 现象 | 原因 |
|---|---|
| 全扫 0 命中 | CRC 步数不对（最常见）、房间/组件名拼错、`salt` 没传 |
| 只有个别房间对上 | 分区池顺序被排序过；房间名少了 `_0`/`West_` 前缀 |
| 密码每位都出现重复数字 | 池被当成“有放回抽样” |
| 换了关卡后全错 | 该关卡的 ULevel 不叫 `PersistentLevel`，或协调器走了另一个分支 |

---

## 8. 已知边界（别踩）

1. **只有 `CHJ_MT01` 走通了端到端**。其它关卡缺 `Sections` 数据；
   `seed.py` 里已经把它们列成 `TODO`，不会瞎给答案。
2. **另一条密码分支**（`sub_1436FD200`，即 MultiroomPuzzle 的“一次分配全部贴花”路径）
   公式已反编译（`seedcore.passcode_for_room`），但**没有实测样本验证**。
3. **贴花选择 / 材质变体**没验证：
   - 选中哪 4 个贴花：`sub_1436FEB10(room, arr, decals, n, compSeed + 1000)`
   - 贴花外观：`GetSeed(decal) + 8847`
   这两块只影响“长什么样/在哪”，不影响密码，但做地图标注时会用到。
4. `want = 3` 取的是单/双/三人难度同一套配置（`bUseDefinedSections` 分支，`MinimumPuzzleRoomsInSection = 0`）。
   如果以后发现多人局数量不同，改 `LEVELS[...]['want']`。
5. 房间顺序是**代码抽取顺序**，不等于玩家进门的顺序；用它做“第几个房间”的判断要谨慎。

---

## 9. 下一步 TODO（按性价比排序）

1. **补 828828 的密码实测** → 7/7，彻底闭环。
2. **抓“同一房间、不同 seed”的样本 ×3**：这是最有价值的数据。
   有了它，即使以后怀疑某个常量，也能在 2³² 里唯一确定（误报期望 `2³²/5040³ ≈ 0.03`），
   不用再猜公式形态。
3. **`CHJ_MT02` / `CHJ_MT03`**：先确认协调器类 → 看 `Sections` 属性 → 填进 `seed.py` 的 `LEVELS`。
   若协调器类不是 `LargePuzzleRoom_ObjCoord_BP_C`，就要改走 `sub_1436FD200` 那条分支。
4. **其它 Mini Trial 的随机要素**（钥匙位置、保险箱密码、电路谜题等）：
   手法完全一样 —— 找到“读 `dword_146E2E5C4`”的入口 + `RandSeeded` 的盐，
   再用同样的 `scan_x` 思路验证。
5. 把「关卡 → 随机要素」做成表格，逐步扩充 `seed.py` 的输出（现在只输出房间+密码，
   结构已经留好：`predict()` 返回 dict，加字段即可）。

---

## 10. 给下一个会话的最小上下文

> 任务是**静态**推出《The Outlast Trials》里“让正义天平倾斜”一局的 3 个密码房和每间 4 位密码。
> 房间选择用 `seedcore.pick_rooms`（已早于本次解出）。
> 密码 = `f(compSeed, S%1000)`，`compSeed` 只由房间名和关卡名决定，靠 `seedcore.crc32_fname`（**每字符 4 步的 CRC32**）。
> 全流程已 6/6 验证，直接用 `python release/home/seed.py CHJ_MT01 <seed>` 即可。
> 如果结果不对，第一嫌疑是 CRC 步数，第二嫌疑是房间名/组件名，第三嫌疑是分区池顺序。
