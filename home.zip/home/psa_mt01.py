# -*- coding: utf-8 -*-
"""PSA_MT01（警察局阁楼 · 图案钥匙与录像盘）seed → 钥匙点位 / 房间 / 录像盘。

相比 release/coop/PSA_MT01/PSA_MT01.py 的唯一修正：
RBRoom_Morgue_Master 有 **两个** 钥匙生成点，第二个 `PSA_MT01_KeySpawner_Morgue_2`
不在 `PSA_MT01_B00` 子关卡里，而在 `PSA_LD_Items` 子关卡
（pak/OPP/Content/Maps_json/PoliceStationAttic/PSA_LD_Items.json，
SceneComp.RelativeLocation = -794.6382, 2209.8171, 139.12964）。
旧脚本的点位缓存只扫了 B00/B01，因此停尸房池只有 1 个点，
凡是 seed 把停尸房选成中间节点（要再出两把钥匙）的局都会抛
「no remaining exported key-spawner actor」。958958 正是这种局。

用法：
    python psa_mt01.py 958958              # 最短链 + 7 把钥匙 + 录像盘
    python psa_mt01.py 958958 --tree       # 打印完整 7 节点树
    python psa_mt01.py 958958 --trace      # 房间抽取的重抽过程
    python psa_mt01.py 958958 --json       # UTF-8 JSON
    python psa_mt01.py --spawners          # 15 个钥匙房 × 2 个生成点全表
    python psa_mt01.py --selftest          # 219219 + 958958 实测核对
"""
import argparse
import json
import math

M32 = 0xFFFFFFFF
M64 = 0xFFFFFFFFFFFFFFFF

START_ROOM = "RBRoom_ReelStorage"
START_KEY = {
    "actor": "PSA_MT01_KeySpawner_FirstKey_1",
    "p": [-259.0, 2879.1, 1489.3],
}
MIN_ROOM_DISTANCE = 2000.0  # KeyLockedRooms_ObjCoord_BP_2.MinDistanceBetweenKeyAndRoom

SYMBOLS = [
    "Bunny", "Club", "Crown", "Diamond", "Eye",
    "Fire", "Heart", "Moon", "Spade", "Star",
]
SYMBOL_ZH = {
    "Bunny": "兔子", "Club": "梅花", "Crown": "王冠", "Diamond": "方块",
    "Eye": "眼睛", "Fire": "火焰", "Heart": "红心", "Moon": "月亮",
    "Spade": "黑桃", "Star": "五角星", "FilmReel": "录像盘",
}

ROOM_ALIASES = {
    "RBRoom_ChiefOfficeSideRoom_22": "RBRoom_OfficeBathroom_24",
    "RBRoom_Infirmary_7": "RBRoom_3",
}

# RBRoom 的 Brush 根坐标（PSA_LD_Rooms.json），距离过滤用的就是它
ROOM_POSITIONS = {
    "RBRoom14_12": [-1744.0865, -456.54102, 750.1665],
    "RBRoom25_2": [-1464.7479, 456.32285, 99.65025],
    "RBRoom6_6": [-1613.904, 2912.0154, 1050.4243],
    "RBRoom7_9": [-1606.9672, 1943.3916, 1050.2352],
    "RBRoom_2ndFloorCafeteria": [705.6417, 743.5349, 1049.9722],
    "RBRoom_CafeteriaBreakRoom_17": [-1397.0144, 398.55035, 399.6241],
    "RBRoom_ChiefOfficeSideRoom_22": [-3750.028, 2373.6821, 464.63348],
    "RBRoom_ChiefOffice_27": [-3844.5745, 2854.8433, 400.2],
    "RBRoom_DetectiveOffices03_50": [1305.4845, 15.114014, 400.00073],
    "RBRoom_Generator": [-2565.2915, 2253.7273, 128.94824],
    "RBRoom_Infirmary_7": [-77.42565, 351.68613, 400.3535],
    "RBRoom_InterrogationRoom02_1": [2245.2808, 1858.9752, 400.09998],
    "RBRoom_Morgue_Master": [-26.670425, 2127.8098, 128.06154],
    "RBRoom_ReelStorage": [87.80759, 536.36743, 1080.2],
    "RBRoom_ShootingRange": [-3731.0142, -167.93793, 128.06158],
}

# 15 个钥匙房 × 2 个生成点，池内顺序 = actor 序号升序（见 PSA_MT01.md §6.3）
ROOM_SPAWNERS = {
    "RBRoom14_12": [
        {"actor": "PSA_MT01_KeySpawner_Locker_1", "p": [-1917.9, -654.2, 789.1]},
        {"actor": "PSA_MT01_KeySpawner_Locker_2", "p": [-1916.2, -533.3, 789.1]},
    ],
    "RBRoom25_2": [
        {"actor": "PSA_MT01_KeySpawner_Basement_1", "p": [-1318.8, 806.3, 139.2]},
        {"actor": "PSA_MT01_KeySpawner_Basement_2", "p": [-1324.5, 617.7, 139.1]},
    ],
    "RBRoom6_6": [
        {"actor": "PSA_MT01_KeySpawner_SecurityRoom_3", "p": [-2264.3, 3209.8, 1089.1]},
        {"actor": "PSA_MT01_KeySpawner_SecurityRoom_4", "p": [-2386.3, 3215.3, 1089.2]},
    ],
    "RBRoom7_9": [
        {"actor": "PSA_MT01_KeySpawner_VentilationRoom_1", "p": [-1980.0, 1548.2, 1089.2]},
        {"actor": "PSA_MT01_KeySpawner_VentilationRoom_2", "p": [-1758.1, 1552.7, 1089.3]},
    ],
    "RBRoom_2ndFloorCafeteria": [
        {"actor": "PSA_MT01_KeySpawner_Research_1", "p": [1719.7, 86.6, 1139.2]},
        {"actor": "PSA_MT01_KeySpawner_Research_2", "p": [1716.3, 208.6, 1139.4]},
    ],
    "RBRoom_CafeteriaBreakRoom_17": [
        {"actor": "PSA_MT01_KeySpawner_CafeteriaBreakRoom_1", "p": [-831.1, 312.6, 439.2]},
        {"actor": "PSA_MT01_KeySpawner_CafeteriaBreakRoom_2", "p": [-830.5, 170.4, 439.2]},
    ],
    "RBRoom_ChiefOfficeSideRoom_22": [
        {"actor": "PSA_MT01_KeySpawner_ChiefOfficeSideRoom_0", "p": [-3811.7, 2084.2, 439.2]},
        {"actor": "PSA_MT01_KeySpawner_ChiefOfficeSideRoom_1", "p": [-3674.4, 2083.1, 439.3]},
    ],
    "RBRoom_ChiefOffice_27": [
        {"actor": "PSA_MT01_KeySpawner_ChiefOffice_1", "p": [-3570.7, 3403.4, 439.2]},
        {"actor": "PSA_MT01_KeySpawner_ChiefOffice_2", "p": [-3327.2, 3402.9, 439.2]},
    ],
    "RBRoom_DetectiveOffices03_50": [
        {"actor": "PSA_MT01_KeySpawner_Detective_1", "p": [1525.5, 591.0, 440.2]},
        {"actor": "PSA_MT01_KeySpawner_Detective_2", "p": [1647.6, 589.3, 440.1]},
    ],
    "RBRoom_Generator": [
        {"actor": "PSA_MT01_KeySpawner_Generator_1", "p": [-2961.6, 2103.1, 139.2]},
        {"actor": "PSA_MT01_KeySpawner_Generator_2", "p": [-2844.8, 2101.7, 139.1]},
    ],
    "RBRoom_Infirmary_7": [
        {"actor": "PSA_MT01_KeySpawner_Infirmary_1", "p": [-335.1, 719.1, 439.2]},
        {"actor": "PSA_MT01_KeySpawner_Infirmary_2", "p": [-445.0, 717.7, 439.4]},
    ],
    "RBRoom_InterrogationRoom02_1": [
        {"actor": "PSA_MT01_KeySpawner_InterrogationRoom_1", "p": [2316.5, 2033.7, 439.1]},
        {"actor": "PSA_MT01_KeySpawner_InterrogationRoom_2", "p": [2315.0, 2157.9, 439.3]},
    ],
    "RBRoom_Morgue_Master": [
        {"actor": "PSA_MT01_KeySpawner_Morgue_1", "p": [-790.7, 1993.2, 139.2],
         "level": "PSA_MT01_B00"},
        # ↓ 本次补上的漏点：在 PSA_LD_Items 子关卡，不在 B00
        {"actor": "PSA_MT01_KeySpawner_Morgue_2", "p": [-794.6, 2209.8, 139.1],
         "level": "PSA_LD_Items"},
    ],
    "RBRoom_ReelStorage": [
        {"actor": "PSA_MT01_KeySpawner_ClassRoom_1", "p": [308.8, 375.2, 1087.3]},
        {"actor": "PSA_MT01_KeySpawner_ClassRoom_2", "p": [307.3, 624.8, 1087.9]},
    ],
    "RBRoom_ShootingRange": [
        {"actor": "PSA_MT01_KeySpawner_ShootingRange_1", "p": [-3898.8, -353.9, 139.2]},
        {"actor": "PSA_MT01_KeySpawner_ShootingRange_2", "p": [-3895.9, -534.4, 139.3]},
    ],
}

FILM_REELS = {
    "RBRoom14_12": {"actor": "DiaporamaWheel_LargeObject_BP_3", "p": [-1572.1, -805.0, 807.5]},
    "RBRoom25_2": {"actor": "DiaporamaWheel_LargeObject_BP12_14", "p": [-1615.7, 581.5, 107.5]},
    "RBRoom6_6": {"actor": "DiaporamaWheel_LargeObject_BP3_6", "p": [-2330.7, 3165.8, 1057.5]},
    "RBRoom7_9": {"actor": "DiaporamaWheel_LargeObject_BP4_9", "p": [-1849.1, 1675.1, 1057.5]},
    "RBRoom_2ndFloorCafeteria": {"actor": "DiaporamaWheel_LargeObject_BP2_2", "p": [1084.2, 24.7, 1057.5]},
    "RBRoom_CafeteriaBreakRoom_17": {"actor": "DiaporamaWheel_LargeObject_BP7_18", "p": [-1426.3, 420.8, 407.5]},
    "RBRoom_ChiefOfficeSideRoom_22": {"actor": "DiaporamaWheel_LargeObject_BP6_15", "p": [-3734.9, 2129.8, 407.5]},
    "RBRoom_ChiefOffice_27": {"actor": "DiaporamaWheel_LargeObject_BP5_12", "p": [-3453.7, 3263.4, 407.5]},
    "RBRoom_DetectiveOffices03_50": {"actor": "DiaporamaWheel_LargeObject_BP9_5", "p": [1590.3, 630.1, 407.5]},
    "RBRoom_Generator": {"actor": "DiaporamaWheel_LargeObject_BP13_19", "p": [-2707.7, 2303.0, 107.5]},
    "RBRoom_Infirmary_7": {"actor": "DiaporamaWheel_LargeObject_BP8_2", "p": [16.3, 100.1, 407.5]},
    "RBRoom_InterrogationRoom02_1": {"actor": "DiaporamaWheel_LargeObject_BP10_8", "p": [2270.4, 2094.7, 407.5]},
    "RBRoom_Morgue_Master": {"actor": "DiaporamaWheel_LargeObject_BP14_22", "p": [-420.5, 2700.8, 107.5]},
    "RBRoom_ShootingRange": {"actor": "DiaporamaWheel_LargeObject_BP11_11", "p": [-2661.7, -403.5, 107.5]},
}


# ---------------------------------------------------------------------------
# 随机原语：sub_14270F020 / 0x1402D29E0 的 RandSeeded(seed, count)
# 盐只取 关卡种子 % 1000（dword_146E2E5C4 % 0x3E8）
# ---------------------------------------------------------------------------
def rand_u16(seed, salt):
    a = (0xBF58476D1CE4E5B9 * ((seed ^ (seed >> 30)) & M64)) & M64
    a ^= a >> 27
    b = (0xBF58476D1CE4E5B9 * salt) & M64
    b ^= b >> 27
    v = ((0x94D049BB133111EB * a) & M64) ^ ((0x94D049BB133111EB * b) & M64)
    v ^= v >> 31
    v = (0xBF58476D1CE4E5B9 * (v ^ (v >> 30))) & M64
    v ^= v >> 27
    return ((321982955 * v) ^ (((0x94D049BB133111EB * v) & M64) >> 31)) & 0xFFFF


def rand_index(seed, count, salt):
    if not count or not seed or not salt:
        return 0
    return rand_u16(seed & M32, salt) % count


def swap_remove(items, index):
    item = items[index]
    items[index] = items[-1]
    items.pop()
    return item


def distance(a, b):
    return math.sqrt(sum((a[i] - b[i]) ** 2 for i in range(3)))


def display_room(room):
    return ROOM_ALIASES.get(room, room)


# ---------------------------------------------------------------------------
# 0x1435820D0 的三段抽取
# ---------------------------------------------------------------------------
def draw_symbols(salt):
    """10 个图案先弃到 8 个（seed 从 45834 递增），再按节点 1..7 各抽 1。"""
    pool = list(SYMBOLS)
    dropped = []
    seed = 45834
    while len(pool) > 8:
        dropped.append(swap_remove(pool, rand_index(seed, len(pool), salt)))
        seed += 1
    nodes = {}
    for node in range(1, 8):
        nodes[node] = swap_remove(pool, rand_index(38322 + node, len(pool), salt))
    return nodes, dropped, list(pool)


def draw_rooms(salt, trace=False):
    """节点 2..7：先在父房生成点池里抽点，再挑一个「离该点 ≥ 2000」的未用房间。"""
    candidates = sorted(
        (room for room in ROOM_POSITIONS if room != START_ROOM), key=str.casefold)
    pools = {room: [dict(item) for item in items]
             for room, items in ROOM_SPAWNERS.items()}
    rooms = {1: START_ROOM}
    key_spawns = {1: dict(START_KEY)}
    traces = []

    for node in range(2, 8):
        parent = rooms[node // 2]
        pool = pools[parent]
        if not pool:
            raise RuntimeError("节点 %d：%s 的生成点池耗尽" % (node, parent))
        spawn = swap_remove(pool, rand_index(320239 + node, len(pool), salt))
        key_spawns[node] = spawn

        temporary = list(candidates)
        selected = None
        attempts = []
        for attempt in range(20):
            index = rand_index(38342 + node + attempt, len(temporary), salt)
            room = temporary[index]
            dist = distance(spawn["p"], ROOM_POSITIONS[room])
            attempts.append({
                "attempt": attempt,
                "seed": 38342 + node + attempt,
                "index": index,
                "room": room,
                "distance": round(dist, 3),
            })
            if dist >= MIN_ROOM_DISTANCE:
                selected = room
                break
            swap_remove(temporary, index)
        if selected is None:
            raise RuntimeError("节点 %d 连续 20 次都没抽到距离 ≥ %g 的房间"
                               % (node, MIN_ROOM_DISTANCE))
        candidates.remove(selected)
        rooms[node] = selected
        traces.append({"node": node, "parent_room": parent,
                       "key_spawn": spawn["actor"], "attempts": attempts})
    return rooms, key_spawns, traces


def predict(level_seed, trace=False):
    if not 0 < level_seed <= M32:
        raise ValueError("seed 必须在 [1, 2^32-1]")
    salt = level_seed % 1000
    symbols, dropped, unused = draw_symbols(salt)
    rooms, key_spawns, traces = draw_rooms(salt)

    # 录像盘只落在叶节点 4..7，seed 常量 98639 由 0x143582C4D 的
    # 折叠常量 0xF1F56F239AC38BC2 唯一反解得到（全 2^21 唯一解）
    film_leaf = rand_index(98639, 4, salt)
    film_node = 4 + film_leaf
    film = dict(FILM_REELS[rooms[film_node]])
    film.update({"node": film_node, "room": rooms[film_node],
                 "room_display": display_room(rooms[film_node])})

    path_nodes = []
    node = film_node
    while node:
        path_nodes.append(node)
        node //= 2
    path_nodes.reverse()

    keys, tree = [], []
    for node in range(1, 8):
        parent = node // 2
        spawn = key_spawns[node]
        keys.append({
            "node": node,
            "symbol": symbols[node],
            "symbol_name_zh": SYMBOL_ZH[symbols[node]],
            "pickup_actor": spawn["actor"],
            "pickup_coordinates": spawn["p"],
            "found_in_room": None if node == 1 else display_room(rooms[parent]),
            "opens_room": display_room(rooms[node]),
        })
        children = [c for c in (node * 2, node * 2 + 1) if c <= 7]
        tree.append({
            "node": node,
            "room": display_room(rooms[node]),
            "door_symbol": symbols[node],
            "door_symbol_name_zh": SYMBOL_ZH[symbols[node]],
            "contained_keys": [SYMBOL_ZH[symbols[c]] for c in children],
            "has_film_reel": node == film_node,
        })

    path = []
    for node in path_nodes:
        if node == 1:
            continue  # 起始钥匙位置固定，不算一步
        spawn = key_spawns[node]
        path.append({
            "symbol": symbols[node],
            "symbol_name_zh": SYMBOL_ZH[symbols[node]],
            "room": display_room(rooms[node // 2]),
            "actor": spawn["actor"],
            "coordinates": list(spawn["p"]),
            "coordinate_type": "actor",
            "kind": "key",
            "opens_room": display_room(rooms[node]),
        })
    path.append({
        "symbol": "FilmReel",
        "symbol_name_zh": SYMBOL_ZH["FilmReel"],
        "room": film["room_display"],
        "actor": film["actor"],
        "coordinates": list(film["p"]),
        "coordinate_type": "actor",
        "kind": "film_reel",
    })

    return {
        "level": "PSA_MT01",
        "seed": level_seed,
        "salt": salt,
        "symbols_dropped": dropped,
        "symbols_unused": unused,
        "keys": keys,
        "rooms": tree,
        "film_reel": film,
        "film_node": film_node,
        "path": path,
        "shortest_path_names_zh": [SYMBOL_ZH[symbols[n]] for n in path_nodes] + ["录像盘"],
        "room_selection_trace": traces if trace else None,
    }


# ---------------------------------------------------------------------------
# 实测核对
# ---------------------------------------------------------------------------
SAMPLES = [
    (219219, {
        "root_symbol": "Eye",
        "rooms": {1: "RBRoom_ReelStorage", 2: "RBRoom_ShootingRange",
                  3: "RBRoom25_2", 4: "RBRoom6_6",
                  5: "RBRoom_ChiefOfficeSideRoom_22", 6: "RBRoom_ChiefOffice_27",
                  7: "RBRoom_DetectiveOffices03_50"},
        "spawners": {2: "PSA_MT01_KeySpawner_ClassRoom_1",
                     3: "PSA_MT01_KeySpawner_ClassRoom_2",
                     4: "PSA_MT01_KeySpawner_ShootingRange_2",
                     5: "PSA_MT01_KeySpawner_ShootingRange_1",
                     6: "PSA_MT01_KeySpawner_Basement_2",
                     7: "PSA_MT01_KeySpawner_Basement_1"},
        "film_actor": "DiaporamaWheel_LargeObject_BP9_5",
    }),
    (958958, {
        "root_symbol": "Heart",
        "rooms": {1: "RBRoom_ReelStorage", 2: "RBRoom_ShootingRange",
                  3: "RBRoom_Morgue_Master", 5: "RBRoom_Generator",
                  7: "RBRoom_ChiefOffice_27"},
        "spawners": {2: "PSA_MT01_KeySpawner_ClassRoom_2",
                     3: "PSA_MT01_KeySpawner_ClassRoom_1",
                     4: "PSA_MT01_KeySpawner_ShootingRange_2",
                     5: "PSA_MT01_KeySpawner_ShootingRange_1"},
        "film_actor": "DiaporamaWheel_LargeObject_BP7_18",
    }),
]


def selftest(verbose=True):
    bad = total = 0
    for seed, want in SAMPLES:
        res = predict(seed)
        checks = []
        checks.append(("根图案", res["keys"][0]["symbol"], want["root_symbol"]))
        for node, room in want["rooms"].items():
            checks.append(("节点%d房间" % node, res["rooms"][node - 1]["room"],
                           display_room(room)))
        for node, actor in want["spawners"].items():
            checks.append(("节点%d生成点" % node, res["keys"][node - 1]["pickup_actor"],
                           actor))
        checks.append(("录像盘", res["film_reel"]["actor"], want["film_actor"]))
        for name, got, expect in checks:
            total += 1
            ok = got == expect
            bad += 0 if ok else 1
            if verbose:
                print("  %-7d %-14s 预测=%-38s 实测=%-38s %s"
                      % (seed, name, got, expect, "OK" if ok else "MISMATCH"))
    print("自检：%d/%d 通过" % (total - bad, total))
    return bad == 0


# ---------------------------------------------------------------------------
def _print(result, tree=False, trace=False):
    print("PSA_MT01  seed=%d  salt=%d" % (result["seed"], result["salt"]))
    print("最短链: " + " -> ".join(result["shortest_path_names_zh"]))
    print("未用到的图案: %s（弃牌 %s）"
          % (", ".join(result["symbols_unused"]) or "无",
             ", ".join(result["symbols_dropped"])))
    print("\n录像盘：%s   %s   %s"
          % (result["film_reel"]["room_display"], result["film_reel"]["actor"],
             result["film_reel"]["p"]))
    print("\n钥匙点位（拿到钥匙的房间 -> 它打开的房间）:")
    for key in result["keys"]:
        print("  %-4s %-38s %-30s -> %s"
              % (key["symbol_name_zh"], key["pickup_actor"],
                 key["found_in_room"] or "起始区域", key["opens_room"]))
    if tree:
        print("\n7 节点树:")
        for room in result["rooms"]:
            contents = list(room["contained_keys"])
            if room["has_film_reel"]:
                contents.append("录像盘")
            print("  节点%d %-30s（%s）: %s"
                  % (room["node"], room["room"], room["door_symbol_name_zh"],
                     "，".join(contents) if contents else "空"))
    if trace:
        print("\n房间抽取 trace:")
        for entry in result["room_selection_trace"]:
            for att in entry["attempts"]:
                print("  node=%d parent=%-28s key=%-38s att=%2d seed=%d idx=%2d %-30s d=%.3f %s"
                      % (entry["node"], entry["parent_room"], entry["key_spawn"],
                         att["attempt"], att["seed"], att["index"], att["room"],
                         att["distance"],
                         "OK" if att["distance"] >= MIN_ROOM_DISTANCE else "reject"))


def main():
    ap = argparse.ArgumentParser(description=__doc__,
                                 formatter_class=argparse.RawDescriptionHelpFormatter)
    ap.add_argument("seed", nargs="?", type=int, help="关卡种子（6 位数）")
    ap.add_argument("--json", action="store_true", dest="as_json")
    ap.add_argument("--tree", action="store_true", help="打印完整 7 节点树")
    ap.add_argument("--trace", action="store_true", help="打印房间重抽过程")
    ap.add_argument("--spawners", action="store_true", help="打印 15 房 × 2 生成点")
    ap.add_argument("--selftest", action="store_true")
    args = ap.parse_args()

    if args.spawners:
        for room in sorted(ROOM_SPAWNERS, key=str.casefold):
            print("%-30s %s" % (display_room(room),
                                "  ".join("%s%s" % (item["actor"], item["p"])
                                          for item in ROOM_SPAWNERS[room])))
        return
    if args.selftest:
        raise SystemExit(0 if selftest() else 1)
    if args.seed is None:
        ap.print_help()
        return
    result = predict(args.seed, trace=args.trace)
    if args.as_json:
        print(json.dumps(result, ensure_ascii=False, indent=2))
    else:
        _print(result, tree=args.tree, trace=args.trace)


if __name__ == "__main__":
    main()
