# -*- coding: utf-8 -*-
"""PSB_MT01「警察局地下室 · 找钥匙把受试者送进粉碎机」seed 分析 CLI。

    python psb_mt01.py --sectors        # 3 个扇区：锁位 / 线索电视 / 尸体数 / 区域说明
    python psb_mt01.py --corpses        # 41 具尸体：池序号 / 扇区 / 房间 / 坐标
    python psb_mt01.py --corpses A      # 只看 A 区
    python psb_mt01.py --pool           # 10 个图案（QuestItemClasses 顺序 + 贴图 + 中文）
    python psb_mt01.py 565565           # ★ 该 seed：3 个区的钥匙图案 + 每区几具 / 什么图案
    python psb_mt01.py 565565 --json    # 机器可读
    python psb_mt01.py --known          # 实测样本回放
    python psb_mt01.py --selftest       # 静态自检（含 seed→图案 12/12）

✅ seed → 每区钥匙图案 **已闭环**（2026-10-30，见 PSB_MT01.md §5）：
   图案 = pool[ RandSeeded(0xCD055621 + 223551 + V + j, |pool|, salt=S%1000) ]，
   抽后保序删除；组序 A(3) → C(4) → B(3)，每组第 1 具就是本区钥匙。
   已用 111111 / 565565 / 378378 三条实测验证 12/12。

⚠️ 「钥匙图案落在哪一具尸体上」仍需一个未知量：三个候选组的初始顺序
   （由 sub_14361C230 开头那次 std::sort 决定，它用了随 seed 变化的伪随机数）。
   见 PSB_MT01.md §6：`--corpses` 给出该区的候选池与房间/坐标。
"""
import argparse
import json
import os
import sys

M32 = 0xFFFFFFFF
M64 = 0xFFFFFFFFFFFFFFFF


def _mix64(seed, salt):
    """sub_1402D29E0 / sub_1413F08D0 共用的 64 位混合（同 opp_seed/seedcore.py）。"""
    a = (0xBF58476D1CE4E5B9 * ((seed ^ (seed >> 30)) & M64)) & M64
    a ^= a >> 27
    g = (salt % 1000) & M64
    b = (0xBF58476D1CE4E5B9 * g) & M64
    b ^= b >> 27
    v5 = (((0x94D049BB133111EB * a) & M64) ^ ((0x94D049BB133111EB * b) & M64)) & M64
    t = (v5 ^ (v5 >> 31)) & M64
    v6 = (0xBF58476D1CE4E5B9 * (t ^ (t >> 30))) & M64
    u = (v6 ^ (v6 >> 27)) & M64
    v7 = (((321982955 * u) & M64) ^ (((0x94D049BB133111EB * u) & M64) >> 31)) & M64
    return v7 & M32


def rand_seeded(seed, n, salt=0):
    """sub_1402D29E0(seed, N) -> [0, N)。"""
    if not n or not seed:
        return 0
    return (_mix64(seed & M32, salt) & 0xFFFF) % n

_HERE = os.path.dirname(os.path.abspath(__file__))
if _HERE not in sys.path:
    sys.path.insert(0, _HERE)

import psb_mt01_static as S

POOL = list(S.QUEST_ITEM_CLASSES)
PATTERN_ZH = S.PATTERN_ZH

# ---------------------------------------------------------------------------
# seed → 图案（sub_14361C230 反编译 + 全 2^32 反解，唯一解）
# ---------------------------------------------------------------------------
B = 0xCD055621          # GetSeed(协调器) 经 sub_1402C30C0 写回后的值
OFF_KEY = 223551        # 0x14361c967  v123 = v143 + 223551
OFF_CORPSE = 243551     # 0x14361c95c  v120 = v143 + 243551
# 组序 + 每组条目数（DesiredCount=10 的分配）
GROUPS = [('A', 3), ('C', 4), ('B', 3)]

# 一局每区实际刷出的具数（玩家实测：1 具是本区图案的钥匙，其余是别的图案的干扰）
SPAWNED_PER_SECTOR = {'A': 3, 'B': 3, 'C': 4}

# 实测样本（release/home/test.txt）
#   'all' = 一局实际刷出来的尸体（sector, actor, 该尸体显示的图案）
SAMPLES = {
    378378: {
        'patterns': {'A': 'Moon', 'B': 'Fire', 'C': 'Spade'},
        'all': [
            ('A', 'CorpseSearch_PS_Trial02_AgainstWall_BP2_5', 'Heart'),
            ('A', 'CorpseSearch_PS_Trial02_BP3_8', 'Crown'),
            ('A', 'CorpseSearch_PS_Trial02_AgainstWall_BP_2', 'Moon'),
            ('B', 'CorpseSearch_PS_Trial02_Desk_BP_5', 'Diamond'),
            ('B', 'CorpseSearch_PS_Trial02_WallThroat_BP7_26', 'Fire'),
            ('B', 'CorpseSearch_PS_Trial02_Desk_BP2_2', 'Bunny'),
            ('C', 'CorpseSearch_PS_Trial02_BP7_2', 'Eye'),
            ('C', 'CorpseSearch_PS_Trial02_WallThroat_BP8_32', 'Spade'),
            ('C', 'CorpseSearch_PS_Trial02_OnChair_BP3_8', 'Club'),
        ],
    },
    565565: {
        'patterns': {'A': 'Heart', 'B': 'Club', 'C': 'Eye'},
        'all': [
            ('A', 'CorpseSearch_PS_Trial02_AgainstWall_BP3_8', 'Heart'),
            ('B', 'CorpseSearch_PS_Trial02_BP10_35', 'Club'),
            ('C', 'CorpseSearch_PS_Trial02_AgainstWall_BP9_2', 'Eye'),
            ('C', 'CorpseSearch_PS_Trial02_AgainstWall_BP5_2', 'Diamond'),
        ],
    },
    111111: {
        'patterns': {'A': 'Star', 'B': 'Bunny', 'C': 'Diamond'},
        'all': [],
    },
}

for _seed, _info in SAMPLES.items():
    _info['corpses'] = {s: a for s, a, p in _info['all'] if p == _info['patterns'][s]}
    _info['decoys'] = [(s, a, p) for s, a, p in _info['all'] if p != _info['patterns'][s]]


def _zh(p):
    return '%s(%s)' % (PATTERN_ZH.get(p, p), p)


def room_of(c):
    r = S.ROOMS.get(str(c['room']))
    return r[0] if r else '?'


def corpses_of(sector):
    return [c for c in S.CORPSES if c['sector'] == sector]


# ---------------------------------------------------------------------------
# 预测
# ---------------------------------------------------------------------------
def patterns_of(seed):
    """seed -> [(sector, [(j, 图案)])]，按抽取顺序；j==0 是本区钥匙。"""
    salt = seed % 1000
    pool = list(POOL)
    out = []
    V = 0
    for sec, cnt in GROUPS:
        rows = []
        for j in range(cnt):
            idx = rand_seeded((B + OFF_KEY + V + j) & M32, len(pool), salt)
            rows.append((j, pool.pop(idx)))
            V += 1
        out.append((sec, rows))
    return out


def key_patterns(seed):
    """seed -> {'A': 图案, 'B': 图案, 'C': 图案}。"""
    return {sec: rows[0][1] for sec, rows in patterns_of(seed)}


def predict(seed):
    """返回本局结构：3 个区的钥匙图案 + 每区刷出的图案清单。"""
    known = SAMPLES.get(seed)
    out = {'level': 'PSB_MT01', 'seed': seed, 'salt': seed % 1000, 'sectors': [],
           'pattern_solved': True,
           'spawned_per_sector': dict(SPAWNED_PER_SECTOR),
           'notes': ['seed → 每区钥匙图案 已闭环；图案落在哪具尸体上仍差「候选组初始顺序」，'
                     '见 PSB_MT01.md §6']}
    pats = patterns_of(seed)
    for s in S.SECTORS:
        sec = s['key']
        cand = corpses_of(sec)
        rows = dict(pats)[sec]
        item = {
            'sector': sec,
            'key_destination': s['kid'],
            'clue_tv': s['tv'],
            'pattern': rows[0][1],
            'pattern_zh': PATTERN_ZH.get(rows[0][1]),
            'spawned_patterns': [{'j': j, 'pattern': p, 'pattern_zh': PATTERN_ZH.get(p),
                                  'is_key': j == 0} for j, p in rows],
            'candidate_count': len(cand),
            'candidates': [{'i': c['i'], 'actor': c['actor'], 'room': room_of(c),
                            'room_zh': (S.ROOMS.get(str(c['room'])) or ['', ''])[1],
                            'p': c['p']} for c in cand],
        }
        if known:
            item['measured_pattern'] = known['patterns'].get(sec)
            item['verified_corpse'] = known['corpses'].get(sec)
            rows2 = [(a, p) for s2, a, p in known['all'] if s2 == sec]
            if rows2:
                by_actor = {c['actor']: c for c in S.CORPSES}
                item['spawned'] = [{'i': by_actor[a]['i'], 'actor': a,
                                    'room': room_of(by_actor[a]),
                                    'p': by_actor[a]['p'], 'pattern': p}
                                   for a, p in rows2]
        out['sectors'].append(item)
    return out


def render(res):
    lines = ['PSB_MT01  警察局地下室 · 找钥匙把受试者送进粉碎机',
             'seed = %d   salt = %d' % (res['seed'], res['salt'])]
    for n in res['notes']:
        lines.append('! ' + n)
    for item in res['sectors']:
        pat = item['pattern']
        lines.append('')
        lines.append('Sector %s   锁位 %s   线索电视 %s'
                     % (item['sector'], item['key_destination'], item['clue_tv']))
        if item.get('measured_pattern') and item['measured_pattern'] != pat:
            lines.append('   ★★ 钥匙图案：%s   —— 与实测 %s 不符！'
                         % (_zh(pat), _zh(item['measured_pattern'])))
        elif item.get('measured_pattern'):
            lines.append('   钥匙图案：%s   ← 已实测验证' % _zh(pat))
        else:
            lines.append('   钥匙图案：%s' % _zh(pat))
        lines.append('   本局该区 %d 具，身上的图案依次是：'
                     % len(item['spawned_patterns']))
        for r in item['spawned_patterns']:
            lines.append('     %s 第%d具  %s' % ('★钥匙' if r['is_key'] else '  干扰',
                                                 r['j'] + 1, _zh(r['pattern'])))
        spawn = item.get('spawned')
        if spawn:
            lines.append('   实测到的尸体：')
            for c in spawn:
                mark = '★真' if c['pattern'] == pat else ' 假'
                lines.append('     %s #%-2d %-46s %-38s 显示 %s'
                             % (mark, c['i'], c['actor'], c['room'], _zh(c['pattern'])))
        lines.append('   候选池 %d 具（`--corpses %s` 看全表）：'
                     % (item['candidate_count'], item['sector']))
    return '\n'.join(lines)


# ---------------------------------------------------------------------------
# CLI
# ---------------------------------------------------------------------------
def cmd_sectors():
    print('PSB_MT01  警察局地下室')
    for z in S.ZONES:
        print('\n%s：%s' % (z['id'], (z.get('name_zh') or '').strip()))
        if z.get('note_zh'):
            print('   ' + z['note_zh'].strip())
    print('\n%-8s %-40s %-28s %s' % ('Sector', '钥匙锁位', '线索电视', '尸体数'))
    for s in S.SECTORS:
        print('%-8s %-40s %-28s %d'
              % (s['key'], s['kid'], s['tv'], len(corpses_of(s['key']))))


def cmd_corpses(sector=None):
    print('%-4s %-7s %-46s %-40s %s' % ('#', 'Sector', 'actor', '房间', '坐标'))
    for c in S.CORPSES:
        if sector and c['sector'] != sector:
            continue
        print('%-4d %-7s %-46s %-40s %s'
              % (c['i'], c['sector'], c['actor'], room_of(c), c['p']))


def cmd_find(pat):
    """按房间名 / 尸体名 模糊查候选（实测记录 → 候选人序号 的桥梁）。"""
    key = pat.lower()
    rows = []
    for c in S.CORPSES:
        room = S.ROOMS.get(str(c['room'])) or ['', '']
        hay = ' '.join([c['actor'], room[0], room[1] or '']).lower()
        if key in hay:
            rows.append(c)
    if not rows:
        print('没有匹配「%s」的候选尸体' % pat)
        return 1
    print('%-4s %-7s %-46s %-40s %-22s %s'
          % ('#', 'Sector', 'actor', '房间', '房间中文', '坐标'))
    for c in rows:
        room = S.ROOMS.get(str(c['room'])) or ['', '']
        print('%-4d %-7s %-46s %-40s %-22s %s'
              % (c['i'], c['sector'], c['actor'], room[0], room[1], c['p']))
    return 0


def cmd_pool():
    print('QuestItemClasses（池顺序，保序删除；# = 抽取下标）')
    for i, p in enumerate(POOL):
        print('  %2d  %-10s %-6s %s' % (i, p, PATTERN_ZH.get(p, ''),
                                        S.PATTERN_TEXTURE.get(p, '')))
    print('')
    print('每区刷出 %d 具（A/B 各 3，C 有 4），全局 10 具；'
          '图案从这 10 个里抽，抽走即删（保序），因此互不重复'
          % (3,))
    print('   （0x14361CA7C 抽图案 + 0x14361CA8D RemoveAt；0x14361CA55 抽尸体 + RemoveAt）')


def cmd_known():
    for seed in sorted(SAMPLES):
        print('--- seed %d' % seed)
        print(render(predict(seed)))
        print('')


def selftest():
    bad = 0
    total = 0

    def check(label, ok):
        nonlocal bad, total
        total += 1
        bad += 0 if ok else 1
        print('  %-44s %s' % (label, 'OK' if ok else 'FAIL'))

    check('41 具尸体', len(S.CORPSES) == 41)
    for sec, n in (('A', 15), ('B', 10), ('C', 16)):
        check('Sector %s 尸体数 = %d' % (sec, n), len(corpses_of(sec)) == n)

    facts = [
        ('CorpseSearch_PS_Trial02_AgainstWall_BP3_8', 'RBRoom_GarageBoilerCorridor'),
        ('CorpseSearch_PS_Trial02_BP10_35', 'RBRoom_Maintenance'),
        ('CorpseSearch_PS_Trial02_AgainstWall_BP9_2', 'RBRoom_Construction'),
        ('CorpseSearch_PS_Trial02_AgainstWall_BP5_2', 'RBRoom_ShootingRangeMaintenance_Slave03'),
        # 378378 的 9 具（玩家逐具记录）
        ('CorpseSearch_PS_Trial02_AgainstWall_BP2_5', 'RBRoom_TireStorage'),
        ('CorpseSearch_PS_Trial02_BP3_8', 'RBRoom_GarageStorage_Master'),
        ('CorpseSearch_PS_Trial02_AgainstWall_BP_2', 'RBRoom_GarageMain_Master'),
        ('CorpseSearch_PS_Trial02_Desk_BP_5', 'RBRoom_Morgue_Master'),
        ('CorpseSearch_PS_Trial02_WallThroat_BP7_26', 'RBRoom_MorgueStairs'),
        ('CorpseSearch_PS_Trial02_Desk_BP2_2', 'RBRoom_MainStairs'),
        ('CorpseSearch_PS_Trial02_BP7_2', 'RBRoom_Construction'),
        ('CorpseSearch_PS_Trial02_WallThroat_BP8_32', 'RBRoom_ShootingRange'),
        ('CorpseSearch_PS_Trial02_OnChair_BP3_8', 'RBRoom_Archives01_Master'),
    ]
    by_actor = {c['actor']: c for c in S.CORPSES}
    for actor, room in facts:
        c = by_actor.get(actor)
        check('房间核对 %-34s' % actor.replace('CorpseSearch_PS_Trial02_', ''),
              bool(c) and room_of(c) == room)

    check('A/B/C ↔ KID 顺序',
          [s['kid'] for s in S.SECTORS] == ['KeyItemDestination_Device_Base_BP2',
                                            'KeyItemDestination_Device_Base_BP3',
                                            'KeyItemDestination_Device_Base_BP_2'])
    check('图案池 10 个且无 Plain', len(POOL) == 10 and len(set(POOL)) == 10 and 'Plain' not in POOL)

    for seed, info in SAMPLES.items():
        for sec, actor in info['corpses'].items():
            c = by_actor.get(actor)
            check('%d Sector %s 钥匙尸体扇区' % (seed, sec), bool(c) and c['sector'] == sec)

    # 378378：每区 3 具、图案 9 个互不相同、每区恰好 1 具等于本区图案
    info = SAMPLES[378378]
    spawn = info['all']
    check('378378 一局 9 具', len(spawn) == 9)
    check('378378 九具图案互不相同', len({p for _, _, p in spawn}) == 9)
    for sec in 'ABC':
        rows = [p for s, _, p in spawn if s == sec]
        check('378378 Sector %s 3 具且恰 1 真' % sec,
              len(rows) == 3 and rows.count(info['patterns'][sec]) == 1)
    for s, actor, _ in spawn:
        c = by_actor.get(actor)
        check('378378 扇区归属 %-24s' % actor.replace('CorpseSearch_PS_Trial02_', ''),
              bool(c) and c['sector'] == s)

    # ★ seed → 每区钥匙图案（3 条实测 × 3 区 = 9 条）
    for seed, info in sorted(SAMPLES.items()):
        got = key_patterns(seed)
        for sec in 'ABC':
            want = info['patterns'][sec]
            check('%d Sector %s 钥匙图案 = %s' % (seed, sec, PATTERN_ZH.get(want, want)),
                  got[sec] == want)
    # 378378 每区**实测出现过的**图案 ⊆ 模型算出的该区图案集合
    sim = {sec: {p for _, p in rows} for sec, rows in patterns_of(378378)}
    for sec in 'ABC':
        obs = {p for s2, _, p in SAMPLES[378378]['all'] if s2 == sec}
        check('378378 Sector %s 图案集合吻合（%d 个）' % (sec, len(obs)),
              bool(obs) and obs <= sim[sec])

    print('自检：%d/%d 通过' % (total - bad, total))
    return bad == 0


def main(argv=None):
    ap = argparse.ArgumentParser(description='PSB_MT01 seed 分析')
    ap.add_argument('seed', nargs='?', type=int)
    ap.add_argument('--sectors', action='store_true', help='3 个扇区')
    ap.add_argument('--corpses', nargs='?', const='', metavar='A|B|C', help='41 具尸体')
    ap.add_argument('--pool', action='store_true', help='10 个图案')
    ap.add_argument('--find', metavar='TEXT', help='按房间名/尸体名模糊查候选')
    ap.add_argument('--known', action='store_true', help='实测样本回放')
    ap.add_argument('--selftest', action='store_true', help='静态自检')
    ap.add_argument('--json', action='store_true', help='机器可读')
    args = ap.parse_args(argv)
    try:
        sys.stdout.reconfigure(encoding='utf-8')
    except Exception:
        pass

    if args.selftest:
        return 0 if selftest() else 1
    if args.sectors:
        cmd_sectors()
        return 0
    if args.corpses is not None:
        cmd_corpses(args.corpses.strip().upper() or None)
        return 0
    if args.pool:
        cmd_pool()
        return 0
    if args.find:
        return cmd_find(args.find)
    if args.known:
        cmd_known()
        return 0
    if args.seed is None:
        ap.print_help()
        return 2
    res = predict(args.seed)
    print(json.dumps(res, ensure_ascii=False, indent=2) if args.json else render(res))
    return 0


if __name__ == '__main__':
    sys.exit(main())
