# -*- coding: utf-8 -*-
"""DTS_MT01「用线索找出正确的人体模型并搬回」—— 关卡种子 → 本局数据。

地图：DowntownRiotSewers（关卡资产 DRS_MT01_B00 / _B01，文本里的 trial 名是 DTS_MT01）

能算的：
    固定第 1 个调频器（起点 PolicePlanque）+ 随机池 19 个候选的房间/坐标
    随机抽取算法（REA→IDA 反编译）：
        seed = |crc("Objective Actors") + GetSeed(DRS_MT01_Frequency_ObjCoord_BP2)|
        连抽 3 个：idx = RandSeeded(seed + k, 池大小)，RemoveAtSwap
    ⚠ 池序未闭环：名称序+3-循环修正在 3 样本 3/3，第 4 样本（197197）2/3，
      且已排除全部静态池序/常见形状（见 DTS_MT01.md §4）
    已知目标模型坐标可查（--mannequins）；836836 实测目标 Scythe_BP13_2@(6044.1,7952.1,-335)
目标人体模型（线索四条：性别/字母/数字/房间）：
    性别固定 Women；字母+数字 = 武器编码（A1..B3 ↔ 6 武器枚举，字母=idx//3、数字=idx%3+1）；
    房间线索 = 区域显示名（IRISH PUB 等，一个区域含多个实际房间）；
    启用集内 (区域,武器) 唯一 ⇒ 线索组合唯一确定人偶。
    「seed→区域」候选模型（先武器后区域，3/3 但未验证，见 DTS_MT01.md §4）；
    「30 启用」抽取已闭环（base 0x90FB6FBF swap-remove 连抽 30，3/3）。

用法：
    python dts_mt01.py 252252                 # 调频器 + 区域/武器/人偶预测 + 30 启用
    python dts_mt01.py 252252 --json
    python dts_mt01.py --samples              # 3 样本回归
    python dts_mt01.py --regions              # 区域×武器矩阵
    python dts_mt01.py --panels               # 调频器候选池
    python dts_mt01.py --mannequins           # 84 人偶（区域/武器/坐标）
"""
import argparse
import json
import math
import os
import sys

M32 = 0xFFFFFFFF
M64 = 0xFFFFFFFFFFFFFFFF

LEVEL_OBJECT = 'PersistentLevel'

# 关卡对象（DRS_MT01_B00.json）
FIXED_COORD = 'DRS_MT01_Frequency_ObjCoord_FirstOne'
MAIN_COORD = 'DRS_MT01_Frequency_ObjCoord_BP2'
DELIVER_COORD = 'DRS_MT01_GatherAndDeliver_Mannequin_ObjCoord_BP'

# 反编译出来的盐：sub_1402AE7F0（面板协调器随机化入口）构造 L"Objective Actors"
# （.rdata 0x14665E254）传给 sub_1402B0070 → sub_1402B05C0。
# 旧文档 §5 写的 L"Operatable"（sub_14361A4E0 的另一条入口）实测对不上，已弃用。
SALT_NAME = 'Objective Actors'
SALT_NAME_OPERATABLE = SALT_NAME   # 兼容旧引用
# sub_1402C30C0（BuildObjectiveRandomizationGroups）只把 seed 指针 ++，每次一组
GROUP_SEED_STEP = 1
DIST_SAME_OBJECTIVES = 1000.0
# FrequencyMatchPanel_ObjCoord_BP.PrimaryActorsRandomizationSetup.DesiredStateCount.MaxCount
# ⚠ 实测（1P 的三条样本）都是 3 个随机面板 ⇒ 这些 MaxCount 并没有真的夹住 DesiredCount。
MAX_COUNT_BY_PLAYERS = {1: 3, 2: 3, 3: 3}

# 抽取池顺序：sub_1402B46B0 按「类名 + 全路径」大小写不敏感升序排 19 个候选。
# 名称序（Child10_14 … Child9_26）+ 实测 3-循环修正：
#   位置 2/5/6 = Child16_2 / Child12_11 / Child15_8（名称序是 12_11/15_8/16_2）。
# 3-循环来自 3 样本反解（8 个位置被钉死），成因未明（Outer/Template/比较表均同）。
# 对新 seed 的预测依赖这 11 个未钉死位置取名称序——命中率预期高但非实锤。
PANEL_POOL_ORDER = [
    'Child10_14', 'Child11_37', 'Child16_2', 'Child13_2', 'Child14_5',
    'Child12_11', 'Child15_8', 'Child17_2', 'Child18_5', 'Child19_8',
    'Child20_14', 'Child21_17', 'Child22', 'Child23', 'Child2_5',
    'Child4_2', 'Child5_5', 'Child6_8', 'Child9_26',
]

_HERE = os.path.dirname(os.path.abspath(__file__))
_ROOT = os.path.dirname(os.path.dirname(_HERE))
LEVEL_JSON = os.path.join(_ROOT, 'pak', 'OPP', 'Content', 'Maps_json',
                          'DowntownRiotSewers', 'DRS_MT01_B00.json')
ROOMS_JSON = os.path.join(_ROOT, 'pak', 'OPP', 'Content', 'Maps_json',
                          'DowntownRiotSewers', 'DRS_01_LD_Rooms.json')

# ---------------------------------------------------------------------------
# 随机原语（与 release/seed/seedcore.py 同源）
# ---------------------------------------------------------------------------
_CRC_TAB = []
for _i in range(256):
    _c = _i
    for _ in range(8):
        _c = ((_c >> 1) ^ 0xEDB88320) if (_c & 1) else (_c >> 1)
    _CRC_TAB.append(_c & M32)


def crc32_fname(name):
    """FName / 宽串 CRC32：每个 16 位字符走 4 步 [lo, hi, 0, 0]。"""
    crc = M32
    for ch in name:
        u = ord(ch) & 0xFFFF
        crc = _CRC_TAB[(crc ^ (u & 0xFF)) & 0xFF] ^ (crc >> 8)
        crc = _CRC_TAB[(crc ^ (u >> 8)) & 0xFF] ^ (crc >> 8)
        crc = _CRC_TAB[crc & 0xFF] ^ (crc >> 8)
        crc = _CRC_TAB[crc & 0xFF] ^ (crc >> 8)
    return (~crc) & M32


def seed_of_object(name, outer_seed=0):
    """GetSeed 的名字分支：||crc(name) + seed(outer)||。"""
    v = (crc32_fname(name) + outer_seed) & M32
    return v if v < 0x80000000 else (0x100000000 - v) & M32


def _mix64(seed, salt):
    a = (0xBF58476D1CE4E5B9 * ((seed ^ (seed >> 30)) & M64)) & M64
    a ^= a >> 27
    g = (salt % 1000) & M64
    b = (0xBF58476D1CE4E5B9 * g) & M64
    b ^= b >> 27
    v5 = (((0x94D049BB133111EB * a) & M64) ^
          ((0x94D049BB133111EB * b) & M64)) & M64
    t = (v5 ^ (v5 >> 31)) & M64
    v6 = (0xBF58476D1CE4E5B9 * (t ^ (t >> 30))) & M64
    u = (v6 ^ (v6 >> 27)) & M64
    v7 = (((321982955 * u) & M64) ^
          (((0x94D049BB133111EB * u) & M64) >> 31)) & M64
    return v7 & M32


def rand_seeded(seed, n, salt=0):
    """sub_1402D29E0：返回 [0, N)；salt 传关卡种子（内部只取 %1000）。"""
    if not n or not seed:
        return 0
    return (_mix64(seed & M32, salt) & 0xFFFF) % n


# ---------------------------------------------------------------------------
# 静态数据：房间 / 面板 / 协调器 / 人体模型
# ---------------------------------------------------------------------------
def _load(path):
    with open(path, encoding='utf-8') as fp:
        return json.load(fp)


def _vec(d):
    if not d:
        return (0.0, 0.0, 0.0)
    return (float(d.get('X', 0.0)), float(d.get('Y', 0.0)), float(d.get('Z', 0.0)))


def _inner_path(objname):
    """ObjectName'Outer:Path:PersistentLevel.Actor.Component' → ['PersistentLevel','Actor','Component']"""
    if not objname:
        return []
    s = objname
    if "'" in s:
        s = s.split("'", 1)[1]
    if s.endswith("'"):
        s = s[:-1]
    if ':' in s:
        s = s.split(':', 1)[1]
    return [x for x in s.split('.') if x]


class World(object):
    """DRS_MT01 的静态世界：房间 AABB、调频面板、人体模型出生点。"""

    def __init__(self):
        self.objs = _load(LEVEL_JSON)
        self.rooms = self._load_rooms()
        self.coords = self._load_coords()
        self.panels = self._load_panels()
        self.mannequins = self._load_mannequins()

    # -- 房间 ------------------------------------------------------------
    def _load_rooms(self):
        data = _load(ROOMS_JSON)
        body = {}
        for o in data:
            if o.get('Type') == 'BodySetup':
                path = _inner_path((o.get('Outer') or {}).get('ObjectName'))
                key = path[1] if len(path) > 1 else ''
                elems = ((o.get('Properties') or {}).get('AggGeom') or {}).get('ConvexElems') or []
                if elems:
                    body[key] = [e.get('ElemBox') for e in elems if e.get('ElemBox')]
        brush = {}
        for o in data:
            if o.get('Type') == 'BrushComponent':
                path = _inner_path((o.get('Outer') or {}).get('ObjectName'))
                key = path[1] if len(path) > 1 else ''
                p = o.get('Properties') or {}
                brush[key] = (_vec(p.get('RelativeLocation')),
                              _vec(p.get('RelativeScale3D')) if p.get('RelativeScale3D') else (1.0, 1.0, 1.0))
        rooms = []
        for o in data:
            if o.get('Type') != 'RBRoom':
                continue
            name = o.get('Name')
            p = o.get('Properties') or {}
            disp = p.get('GameplayDisplayName') or {}
            boxes = body.get(name) or []
            loc, scl = brush.get(name, ((0.0, 0.0, 0.0), (1.0, 1.0, 1.0)))
            aabbs = []
            for box in boxes:
                bmin, bmax = _vec(box.get('Min')), _vec(box.get('Max'))
                lo = tuple(loc[i] + bmin[i] * scl[i] for i in range(3))
                hi = tuple(loc[i] + bmax[i] * scl[i] for i in range(3))
                lo, hi = (tuple(min(a, b) for a, b in zip(lo, hi)),
                          tuple(max(a, b) for a, b in zip(lo, hi)))
                aabbs.append((lo, hi))
            if not aabbs:
                continue
            lo = tuple(min(a[0][i] for a in aabbs) for i in range(3))
            hi = tuple(max(a[1][i] for a in aabbs) for i in range(3))
            rooms.append({
                'name': name,
                'display': disp.get('SourceString') or p.get('GameplayId') or name,
                'gameplay_id': p.get('GameplayId'),
                'size': p.get('RoomSize'),
                'lo': lo, 'hi': hi, 'aabbs': aabbs,
                'volume': (hi[0] - lo[0]) * (hi[1] - lo[1]) * (hi[2] - lo[2]),
            })
        return rooms

    def rooms_at(self, pos, tol=1.0):
        out = []
        for r in self.rooms:
            for lo, hi in r['aabbs']:
                if (lo[0] - tol <= pos[0] <= hi[0] + tol and
                        lo[1] - tol <= pos[1] <= hi[1] + tol and
                        lo[2] - tol <= pos[2] <= hi[2] + tol):
                    out.append(r)
                    break
        if not out:                                   # 退化为 2D（有些房间 z 跨度不含面板高度）
            for r in self.rooms:
                for lo, hi in r['aabbs']:
                    if (lo[0] - tol <= pos[0] <= hi[0] + tol and
                            lo[1] - tol <= pos[1] <= hi[1] + tol):
                        out.append(r)
                        break
        return out

    def room_names(self, pos):
        rs = self.rooms_at(pos)
        if not rs:
            return ['?']
        rs.sort(key=lambda r: r['volume'])
        return [r['name'] for r in rs]

    def room_displays(self, pos):
        rs = self.rooms_at(pos)
        if not rs:
            return ['?']
        rs.sort(key=lambda r: r['volume'])
        seen, out = set(), []
        for r in rs:
            if r['display'] not in seen:
                seen.add(r['display'])
                out.append(r['display'])
        return out

    # -- 面板 ------------------------------------------------------------
    def _actor_pos(self, name):
        for o in self.objs:
            if o.get('Type') != 'SceneComponent' or o.get('Name') != 'SceneComp':
                continue
            path = _inner_path((o.get('Outer') or {}).get('ObjectName'))
            if len(path) > 1 and path[1] == name:
                return _vec((o.get('Properties') or {}).get('RelativeLocation'))
        return None

    def _load_panels(self):
        out = []
        for o in self.objs:
            if o.get('Type') != 'FrequencyMatchPanel_DTS_Child_C':
                continue
            pos = self._actor_pos(o.get('Name'))
            if pos is None:
                continue
            out.append({'name': o.get('Name'), 'pos': pos})
        for p in out:
            p['rooms'] = self.room_names(p['pos'])
            p['room_display'] = self.room_displays(p['pos'])
        items = (self.coords.get(MAIN_COORD) or {}).get('ObjectiveActors') or []
        seq = [a['SubPathString'].split('.')[-1] for a in items]
        order = {n: i for i, n in enumerate(seq)}
        out.sort(key=lambda p: order.get(p['name'], 999))
        return out

    def _load_coords(self):
        out = {}
        for o in self.objs:
            n = o.get('Name') or ''
            if n in (FIXED_COORD, MAIN_COORD, DELIVER_COORD):
                out[n] = o.get('Properties') or {}
        return out

    def candidates(self):
        """BP2 的 ObjectiveActors 顺序（19 个）。"""
        items = (self.coords.get(MAIN_COORD) or {}).get('ObjectiveActors') or []
        names = [a['SubPathString'].split('.')[-1] for a in items]
        by = {p['name']: p for p in self.panels}
        return [by[n] for n in names if n in by]

    def fixed_panel(self):
        items = (self.coords.get(FIXED_COORD) or {}).get('ObjectiveActors') or []
        names = [a['SubPathString'].split('.')[-1] for a in items]
        by = {p['name']: p for p in self.panels}
        return by.get(names[0]) if names else None

    def desired_count(self):
        setup = (self.coords.get(MAIN_COORD) or {}).get('PrimaryActorsRandomizationSetup') or {}
        return int(((setup.get('DesiredCount') or {}).get('DefaultValues') or {}).get('NormalLocalValue', 3))

    # -- 人体模型 / 武器 --------------------------------------------------
    def _load_mannequins(self):
        out = []
        for o in self.objs:
            t = o.get('Type') or ''
            if 'ManneqinSetup' not in t:
                continue
            pos = self._actor_pos(o.get('Name'))
            weapon = t.replace('DTR_MT01_ManneqinSetup_', '').replace('_BP_C', '')
            out.append({'name': o.get('Name'), 'weapon': weapon, 'pos': pos or (0.0, 0.0, 0.0)})
        for m in out:
            m['rooms'] = self.room_names(m['pos'])
            m['room_display'] = self.room_displays(m['pos'])
        out.sort(key=lambda m: (m['weapon'], m['name']))
        return out


def room_groups(world):
    """RBRoomGroup_MT01_* → 房间名集合（“房间组”，潜在的分组键）。"""
    out = {}
    for o in world.objs:
        if o.get('Type') != 'RBRoomGroup':
            continue
        p = o.get('Properties') or {}
        rooms = set()
        for r in p.get('Rooms') or []:
            rooms.add(r['SubPathString'].split('.')[-1])
        out[o.get('Name')] = rooms
    return out


# ---------------------------------------------------------------------------
# 抽取：sub_14361A4E0 → sub_143617580 → sub_1402B05C0 → sub_1402C30C0
# ---------------------------------------------------------------------------
def objective_seed(coordinator, level_seed):
    """seed = |crc("Objective Actors") + GetSeed(协调器)|（32 位环绕）。

    链路：sub_1402AE7F0 构造 L"Objective Actors" → sub_1402B0070 →
    sub_1402B05C0 的 `v240 = crc32(name) + GetSeed(coord)`（0x1402B163E 附近）。
    """
    gs = seed_of_object(coordinator, crc32_fname(LEVEL_OBJECT))
    return (crc32_fname(SALT_NAME) + gs) & M32, gs


def _group_key(panel, world, model, groups):
    if model == 'single':
        return 'all'
    if model == 'roomgroup':
        for gname, rooms in groups.items():
            # 取“最具体”的房间（坐标命中的房间中体积最小的）判断所属房间组
            for rn in panel['rooms']:
                if rn in rooms:
                    return gname
        return 'unknown'
    return 'all'


def build_groups(panels, world, model, groups):
    """按 GetObjectiveTypeIndex 的分组（用静态代理键近似），保持首次出现顺序。"""
    order, buckets = [], {}
    for p in panels:
        k = _group_key(p, world, model, groups)
        if k not in buckets:
            buckets[k] = []
            order.append(k)
        buckets[k].append(p)
    return [buckets[k] for k in order]


def select_panels(level_seed, world, model='single', count=None, players=4,
                  dist=DIST_SAME_OBJECTIVES, trace=False):
    """返回 (选中列表, 细节 dict)。

    2026-10-31 修正版（3 样本 3/3）：池 = PANEL_POOL_ORDER，
    连抽 3 个 swap-remove，种子 = seed + k（k = 已选数，见 0x1402B05C0 抽取环）。
    model='roomgroup' 是旧分组假设，仅供对照，不再参与默认预测。
    """
    salt = level_seed % 1000
    if count is None:
        # 实测 1P 也是 3 个随机面板（DesiredCount=3，MaxCount 未夹住）
        count = world.desired_count()
    seed, gs = objective_seed(MAIN_COORD, level_seed)
    by = {p['name'].replace('FrequencyMatchPanel_DTS_', ''): p
          for p in world.candidates()}
    pool = [by[n] for n in PANEL_POOL_ORDER if n in by]

    picked = []
    for k in range(count):
        idx = rand_seeded((seed + k) & M32, len(pool), salt)
        cand = pool[idx]
        pool[idx] = pool[-1]
        pool.pop()
        picked.append(cand)
        if trace:
            print('    pick %-34s (idx=%d, k=%d, pool=%d)'
                  % (cand['name'], idx, k, len(pool) + 1))

    info = {
        'seed': seed, 'coord_seed': gs, 'salt': salt,
        'model': model + ('' if model == 'single' else '（旧假设，仅供对照）'),
        'count': count,
        'pool_order': PANEL_POOL_ORDER,
        'groups': [{'key': 'all', 'size': len(pool) + len(picked),
                    'members': PANEL_POOL_ORDER}],
        'rejected': [],
    }
    return picked, info


def mannequin_seed(level_seed):
    """人体模型阶段的盐是 L"Large Objects"（sub_1437B67A0 → xmmword_146656762）。"""
    gs = seed_of_object(DELIVER_COORD, crc32_fname(LEVEL_OBJECT))
    return (crc32_fname('Large Objects') + gs) & M32, gs


WPN_ENUM = ['Chainsaw', 'FaceDrill', 'HandDrill', 'Paddle', 'Scythe', 'Whip']


def region_matrix(world):
    """区域(显示名) → 武器 → 人偶名列表。区域内同武器可有多个静态人偶（启用时去重）。"""
    out = {}
    for m in world.mannequins:
        for rd in m['room_display']:
            out.setdefault(rd, {}).setdefault(m['weapon'], []).append(m['name'])
    return out


def enabled30(level_seed, world):
    """「30 启用」抽取（已验证 3/3）：84 名称序 swap-remove 连抽 30，salt=seed%1000。"""
    names = sorted(m['name'] for m in world.mannequins)
    gs = seed_of_object(DELIVER_COORD, crc32_fname(LEVEL_OBJECT))
    base = (crc32_fname('Large Objects') + gs) & M32
    salt = level_seed % 1000
    pool = list(names)
    out = []
    for k in range(30):
        idx = rand_seeded((base + k) & M32, len(pool), salt)
        out.append(pool[idx])
        pool[idx] = pool[-1]
        pool.pop()
    return out


def region_stage(level_seed, world):
    """「seed→区域→武器→人偶」候选模型（S2 先武器后区域；3/3 但未验证，md §4）。

    weapon = WPN_ENUM[rand_seeded(base+23, 6, salt)]
    region = 持枪区域池（武器种数降序/名称升序）[rand_seeded(base+24, n, salt)]
    目标 = 该 (区域, 武器) 的启用人偶（区域内同武器唯一）。
    """
    gs = seed_of_object(DELIVER_COORD, crc32_fname(LEVEL_OBJECT))
    base = (crc32_fname('ClueRooms') + gs) & M32
    salt = level_seed % 1000
    matrix = region_matrix(world)
    regions = sorted(matrix, key=lambda r: (-len(matrix[r]), r))
    weapon = WPN_ENUM[rand_seeded((base + 23) & M32, 6, salt)]
    rpool = [r for r in regions if weapon in matrix[r]]
    region = rpool[rand_seeded((base + 24) & M32, len(rpool), salt)] if rpool else '?'
    cands = sorted(matrix.get(region, {}).get(weapon, []))
    en = enabled30(level_seed, world)
    widx = WPN_ENUM.index(weapon) if weapon in WPN_ENUM else -1
    return {
        'verified': False,
        'model': 'S2 先武器后区域（候选，见 DTS_MT01.md §4）',
        'base': base,
        'weapon': weapon,
        'weapon_code': ('%s%d' % ('AB'[widx // 3], widx % 3 + 1)) if widx >= 0 else '?',
        'region': region,
        'region_pool': rpool,
        'candidates_static': cands,
        'candidates_enabled': [n for n in cands if n in en],
    }


# ---------------------------------------------------------------------------
# 输出
# ---------------------------------------------------------------------------
def _fmt_pos(p):
    return '(%7.1f,%7.1f,%6.1f)' % p


def describe_panels(world):
    lines = []
    fixed = world.fixed_panel()
    lines.append('固定第 1 个（FirstOne 协调器，写死）：')
    if fixed:
        lines.append('  %-34s %s  %s' % (fixed['name'], _fmt_pos(fixed['pos']),
                                         ' / '.join(fixed['rooms'])))
        lines.append('  显示名：%s' % ' / '.join(fixed['room_display']))
    lines.append('随机池 %d 个（BP2 的 ObjectiveActors 顺序，DesiredCount=%d，同目标最小间距 %.0f）：'
                 % (len(world.candidates()), world.desired_count(), DIST_SAME_OBJECTIVES))
    for i, p in enumerate(world.candidates()):
        lines.append('  [%2d] %-34s %s  %-46s %s'
                     % (i, p['name'].replace('FrequencyMatchPanel_DTS_', ''),
                        _fmt_pos(p['pos']), '/'.join(p['rooms']),
                        '/'.join(p['room_display'])))
    return lines


def describe_mannequins(world):
    lines = []
    by = {}
    for m in world.mannequins:
        by.setdefault(m['weapon'], []).append(m)
    lines.append('人体模型 / 武器出生点：%d 个（6 种武器）' % len(world.mannequins))
    setup = (world.coords.get(DELIVER_COORD) or {}).get('LargePickupActorsRandomizationSetup') or {}
    want = ((setup.get('DesiredCount') or {}).get('DefaultValues') or {}).get('NormalLocalValue')
    trapped = ((world.coords.get(DELIVER_COORD) or {}).get('NumberOfTrappedPickups') or {})
    trapped = ((trapped.get('DefaultValues') or {}).get('NormalLocalValue'))
    lines.append('  本局随机出现 %s 个，其中 %s 个是陷阱（LargePickupActorsRandomizationSetup）'
                 % (want, trapped))
    for w in sorted(by):
        lines.append('  %-10s x%d' % (w, len(by[w])))
        for m in by[w]:
            lines.append('      %-38s %s  %s'
                         % (m['name'], _fmt_pos(m['pos']), '/'.join(m['rooms'])))
    return lines


def describe_regions(world):
    """区域×武器矩阵（区域内同武器重复格标出）。"""
    matrix = region_matrix(world)
    lines = ['区域×武器矩阵：%d 个区域（重复 = 静态同格多人偶，启用时去重）' % len(matrix)]
    for r in sorted(matrix):
        wpns = matrix[r]
        dup = {w: v for w, v in wpns.items() if len(v) > 1}
        lines.append('  %-28s 武器%d种 人偶%d  重复:%s'
                     % (r, len(wpns), sum(len(v) for v in wpns.values()),
                        ', '.join('%s x%d' % (w, len(v)) for w, v in sorted(dup.items()))
                        if dup else '-'))
        for w in WPN_ENUM:
            if w in wpns:
                lines.append('      %-10s %s' % (w, ' | '.join(
                    n.split('Setup_')[-1] for n in sorted(wpns[w]))))
    return lines


def predict(level_seed, model='single', players=4, with_alt=True):
    world = World()
    fixed = world.fixed_panel()
    picked, info = select_panels(level_seed, world, model, players=players)
    alt = None
    if with_alt:
        other = 'roomgroup' if model == 'single' else 'single'
        alt_picked, alt_info = select_panels(level_seed, world, other, players=players)
        alt = {'model': alt_info,
               'panels': [{'name': p['name'], 'pos': p['pos'], 'rooms': p['rooms'],
                           'display': p['room_display']} for p in alt_picked]}
    return {
        'level': 'DTS_MT01',
        'seed': level_seed,
        'salt': level_seed % 1000,
        'coordinator': MAIN_COORD,
        'fixed': fixed and {'name': fixed['name'], 'pos': fixed['pos'],
                            'rooms': fixed['rooms'], 'display': fixed['room_display']},
        'players': players,
        'panels': [{'name': p['name'], 'pos': p['pos'], 'rooms': p['rooms'],
                    'display': p['room_display']} for p in picked],
        'mannequin_stage': {'coordinator': DELIVER_COORD,
                            'salt_name': 'Large Objects',
                            'seed': mannequin_seed(level_seed)[0],
                            'coord_seed': mannequin_seed(level_seed)[1],
                            'enabled30': enabled30(level_seed, world)},
        'region_stage': region_stage(level_seed, world),
        'known_target': _known_target(level_seed, world),
        'model': info,
        'alt_model': alt,
    }


def _known_target(level_seed, world):
    """实测样本里记录过的目标人体模型（房间/坐标查静态表）。"""
    for s in SAMPLES:
        if s['seed'] != level_seed:
            continue
        for m in world.mannequins:
            if m['name'] == s['mannequin']:
                return {'name': m['name'], 'pos': m['pos'],
                        'rooms': m['rooms'], 'display': m['room_display']}
    return None


def render(result):
    lines = ['DTS_MT01  闹市区 · 调频线索 + 搬回正确人体模型  (DowntownRiotSewers)',
             'seed = %d   salt = %d   %dP   分组模型 = %s'
             % (result['seed'], result['salt'], result.get('players', 4),
                result['model']['model']),
             '调频器模型：池序未闭环（3 样本 3/3 后被 197197 打破为 2/3，见 md §4）']
    f = result['fixed']
    if f:
        lines.append('  [固定] %-30s %s  %s'
                     % (f['name'], _fmt_pos(f['pos']), ' / '.join(f['rooms'])))
    lines.append('  [随机 %d 个]' % len(result['panels']))
    for i, p in enumerate(result['panels'], 1):
        lines.append('    %d. %-30s %s  %s  %s'
                     % (i, p['name'], _fmt_pos(p['pos']),
                        '/'.join(p['rooms']), '/'.join(p['display'])))
    m = result['model']
    lines.append('  seed 链：GetSeed(%s)=0x%X → seed=0x%X（crc("%s")=0x%X）'
                 % (MAIN_COORD, m['coord_seed'], m['seed'],
                    SALT_NAME, crc32_fname(SALT_NAME)))
    lines.append('  分组：%d 组 → %s'
                 % (len(m['groups']),
                    ', '.join('%s(%d)' % (g['key'], g['size']) for g in m['groups'])))
    ms = result.get('mannequin_stage')
    rs = result.get('region_stage')
    if ms:
        lines.append('  人体模型阶段：30 启用抽取 base=0x%X（crc("Large Objects")+GetSeed(%s)）'
                     % (ms['seed'], ms['coordinator']))
        en = ms.get('enabled30') or []
        kt = result.get('known_target')
        if kt:
            nm = kt['name']
            pos = en.index(nm) if nm in en else None
            if pos is None and nm.endswith('Chainsaw_BP_2'):
                alt = 'DTR_MT01_ManneqinSetup_Chainsaw_BP3_13'
                pos = en.index(alt) if alt in en else None
                nm = alt if pos is not None else nm
            lines.append('  [实测目标] %-40s 30 抽位次=%s' % (nm, pos if pos is not None else '不在 30 内'))
    if rs:
        lines.append('  区域预测（%s，base=0x%X）：' % (rs['model'], rs['base']))
        lines.append('    线索 = %s 区域 / %s 武器（编码 %s）   ← 性别固定 Women'
                     % (rs['region'], rs['weapon'], rs['weapon_code']))
        lines.append('    该格人偶：%s  [静态 %d / 启用 %d]'
                     % (' | '.join(x.split('Setup_')[-1] for x in rs['candidates_static'])
                        or '(无)',
                        len(rs['candidates_static']), len(rs['candidates_enabled'])))
        if rs['candidates_enabled']:
            lines.append('    ⇒ 目标人偶：%s'
                         % ' | '.join(x.split('Setup_')[-1] for x in rs['candidates_enabled']))
    if m['rejected']:
        lines.append('  间距剔除：%s' % ', '.join(m['rejected']))
    if len(result['panels']) < m['count']:
        lines.append('  ! 该 seed 触发最小间距剔除，缺的 1 个由「剩余池补抽」分支补齐')
    alt = result.get('alt_model')
    if alt:
        lines.append('  [备选假设 %s] %s'
                     % (alt['model']['model'],
                        ' | '.join('%s(%s)' % (p['name'].replace('FrequencyMatchPanel_DTS_', ''),
                                               '/'.join(p['display'])) for p in alt['panels'])))
    return '\n'.join(lines)


def _norm(s):
    return ''.join(ch for ch in str(s).upper() if ch.isalnum())


def _panel_matches(panel, observed):
    """observed（玩家记下来的房间名）能否对上这个面板。"""
    o = _norm(observed)
    if not o:
        return False
    names = list(panel['rooms']) + list(panel.get('display') or panel.get('room_display') or [])
    for cand in names:
        c = _norm(cand)
        if not c or c == '?':
            continue
        if o in c or c in o:
            return True
    return False


def verify(seed, observed_rooms, players=4):
    """用一条实测记录（seed + 3 个房间）判定分组假设。"""
    world = World()
    rows = []
    for model in ('single', 'roomgroup'):
        picked, info = select_panels(seed, world, model, players=players)
        hit = [any(_panel_matches(p, r) for p in picked) for r in observed_rooms]
        rows.append((model, picked, hit))
    lines = ['DTS_MT01  校验  seed=%d  %dP  观测房间：%s'
             % (seed, players, ', '.join(observed_rooms))]
    for model, picked, hit in rows:
        lines.append('  [%s] 命中 %d/%d  → %s'
                     % (model, sum(hit), len(hit),
                        ' | '.join('%s(%s)' % (
                            p['name'].replace('FrequencyMatchPanel_DTS_', ''),
                            '/'.join(p.get('display') or p.get('room_display') or []))
                            for p in picked)))
        for r, ok in zip(observed_rooms, hit):
            if not ok:
                lines.append('      未命中：%s' % r)
    best = max(rows, key=lambda x: sum(x[2]))
    worst = min(rows, key=lambda x: sum(x[2]))
    if sum(best[2]) > sum(worst[2]):
        lines.append('  ⇒ 支持 %s（%d/%d vs %d/%d）'
                     % (best[0], sum(best[2]), len(best[2]), sum(worst[2]), len(worst[2])))
    else:
        lines.append('  ⇒ 两个假设得分相同，换一条样本再测（或房间名写细一点）')
    return '\n'.join(lines)


# 实测样本（来自 release/home/test.txt）。房间名是游戏里/界面上看到的写法。
SAMPLES = [
    {
        'seed': 252252, 'players': 1,
        'rooms': ['RBRoom_Store', 'RBRoom14_33', 'RBRoom_UppSewer_CorridorRightGenerator_01'],
        'actors': ['Child17_2', 'Child15_8', 'Child20_14'],
        'clue': {'body': 'Women', 'letter': 'A', 'number': '1', 'room': 'IRISH_PUB'},
        'weapon': 'Chainsaw', 'weapon_room': 'Pub_Master',
        'mannequin': 'DTR_MT01_ManneqinSetup_Chainsaw_BP_2',
    },
    {
        'seed': 61061, 'players': 1,
        'rooms': ['RBRoom10_21', 'RBRoom26_6', 'RBRoom_Store'],
        'actors': ['Child5_5', 'Child9_26', 'Child17_2'],
        'clue': {'letter': 'B', 'number': '2', 'room': 'GARAGE'},
        'weapon': 'Scythe', 'weapon_room': 'RBRoom_Garage',
        'mannequin': 'DTR_MT01_ManneqinSetup_Scythe_BP5_5',
    },
    {
        'seed': 836836, 'players': 1,
        'rooms': ['RBRoom8_3', 'RBRoom_HairDresser_Slave01', 'RBRoom_MotelRoom203'],
        'actors': ['Child16_2', 'Child10_14', 'Child18_5'],
        'clue': {'letter': '?', 'number': '?', 'room': '?'},
        'weapon': 'Scythe', 'weapon_room': 'RBRoom10_21',
        'mannequin': 'DTR_MT01_ManneqinSetup_Scythe_BP13_2',
    },
    {
        'seed': 197197, 'players': 1,
        'rooms': [],
        'actors': ['Child15_8', 'Child17_2', 'Child10_14'],
        'clue': {'body': 'Women', 'letter': 'A', 'number': '3', 'room': 'Bank_Vault'},
        'weapon': 'HandDrill', 'weapon_room': 'Bank_Vault',
        'mannequin': '',
    },
]


def samples():
    """跑已知实测样本：调频器预测命中率 + 「武器/房间 → 模型」是否对得上。"""
    world = World()
    lines = ['DTS_MT01  已知实测样本回归']
    for s in SAMPLES:
        picked, info = select_panels(s['seed'], world, 'single', players=s['players'])
        got_actors = [p['name'].replace('FrequencyMatchPanel_DTS_', '') for p in picked]
        want_actors = s.get('actors')
        if want_actors:
            ok_set = sorted(got_actors) == sorted(want_actors)
            lines.append('  seed=%-7d %dP  调频器（按 actor）：%s  %s'
                         % (s['seed'], s['players'], ','.join(got_actors),
                            'ALL OK' if ok_set else 'MISMATCH want=' + ','.join(want_actors)))
        hit = [any(_panel_matches(p, r) for p in picked) for r in s['rooms']]
        lines.append('      按房间名：%d/%d 命中' % (sum(hit), len(hit)))
        for r, ok in zip(s['rooms'], hit):
            lines.append('      %-46s %s' % (r, 'OK' if ok else 'MISS'))
        lines.append('      预测 → %s' % ' | '.join(
            '%s(%s)' % (p['name'].replace('FrequencyMatchPanel_DTS_', ''),
                        '/'.join(p['room_display'])) for p in picked))
        # 「武器 + 房间 → 模型」：静态表能不能对上实测
        m = [x for x in world.mannequins if x['name'] == s['mannequin']]
        if m:
            m = m[0]
            same_weapon = m['weapon'].lower() == s['weapon'].lower()
            lines.append('      模型 %s → 武器=%s 房间=%s  %s'
                         % (m['name'].split('DTR_MT01_ManneqinSetup_')[-1],
                            m['weapon'], '/'.join(m['room_display']),
                            'OK' if same_weapon else 'MISS'))
            in_room = any(_norm(r) in _norm(s['weapon_room']) or _norm(s['weapon_room']) in _norm(r)
                          for r in m['rooms'])
            lines.append('      实测武器房 %s → %s' % (s['weapon_room'],
                                               'OK' if in_room else 'MISS'))
    return '\n'.join(lines)


def selftest(verbose=True):
    """没有实测样本，这里只校验静态数据与算法自洽。"""
    checks = []
    checks.append(('crc(PersistentLevel) == 0x4C09CC22',
                   crc32_fname(LEVEL_OBJECT) == 0x4C09CC22))
    world = World()
    checks.append(('调频面板 20 个', len(world.panels) == 20))
    checks.append(('随机池 19 个', len(world.candidates()) == 19))
    checks.append(('固定面板在 PolicePlanque（RBRoom27_6）',
                   bool(world.fixed_panel()) and world.fixed_panel()['rooms'][0] == 'RBRoom27_6'))
    checks.append(('19 个候选都能落到房间',
                   all(p['rooms'] != ['?'] for p in world.candidates())))
    checks.append(('人体模型出生点 84 个 / 6 种武器',
                   len(world.mannequins) == 84 and
                   len(set(m['weapon'] for m in world.mannequins)) == 6))
    for seed in (252252, 111111, 999999, 1000):
        picked, info = select_panels(seed, world, 'single')
        checks.append(('seed %d 抽出 %d 个且互不重复' % (seed, len(picked)),
                       len(picked) >= 2 and len(set(p['name'] for p in picked)) == len(picked)))
        picked2, _ = select_panels(seed, world, 'single')
        checks.append(('seed %d 可复现' % seed,
                       [p['name'] for p in picked] == [p['name'] for p in picked2]))
    bad = [n for n, ok in checks if not ok]
    if verbose:
        for name, ok in checks:
            print('  %-42s %s' % (name, 'OK' if ok else 'FAIL'))
        print('自检：%d/%d 通过' % (len(checks) - len(bad), len(checks)))
    return not bad


def main(argv=None):
    ap = argparse.ArgumentParser(description='DTS_MT01 关卡种子分析')
    ap.add_argument('seed', nargs='?', type=int, help='关卡种子（6 位）')
    ap.add_argument('--model', default='single', choices=('single', 'roomgroup'),
                    help='分组假设：single=所有面板同一 objective type（默认）')
    ap.add_argument('--players', type=int, default=4, choices=(1, 2, 3, 4),
                    help='玩家人数（1P/2P → 1+2 个调频器；3P/4P → 1+3，默认 4）')
    ap.add_argument('--panels', action='store_true', help='列出调频器候选池')
    ap.add_argument('--mannequins', action='store_true', help='列出人体模型/武器出生点')
    ap.add_argument('--regions', action='store_true', help='区域×武器矩阵')
    ap.add_argument('--rooms', action='store_true', help='列出房间组')
    ap.add_argument('--verify', metavar='ROOMS',
                    help='用实测记录反推分组假设，如 --verify "MOTEL,CENTRALE,ELECTRIC ROOM"')
    ap.add_argument('--json', action='store_true')
    ap.add_argument('--out', metavar='FILE', help='把 JSON 写进 UTF-8 文件（PowerShell 的 > 是 UTF-16）')
    ap.add_argument('--trace', action='store_true')
    ap.add_argument('--selftest', action='store_true', help='校验静态数据/算法自洽')
    ap.add_argument('--samples', action='store_true', help='跑已知实测样本（调频器预测 vs 实测）')
    args = ap.parse_args(argv)
    try:
        sys.stdout.reconfigure(encoding='utf-8')
    except Exception:
        pass

    if args.selftest:
        return 0 if selftest() else 1
    if args.samples:
        print(samples())
        return 0

    world = World()
    if args.rooms:
        for name, rooms in room_groups(world).items():
            print('%-32s %d rooms' % (name, len(rooms)))
        return 0
    if args.panels:
        print('\n'.join(describe_panels(world)))
        return 0
    if args.mannequins:
        print('\n'.join(describe_mannequins(world)))
        return 0
    if args.regions:
        print('\n'.join(describe_regions(world)))
        return 0
    if args.seed is None:
        ap.print_help()
        return 2

    if args.verify:
        rooms = [r.strip() for r in args.verify.split(',') if r.strip()]
        print(verify(args.seed, rooms, args.players))
        return 0

    if args.trace:
        print('\n'.join(describe_panels(world)))
        print('--- trace ---')
    result = predict(args.seed, args.model, args.players)
    if args.out:
        with open(args.out, 'w', encoding='utf-8') as fp:
            json.dump(result, fp, ensure_ascii=False, indent=2)
        print('已写入 %s' % args.out)
        return 0

    print(json.dumps(result, ensure_ascii=False, indent=2) if args.json else render(result))
    return 0


if __name__ == '__main__':
    sys.exit(main())
