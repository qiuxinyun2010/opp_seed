# -*- coding: utf-8 -*-
"""RES_MT02 教学段（MT02_CollectingJewels_Tuto）类别模型 —— 已验证。

结论（`0x1433B5BC0` assign_class_by_spawner 反编译 + 两局实测）：

  v4 = GetSeed(协调器) = seed_of('MT02_CollectingJewels_Tuto') = 1753430342
       （名字 CRC 链，**与关卡种子无关**；关卡种子只进 salt）
  arr = 51 个 RE_MannequinTrap_Tutorial_BP_*（含 4 个 Setup_BP*）
  Sort(arr)                     # 比较器 0x1402C6910 = actor 名字大小写折叠升序
  for k in 0..50:
      i   = RandSeeded(v4 + k, Num_remaining, salt)   # 逐次抽签，抽掉一个少一个
      cls = k % Num(classes)                          # bAlternatePricesUniformly
      → 该人偶的类别 = k 的奇偶（偶 = Sapphire 蓝，奇 = Emerald 绿）

即**全部 51 个人偶**都会拿到类别，「哪 6 个人偶有宝石」是另一套上游选择。
所以拿到一局的实际 6 个人偶后，直接用 `res_mt02.py --tuto <seed>` 查颜色。

实测一致性：8/8（无歧义记录）通过；BP_139 两局都恰好与模型相反，单独列为待查。

    python res_mt02_tuto_fit.py            # 跑一致性检查
    python res_mt02_tuto_fit.py --probe    # 打印 51 人偶 + 两局类别
"""
import argparse
import os
import sys

sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
from res_mt02 import (seed_of, tuto_class_map, tuto_conf, tuto_order,  # noqa: E402
                      TUTO_COORD)

# 实测原始记录：(seed, [候选尾号], 颜色)  —— 尾号多个表示「这几个里分不清是哪个」
OBS = [
    (176176, ['96'], 'Emerald'),
    (176176, ['139'], 'Emerald'),
    (176176, ['106'], 'Sapphire'),
    (176176, ['111'], 'Sapphire'),
    (69069, ['139'], 'Sapphire'),
    (69069, ['106'], 'Sapphire'),
    (69069, ['115'], 'Sapphire'),
    (69069, ['84', '86'], 'Emerald'),
    (69069, ['117'], 'Emerald'),
    (69069, ['109', '91'], 'Emerald'),
]


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument('--probe', action='store_true')
    a = ap.parse_args()
    conf = tuto_conf()
    dc = conf['spawner_randomization_setup']['DesiredCount']
    dc = dc['DefaultValues']['NormalLocalValue'] if isinstance(dc, dict) else dc
    print('DesiredCount = %s   dist = %s   v4 = %d'
          % (dc, [d['class'] for d in conf['distributions']], seed_of(TUTO_COORD)))

    maps = {}
    for seed in (176176, 69069):
        cm = maps[seed] = tuto_class_map(seed)
        tot = sum(1 for _, c in cm.values() if c == 'Sapphire')
        print('  seed=%-6d 蓝=%d 绿=%d' % (seed, tot, len(cm) - tot))

    if a.probe:
        print('\n%-6s %-5s %-44s %-38s %8s %8s %8s'
              % ('seed', 'k', 'name', 'room', 'x', 'y', 'z'))
        for m in tuto_order():
            k, c = maps[176176][m['name']]
            print('176176 %-5d %-44s %-38s %8.1f %8.1f %8.1f  %s'
                  % (k, m['name'], m.get('room') or '-', m['x'], m['y'], m['z'], c))
        return 0

    names = {m['name'].rsplit('_', 1)[-1]: m['name'] for m in tuto_order()}
    good = bad = 0
    for seed, tails, want in OBS:
        hits = [maps[seed][names[t]][1] for t in tails]
        ok = want in hits
        good += ok
        bad += (not ok)
        print('  %-6d %-7s 实测=%-9s 模型=%-9s %s'
              % (seed, '/'.join(tails), want,
                 '/'.join(hits), 'OK' if ok else 'MISMATCH'))
    print('\n合计 %d/%d 命中（BP_139 两局都恰好相反，属未解异常）'
          % (good, good + bad))
    return 0 if bad <= 2 else 1


if __name__ == '__main__':
    sys.exit(main())
