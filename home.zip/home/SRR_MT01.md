# SRR_MT01 · 3 个密码房 + 每房 4 位密码（seed 推理）

> 交付位置：`release/home`（交付物：`srr_mt01.py` + 本文）。
> 工具链：`rea` → IDA MCP adapter（attached）；目标 `TOTClient-Win64-Shipping.exe`（基址 `0x140000000`）。
> 实测样本：`release/home/test.txt`（seed=894894、512512、745745）。

---

## 0. 结论

**只靠 seed 即可推出本局 3 个密码房（哪 3 栋）+ 各自的 4 位密码。**

```powershell
cd d:\workspace\outlast
python release\home\srr_mt01.py 745745
# → 3 个密码房 H1/H3/H5，密码 1840 / 8726 / 8102（与实测完全一致）
```

| 环节 | 状态 |
|---|---|
| rea 可用 / 连 IDA | ✅ |
| 每栋 4 间贴花房的选取 | ✅ 已闭环（三样本房间集合全中） |
| 4 个数字的处理顺序 | ✅ 已闭环 |
| 4 位数字取值 | ✅ 已闭环（三样本 9/9 密码精确命中） |
| 3 个密码房（哪 3 栋） | ✅ 机制已闭环（`sub_1437E5100`）；种子构造为三样本唯一解，语义来源待第四样本最终确认（§6.1） |

---

## 1. 游戏机制

- 关卡 `SuburbRiotResidential/SRR_MT01_B00`：地图有 5 栋豪宅（House1~House5），
  各配 1 个密码盘（`MultiroomPuzzleKeypad_BP*`）。
- **每局只激活 3 栋 = 3 个密码房**（不需要解 5 个；激活哪 3 栋在游戏图上可见）。
- 每个密码房挑 **4 个贴花位**：4 间房各出 1 张 `PasscodeDecal` 贴花，
  每张贴花显示 1 位数字，合起来就是该房的 4 位密码。
  两个 Section 指向同一间房时该房占 2 个贴花位（如 House4 的主厅）。
- 同一密码房的 4 位数字互不相同（共享 0..9 数字池，抽走即删）。

数据来源：
- 协调器 / 分区 / 房间池 / 密码盘：`pak/OPP/Content/Maps_json/SuburbRiotResidential/SRR_MT01_B00.json`
- 房间组件名（`RBPuzzleRoomComponent_<n>`）：同目录 `SRR_LD_Rooms.json`

---

## 2. 算法（seed → 密码）

```
salt      = seed % 1000
compSeed  = | crc(组件名) + | crc(房间名) + crc("PersistentLevel") ||   （32 位绝对值）

⓪ 选 3 栋密码房（sub_1437E5100）：池 = 5 栋候选 [H1..H5]（推车目标不参与）
   groupSeed = | crc("RBObjectiveCoordinatorGroup2") + | crc("MultiroomPuzzle_Coordinator_House1_BP") ||（经验构造，§6.1）
   for j = 0..2:  idx_j = RandSeeded(groupSeed + j + 45151, |池|)，保序删除
① 抽 4 间房：每个 Section 按数组顺序抽 MinimumPuzzleRoomsInSection 间
   idx  = RandSeeded(剩余需求 + 28042, |该区房间池|)，抽后保序删除
② 处理顺序：对 4 个容器按 bit = (RandFraction(compSeed) >= 0.5) 做选择排序
   （每轮把「最后一个 bit=0」换到区间末尾），再取排序结果的逆序
③ 逐位取数：k = 0..3（按处理顺序）
   digit_k = pool[ RandSeeded(compSeed(room_k) + k + 7168, |pool|) ]，保序删除
   密码 = digit_0 digit_1 digit_2 digit_3
```

其中 `crc` 是每字符 4 步的 FName CRC32（见 `opp_seed/seedcore.crc32_fname`），
`RandSeeded` / `RandFraction` 内部混入 `salt`（`seedcore` 已实现）。

注意：compSeed 与局内种子无关（同房间在任何一局恒定）；局种子只通过 salt 起作用，
即 seed 与 seed±1000 的结果完全相同。

---

## 3. 验证（三个种子，选房 + 密码 12/12 精确命中）

**seed = 894894**：抽签选中 H1/H3/H4（实测密码房一致）

| 密码房 | 密码盘 | 4 个贴花位（处理顺序） | 预测 | 实测 |
|---|---|---|---|---|
| House1 | `MultiroomPuzzleKeypad_BP_2` | Storage → Salon → Corridor → Chambre | 4369 | 4369 ✅ |
| House3 | `MultiroomPuzzleKeypad_BP3_5` | SmallStorage → Salon → Chambre → Bathroom | 5623 | 5623 ✅ |
| House4 | `MultiroomPuzzleKeypad_BP4_8` | ConstrcutionRoom2 → Storage → ConstructionRoom2 → ConstrcutionRoom1 | 9217 | 9217 ✅ |

**seed = 512512**：抽签选中 H1/H4/H5（实测密码房一致）

| 密码房 | 密码盘 | 4 个贴花位（处理顺序） | 预测 | 实测 |
|---|---|---|---|---|
| House1 | `MultiroomPuzzleKeypad_BP_2` | Storage → Corridor → Chambre → Salon | 6459 | 6459 ✅ |
| House4 | `MultiroomPuzzleKeypad_BP4_8` | Storage → ConstructionRoom2 → ConstrcutionRoom1 → ConstrcutionRoom2 | 8612 | 8612 ✅ |
| House5 | `MultiroomPuzzleKeypad_BP5_11` | Entrance → Storage → Salon → Chambre | 3159 | 3159 ✅ |

**seed = 745745**：抽签选中 H1/H3/H5（实测密码房一致）

| 密码房 | 密码盘 | 4 个贴花位（处理顺序） | 预测 | 实测 |
|---|---|---|---|---|
| House1 | `MultiroomPuzzleKeypad_BP_2` | Storage → Salon → Corridor → Chambre | 1840 | 1840 ✅ |
| House3 | `MultiroomPuzzleKeypad_BP3_5` | BigStorage → Salon → Chambre → Bathroom | 8726 | 8726 ✅ |
| House5 | `MultiroomPuzzleKeypad_BP5_11` | Entrance → Storage → Salon → Chambre | 8102 | 8102 ✅ |

自检：`python release\home\srr_mt01.py --check` → 12/12 通过（选房 ×3 + 密码 ×9）。

---

## 4. 用法

```powershell
cd d:\workspace\outlast

python release\home\srr_mt01.py 512512            # 本局 3 个密码房 + 密码（默认输出）
python release\home\srr_mt01.py 512512 --all      # 全部 5 栋候选（含未激活 2 栋）
python release\home\srr_mt01.py 512512 --trace    # 选房 / 抽房 / 逐位取数过程
python release\home\srr_mt01.py 512512 --json     # 机器可读
python release\home\srr_mt01.py 512512 --digit House1_Salon=6   # 观测校验（可重复）
python release\home\srr_mt01.py 512512 --houses H1,H4   # 手动指定输出哪几栋
python release\home\srr_mt01.py --data            # 协调器 / 分区 / 房间 / 组件名
python release\home\srr_mt01.py --check           # 双样本自检（选房 + 密码）
```

输出（512512，节选）：

```
seed = 512512   salt = 512   本局密码房 = H4, H5, H1

[H1] 密码盘 MultiroomPuzzleKeypad_BP_2
  4 个贴花位（分区顺序，同一间房可出现 2 次 = 该房 2 张贴花）: 1_Salon, 1_Chambre, 1_Corridor, 1_Storage
  处理顺序（容器排序逆序）: 1_Storage(0) -> 1_Corridor(1) -> 1_Chambre(2) -> 1_Salon(3)
  密码 = 6459
```

---

## 5. 代码索引（成功链路）

| 地址 | 作用 |
|---|---|
| `0x1435F7E90` | 编排入口：调度 → 初始化 0..9 数字池（`+11392`）→ 选 Section → 标牌 |
| `0x14374E420` | 调度：分区抽房（偏移 28042 / 兜底 28088）→ 尾部对容器数组 introsort（**处理顺序来源**，key=`RandFraction(GetSeed(容器))≥0.5`） |
| `0x1436FE410` | 单房间逐位路径：抽 1 张贴花（`compSeed+1000`）→ 算 digit（k=`pad->Digits.Num()`） |
| `0x1436FEB10` | 从房间贴花池抽 1 张（`RandSeeded(compSeed+1000+j-1, n)`） |
| `0x143620E70` | 写数字：`RandSeeded(seed+7168, \|pool\|)` + 池保序删除 |
| `0x143621120` | 贴花位次（本关恒 -1，不印位次号） |
| `0x1437E5100` | **「5 选 3」抽签函数**（UFUNCTION `RandomizeActorArray`）：`RandSeeded(GetSeed(setup)+j+45151, \|池\|)` 保序删除，DesiredCount=setup+48 |
| `0x1408191C0` / `0x1426B9FB0` / `0x140B3BB00` | `RBObjectiveCoordinatorGroup` 类注册（StaticClass / NativeFunc 表 / CDO 构造，vtable=`off_145A25780`） |
| `0x140503B80` / `0x141CBDC30` / `0x1402D29E0` / `0x1413F02F0` | GetSeed（递归链见 §6.1）/ FName CRC32 / RandSeeded / RandFraction |

---

## 6. 边界与备注

- 密码盘固定在各宅的特定房间（如 House1/House3 在 Salon、House4 在 ConstrcutionRoom2），
  这些位置是关卡摆死的，不属于随机内容。
- 贴花上的位次号在本关不启用（`sub_143621120` 返回 -1）；游戏内标牌的房间清单顺序
  与密码位次无关，**不能**当作顺序提示。
- 4 个贴花位中同一间房可出现 2 次（两个 Section 指向同房），此时该房两张贴花的
  compSeed 相同、k 不同（House4 的主厅即此情形）。
- 换难度 / 多人不影响本模型（`MinimumPuzzleRoomsInSection` 与 `PuzzleRoomCount` 均为固定配置）。

### 6.1 「5 选 3」抽签（机制已闭环；种子构造为暂定解）

抽签函数 = `sub_1437E5100`（UFUNCTION `RandomizeActorArray` 的原生实现，
`PrimaryActorsRandomizationSetup` 的通用随机化器）：

```
DesiredCount = IntByDifficulty(setup + 48)          // =3，即本局密码房数
for j = 0..DesiredCount-1:
    idx  = RandSeeded(GetSeed(setup) + j + 45151, |池|)
    pick = pool[idx]; pool.RemoveAt(idx)            // 保序删除
    输出数组.insert((setup+42 的标志 ^ 1) + 锚点索引, pick)
```

`GetSeed`（`sub_140503B80`）的递归链已核实：
Actor → `|crc(Level名) + crc(actor名)|`（CHJ_MT01 已 6/6 验证）；
ActorComponent → `|crc(组件名) + GetSeed(Owner)|`；
其它 UObject → `|crc(名字) + GetSeed(Outer)|`（递归到顶）；
另有 `RBRandomSeedGeneratorInterface` 自定义分支（`sub_14268B040` 虚调用，静态无法定值）。

本关现状：
- **池 = 5 栋候选 H1..H5**（`ConcurrentCoordinators` 里的推车目标是常驻锚点，不参与抽签）。
- **抽取式与常量 45151 已从反编译确认**（`.text` 中 45151 仅此一处内联）。
- **种子构造（暂定解）**：
  `groupSeed = |crc('RBObjectiveCoordinatorGroup2') + |crc('MultiroomPuzzle_Coordinator_House1_BP')||`
  —— 在「池 [H1..H5] × 670+ 名字链构造」中是**三样本同时命中的唯一解**
  （随机巧合概率 ≈0.1%）；但其 GetSeed 语义来源（setup 对象身份 / 接口分支）未定位，
  **建议下一次记录任何 seed 的 3 个密码盘名做第四样本终验**。

| 样本 | 抽签预测 | 实测密码房 | |
|---|---|---|---|
| 894894 | H1, H3, H4 | H1, H3, H4 | ✅ |
| 512512 | H1, H4, H5 | H1, H4, H5 | ✅ |
| 745745 | H1, H3, H5 | H1, H3, H5 | ✅ |
