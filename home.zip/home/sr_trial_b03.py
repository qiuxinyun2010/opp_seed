# -*- coding: utf-8 -*-
"""SR_Trial B03 调频阶段 —— seed→弹出顺序 + 组内选择（第五轮突破）。

核心发现（2026-11-01）：
  v240 = 45991 + get_seed(coord)
  弹出顺序：splitmix16(v240+k, salt) % 剩余组数，交换删除(swap-remove)
  组内选择：splitmix16(v240+1+k, salt) % 组内池大小（池序=ObjectiveActors序）

45991 = ~CRC32w(a4_string) 的值（sub_1402B05C0 中 v125 项），
  a4 是传入的盐名字符串。旧文档写 base = crc32_fname("Objective Actors")，
  但实测拟合得 45991，说明盐名可能是其他字符串或 get_seed 外层链不同。

用法：
  python sr_trial_b03.py 485485          # 完整预测
  python sr_trial_b03.py 485485 --trace   # 附抽取过程
  python sr_trial_b03.py --check          # 自检（485485 实测对照）
"""
import os, sys
_HERE = os.path.dirname(os.path.abspath(__file__))
if _HERE not in sys.path:
    sys.path.insert(0, _HERE)

import srr_mt02 as rb

M32 = rb.M32
V240_OFFSET = 45991   # v240 = V240_OFFSET + get_seed(coord)

ZH = {'Bunny': '兔子', 'Heart': '红心', 'Moon': '月亮',
      'Spade': '黑桃', 'Club': '梅花', 'Diamond': '方块'}
POLY6 = ['Bunny', 'Heart', 'Moon', 'Spade', 'Club', 'Diamond']

COORDS = {
    'B03_Poor': {
        'name': 'SR_B02_ObjCoord_OrderedClueFrequency_Poor',
        'pool': POLY6, 'targets': 6,
    },
    'B03_Rich': {
        'name': 'SR_B02_ObjCoord_OrderedClueFrequency_Rich',
        'pool': POLY6, 'targets': 6,
    },
}

# 调频器坐标（关卡 JSON，RelativeLocation）
TUNER_COORDS = {
    'FrequencyMatchSuburbs_Poor_1': (131.0, 2337.0, 400.0),
    'FrequencyMatchSuburbs_Poor_2': (-848.4, 1508.9, 400.0),
    'FrequencyMatchSuburbs_Poor_3': (805.3, 3522.5, 0.0),
    'FrequencyMatchSuburbs_Poor_4': (-715.0, 1037.0, 0.0),
    'FrequencyMatchSuburbs_Poor_5': (-543.0, 2859.0, 400.0),
    'FrequencyMatchSuburbs_Poor_6': (525.0, 3190.1, 400.0),
    'FrequencyMatchSuburbs_Poor_7': (487.0, 934.0, 0.0),
    'FrequencyMatchSuburbs_Poor_8': (-566.8, 2223.7, 0.0),
    'FrequencyMatchSuburbs_Poor_9': (-685.7, 3316.5, 0.0),
    'FrequencyMatchSuburbs_Poor_10': (771.2, 763.4, 400.5),
    'FrequencyMatchSuburbs_Poor_11': (1057.0, 2718.0, 400.0),
    'FrequencyMatchSuburbs_Poor_12': (677.0, 2496.0, 400.0),
    'FrequencyMatchSuburbs_Poor_13': (759.2, 1943.1, 0.0),
    'FrequencyMatchSuburbs_Rich_1': (1997.0, -2205.0, 400.0),
    'FrequencyMatchSuburbs_Rich_2': (1390.6, -4449.7, 400.0),
    'FrequencyMatchSuburbs_Rich_4': (-355.0, -1678.0, 400.0),
    'FrequencyMatchSuburbs_Rich_5': (1583.1, -3316.0, -83.0),
    'FrequencyMatchSuburbs_Rich_6': (1966.2, -2820.8, -83.0),
    'FrequencyMatchSuburbs_Rich_7': (1887.0, -2821.0, -83.0),
    'FrequencyMatchSuburbs_Rich_8': (1109.6, -3315.1, -83.0),
    'FrequencyMatchSuburbs_Rich_9': (196.7, -5026.3, 400.0),
    'FrequencyMatchSuburbs_Rich_10': (106.0, -5051.0, 400.0),
    'FrequencyMatchSuburbs_Rich_11': (658.0, -4190.0, 400.0),
    'FrequencyMatchSuburbs_Rich_12': (-135.0, -3646.0, 400.0),
    'FrequencyMatchSuburbs_Rich_13': (2174.0, -4540.0, 400.0),
    'FrequencyMatchSuburbs_Rich_14': (2261.6, -4066.0, 400.0),
    'FrequencyMatchSuburbs_Rich_15': (3307.5, -1293.0, 400.0),
    'FrequencyMatchSuburbs_Rich_16': (2827.0, -1191.0, 400.0),
    'FrequencyMatchSuburbs_Rich_17': (2340.0, -1338.0, 400.0),
    'FrequencyMatchSuburbs_Rich_18': (-141.0, -1160.0, 400.0),
    'FrequencyMatchSuburbs_Rich_19': (716.1, -1299.3, 400.0),
}

# SectionIndex（MISSING=0）
SEC = {
    'Rich': {1:3, 2:2, 4:1, 5:5, 6:4, 7:4, 8:5, 9:0, 10:0, 11:0, 12:0,
             13:2, 14:2, 15:3, 16:3, 17:3, 18:1, 19:1},
    'Poor': {1:2, 2:1, 3:4, 4:1, 5:2, 6:3, 7:0, 8:5, 9:5, 10:0, 11:3, 12:3, 13:4},
}
# ObjectiveActors 顺序
OA = {
    'Rich': [15, 16, 13, 14, 17, 1, 6, 2, 7, 5, 8, 11, 19, 9, 10, 12, 18, 4],
    'Poor': [1, 2, 3, 4, 6, 5, 7, 9, 8, 10, 12, 11, 13],
}

# 上屏偏移（代码读出 924519，实测需 +4 = 924523）
PRIMARY_OFFSET = 924523

# 实测记录（按 seed 索引）
RECORDED_BY_SEED = {
    485485: {
        'B03_Rich': {
            'screen': ['Club', 'Moon', 'Heart'],
            'tuners': {2:'Club', 1:'Bunny', 18:'Diamond', 5:'Spade', 11:'Heart', 6:'Moon'},
        },
        'B03_Poor': {
            'screen': ['Moon', 'Bunny', 'Club'],
            'tuners': {7:'Heart', 3:'Spade', 6:'Diamond', 5:'Moon', 2:'Club', 9:'Bunny'},
        },
    },
}


def _get_v240(key, seed):
    return (V240_OFFSET + rb.get_seed(COORDS[key]['name'])) & M32

def _rs(x, n, salt):
    return rb.rand_seeded(x & M32, n, salt)

def _swap_remove(pool, idx):
    pool[idx] = pool[-1]
    pool.pop()

def _groups_for(key):
    """按 ObjectiveActors 顺序构建组（组内保持 OA 顺序）。"""
    kind = 'Rich' if 'Rich' in key else 'Poor'
    oa, sec = OA[kind], SEC[kind]
    groups = {}
    for n in oa:
        groups.setdefault(sec.get(n, 0), []).append(n)
    return [groups[k] for k in sorted(groups)]

def patterns(key, seed):
    """按目标序号 0..5 抽取的图案（抽中即保序删除，步长=1 因有 AlternatePairs）。"""
    c = COORDS[key]
    pool = list(c['pool'])
    B = rb.get_seed(c['name'])
    salt = seed % 1000
    out = []
    for k in range(c['targets']):
        if not pool:
            break
        i = rb.rand_seeded((B + 223551 + k) & M32, len(pool), salt)
        out.append(pool.pop(i))
    return out

def primary_positions(key, seed, count=3):
    c = COORDS[key]
    B = rb.get_seed(c['name'])
    salt = seed % 1000
    pool = list(range(c['targets']))
    out = []
    for j in range(count):
        if not pool:
            break
        i = rb.rand_seeded((B + PRIMARY_OFFSET + j) & M32, len(pool), salt)
        out.append(pool.pop(i))
    return out

def pop_order(key, seed):
    """组的弹出顺序（swap-remove）。返回 [组索引...]。"""
    v240 = _get_v240(key, seed)
    salt = seed % 1000
    groups = _groups_for(key)
    pool = list(range(len(groups)))
    out = []
    for k in range(len(groups)):
        rem = len(pool)
        if rem == 0:
            break
        idx = _rs(v240 + k, rem, salt)
        out.append(pool[idx])
        _swap_remove(pool, idx)
    return out

def within_group(key, seed):
    """组内选择（hash id = v240+1+k，池序 = ObjectiveActors 序）。"""
    v240 = _get_v240(key, seed)
    salt = seed % 1000
    groups = _groups_for(key)
    order = pop_order(key, seed)
    out = []
    for k, gi in enumerate(order):
        members = groups[gi]
        idx = _rs(v240 + 1 + k, len(members), salt)
        out.append((gi, members, idx, members[idx]))
    return out

def predict(key, seed, trace=False):
    pat = patterns(key, seed)
    pos = primary_positions(key, seed)
    screen = [pat[p] for p in pos]
    wg = within_group(key, seed)

    prefix = 'Rich' if 'Rich' in key else 'Poor'
    tuners = []
    for k, (gi, members, idx, actor_num) in enumerate(wg):
        actor = 'FrequencyMatchSuburbs_%s_%d' % (prefix, actor_num)
        coords = TUNER_COORDS.get(actor, (0, 0, 0))
        tuners.append({
            'pattern': pat[k],
            'pattern_zh': ZH.get(pat[k], pat[k]),
            'actor': actor,
            'group': gi,
            'pool_index': idx,
            'coordinates': list(coords),
        })
        if trace:
            print('  k=%d grp=%d members=%s idx=%d -> %s 图案=%s xyz=%s'
                  % (k, gi, members, idx, actor, ZH.get(pat[k], pat[k]), coords))

    return {
        'screen': screen,
        'screen_zh': [ZH.get(s, s) for s in screen],
        'patterns': pat,
        'pop_order': pop_order(key, seed),
        'tuners': tuners,
    }


def show(seed):
    print('SR_Trial B03 调频预测  seed=%d  salt=%d  v240_offset=%d' % (seed, seed % 1000, V240_OFFSET))
    rec_by_key = RECORDED_BY_SEED.get(seed, {})
    for key in ('B03_Rich', 'B03_Poor'):
        r = predict(key, seed)
        rec = rec_by_key.get(key, {})
        print()
        print('  [%s] %s' % (key, COORDS[key]['name']))
        print('    目标图案 0..5 : %s' % ' / '.join(
            '%d:%s' % (i, ZH.get(s, s)) for i, s in enumerate(r['patterns'])))
        print('    弹出顺序      : %s' % r['pop_order'])
        print('    屏幕预测      : %s' % ' - '.join(r['screen_zh']))
        if rec.get('screen'):
            same = set(r['screen']) == set(rec['screen'])
            mark = ''.join('o' if a == b else 'x' for a, b in zip(r['screen'], rec['screen']))
            print('    屏幕实测      : %s   逐位 %s   集合 %s'
                  % (' - '.join(ZH.get(s, s) for s in rec['screen']),
                     mark, '一致' if same else '不一致'))
        print('    调频器点位:')
        for t in r['tuners']:
            actor_num = int(t['actor'].rsplit('_', 1)[-1])
            rec_pat = rec.get('tuners', {}).get(actor_num)
            mark = 'OK' if rec_pat == t['pattern'] else ('X(实测=%s)' % ZH.get(rec_pat, '?') if rec_pat else '')
            print('      %-44s (%8.1f, %8.1f, %7.1f)  %s %s'
                  % (t['actor'], t['coordinates'][0], t['coordinates'][1], t['coordinates'][2],
                     t['pattern_zh'], mark))


def check():
    """485485 自检。"""
    bad = total = 0
    seed = 485485
    rec_by_key = RECORDED_BY_SEED.get(seed, {})
    for key in ('B03_Rich', 'B03_Poor'):
        r = predict(key, seed)
        rec = rec_by_key[key]
        # 屏幕集合
        total += 1
        ok = set(r['screen']) == set(rec['screen'])
        bad += 0 if ok else 1
        print('  %s 屏幕 集合 预测={%s} 实测={%s} %s'
              % (key, ','.join(sorted(r['screen'])), ','.join(sorted(rec['screen'])),
                 'OK' if ok else 'MISMATCH'))
        # 弹出顺序
        groups = _groups_for(key)
        total += 1
        # 验证弹出顺序产生的 tuner 集合是否与实测一致
        got_nums = set()
        for t in r['tuners']:
            got_nums.add(int(t['actor'].rsplit('_', 1)[-1]))
        want_nums = set(rec['tuners'].keys())
        ok = got_nums == want_nums
        bad += 0 if ok else 1
        print('  %s 弹出 面板 预测=%s 实测=%s %s'
              % (key, sorted(got_nums), sorted(want_nums), 'OK' if ok else 'MISMATCH'))
        # 组内
        for t in r['tuners']:
            actor_num = int(t['actor'].rsplit('_', 1)[-1])
            total += 1
            ok = rec['tuners'].get(actor_num) == t['pattern']
            bad += 0 if ok else 1
            print('  %s 组内 %-8s 预测=%-7s 实测=%-7s %s'
                  % (key, t['actor'].rsplit('_', 1)[-1], t['pattern_zh'],
                     ZH.get(rec['tuners'].get(actor_num, '?'), '?'),
                     'OK' if ok else 'MISMATCH'))
    print('自检：%d/%d 通过' % (total - bad, total))
    return bad == 0


def main(argv):
    if '--check' in argv:
        return 0 if check() else 1
    seeds = [int(a) for a in argv if a.isdigit()]
    if not seeds:
        seeds = [485485]
    for i, s in enumerate(seeds):
        if i:
            print()
        show(s)
    return 0


if __name__ == '__main__':
    sys.exit(main(sys.argv[1:]))
