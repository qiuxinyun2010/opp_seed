# PSB_MT01：seed → 3 个区域的钥匙图案 → 图案尸体点位

> 产物全部在 `release/home`。结论分三段：**REA/IDA 可用性**、**Q1（图案，已闭环）**、
> **Q2（尸体点位，本轮把算法端到端坐实，唯一未解的是候选数组顺序）**，末尾是 41 具候选尸体的点位表。

---

## 0. REA 与 IDA 连通性（2026-10-31 复核：已连通）

| 项 | 状态 | 证据 |
|---|---|---|
| REA MCP 服务本体 | **可用** | `rea.*` 工具返回结构化结果 |
| REA → ida provider | **已连通** | `rea.list_documents` 直接返回已挂载的 `TOTClient-Win64-Shipping.exe`（image base `0x140000000`，sha256 `2cd37c88…a4192e`）；`current_document` 报错只是该 provider 不支持该操作，**不是连通问题** |
| 底层 IDA MCP 插件 | **可用**（备用） | `POST http://127.0.0.1:13337/mcp` 正常 |

结论：**rea 现已直连 IDA**，可走 `procedure_pseudo_code` / `analyze_function` / `xrefs` 等做反编译静态分析，
不再需要 HTTP 绕行。本轮回溯 Q2 用的就是 rea。

---

## 1. Q1：seed → 每个区域的钥匙图案（已闭环，实测 12/12）

反编译 `sub_14361C230`（协调器 `PSB_MT01_B01_CorpseSearch_3`）得到的唯一真实调用点：

```c
/* 0x14361CA08 尸体抽取 */  v79 = RandSeeded(v143 + 243551 + V + j, group.Num);
/* 0x14361CA7C 图案抽取 */  v84 = RandSeeded(v143 + 223551 + V + j, pool.Num);
```

* `v143 = sub_140503B80(coord, 0)` = 协调器种子，实测标定后 = **0xCD055621**（跨 3 个 seed 恒定，
  因为它是对象名/层级派生的静态量，不是本局 seed）；
* `V` = 全局抽取序号 0..9；`j` = 组内序号；组顺序固定 **A(3) → C(4) → B(3)**；
* `pool` = `QuestItemClasses` 顺序 `Bunny, Club, Diamond, Fire, Heart, Spade, Crown, Eye, Moon, Star`，
  每次抽取后 `RemoveAt(keepOrder)`，所以池长度 10→9→8…；
* 随机原语（`mix64` / `mix16` / `RandSeeded`）与 `opp_seed/seedcore.py` 一致，盐 = `seed % 1000`。

验证：111111 / 565565 / 378378 三局共 12 个图案全中（见 `README.md` 第 12 条）。

跑法：

```
python tools/psb_model.py 378378
# A: j0 月亮(钥匙) j1 王冠 j2 红心
# C: j0 黑桃(钥匙) j1 眼睛 j2 梅花 j3 五角星
# B: j0 火焰(钥匙) j1 方块 j2 兔子
```

> 注意：**钥匙图案 = 每组 j=0 的图案**（A/C/B 各一把），后面的图案是该组另外几具尸体身上的"干扰图案"。

---

## 2. Q2：哪个图案落在哪具尸体上（未闭环，但有明确进展）

### 2.1 完整链路（本轮用汇编重新核实）

1. **洗牌**（`0x14361C34C ~ 0x14361C5B0`）：对 `v144`（协调器 `vtable+2048` 返回的 actor 数组）做一次
   "伪随机排序"。比较器**只用第一个参数**：
   ```
   0x14361C3B5  mov rcx,[r14]      ; 取元素
   0x14361C3BA  call 0x140503B80   ; GetSeed(actor)
   0x14361C3C1  call 0x1413F02F0   ; → 单精度 [0,1)
   0x14361C3CE  ucomiss xmm7,xmm0  ; 与 0.5f 比较
   0x14361C3D1  jbe  0x14361C3AA   ; >=0.5 继续
   ```
   所以等价于 `hot(a) = f(GetSeed(a)) >= 0.5`，一次比较只决定 0/1 → 排序实际是**按 1 bit 分块 + 块内定序**。
   关键：后向扫描比较的是**枢轴**（`0x14361C3E9 mov rcx,[rsi]`），与游标元素无关，这一点已按汇编修正。
2. **分组**（`sub_1402C30C0(coord+1352, &v133, *(coord+6608), &v134, &v143)`）：按
   `SpecificObjectiveActorTarget` 把洗牌后的数组切成 A/B/C 三组，**组内保持洗牌后的相对顺序**，
   并且每个组会把 `v143` 加 1（`sub_1402C30C0` 里唯一的 `*a5` 写点）。
3. **抽取**：§1 的两条 `RandSeeded`，用 `RemoveAt(keepOrder)` 从组里删掉已用尸体。
   → 图案（§1）**只依赖 v143**，所以 Q1 已经能算；而"图案 ↔ 尸体"取决于第 1 步洗牌结果。

### 2.2 洗牌只剩一个未知量，但当前模型还不自洽

`GetSeed`（`0x140503B80`）语义：`GetSeed(obj) = |crc32(obj.Name) + GetSeed(obj.Outer)|`，逐层取绝对值爬 Outer 链。
41 具尸体同属 `PSB_MT01_B01` 的 `PersistentLevel` → 它们共享**同一个未知常量** `L = GetSeed(level)`。

已有工具 `tools/psb_sort_scan.c`（逐行复刻该 intro_sort + 抽取全流程，OpenMP）扫描
`L ∈ [0,2^32)` × {全局洗牌 / 按扇区洗牌} × {bit 取反}，对 378378 的 9 条实测做打分：

```
tools\psb_sort_scan.exe _corpses.txt 7 16777216
RESULT thresh=7 hits=0 ... 最高 s378=7 s565=0     （2^24 用 9.7s，2^32 约 40 分钟）
```

**拿不到 9/9**，说明除 `L` 外还有一处假设不对。按可疑度排序：

1. `v144` 到底是哪一批 actor、什么顺序（`vtable+2048` 的实现体没读，现在按"41 具尸体 + JSON 导出顺序"假设）；
2. `crc32` 变体（现在是 UTF-16 字符按 4 字节喂 CRC，需和 `sub_141CBDC30` 一模一样）；
3. `GetSeed` 的接口覆写分支（`_dec_503b80.c` 第 131–211 行，`RBRandomSeedGeneratorInterface`）；
4. 分组是否真的保序。

### 2.3 收口的两条路（都很轻，不必再盲扫）

* **静态**：读 `v144` 的来源（`vtable+2048` 实现体）+ `sub_141CBDC30` 的 CRC 细节 + 尸体类是否实现该接口；
* **运行时一次性标定**：在 `0x14361CA08` 断下，dump `group` 数组、`v143`、`v70/v71`，
  一局即可反解 `L`，之后回到纯静态。流程见 `release/coop/GUIDE.md`（Frida 侧）。

---

## 3. 点位表：每区候选尸体 → 房间 → 坐标

每局固定抽 **A 区 3 具 / C 区 4 具 / B 区 3 具**，尸体只能来自下表本区的候选集
（"池序"= 关卡 actor 顺序，即洗牌算法的输入顺序）。
一旦确定"哪个图案在哪具尸体上"，用这张表就能直接落到房间和坐标。

#### A 区（15 具候选，池内顺序 = 关卡 actor 顺序）

| 池序 | 尸体 actor | 房间 | 坐标 (X, Y, Z) |
|---:|---|---|---|
| 0 | CorpseSearch_PS_Trial02_AgainstWall_BP2_5 | TireStorage RBRoom_TireStorage | 3459, -1299, 0 |
| 1 | CorpseSearch_PS_Trial02_AgainstWall_BP3_8 | 车库锅炉房走廊 RBRoom_GarageBoilerCorridor | 1249, 906, 0 |
| 2 | CorpseSearch_PS_Trial02_AgainstWall_BP4_11 | 车库车间 RBRoom_GarageWorkshop | 3042, -2603, 0 |
| 3 | CorpseSearch_PS_Trial02_AgainstWall_BP6_20 | 车库锅炉房 RBRoom_GarageBoiler | 1801, 312, 0 |
| 4 | CorpseSearch_PS_Trial02_AgainstWall_BP_2 | 车库主主区 RBRoom_GarageMain_Master | 2506, -1737, 0 |
| 5 | CorpseSearch_PS_Trial02_BP2_20 | 车库锅炉房 RBRoom_GarageBoiler | 1911, -162, 0 |
| 6 | CorpseSearch_PS_Trial02_BP3_8 | 车库储藏室主区 RBRoom_GarageStorage_Master | 2554, -642, 0 |
| 7 | CorpseSearch_PS_Trial02_BP4_11 | 车库锅炉房 RBRoom_GarageBoiler | 1948, -409, 0 |
| 8 | CorpseSearch_PS_Trial02_BP5_17 | TireStorage RBRoom_TireStorage | 2955, -1795, 0 |
| 9 | CorpseSearch_PS_Trial02_BP6_23 | 车库锅炉房 RBRoom_GarageBoiler | 2007, 1216, 0 |
| 10 | CorpseSearch_PS_Trial02_BP_2 | TireStorage RBRoom_TireStorage | 3153, -1639, 0 |
| 11 | CorpseSearch_PS_Trial02_WallThroat_BP2_5 | 车库车间 RBRoom_GarageWorkshop | 3402, -3232, 0 |
| 12 | CorpseSearch_PS_Trial02_WallThroat_BP3_11 | 车库锅炉房 RBRoom_GarageBoiler | 1735, 1568, 0 |
| 13 | CorpseSearch_PS_Trial02_WallThroat_BP4_14 | 车库锅炉房走廊 RBRoom_GarageBoilerCorridor | 1302, 81, 0 |
| 14 | CorpseSearch_PS_Trial02_WallThroat_BP_2 | 车库储藏室副区01 RBRoom_GarageStorage_Slave01 | 3468, -244, 0 |

#### C 区（16 具候选，池内顺序 = 关卡 actor 顺序）

| 池序 | 尸体 actor | 房间 | 坐标 (X, Y, Z) |
|---:|---|---|---|
| 0 | CorpseSearch_PS_Trial02_AgainstWall_BP5_2 | 靶场维修间副区03 RBRoom_ShootingRangeMaintenance_Slave03 | -4414, -2274, 0 |
| 1 | CorpseSearch_PS_Trial02_AgainstWall_BP7_23 | 靶场 RBRoom_ShootingRange | -3903, -94, 2 |
| 2 | CorpseSearch_PS_Trial02_AgainstWall_BP8_29 | 军械库 RBRoom_armory | -2642, -2622, 0 |
| 3 | CorpseSearch_PS_Trial02_AgainstWall_BP9_2 | 施工 RBRoom_Construction | -2238, -3249, -25 |
| 4 | CorpseSearch_PS_Trial02_BP13_44 | 档案库01主区 RBRoom_Archives01_Master | -3170, 298, 0 |
| 5 | CorpseSearch_PS_Trial02_BP15_50 | 靶场 RBRoom_ShootingRange | -3906, -859, 0 |
| 6 | CorpseSearch_PS_Trial02_BP19_62 | 档案库03 RBRoom_Archives03 | -2646, 1249, 0 |
| 7 | CorpseSearch_PS_Trial02_BP20_65 | 靶场 RBRoom_ShootingRange | -2528, -518, 0 |
| 8 | CorpseSearch_PS_Trial02_BP7_2 | 施工 RBRoom_Construction | -2437, -2409, 0 |
| 9 | CorpseSearch_PS_Trial02_OnChair_BP3_8 | 档案库01主区 RBRoom_Archives01_Master | -3097, 711, 0 |
| 10 | CorpseSearch_PS_Trial02_OnChair_BP4_11 | 军械库车间 RBRoom_ArmoryWOrkshop | -3489, -2961, 0 |
| 11 | CorpseSearch_PS_Trial02_OnChair_BP5_14 | 军械库 RBRoom_armory | -3030, -1836, 0 |
| 12 | CorpseSearch_PS_Trial02_OnChair_BP7_23 | 档案库02 RBRoom_Archives02 | -4006, 540, 0 |
| 13 | CorpseSearch_PS_Trial02_OnChair_BP8_5 | 靶场 RBRoom_ShootingRange | -2478, 15, 0 |
| 14 | CorpseSearch_PS_Trial02_WallThroat_BP8_32 | 靶场 RBRoom_ShootingRange | -3000, -549, 0 |
| 15 | CorpseSearch_PS_Trial02_WallThroat_BP9_35 | 施工走廊 RBRoom_ConstructionCorridor | -882, -2605, 0 |

#### B 区（10 具候选，池内顺序 = 关卡 actor 顺序）

| 池序 | 尸体 actor | 房间 | 坐标 (X, Y, Z) |
|---:|---|---|---|
| 0 | CorpseSearch_PS_Trial02_BP10_35 | 维修间 RBRoom_Maintenance | -444, 612, 0 |
| 1 | CorpseSearch_PS_Trial02_BP12_41 | 停尸房楼梯 RBRoom_MorgueStairs | -3103, 1797, 100 |
| 2 | CorpseSearch_PS_Trial02_BP9_32 | 停尸房楼梯 RBRoom_MorgueStairs | -1806, 1865, 0 |
| 3 | CorpseSearch_PS_Trial02_Desk_BP2_2 | 主楼梯 RBRoom_MainStairs | 487, 2072, 0 |
| 4 | CorpseSearch_PS_Trial02_Desk_BP3_5 | 停尸房主区 RBRoom_Morgue_Master | -948, 2200, 0 |
| 5 | CorpseSearch_PS_Trial02_Desk_BP_5 | 停尸房主区 RBRoom_Morgue_Master | -690, 2551, 0 |
| 6 | CorpseSearch_PS_Trial02_OnChair_BP2_5 | 发电机 RBRoom_Generator | -2286, 2399, 0 |
| 7 | CorpseSearch_PS_Trial02_OnChair_BP_2 | 停尸房主区 RBRoom_Morgue_Master | -343, 2028, 0 |
| 8 | CorpseSearch_PS_Trial02_WallThroat_BP5_17 | 洗手间走廊02 RBRoom_BathroomCorridor02 | 1116, 1478, 0 |
| 9 | CorpseSearch_PS_Trial02_WallThroat_BP7_26 | 停尸房楼梯 RBRoom_MorgueStairs | -1824, 2352, 0 |


### 2.4 新发现：组容量被搞错了（很可能是扫描失败的真正原因）

关卡 JSON 里协调器的配置（`PSB_MT01_B00.json`，`PoliceStation_Trial2_QuestItemCoord_BP_C`）：

```
SpawnerActorsRandomizationSetup = { DesiredCount: 10, bSplitByObjectiveType: true }   # Secondary
PrimaryActorsRandomizationSetup = { (DesiredCount 未设) }                             # Primary
```

* **SpawnerActors（Secondary）= 10 个刷怪点**，`bSplitByObjectiveType=true` → 按扇区切成 **A 3 / C 4 / B 3**；
  这也正好是每局"每区抽 3/4/3 具"的来源 —— 不是尸体的池容量。
* **尸体池（Primary）** 才是每区的候选全集：**A 15 / C 16 / B 10（共 41）**。

所以 `0x14361CA08` 里的 `RandSeeded(v143 + 243551 + V + j, group.Num)`，
`group.Num` 应该是**该扇区尸体池的剩余数量（15/16/10 递减）**，
而 `tools/psb_sort_scan.c` 现在用的是 `GCNT={A:3,C:4,B:3}` 当模数 → 取模完全不同，
扫不出解是必然的。

修正后的完整模型：

1. 10 个刷怪点按扇区分组（3/4/3），逐条消费；
2. 每消费一个刷怪点，从**该扇区尸体池**里按 `RandSeeded(v143+243551+V+j, 池剩余数)` 抽一具并 `RemoveAt(keepOrder)`；
3. 图案按 `RandSeeded(v143+223551+V+j, 图案池剩余数)` 抽（Q1，已 12/12）；
4. 第 2 步抽到的位置 → 尸体，仍需洗牌后的组内顺序（§2.1/2.2 的未知量）。

下一步：把 `psb_sort_scan.c` 的模数从 3/4/3 改为 15/16/10（并保持 `RemoveAt(keepOrder)`），再扫 `L`。

---

### 2.5 更正与追加证据（同日复核）

**更正 2.4 的说法**：`tools/psb_sort_scan.c` 里 `GCNT={3,4,3}` 只是"每区抽几次"，
`simulate()` 的取模用的是 `mn = GRP_N[sec]`（该扇区全池 15/16/10，逐次递减），
`build_groups_h()` 也是"41 具全局洗牌后按扇区过滤"。也就是说模数本来就是对的，
§2.4 说"扫描器拿 3/4/3 当模数"是我误读了 `GCNT`，该结论作废。

**比较器已精确核实**（`0x1413F02F0`，即洗牌用的 `f(seed)`）：

```c
if (!g_seed) return 0;
v1 = mix64(a1) ^ mix64(g_seed % 1000);        // splitmix64 双盐
v3 = 321982955 * (v2 ^ (v2>>27)) ^ (mix64(...) >> 31);
return (float)(uint16)v3 * 0.000015258789;    // = k/65536
```

比较是 `f(...) >= 0.5` → 等价于 **`(mix64 & 0xFFFF) >= 0x8000`**，
与 `psb_sort.hi16()` 完全一致；盐仍是 `全局 seed % 1000`。这一环可以排除了。

**新增基线（不洗牌）**：直接按 JSON 顺序当组顺序时，378378 只对 3/9
（A 区月亮、C 区梅花、B 区方块 巧合命中），所以洗牌确实参与，不能省。

**正在跑**：`tools/psb_sort_scan.exe tmp\_corpses.txt 9 4294967296`（后台，pid 33100，
日志 `tmp\scan_full.txt`），全 32 位 `L` × 3 个模型变体，看能否出现 9/9。
若无 9/9，则问题在"洗牌输入顺序（v144 的实际数组）"或"intro_sort 复刻"，而不是 `L`。

### 2.6 全量扫描终止 + GetSeed 存疑（2026-10-31 晚）

* 全 32 位 `L` 扫描跑到 20 min 仍未出结果（单核、6 个变体 ×2^32），按要求**终止**（输出被缓冲，无部分结果）。
* 改为只测"crc 链可推出来的候选 `L`"（`seed_of_object("PersistentLevel", …)` 的若干组合、0、工具默认值），
  共 10 个候选 × 模型/取反/两个 seed：最高 4/9（≈ 随机水平）→ **候选 L 全灭**。
* 回头复核 `GetSeed`（`0x140503B80`）：**不是** 三行的 `|crc32(Name)+GetSeed(Outer)|`。
  反编译出来是带大量嵌套分支、且尾部 `return sub_14268B040(...)` 的大函数，全文没有任何 CRC 查表引用
  （无 `0xEDB88320`、无 `>>8` 序列）。也就是说"41 具尸体共用一个 level 常量 `L`"这个前提本身存疑，
  难怪扫遍 `L` 也拟合不上。

**结论**：Q2 的静态路线卡在 `GetSeed` 的真实语义上（它可能不是名字哈希，而是每 actor 的初始化种子）。
两条可行路：① 啃 `0x140503B80`（大函数，需要 capstone 分段读）；② 在 `0x14361CA08` 断一次，
dump `group` 数组的真实顺序，一次反解，永久闭环。

### 2.7 撤回上条的 GetSeed 质疑 + 排序区间实证（2026-10-31 夜）

**撤回 §2.6 的怀疑。** `RE_METHOD.md` 与 `RES_MT02.md` 都已固化：
`GetSeed(a) = |crc32(a.Name) + crc32(a.Outer)|`，只由名字决定、与关卡种子无关。
`0x140503B80` 之所以看起来硕大，是因为它内联了 `RBRandomSeedGeneratorInterface` 的覆写分支
+ SEH，主路径仍是名字 CRC 链。`tools/` 里的 `seed_of_object()` 就是它。
**所以不存在"未知常量 L"**：尸体直接挂在 `PersistentLevel` 下，每具尸体各有自己的种子。

按该语义重跑（`tmp/_seed_fix.py`，`L = crc32("PersistentLevel")`，不再扫任何常量）：

| 模型 | 378378 | 565565 |
|---|---|---|
| 全局排序→按扇区过滤，inv=0 | 0/9 | 0/3 |
| 全局排序→按扇区过滤，inv=1 | 3/9 | 0/3 |
| 分扇区排序，inv=0/1 | 1/9 | 0/3/0/3 |

即：**换了正确种子模型依旧不拟合** → 缺口不在 `L`，而在"排序的输入数组与排序区间"。

**本轮新汇编证据**（`0x14361C2C6–0x14361C33A`）：

```asm
14361C2C9  lea  rdi,[var_388]          ; 临时 TArray{Begin,Num,Max}
14361C2D1  movaps [rdi],xmm6           ; 清零
14361C2DE  call qword ptr [rax+800h]   ; ← 候选数组来源 vtable+2048（实现体仍未读）
14361C2E4  movsxd rsi,[rdi+8]          ; rsi = Num
14361C2E8  cmp  rsi,2
14361C2EC  jl   loc_14361C6B4          ; Num<2 直接不排序
14361C2F7  mov  rbx,[var_388]          ; rbx = Begin
14361C2FF  lea  rdi,[var_368]          ; 排序上下文（memset 0x2F0）
14361C317  mov  [rdi-10h],rbx          ; First = Begin
14361C31B  lea  rax,[rbx+rsi*8]
14361C31F  add  rax,-8
14361C323  mov  [rdi-8],rax            ; Last = Begin + Num*8 - 8  ← 只到 Num-1
14361C327  cvtsi2ss xmm0,esi
14361C32B  call logf
14361C331  addss xmm0,xmm0             ; 深度上限 = 2*log2(Num)
14361C33A  mov  [rdi],eax
```

两点此前模型没有体现：

1. **排序区间是 `[0, Num-1)`**——最后一个元素不参与排序，原地留在末尾（`Begin+Num*8-8` 是末元素地址，
   若按闭区间理解则少排一个）。已加 `dropLast` 变体重测：结果同上，仍不拟合。
2. 候选数组来自 `vtable+2048`，**它的内容与顺序仍未确定**（§2.2 的第 1 条至今没读）。
   在不知道这批 actor 是什么、以什么顺序放进数组之前，任何"按 JSON 顺序当输入"的模型都只能是猜测。

**当前结论**：Q2 唯一未解的量就是 `vtable+2048` 返回的数组。要么读该实现体，
要么在 `0x14361C2DE` 之后 dump `var_388`（Begin/Num + 指针内容），一次即可定论。

---

### 2.8 本轮（rea 直连 IDA）把整条链端到端坐实（2026-10-31）

用 rea 直接反编译 `sub_14361C230`（协调器 `PSB_MT01_B01_CorpseSearch_3`），与 `sub_1413F02F0`（洗牌 `f`）、
`sub_140503B80`（GetSeed）交叉验证，结论如下：

**A. 算法 100% 坐实（无需再猜）**
- 候选数组 `v144` 来源：`(*(_QWORD*)a1 + 2048)(a1, &v144)` —— `a1` 是协调器，`vtable[256]` 虚方法，
  返回 `TArray<actor>`（行 152）。之后对整个 41 数组做 introsort，再按 `SpecificObjectiveActorTarget`
  切 A/C/B 三组（组内保序），再按 `RandSeeded(v143+243551+V+j, 组剩余数)` 抽尸体、按
  `RandSeeded(v143+223551+V+j, 图案池剩余数)` 抽图案，均 `RemoveAt(keepOrder)`。
- `v143 = GetSeed(a1) = 0xCD055621`，`V` 为全局抽取序号累加，组顺序固定 **A(15)→C(16)→B(10)**，
  每区抽 **A3/C4/B3**。这些与 `psb_mt01.py` 完全一致 —— **Q1 模型（12/12）已是在同一份代码上闭环**。

**B. 比较器 = `rand_seeded._mix64`（数学等价，已证明）**
`sub_1413F02F0(a1)` 的 `mix64` 是 splitmix64 无 gamma 版，且首段对 `a1`、`salt` 各做一遍后 **异或**；
而 `rand_seeded._mix64(seed, salt)` 把 `a1`、`salt` 各自过一遍 splitmix64 再异或 —— 由于乘法在 GF(2) 上线性，
两者逐位相等。结论：**`tools/psb_sort.hi16()` 就是游戏用的比较器，无需再改**。

**C. GetSeed 精确语义 = 名字 CRC 链（已确认，附重要修正）**
`sub_140503B80` 主路径：`GetSeed(obj) = fold( crc32_fname(Name) + GetSeed(Outer) )`，逐层符号折叠
（`v59 = crc32 + GetSeed(outer)`，`if v59<=0 then -v59`）。这与 `seed_of_object(name, L)` 同构。
**重要修正**：41 具尸体分布在 `PSB_MT01_B00` / `PSB_MT01_B01` **两个子关卡的 PersistentLevel 下**，
它们的 Outer 链不同 → **Outer 种子不是单一全局常量，而是按子关卡各一个**。此前 `psb_fit_L.py`
把 41 具尸体当"共用一个 L"去拟合，这个前提本身就有缺口。

**D. 洗牌盐 = `dword_146E2E5C4 % 1000` = 关卡 seed % 1000（已确认，排除）**
`dword_146E2E5C4` 是全局随机种子（被 100+ 处引用，含各类 `RandSeeded`/`GetSeed`），洗牌与抽取用同一盐，
与 Q1 抽取盐一致。所以盐不是缺口。

**E. 唯一未解量 = 候选数组顺序（vtable[256] 的实现体）**
- 先用 `psb_find_vt.py 14361C230 800` 定位 `sub_14361C230` 所在 vtable（`0x145A20C88`，slot 558），
  读它 `vtable+0x800`（idx 256）= **`0x140753460`**，反编译发现它是一段**布尔谓词**
  （读 `RBPlayerState`、比较 `a1+857`，返回 `a1+857==3 || …`），**不是返回 TArray 的 getter**。
- 这说明 `0x145A20C88` 是**基类/副 vtable**，真正的协调器**主 vtable** 在别处，其 slot 256 才是 getter。
  `rea.xrefs(0x14361C230)` 只返回 `0x145A21DF8`（基类 vtable 一个引用），协调器主 vtable 里是 thunk，
  故工具层面拿不到主 vtable 的 slot 256。
- 因此"候选数组的真实顺序"只能由两路定论：
  1. **静态**：找到协调器主 vtable（RTTI `PoliceStation_Trial2_QuestItemCoord_BP_C` 的 `_COL`→vtable），
     读其 slot 256 实现体，看它把哪些 actor、以什么顺序塞进 `TArray`；
  2. **运行时一次性标定**：在 `0x14361C2DE`（`call [rax+800h]` 之后）dump `var_388`
     （Begin/Num + 指针指向的 41 个 actor 名），一局即可反解顺序，之后回到纯静态。

**F. 标定验证（本轮实测）**
- `python tools/psb_fit_L.py`：候选 `L` 共 42 个，最优 `L=0xCD055602`（B-31），**对 4 错 9**（≈ 随机水平）。
- 用 §C 的精确 CRC 链 + 按子关卡分 Outer、按 JSON 顺序当候选数组，测试若干策略（A/B/C/D/E）均 **0/7~1/7**。
  两条路都证明：**在"候选数组 = JSON/关卡 actor 顺序"的假设下，任何 L 都拟合不上** → 顺序确实是唯一缺口。

**本轮交付结论**：Q1 已从 seed 完全推导每区钥匙图案（12/12 验证）；Q2 的"图案↔尸体"算法已端到端坐实，
**只差候选数组顺序（协调器主 vtable[256] 的 getter，或一次运行时 dump）**。拿到顺序后，
`psb_mt01.py` + `psb_sort.py` + `psb_corpses.py` 即可由 seed 直接算出每具图案尸体的房间与坐标。
