# -*- coding: utf-8 -*-
"""SR_Trial 第二阶段（找密码）离线预测器：只吃关卡种子。

调用链与偏移全部来自静态反编译（证据见 SR_TRIAL.md §10）：

  sub_14374E420（协调器 Setup）
    1) 抽房：Sections 按 JSON 数组顺序逐区处理，
       idx = RandInt(剩余数 + 28042, 区内房间数)，剩余 4→3→2→1，
       MinimumPuzzleRoomsInSection = 1 ⇒ 每区 1 间。
       注意：分区排序 / randomID(48688) 在抽房之后才发生，只服务补位(28088)，
       SR_Trial 每区都抽满 ⇒ 补位走不到 ⇒ 分区顺序对密码无影响。
    2) 房间数组 (coordinator+11064) = 抽取顺序，随后**原地**洗牌：
       key = RandFraction(GetSeed(房间))          （无 134123 偏移）
       小区间分支（n<=8）：end 从末尾往前，挑「最后一个 key<0.5 者」与 end 交换。

  sub_1435F7860 / 标牌文本
    3) 位次顺序 = 房间数组**从末尾往前**（位置 1 = 数组最后一个元素）。

  sub_1436FE410 → sub_143620E70
    4) 共享数字池 0..9；第 k 位（k=0..3）：
       digit = pool[ RandInt(GetSeed(房间) + k + 7168, |pool|) ]，保序删除（memmove）。
       位次号 = k+1；贴花 order 字段对 SR_Trial 恒为 -1
       （sub_143621120：区内房间数 1 < 需求 4），所以位次只能由 k 决定。

用法：
    python sr_trial_password.py              # 跑两个实测样本自检
    python sr_trial_password.py 485485 700123
    python sr_trial_password.py --trace 485485
"""
import sys

import sr_trial as S


def pick_rooms(level_seed, sections=None, want=None, trace=False):
    """按 Sections 的 JSON 顺序逐区抽 1 间（sub_14374E420 第一段）。"""
    sections = sections if sections is not None else S.SECTIONS
    want = S.PUZZLE_ROOM_COUNT if want is None else want
    salt = level_seed % 1000
    pools = {i: list(pool) for i, pool in enumerate(sections)}
    picked, remaining = [], want
    for sid in range(len(sections)):
        if remaining <= 0:
            break
        pool = pools[sid]
        if not pool:
            continue
        for _ in range(min(len(pool), 1)):          # MinimumPuzzleRoomsInSection = 1
            idx = S.rand_seeded(remaining + S.SECTION_PICK_OFFSET, len(pool), salt)
            room = pool.pop(idx)
            picked.append(room)
            if trace:
                print('    抽房 section=%d 剩余=%d idx=%d/%d -> %s'
                      % (sid, remaining, idx, len(pool) + 1, S.ROOM_LABEL[room]))
            remaining -= 1
            if remaining <= 0:
                break
    return picked


def shuffle_rooms(level_seed, rooms, trace=False):
    """原地单比特洗牌（sub_14374E420 第二段，n<=8 的分支）。"""
    salt = level_seed % 1000
    frac = {room: S.rand_fraction(S.room_component_seed(room), salt) for room in rooms}
    out = list(rooms)
    end = len(out) - 1
    while end > 0:
        best = 0                                   # 未命中时退化为 begin
        for j in range(1, end + 1):
            if frac[out[j]] < 0.5:
                best = j
        if best != end:
            out[best], out[end] = out[end], out[best]
        end -= 1
    if trace:
        print('    洗牌 frac=%s' % {S.ROOM_LABEL[r]: round(frac[r], 4) for r in rooms})
    return out


def password_order(level_seed, trace=False):
    """返回 (位次 1..4 的房间列表, [(room, digit)])。"""
    picked = pick_rooms(level_seed, trace=trace)
    shuffled = shuffle_rooms(level_seed, picked, trace=trace)
    order = shuffled[::-1]                          # 标牌/位次 = 数组末尾往前
    if trace:
        print('    数组=%s' % [S.ROOM_LABEL[r] for r in shuffled])
        print('    位次=%s' % [S.ROOM_LABEL[r] for r in order])
    pairs = S.assign_digits(level_seed, order, trace=trace)
    return order, pairs


def predict(level_seed, trace=False):
    order, pairs = password_order(level_seed, trace=trace)
    return {
        'seed': level_seed,
        'rooms': order,
        'digits': [d for _, d in pairs],
        'password': S.password_of(pairs),
    }


# (seed, 实测密码, 实测逐房数字)  —— 逐房数字来自记录，比密码串更能验证位次
CASES = [
    (485485, '0856', {'Bedroom': 0, 'Office': 8, 'GameRoom': 5, 'Garage': 6}),
    (500500, '0983', {'Office': 0, 'GameRoom': 9, 'Laundry': 8, 'Bedroom': 3}),
    (166166, '2536', {'Bedroom': 2, 'Office': 5, 'GameRoom': 3, 'Laundry': 6}),
]


def check():
    ok = True
    for seed, want, want_digits in CASES:
        info = predict(seed)
        got = {S.ROOM_LABEL[r]: d for r, d in zip(info['rooms'], info['digits'])}
        hit = info['password'] == want and got == want_digits
        ok &= hit
        print('%s seed=%d 位次=%s 密码=%s 期望=%s 逐房数字%s'
              % ('OK  ' if hit else 'FAIL', seed,
                 [S.ROOM_LABEL[r] for r in info['rooms']], info['password'], want,
                 '' if got == want_digits else ' 不符: %s vs %s' % (got, want_digits)))
    return ok


def main(argv):
    if not argv:
        return 0 if check() else 1
    trace = '--trace' in argv
    args = [a for a in argv if not a.startswith('--')]
    for a in args:
        if not a.isdigit():
            print('用法: python sr_trial_password.py [--trace] <seed> [seed...]')
            return 2
    for a in args:
        info = predict(int(a), trace=trace)
        print('seed=%d  密码=%s  位次=%s'
              % (info['seed'], info['password'],
                 [S.ROOM_LABEL[r] for r in info['rooms']]))
    return 0


if __name__ == '__main__':
    sys.exit(main(sys.argv[1:]))
