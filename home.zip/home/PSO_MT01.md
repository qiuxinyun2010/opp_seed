# PSO_MT01：四区钥匙（警察局办公区）

样本（`home/test.txt`，全部 Easy / 1P）：

| seed | 区 | 生成器 | 房间 |
|---|---|---|---|
| 519519 | C | `...QuestItemSpawner_BP_Child_105` | RBRoom_DetectiveOffices05 |
| 329329 | A | `...QuestItemSpawner_BP_Child_40` | RBRoom_PatrolEntrance_Slave01 |
| 876876 | B | `...QuestItemSpawner_BP_Child_27` | — |
| 235235 | A | `...QuestItemSpawner_BP_Child_40` | — |

## 结论

**目前不能从 seed 推出钥匙位置。** 而且必须撤回上一轮的结论。

- 上一轮用 `crc32("Concurrent Coordinators") + GetSeed(PSO_MT01_B01_Group2)`
  解释「哪几个区出钥匙」，在只有 2 条样本时命中 2/2；加入 876876 / 235235 后
  **降到 2/4**（4 选 1 猜两次的期望就是 2/4），即纯属巧合。该模型已废。
- 区内生成器：在下面这个假设空间里**穷举后 0/4**：
  5 种池顺序 × 8 种重排 × 3 种 actor 种子取法 × 3 种分组（不分组 / 房间组 / 单一房间）
  × 2 种组抽取偏移 × 2 种组顺序 × 「组内 seed 再加组下标」开关 × 129 个偏移
  ≈ 3×10⁶ 组合。最好的组合只有 2/4，和随机猜同一水平。
  `pso_fit.py --strict`（只允许调用点已知常量 `+243551`）同样是 0/4。

一条很硬的约束：**329329 和 235235 落在同一个生成器 `Child_40`**。
现有模型在两条不同 salt（329 / 235）下给出的区内下标分别是 16 和 5，
任何「先排序再抽一个」的结构都很难让两条 salt 落到同一点。

## 静态结构（已确认）

- 4 个协调器 `PSO_MT01_B01_SimpleQuestItem_SectionA..D`，类
  `RBUseQuestItemsObjectiveCoordinator`（静态类 `qword_146E8D9E0`，大小 14200）。
- 每个协调器**有两套独立的随机化**，这是之前混淆的根源：
  - `ObjectiveActors`（1 个）= `KeyItemDestination_Device_Base_BP_*`，即**用钥匙的锁位**；
    `bUseObjectiveActorsRandomization=true`，走 `sub_1402AE7F0` → `sub_1402AF490`
    → `sub_1402B05C0`，盐名是 `"Objective Actors"`（16 个字符，与 DTS_MT01 同一个）。
  - `SpecificItemSpawners`（21/21/20/21）= **钥匙生成点**；
    `bUseSpawnerActorsRandomization=true`，走 `sub_14361C230`。
  → **DTS_MT01 那套 `crc("Objective Actors") + GetSeed(coord)` 的模型只适用于锁位，
    不适用于钥匙生成点。** 实测用它在 4 条样本上也是 0/4。
- 房间组：A=[A(20), Security(1)]，B=[B(20), C(1)]，C=[C(17), B(3)]，D=[D(21)]。

## 代码路径（本轮新读出的）

- `sub_14361C230`：先 `vtable+2048` 取候选数组，**只有数量 ≥ 2 才做 intro-sort**
  （一元比较器 `frac(GetSeed(actor)) >= 0.5`，常量 0.5 的 `ucomiss` 在 `0x14361C3C1`）。
- `sub_14361C230` 的分支点 `*(a1+7273)` 对应属性 **`ObjectiveIndexAlternatePairs`**
  （setter `sub_14383FF20`，注册项 `0x145CD0538`）。**PSO 关卡 JSON 里没有这个属性**
  → 走 `else` 分支，即 `sub_1402C30C0`（分组 + 分配 DesiredCount）那条路，与我建模的一致。
  另一条 `sub_14361CFA0` 只负责给已定目标配锁位，不做生成点抽取。
- `sub_14361CE40`（不重复索引抽取）是 **memmove 保序删除**，不是 swap-remove；
  每轮 `++a4`。修正了旧笔记。
- 候选池来源 `sub_141DA4D70`（`vtable+1752`）：
  1. 先按 **40 字节步长遍历 `SpecificItemSpawners`**（= `a1+728`，数量 `a1+736`），保序追加；
  2. 再追加一批「按类/按 Outer 过滤的世界 actor 迭代器」结果（`sub_140120320` +
     `sub_1404A7180`，受 `a1+704/712` 与 `a1+864` 控制），带去重。
  → **运行时的候选池可能不止 JSON 里的 21/20 个，顺序也可能变**。这是当前最可疑的失配点。
- `sub_1402C30C0` 内部用了位图/稀疏数组（`rol / and / or` 位操作），组顺序很可能是
  **TMap 遍历序**，离线难以精确复现。

## 还需要什么

1. 确认运行时候选池的真实内容与顺序（把 `sub_141DA4D70` 第 2 段收集的东西定下来，
   或直接用 Frida hook `sub_14361C230` 打印候选数组）。
2. **2P 一局**：一次给出 2 个区 + 2 个生成点，能同时钉死「选区」和「区内抽取」。
3. 再多 3~5 个不同 seed 的 1P：把 4 选 1 的巧合空间压下去。

记录格式照旧：`Key-X = <actor>`、`room = ...`、`EffectiveNumberOfPlayers: N`。

## 脚本

- `pso_mt01.py`：候选模型 + 自检（当前 选区 2/4、点位 0/4）。
- `pso_fit.py`：`--strict` / `--diag` / 宽松扫描，用于证伪候选假设。
