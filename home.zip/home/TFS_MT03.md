# TFS_MT03：六个阀门的点位（玩具工厂 · 开启六个阀门）

关卡：`ToyFactoryShipping` · 「Gas the Factory」
配套脚本：`home/tfs_mt03.py`（本目录，可独立运行，不依赖 `opp_seed`）

> **本次结论：静态数据已全部核对完毕，主函数结构已从 IDA 读出来，但最后一步
> 「61390 预选出来的阀门是被排除还是被选中」仍未闭环。** 旧脚本那个
> `MAIN_SECOND = {'A1','B2','B3'}` 是**拟合出来的开关，不是代码里的分支**——
> 代码里没有任何按分区切换路径的逻辑。下面 §4 给出真实结构，§6 给出判别所需的实测。

---

## 1. REA / IDA 状态

`rea` 已连上 IDA（provider `ida`，上游 `ida-pro-mcp 1.30.0`，image base `0x140000000`）。
IDA 未启动时所有调用报 `[WinError 10061]`；启动方式见 `PSA_MT01.md` §1。

## 2. 旧模型哪里不对

`release/coop/TFS_MT03/TFS_MT03.py` 的模型是：

```text
first  = RandSeeded(cs + 61390, count)        # 预选
remaining = count-1 个（RemoveAtSwap 后）
second = RandSeeded(cs + 39135, count-1)
答案 = second  如果分区 ∈ MAIN_SECOND，否则 = first
```

反编译 `0x143803600` 后可以看到：**`61390` 和 `39135` 不是两条并列的路径**，
而是同一条流程里的两段，而且 `39135` 那次抽取的池**不是**「RemoveAtSwap 之后的余池」，
而是**在原序候选数组上按 `IsValid` 过滤出来的新数组**。

另外还有一个坑：旧脚本的 `selftest` 断言的是**精确 actor 名**，但
`test.txt` 里 14014 只记了**房间**。6 个区里有 5 个区的「观测房间」里躺着 2 个候选阀门，
所以那些 actor 名是拟合时反推的，不是实测。真值实际只有房间级，而且更弱。

## 3. 静态数据核对（全部通过）

来源：`pak/OPP/Content/Maps_json/ToyFactoryShipping/TFS_LD_MT03_B00.json`

* **6 个协调器** `MT03_FirePump_ObjCoord_BP_SectionA1/A2/A3/B1/B2/B3`，
  每个 `ValveSectionGroupConfig` = 1 组 × 1 个 Section，
  `NumberOfValveSections = 1` → 代码里的 `v79 = 0`、`N = 1`，
  所以 `61390` 段的 seed 就是 `i + cs + 61390`，`39135` 段就是 `cs + 39135`。
* **候选原序与脚本一致**（含跳号）：
  A1 `01..06`、A2 `01..06`、A3 `1,2,3,5,6,7`、B1 `02,03,04,08`、
  B2 `07,01,02,03,04,5,05,06`、B3 `1,2,3,4,6,5`。
* `MinimumValveInSection`：**6 个区完全相同**，
  `DefaultValues.Easy = 0`（未 override）、`Normal = 1`（override=true）。
* 36 个阀门的 `PipeArrangementsNew[].AllowedByDifficulty` **完全一致**
  （Easy 未 override / Normal override=true），所以 `IsValid` 不是静态逐阀门开关。

## 4. 真实结构（0x143803600）

```text
cs   = GetSeed(coordinator)                       # 每区一个，互不相同
k    = sub_1402BF7F0(MinimumValveInSection, cs, count, 0)     # 每区要"处理"几个阀门
pool = copy(Valves)                               # 原序
for i in 0..k-1:                                  # ---- 61390 段 ----
    j    = RandSeeded(i + cs + 61390, pool.Num()) #   (uint16)Rand % Num
    cand = pool[j]
    if 该阀门可用:   SetState(cand, 1)
    else:            cand 归到"置 0"那批
    RemoveAtSwap(pool, j)                         # 0x140474270
# pool 剩下的 + 上面那批 全部 SetState(0)          # 0x1402947F0

valid = []                                        # ---- 39135 段 ----
for i in 0..count-1:                              # 注意：扫的是原始数组，不是余池
    if 分区已激活 and 有 ObjectiveActor 组件 and IsValid(valves[i]):
        if 开了距离过滤 and 与已选阀门太近: continue
        valid.add(i)
pick    = RandSeeded(cs + 39135, valid.Num())
主阀门   = valid[pick]                             # 索引是原序下标
```

关键地址：

| 地址 | 作用 |
|---|---|
| `0x143803600` | FirePump 分区/阀门随机化主函数 |
| `0x1402BF7F0` | 每区随机数量 `k`（整数区间或比例区间两种形态） |
| `0x140B47990` | `IsValid(候选)`：取 `ObjectiveActor` 组件后读一个 bool |
| `0x1402947F0` | `SetState(候选, state, 0)` |
| `0x140474270` | 候选数组 swap-remove |
| `0x140503B80` | 协调器 `GetSeed` |
| `0x1402D29E0` | `RandSeeded`，盐 = `关卡种子 % 1000` |

`RandSeeded` 的取模细节（IDA：`(uint16)sub_14270F020(seed,0) % count`）：
**必须先截 16 位再取模**，`x & 0xFFFF` 这一步漏了结果会全错（`tfs_mt03.py` 第一版就踩了）。

## 5. 脚本

```powershell
cd d:\workspace\outlast\release\home
python tfs_mt03.py 14014              # 同时打印「预选被排除 / 预选被选中」两路
python tfs_mt03.py 14014 --mode exclude
python tfs_mt03.py 14014 --k 0        # k=0 时 61390 段不跑，39135 直接在全池抽
python tfs_mt03.py 14014 --json
python tfs_mt03.py --fit              # 14014 实测房间 vs 各 (k, mode) 组合
```

## 6. 还没闭环的地方，以及需要什么实测

`python tfs_mt03.py --fit` 的输出里，逐区能命中 14014 观测房间的组合是：

| 分区 | 只有这些组合能命中 |
|---|---|
| B3 | k=1/3 排除；k=3/5 包含 |
| B2 | k=1/3/5 排除；k=7 包含 |
| B1 | k=0 排除（=全池）；k=1/2/3 包含 |
| A3 | k=1 排除；k=1..5 包含 |
| A1 | k=0..3/5 排除；k=4/5 包含 |
| **A2** | **只有 k=1/2/3「包含」**（排除一路任何 k 都不行） |

**没有任何一个统一的 `(k, mode)` 能同时命中 6 个区。** 最有力的两条约束是：

* **A2 必须用「包含」**：观测房间 `West_Processing` 只含 `A2_01/A2_02`，
  而「排除」一路无论 k 取多少都落在 `A2_04/A2_05`（ForemansOffice / PuppetWorshop）。
* **B3/B2/A1 必须用「排除」**：它们 61390 抽到的阀门房间分别是
  `Ext_LoadingDocks_Storage`、`East_Bathroom_Slave`、`West_Sorting`，都与观测不符。

单区最好成绩：`k=1 排除` 4/6（B3/B2/A3/A1）、`k=3 包含` 4/6（B3/B1/A3/A2）。
旧脚本 6/6 是靠逐区混用两条路换来的。

**要关掉这一处，需要再打一局 TFS_MT03 并记录（任一即可，越精确越好）：**

1. 每个区的**阀门 actor 名**（不是只记房间）——站在阀门前 HUD 一般会显示可交互目标名；
   或者用 `opp_seed/ui` 的点位图把 6 个阀门的编号抄下来。
   有了它就能直接判定「包含/排除」并顺带定出 k。
2. 次优：至少记清楚 **A2 和 B1 这两区的房间**（A2 是唯一能一票否决「排除」的区），
   外加**难度**（Easy / Normal 会改变 `MinimumValveInSection`，从而改变 k）。

历史对局里有 3 局 TFS_MT03 还没被用过：`406406`、`222222`（都是 Insane/4P）、
`769769`（Insane/4P）。`runs.csv` 里有 seed，但日志里没有阀门记录，所以拿不到真值。

## 7. 复用经验

* **先分清「真值」和「拟合出来的真值」**：`test.txt` 只记房间，脚本却拿 actor 名做断言，
  会让不确定的部分看起来像已验证。写新关卡时把两者分开标注。
* **一段 seed 常量不等于一条路径**：`61390`、`39135` 是同一条流程的两段，
  不要当成「两个候选，挑一个对的」。
* **`RandSeeded` 一定要先截 16 位再取模**。
* 候选池的**原序**必须从关卡 JSON 的 `Valves[]` 读，跳号（`A3` 没有 `_4`、
  `B2` 另有 `_5`）不能补。
