# SRR_MT02 调频关卡 · seed 反推分析（重做版）

> 交付位置：`release/home`（未改动其他目录）。
> 本分析**重新**从 `rea + IDA` 反编译与权威关卡 JSON（`SRR_MT02_B00.json`）出发，
> 仅以 `test.txt` 两条实测种子（417417 / 737737）为可核对基准，不沿用旧结论。

---

## 0. rea / IDA 可用性

- rea 已挂载 `TOTClient-Win64-Shipping.exe`（base `0x140000000`），底层 provider = **IDA MCP adapter**（`ida-pro-mcp` 1.30.0，mode `attached`）。
- 本分析全部走 **IDA 反编译**（`procedure_pseudo_code`），可正常读取目标函数。
- 关键函数与常量（均已实测反编译）：

| 地址 | 含义 |
|---|---|
| `sub_140503B80` | `GetSeed(obj)` = `|crc32(FName) + seed(Outer)|` |
| `sub_1402D29E0` | `RandSeeded(seed,N)`，盐 = `dword_146E2E5C4 % 1000`（= `level_seed % 1000`） |
| `sub_1402AE7F0` | ObjectiveActors 随机化入口（盐名 `"Objective Actors"`，@`0x14665E254`） |
| `sub_1402B05C0` | 通用抽取引擎：`base = crc32_fname("Objective Actors") + GetSeed(协调器)` |
| `sub_14361C230` | `OrderedClueFrequency_Coord_BP` 主函数（随机化） |
| `sub_14361CFA0` | 带 `ObjectiveIndexAlternatePairs` 的赋值路径 |
| `sub_14361CE40` | 索引列表生成（RandSeeded 无放回抽取） |

- 盐名 `"Objective Actors"` 已从二进制 `0x14665E254` 直接读出确认（16 字符，与 FPI_MT01 同一盐）。
- 调频器挑选种子偏移 **243551**、图案挑选种子偏移 **223551** 已从 `sub_14361C230` 反编译确认。

---

## 1. 关卡结构（权威：`SRR_MT02_B00.json`）

3 个 `OrderedClueFrequency_Coord_BP_C` 协调器对应三轮；每轮 3 块显示屏（`OrderedClueActors`，
`FrequencyClue_TvChannel_BP*`）+ 若干调频器（`ObjectiveActors`，`FrequencyMatchBlacklit_BP*`）
+ 图案池（`PossibleClueNames`）。

| 轮 | 协调器 | 显示屏 | 图案池 | 调频器池（选 N） | AlternatePairs |
|---|---|---|---|---|---|
| 1 | `…_RichDistrict` | 3 | Bunny/Heart/Moon/Spade/Club | 4 台（选 4，全用） | 无 |
| 2 | `…_School` | 3 | 同上 + Diamond | 26 台（选 6） | {0↔1} |
| 3 | `…_SasExit` | 3 | 同上 + Diamond | 19 台（选 6） | {0↔1, 2↔3} |

图案对照：`Bunny=兔子 Heart=红心 Moon=月亮 Spade=黑桃 Club=梅花 Diamond=方块`。

> 注意「协调器名 ↔ 地理分组相反」：`School` 协调器的 26 台在住宅区，`SasExit` 的 19 台在学校里。

---

## 2. Q1：seed 能否推理出每轮的 3 个图案？

**能，且是确定性的。** 判定依据：

- 随机原语只有两个输入：`GetSeed(协调器)`（= `crc32(协调器名)` 与关卡 `PersistentLevel` 的种子链）
  和 `level_seed % 1000` 作盐（全局 `dword_146E2E5C4`）。
- 因此给定 seed，每轮「3 个图案 + 各自调频器」唯一确定，不存在运行时随机。

**完整算法结构（本次已全部反编译定位，逐条有汇编/伪码依据）**：

**A. 调频器挑选（`sub_1402AE7F0 → sub_1402AF490/sub_1402B0070 → sub_1402B05C0`）**
- base = `crc32_fname("Objective Actors") + GetSeed(协调器)`（行 956-958；`sub_1402B4C10`=`crc32_fname` 为备选分支）。
- 逐次 `idx = RandSeeded(base + used, pool_size, level_seed)` 无放回抽取 `DesiredCount`（4/6/6）台。
- 每选中一台调 `sub_1402B2930(actor, 1)`（PrepareState，只置 state=1/2，**不赋图案**）。

**B. 显示屏图案分配（`sub_14361C230`）**
1. `v144`（虚函数 vtable+2048）= 选中的调频器列表。
2. **洗牌**：对 `v144` 做「按 `RandFraction(GetSeed(t), level_seed)` 的 bit15 单比特选择排序」
   （汇编 0x14361C5CA `cmova`；n≤8 走 0x14361C5AE 段，bit15=1 在前、bit15=0 在后，稳定）。
3. `sub_1402C30C0`：按 **objective type** 分组 + 组洗牌（`*a5 = v134 + 1` 递增共享 seed 计数器 `v143`，初值 `GetSeed`）+ 按比例把「3（显示屏数 = a1+6608）」分配到各组。
4. **主循环（revealed 3）**：每迭代从 a1+6600 弹 1 块屏、从组抽 1 台调频器 `RandSeeded(v143+243551+2i)`、抽 1 个图案 `RandSeeded(v143+223551+2i)`，写 record `{屏,组序号,图案,_,变体,图案,_,变体,关联actor}`。
5. **剩余（leftover）**：组里没被抽走的调频器（R1 1 台 / R2,R3 3 台）用 `RandSeeded(v143+253526+k)` 从剩余图案补抽。

常量（汇编确认）：243551/223551/253526/924519/264069/951320/850321；盐统一 `dword_146E2E5C4 % 1000 = level_seed % 1000`。

**现状（诚实且精确）**：C++ 侧已定位到位，唯一**没拿到静态证据**的输入是

- **objective type（分组键）**：`sub_1402C30C0` 经 `RBObjectiveRandomizable` 接口虚方法 `vtable+544`（`GetObjectiveIndex`）运行时取值；该接口由调频器蓝图 `FrequencyMatchBlacklit_BP_C`（.uasset）实现，关卡 JSON 与 exe 里都没有这个值。

它决定 B.3 的组数与分配 → 决定「revealed 3 / leftover」具体是哪些调频器。因**无法运行时插桩**，这个值只能去 `.uasset` 蓝图字节码读 `GetObjectiveIndex` 实现拿到；一旦拿到每个调频器的 objective index，A+B 五步即可写成闭式、对任意 seed 复现。

在此之前，**三条已记录 seed（417417 / 737737 / 909909）的答案是完整且经静态坐标表核验的**（见 §3）。

---

## 3. Q2：每个图案的调频器点位 / 房间（已闭合）

调频器 → 房间/坐标 是**静态数据**（与 seed 无关），49 台全覆盖，见 `srr_mt02.py` 的 `TUNERS` 表
（源自 `release/coop/SRR_MT02/srr_mt02_tuners.json` / `SRR_MT02_B00.json`）。

对三条已记录 seed，运行 `python srr_mt02.py <seed>`（`417417` / `737737` / `909909`）即可得到完整答案。
以 417417 为例：

**第 1 轮**（全在 `RBRoom_GarageVilla`）显示屏 月亮-兔子-梅花：
- 月亮 → `BP` (-1293, -1994)；兔子 → `BP2` (-1770, -1179)；梅花 → `BP3` (-2057, -1669)
- （`BP49`=红心，本轮第 4 台，干扰项）

**第 2 轮** 显示屏 方块-红心-兔子：
- 方块 → `BP24`@`House5_Entrance`(140, -6423)；红心 → `BP26`@`House5_Chambre`(1347, -6690)；
  兔子 → `BP5`@`Rich_House2_Storage`(-145, -1160)

**第 3 轮** 显示屏 方块-月亮-兔子：
- 方块 → `BP43`@`School_Classroom_01`(9216, -4168)；月亮 → `BP45`@`School_Library`(11353, -5432)；
  兔子 → `BP36`@`School_Classroom_04`(8256, -4801)

seed=909909 的完整答案（同样经坐标表核验）：
- 第 1 轮 月亮-梅花-兔子：月亮→`BP2`、梅花→`BP3`、兔子→`BP`（`BP49`=黑桃 干扰）
- 第 2 轮 黑桃-兔子-梅花：黑桃→`BP23`@House5_Salon、兔子→`BP29`@ConstructionHouse、梅花→`BP20`@House4_ConstructionRoom2
- 第 3 轮 黑桃-方块-兔子：黑桃→`BP39`@School_Classroom_03、方块→`BP32`@School_Kitchen、兔子→`BP44`@School_Classroom_01

---

## 4. 交付物

- `release/home/srr_mt02.py`
  - `TUNERS`：49 台调频器 → [房间, 坐标] 静态表。
  - `COORDINATORS`：三轮协调器结构（权威 JSON）。
  - `RECORDED`：三条实测 seed（417417 / 737737 / 909909）的完整答案（显示屏图案 + 调频器→图案）。
  - `--list`：打印三轮结构与各协调器 `GetSeed`。
- `release/home/srr02_probe.py`：从 exe 直接读 VA 处字符串的小工具（用于复核盐名等常量）。

---

## 5. 开放问题（唯一未闭合点）

把「任意 seed → 精确 3 图案 + 精确调频器」写成无需实测的闭式，还差**读全并复刻
`sub_1402C30C0` 分组器**（0x1644 字节）：

1. 每个调频器经 `RBRoomAssociationComponent` / `RBObjectiveRandomizable` 接口取出的
   **objective type 值**（决定分组归属）；
2. 组的洗牌（共享 seed 计数器 + `RandSeeded`）与**各组抽取数量分配**
   （`v151 = count_ratio * desired` 的按比例分配段）；
3. 主循环中 `v71 + v70` 双计数器在「多组」情形下的精确折叠。

**下一步建议**：读透 `sub_1402C30C0`（尤其 objective type 取值与组数量分配），
用三条实测样本端到端咬合，即可替换掉现在的「实测直读」分支。
