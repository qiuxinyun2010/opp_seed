# -*- coding: utf-8 -*-
"""SRR_MT02（郊区住宅区 · 有序调频 OrderedClueFrequency）seed 反推交付物。

结论摘要
========
1. 关卡由 3 个 `OrderedClueFrequency_Coord_BP_C` 协调器驱动，对应三轮。
2. 每个协调器：3 块显示屏（OrderedClueActors，TvChannel）+ N 台调频器（ObjectiveActors，
   FrequencyMatchBlacklit_BP*）+ 图案池（PossibleClueNames）。
3. seed → 图案/调频器 是**确定性**的（随机原语只用 GetSeed(协调器) 与 level_seed%1000 作盐）。
4. 49 台调频器的「房间 + 坐标」是静态数据（与 seed 无关），本文件 TUNERS 表已收录。
5. 图案→调频器 的对应随 seed 变化；本文件对两条已实测 seed（417417 / 737737）给出完整答案。

逆向来源（rea + IDA，TOTClient-Win64-Shipping.exe）
=================================================
  sub_140503B80  GetSeed(obj)           |crc32(FName) + seed(Outer)| 取 abs 32 位
  sub_1402D29E0  RandSeeded(seed,N)     盐 = dword_146E2E5C4 % 1000（= level_seed % 1000）
  sub_1402AE7F0  ObjectiveActors 随机化入口（盐名 "Objective Actors"，见 0x14665E254）
  sub_1402B05C0  通用抽取引擎：base = crc32_fname("Objective Actors") + GetSeed(协调器)
  sub_14361C230  OrderedClueFrequency 协调器主函数（BeginPlay 随机化）
  sub_14361CFA0  带 ObjectiveIndexAlternatePairs 的赋值路径
  sub_14361CE40  索引列表生成（RandSeeded 无放回抽取）

关键常量（IDA 实测）：
  GetSeed 盐名 "Objective Actors"（0x14665E254，16 字符，与 FPI_MT01 同一盐）
  调频器挑选种子偏移  243551（sub_14361C230 主路径 v120 = GetSeed + 243551）
  图案挑选种子偏移    223551（sub_14361CFA0 / sub_14361C230 的 v54/v123 = GetSeed + 223551）
  变体偏移            951320 / 850321 / 253526（用于变体，不影响主图案）

用法
====
  python srr_mt02.py              # 打印两条实测 seed 的完整答案
  python srr_mt02.py 417417       # 单条 seed
  python srr_mt02.py --list       # 列出三轮协调器结构
"""
import sys

M32 = 0xFFFFFFFF
M64 = 0xFFFFFFFFFFFFFFFF

_CRC_TAB = []
for _i in range(256):
    _c = _i
    for _ in range(8):
        _c = ((_c >> 1) ^ 0xEDB88320) if (_c & 1) else (_c >> 1)
    _CRC_TAB.append(_c & M32)


def crc32_fname(name):
    crc = M32
    for ch in name:
        u = ord(ch) & 0xFFFF
        crc = _CRC_TAB[(crc ^ (u & 0xFF)) & 0xFF] ^ (crc >> 8)
        crc = _CRC_TAB[(crc ^ (u >> 8)) & 0xFF] ^ (crc >> 8)
        crc = _CRC_TAB[crc & 0xFF] ^ (crc >> 8)
        crc = _CRC_TAB[crc & 0xFF] ^ (crc >> 8)
    return (~crc) & M32


def seed_of_object(name, outer_seed=0):
    v = (crc32_fname(name) + outer_seed) & M32
    return v if v < 0x80000000 else (0x100000000 - v) & M32


def get_seed(coord_name):
    return seed_of_object(coord_name, crc32_fname("PersistentLevel"))


def _mix64(seed, salt):
    a = (0xBF58476D1CE4E5B9 * ((seed ^ (seed >> 30)) & M64)) & M64
    a ^= a >> 27
    g = (salt % 1000) & M64
    b = (0xBF58476D1CE4E5B9 * g) & M64
    b ^= b >> 27
    v5 = (((0x94D049BB133111EB * a) & M64) ^ ((0x94D049BB133111EB * b) & M64)) & M64
    t = (v5 ^ (v5 >> 31)) & M64
    v6 = (0xBF58476D1CE4E5B9 * (t ^ (t >> 30))) & M64
    u = (v6 ^ (v6 >> 27)) & M64
    v7 = (((321982955 * u) & M64) ^ (((0x94D049BB133111EB * u) & M64) >> 31)) & M64
    return v7 & M32


def rand_seeded(seed, n, salt=0):
    if not n or not seed:
        return 0
    return (_mix64(seed & M32, salt) & 0xFFFF) % n


# ---------------------------------------------------------------------------
# 三轮协调器（源自 SRR_MT02_B00.json，权威）
# ---------------------------------------------------------------------------
COORDINATORS = {
    # 第 1 轮（富豪区入口）：4 台调频器全用（池=DesiredCount=4），5 选 4 图案
    "RichDistrict": {
        "name": "SRR_MT02_OrderedClueFrequency_RichDistrict",
        "screens": ["FrequencyClue_TvChannel_BP_RichDistrictEntrance_1",
                    "FrequencyClue_TvChannel_BP_RichDistrictEntrance_2",
                    "FrequencyClue_TvChannel_BP_RichDistrictEntrance_3"],
        "clues": ["Bunny", "Heart", "Moon", "Spade", "Club"],
        "objective": ["FrequencyMatchBlacklit_BP", "FrequencyMatchBlacklit_BP2",
                      "FrequencyMatchBlacklit_BP3", "FrequencyMatchBlacklit_BP49"],
        "desired": 4,
    },
    # 第 2 轮（学校停车场入口，住宅区 26 台选 6）
    "School": {
        "name": "SRR_MT02_OrderedClueFrequency_School",
        "screens": ["FrequencyClue_TvChannel_SchoolEntrance_1",
                    "FrequencyClue_TvChannel_SchoolEntrance_2",
                    "FrequencyClue_TvChannel_SchoolEntrance_3"],
        "clues": ["Bunny", "Heart", "Moon", "Spade", "Club", "Diamond"],
        "objective": ["FrequencyMatchBlacklit_BP23", "FrequencyMatchBlacklit_BP24",
                      "FrequencyMatchBlacklit_BP25", "FrequencyMatchBlacklit_BP27_3",
                      "FrequencyMatchBlacklit_BP26", "FrequencyMatchBlacklit_BP29",
                      "FrequencyMatchBlacklit_BP28", "FrequencyMatchBlacklit_BP16",
                      "FrequencyMatchBlacklit_BP17", "FrequencyMatchBlacklit_BP15",
                      "FrequencyMatchBlacklit_BP13", "FrequencyMatchBlacklit_BP14",
                      "FrequencyMatchBlacklit_BP4", "FrequencyMatchBlacklit_BP6",
                      "FrequencyMatchBlacklit_BP7", "FrequencyMatchBlacklit_BP5",
                      "FrequencyMatchBlacklit_BP19_22", "FrequencyMatchBlacklit_BP19",
                      "FrequencyMatchBlacklit_BP21", "FrequencyMatchBlacklit_BP20",
                      "FrequencyMatchBlacklit_BP22", "FrequencyMatchBlacklit_BP11",
                      "FrequencyMatchBlacklit_BP12", "FrequencyMatchBlacklit_BP10",
                      "FrequencyMatchBlacklit_BP8", "FrequencyMatchBlacklit_BP9"],
        "desired": 6,
    },
    # 第 3 轮（学校后院 SAS 出口，学校里 19 台选 6）
    "SasExit": {
        "name": "SRR_MT02_OrderedClueFrequency_SasExit",
        "screens": ["FrequencyClue_TvChannel_BP_SASExit_1",
                    "FrequencyClue_TvChannel_BP_SASExit_2",
                    "FrequencyClue_TvChannel_BP_SASExit_3"],
        "clues": ["Bunny", "Heart", "Moon", "Spade", "Club", "Diamond"],
        "objective": ["FrequencyMatchBlacklit_BP30", "FrequencyMatchBlacklit_BP31",
                      "FrequencyMatchBlacklit_BP33", "FrequencyMatchBlacklit_BP32",
                      "FrequencyMatchBlacklit_BP35", "FrequencyMatchBlacklit_BP34",
                      "FrequencyMatchBlacklit_BP38", "FrequencyMatchBlacklit_BP39",
                      "FrequencyMatchBlacklit_BP40", "FrequencyMatchBlacklit_BP41",
                      "FrequencyMatchBlacklit_BP42", "FrequencyMatchBlacklit_BP43",
                      "FrequencyMatchBlacklit_BP44", "FrequencyMatchBlacklit_BP37",
                      "FrequencyMatchBlacklit_BP36", "FrequencyMatchBlacklit_BP45",
                      "FrequencyMatchBlacklit_BP46", "FrequencyMatchBlacklit_BP47",
                      "FrequencyMatchBlacklit_BP48"],
        "desired": 6,
    },
}

# 轮次顺序（第 1 轮 RichDistrict，第 2 轮 School，第 3 轮 SasExit）
ROUND_ORDER = ["RichDistrict", "School", "SasExit"]

SYM_CN = {"Bunny": "兔子", "Heart": "红心", "Moon": "月亮",
          "Spade": "黑桃", "Club": "梅花", "Diamond": "方块"}

# ---------------------------------------------------------------------------
# 49 台调频器 -> [房间, 坐标]（静态，源自 srr_mt02_tuners.json / SRR_MT02_B00）
# ---------------------------------------------------------------------------
TUNERS = {
    "FrequencyMatchBlacklit_BP": ["RBRoom_GarageVilla", [-1293.1, -1993.9, 400.0]],
    "FrequencyMatchBlacklit_BP2": ["RBRoom_GarageVilla", [-1769.7, -1179.0, 400.0]],
    "FrequencyMatchBlacklit_BP3": ["RBRoom_GarageVilla", [-2057.0, -1669.0, 400.0]],
    "FrequencyMatchBlacklit_BP49": ["RBRoom_GarageVilla", [-2059.2, -1993.5, 400.0]],
    "FrequencyMatchBlacklit_BP4": ["RBRoom_Rich_House2_Chambre", [-362.6, -1680.7, 400.0]],
    "FrequencyMatchBlacklit_BP5": ["RBRoom_Rich_House2_Storage", [-144.6, -1159.7, 400.0]],
    "FrequencyMatchBlacklit_BP6": ["RBRoom_Rich_House2_Salon", [-59.0, -2224.0, 400.0]],
    "FrequencyMatchBlacklit_BP7": ["RBRoom_House2_Kitchen", [758.4, -1384.5, 400.0]],
    "FrequencyMatchBlacklit_BP8": ["RBRoom_Rich_House1_Storage", [1890.8, -1196.4, 400.0]],
    "FrequencyMatchBlacklit_BP9": ["RBRoom_Rich_House1_Bathroom", [2540.6, -988.8, 400.0]],
    "FrequencyMatchBlacklit_BP10": ["RBRoom_Rich_House1_Chambre", [2455.6, -1897.6, 400.0]],
    "FrequencyMatchBlacklit_BP11": ["RBRoom_Rich_House1_Salon", [3352.0, -2207.3, 400.0]],
    "FrequencyMatchBlacklit_BP12": ["RBRoom_Rich_House1_Salon", [3360.1, -1360.2, 400.0]],
    "FrequencyMatchBlacklit_BP13": ["RBRoom_Rich_House3_Salon", [-791.9, -4621.1, 400.0]],
    "FrequencyMatchBlacklit_BP14": ["RBRoom_Rich_House3_SmallStorage", [-15.1, -3665.7, 400.0]],
    "FrequencyMatchBlacklit_BP15": ["RBRoom_Rich_House3_Chambre", [652.7, -4197.7, 400.0]],
    "FrequencyMatchBlacklit_BP16": ["RBRoom_Rich_House3_BigStorage", [190.3, -5031.6, 400.0]],
    "FrequencyMatchBlacklit_BP17": ["RBRoom_Rich_House3_BigStorage", [652.4, -4547.4, 400.0]],
    "FrequencyMatchBlacklit_BP19": ["RBRoom_Rich_House4_ConstrcutionRoom2", [1497.1, -3585.8, 400.0]],
    "FrequencyMatchBlacklit_BP19_22": ["RBRoom_Rich_House4_ConstrcutionRoom2", [1374.9, -4180.6, 400.0]],
    "FrequencyMatchBlacklit_BP20": ["RBRoom_Rich_House4_ConstructionRoom2", [1919.2, -3971.5, 400.0]],
    "FrequencyMatchBlacklit_BP21": ["RBRoom_Rich_House4_ConstrcutionRoom1", [2132.7, -4109.3, 400.0]],
    "FrequencyMatchBlacklit_BP22": ["RBRoom_Rich_House4_Storage", [2553.0, -4911.1, 400.0]],
    "FrequencyMatchBlacklit_BP23": ["RBRoom_House5_Salon", [136.2, -6220.2, 400.5]],
    "FrequencyMatchBlacklit_BP24": ["RBRoom_House5_Entrance", [140.1, -6422.8, 400.5]],
    "FrequencyMatchBlacklit_BP25": ["RBRoom_House5_Entrance", [726.2, -6188.9, 400.5]],
    "FrequencyMatchBlacklit_BP26": ["RBRoom_House5_Chambre", [1347.4, -6689.6, 400.5]],
    "FrequencyMatchBlacklit_BP27_3": ["RBRoom_House5_Storage", [1277.0, -7069.8, 400.0]],
    "FrequencyMatchBlacklit_BP28": ["RBRoom_ConstructionHouse", [2447.1, -6267.4, 399.0]],
    "FrequencyMatchBlacklit_BP29": ["RBRoom_ConstructionHouse", [3024.9, -6267.7, 399.0]],
    "FrequencyMatchBlacklit_BP30": ["RBRoom_School_Secreteria", [5031.2, -2740.8, 400.0]],
    "FrequencyMatchBlacklit_BP31": ["RBRoom_School_Secreteria", [5911.2, -3158.7, 400.0]],
    "FrequencyMatchBlacklit_BP32": ["RBRoom_School_Kitchen", [4947.5, -5841.4, 400.0]],
    "FrequencyMatchBlacklit_BP33": ["RBRoom_School_Kitchen", [6552.9, -5840.8, 400.0]],
    "FrequencyMatchBlacklit_BP34": ["RBRoom_School_Toilet", [6641.0, -4824.6, 400.0]],
    "FrequencyMatchBlacklit_BP35": ["RBRoom_School_Toilet", [7006.3, -4142.2, 400.0]],
    "FrequencyMatchBlacklit_BP36": ["RBRoom_School_Classroom_04", [8255.5, -4800.6, 399.9]],
    "FrequencyMatchBlacklit_BP37": ["RBRoom_School_Classroom_04", [7908.3, -4333.5, 399.9]],
    "FrequencyMatchBlacklit_BP38": ["RBRoom_School_Classroom_03", [7510.2, -6094.9, 400.0]],
    "FrequencyMatchBlacklit_BP39": ["RBRoom_School_Classroom_03", [7730.7, -5443.3, 400.0]],
    "FrequencyMatchBlacklit_BP40": ["RBRoom_MusicClassroomStorage", [8785.7, -6005.5, 400.0]],
    "FrequencyMatchBlacklit_BP41": ["RBRoom_School_Classroom_02", [9562.4, -6158.6, 400.0]],
    "FrequencyMatchBlacklit_BP42": ["RBRoom_School_Classroom_02", [9286.7, -5555.4, 400.0]],
    "FrequencyMatchBlacklit_BP43": ["RBRoom_School_Classroom_01", [9215.7, -4167.5, 399.9]],
    "FrequencyMatchBlacklit_BP44": ["RBRoom_School_Classroom_01", [8405.1, -4170.7, 399.9]],
    "FrequencyMatchBlacklit_BP45": ["RBRoom_School_Library", [11353.4, -5431.5, 400.0]],
    "FrequencyMatchBlacklit_BP46": ["RBRoom_School_Library", [11233.3, -4202.8, 400.0]],
    "FrequencyMatchBlacklit_BP47": ["RBRoom_Exterior_WomenToilet", [9970.1, -2738.4, 400.0]],
    "FrequencyMatchBlacklit_BP48": ["RBRoom_Exterior_MaleToilet", [9978.3, -2328.1, 400.0]],
}

# ---------------------------------------------------------------------------
# 已实测 seed：轮 -> 显示屏 3 图案顺序 + {调频器: 图案}
# 来源 release/home/test.txt（实测记录）
# ---------------------------------------------------------------------------
RECORDED = {
    417417: {
        "RichDistrict": {
            "display": ["Moon", "Bunny", "Club"],
            "tuners": {"FrequencyMatchBlacklit_BP": "Moon",
                       "FrequencyMatchBlacklit_BP2": "Bunny",
                       "FrequencyMatchBlacklit_BP3": "Club",
                       "FrequencyMatchBlacklit_BP49": "Heart"},
        },
        "School": {
            "display": ["Diamond", "Heart", "Bunny"],
            "tuners": {"FrequencyMatchBlacklit_BP5": "Bunny",
                       "FrequencyMatchBlacklit_BP6": "Club",
                       "FrequencyMatchBlacklit_BP19": "Moon",
                       "FrequencyMatchBlacklit_BP24": "Diamond",
                       "FrequencyMatchBlacklit_BP26": "Heart",
                       "FrequencyMatchBlacklit_BP29": "Spade"},
        },
        "SasExit": {
            "display": ["Diamond", "Moon", "Bunny"],
            "tuners": {"FrequencyMatchBlacklit_BP36": "Bunny",
                       "FrequencyMatchBlacklit_BP38": "Club",
                       "FrequencyMatchBlacklit_BP43": "Diamond",
                       "FrequencyMatchBlacklit_BP45": "Moon",
                       "FrequencyMatchBlacklit_BP47": "Spade",
                       "FrequencyMatchBlacklit_BP31": "Heart"},
        },
    },
    737737: {
        "RichDistrict": {
            "display": ["Moon", "Spade", "Club"],
            "tuners": {"FrequencyMatchBlacklit_BP": "Heart",
                       "FrequencyMatchBlacklit_BP2": "Moon",
                       "FrequencyMatchBlacklit_BP3": "Spade",
                       "FrequencyMatchBlacklit_BP49": "Club"},
        },
        "School": {
            "display": ["Club", "Moon", "Heart"],
            "tuners": {"FrequencyMatchBlacklit_BP5": "Spade",
                       "FrequencyMatchBlacklit_BP8": "Diamond",
                       "FrequencyMatchBlacklit_BP11": "Heart",
                       "FrequencyMatchBlacklit_BP21": "Club",
                       "FrequencyMatchBlacklit_BP27_3": "Bunny",
                       "FrequencyMatchBlacklit_BP25": "Moon"},
        },
        "SasExit": {
            "display": ["Moon", "Heart", "Diamond"],
            "tuners": {"FrequencyMatchBlacklit_BP30": "Diamond",
                       "FrequencyMatchBlacklit_BP33": "Spade",
                       "FrequencyMatchBlacklit_BP37": "Club",
                       "FrequencyMatchBlacklit_BP45": "Heart",
                       "FrequencyMatchBlacklit_BP40": "Moon",
                       "FrequencyMatchBlacklit_BP47": "Bunny"},
        },
    },
    909909: {
        "RichDistrict": {
            "display": ["Moon", "Club", "Bunny"],
            "tuners": {"FrequencyMatchBlacklit_BP": "Bunny",
                       "FrequencyMatchBlacklit_BP2": "Moon",
                       "FrequencyMatchBlacklit_BP3": "Club",
                       "FrequencyMatchBlacklit_BP49": "Spade"},
        },
        "School": {
            "display": ["Spade", "Bunny", "Club"],
            "tuners": {"FrequencyMatchBlacklit_BP12": "Heart",
                       "FrequencyMatchBlacklit_BP20": "Club",
                       "FrequencyMatchBlacklit_BP8": "Diamond",
                       "FrequencyMatchBlacklit_BP29": "Bunny",
                       "FrequencyMatchBlacklit_BP23": "Spade",
                       "FrequencyMatchBlacklit_BP22": "Moon"},
        },
        "SasExit": {
            "display": ["Spade", "Diamond", "Bunny"],
            "tuners": {"FrequencyMatchBlacklit_BP32": "Diamond",
                       "FrequencyMatchBlacklit_BP33": "Moon",
                       "FrequencyMatchBlacklit_BP39": "Spade",
                       "FrequencyMatchBlacklit_BP44": "Bunny",
                       "FrequencyMatchBlacklit_BP40": "Club",
                       "FrequencyMatchBlacklit_BP45": "Heart"},
        },
    },
}


def render_seed(seed):
    print("=" * 78)
    print("SRR_MT02  seed = %d   (salt = %d)" % (seed, seed % 1000))
    print("=" * 78)
    for round_idx, rnd in enumerate(ROUND_ORDER, 1):
        rec = RECORDED[seed][rnd]
        print("\n【第 %d 轮 · %s】显示屏 3 图案: %s"
              % (round_idx, rnd,
                 " - ".join(SYM_CN[p] for p in rec["display"])))
        # 图案 -> 调频器（取与显示图案匹配的调频器）
        inv = {c: a for a, c in rec["tuners"].items()}
        for k, pat in enumerate(rec["display"], 1):
            actor = inv.get(pat)
            room, xyz = TUNERS.get(actor, ("?", [0, 0, 0]))
            print("   %d) %-4s -> 调频器 %-28s 房间 %-32s 坐标(%.0f, %.0f, %.0f)"
                  % (k, SYM_CN[pat], actor, room, xyz[0], xyz[1], xyz[2]))
        print("   （本回合全部调频器 %d 台，其中 3 台对应显示图案，其余为干扰项）" % len(rec["tuners"]))
        for actor, clue in rec["tuners"].items():
            room, xyz = TUNERS.get(actor, ("?", [0, 0, 0]))
            mark = " <- 显示" if clue in rec["display"] else "    (干扰)"
            print("        %s(%s) @ %s%s" % (SYM_CN[clue], actor.rsplit("_BP", 1)[-1], room, mark))


def list_structure():
    print("SRR_MT02 三轮协调器结构（源自 SRR_MT02_B00.json）：")
    for round_idx, rnd in enumerate(ROUND_ORDER, 1):
        c = COORDINATORS[rnd]
        print("  第 %d 轮 %-12s 协调器 %s" % (round_idx, rnd, c["name"]))
        print("      GetSeed = %d (0x%08x)" % (get_seed(c["name"]), get_seed(c["name"])))
        print("      显示屏 %d 块 | 图案池 %d | 调频器池 %d 台（选 %d）"
              % (len(c["screens"]), len(c["clues"]), len(c["objective"]), c["desired"]))
        print("      图案池: %s" % ", ".join(c["clues"]))


def main():
    if "--list" in sys.argv:
        list_structure()
        return
    seeds = [int(a) for a in sys.argv[1:] if a.isdigit()]
    if not seeds:
        seeds = sorted(RECORDED)
    for seed in seeds:
        if seed in RECORDED:
            render_seed(seed)
        else:
            print("seed=%d 暂无实测记录。当前算法结构已确定（确定性），"
                  "但任意 seed 的精确图案→调频器闭式仍需补充实测样本或读全 "
                  "sub_14361C230 / sub_1402B05C0 的分组抽取段。" % seed)


if __name__ == "__main__":
    main()
