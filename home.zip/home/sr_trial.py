# -*- coding: utf-8 -*-
"""SR_Trial（SuburbRiot_T08_B02）第 2 阶段：4 位密码房推理。

阶段结构（关卡 JSON `SuburbRiot_T08_B02.json`）：
    协调器  SR_B02_ObjCoord_MultiRoomPuzzle   (MultiroomPuzzle_Coordinator_BP_C)
    键盘    MultiroomPuzzleKeypad_BP_2        @(-3073, -574, 750.5)
    标牌    PrintableTextSign_BP_2            @(-3073, -488, 912)  "Check the sign in the bedroom"
    贴花    PasscodeDecal_BP*  ×68（全图，只有被选中的 4 间房里的 1 个生效）
    每个贴花有 DecalComponent（数字）+ OrderDecalComponent（第几位）

算法（全部来自 IDA 反编译，见 SR_TRIAL.md）：
    compSeed(room) = | crc32('RBPuzzleRoomComponent_0') + | crc32('PersistentLevel') + crc32(room) | |
    pool           = [0..9]，全 4 间房共用，抽走即从数组里删（保序，不是 swap-remove）
    第 k 间被处理的房：idx = RandSeeded(compSeed(room) + k + 7168, len(pool), seed % 1000)
                      digit = pool.pop(idx)                      # pool 现为 len 10-k
    → 4 个数字互不相同，按「处理顺序」拼成密码（贴花的 OrderDecal 显示的就是这个位置）

已验证样本（release/home/test.txt, seed=485485）：
    Bedroom=0  Office=8  GameRoom=5  Garage=6  →  0856

用法：
    python sr_trial.py 485485
    python sr_trial.py 485485 --trace
    python sr_trial.py 485485 --order Bedroom,Office,GameRoom,Garage   # 手动指定处理顺序
    python sr_trial.py --check                # 用 485485 自检
    python sr_trial.py --sections             # 打印分区/房间池
"""
import argparse
import json
import sys

M32 = 0xFFFFFFFF
LEVEL_OBJECT = 'PersistentLevel'
ROOM_COMPONENT = 'RBPuzzleRoomComponent_0'

# 协调器 SR_B02_ObjCoord_MultiRoomPuzzle 的 bUseDefinedSections=true 分支（顺序 = JSON 数组顺序）
SECTIONS = [
    ['RBRoom_Mansion2nd_GameRoom_Reward', 'RBRoom_Mansion2nd_Fireplace'],       # [0]
    ['RBRoom_Mansion1st_Office', 'RBRoom_Mansion1st_Bathroom_Reward'],          # [1]
    ['RBRoom_Mansion1st_Laundry', 'RBRoom_Mansion1st_Garage'],                  # [2]
    ['RBRoom_Mansion2nd_EscortBedroom'],                                        # [3]
]
PUZZLE_ROOM_COUNT = 4          # PuzzleRoomCount.NormalLocalValue
NORMAL_DECALS = 4              # NumberOfNormalDecals.NormalLocalValue

ROOM_LABEL = {
    'RBRoom_Mansion2nd_GameRoom_Reward': 'GameRoom',
    'RBRoom_Mansion2nd_Fireplace': 'Fireplace',
    'RBRoom_Mansion1st_Office': 'Office',
    'RBRoom_Mansion1st_Bathroom_Reward': 'Bathroom',
    'RBRoom_Mansion1st_Laundry': 'Laundry',
    'RBRoom_Mansion1st_Garage': 'Garage',
    'RBRoom_Mansion2nd_EscortBedroom': 'Bedroom',
}
LABEL_ROOM = {v: k for k, v in ROOM_LABEL.items()}

# CHJ_MT01 已证实的「分区排序 + 逐区补位」参数，SR_Trial 沿用（4/4 房间命中，见 SR_TRIAL.md §5）
SECTION_KEY_SEED = 48688       # 分区 randomID：RandSeeded(48688, |pool|)（CHJ 反推，待复核）
SIMILARITY_SEED = 93405        # 分区比较器：RandBool(randomID + 93405)
SECTION_PICK_OFFSET = 28042    # sub_14374E420：区內按 Minimum 抽房间 RandSeeded(剩余 + 28042, |pool|)
FILL_OFFSET = 28088            # sub_14374E420：补位 RandSeeded(剩余 + 28088, |pool|)
DIGIT_OFFSET = 7168            # sub_143620E70: RandSeeded(seed + 7168, |pool|)
SHUFFLE_OFFSET = 134123        # sub_1435F7860：房间列表洗牌 key = RandFraction(GetSeed(item) + 134123)

# 实测样本（test.txt）
SAMPLES = {
    485485: {
        'rooms': {                       # room -> (digit, 位置)
            'RBRoom_Mansion2nd_EscortBedroom': (0, 1),
            'RBRoom_Mansion1st_Office': (8, 2),
            'RBRoom_Mansion2nd_GameRoom_Reward': (5, 3),
            'RBRoom_Mansion1st_Garage': (6, 4),
        },
        'password': '0856',
        # 实测的处理顺序（= 位置 1..4 的房间顺序）
        'order': ['RBRoom_Mansion2nd_EscortBedroom', 'RBRoom_Mansion1st_Office',
                  'RBRoom_Mansion2nd_GameRoom_Reward', 'RBRoom_Mansion1st_Garage'],
        'sections': [1, 0, 3, 2],     # 反推的「洗牌前」分区顺序（28042 偏移口径）
    },
    500500: {
        'rooms': {
            'RBRoom_Mansion1st_Office': (0, 1),
            'RBRoom_Mansion2nd_GameRoom_Reward': (9, 2),
            'RBRoom_Mansion1st_Laundry': (8, 3),
            'RBRoom_Mansion2nd_EscortBedroom': (3, 4),
        },
        # test.txt 写的是 0984，但同段逐房记录是 Office=0 / GameRoom=9 / Laundry=8 / Bedroom=3，
        # 拼起来是 0983；模型也只在 0983 上有解（0984 无解）→ 以 0983 为准。
        'password': '0983',
        'order': ['RBRoom_Mansion1st_Office', 'RBRoom_Mansion2nd_GameRoom_Reward',
                  'RBRoom_Mansion1st_Laundry', 'RBRoom_Mansion2nd_EscortBedroom'],
        'sections': [1, 0, 2, 3],
    },
}


# ---------------------------------------------------------------------------
# 随机原语（sub_141CBDC30 / sub_140503B80 / sub_1402D29E0）
# ---------------------------------------------------------------------------
_CRC_TAB = []
for _i in range(256):
    _c = _i
    for _ in range(8):
        _c = ((_c >> 1) ^ 0xEDB88320) if (_c & 1) else (_c >> 1)
    _CRC_TAB.append(_c & M32)


def crc32_fname(name):
    """FName 的 CRC32：每个 16 位字符按 [lo, hi, 0, 0] 走 4 步（别用 zlib.crc32(utf-16-le)）。"""
    crc = M32
    for ch in name:
        u = ord(ch) & 0xFFFF
        crc = _CRC_TAB[(crc ^ (u & 0xFF)) & 0xFF] ^ (crc >> 8)
        crc = _CRC_TAB[(crc ^ (u >> 8)) & 0xFF] ^ (crc >> 8)
        crc = _CRC_TAB[crc & 0xFF] ^ (crc >> 8)
        crc = _CRC_TAB[crc & 0xFF] ^ (crc >> 8)
    return (~crc) & M32


def seed_of_object(name, outer_seed=0):
    """GetSeed 的名字兜底分支：|crc(name) + seed(Outer)|。"""
    v = (crc32_fname(name) + outer_seed) & M32
    return v if v < 0x80000000 else (0x100000000 - v) & M32


def rand_seeded(seed, n, salt=0):
    """sub_1402D29E0(seed, N) -> [0, N)，内部混入 dword_146E2E5C4 % 1000 作盐。"""
    if not n or not seed:
        return 0
    seed &= M32
    a = (0xBF58476D1CE4E5B9 * ((seed ^ (seed >> 30)) & M32)) & 0xFFFFFFFFFFFFFFFF
    a ^= a >> 27
    g = (salt % 1000) & 0xFFFFFFFFFFFFFFFF
    b = (0xBF58476D1CE4E5B9 * g) & 0xFFFFFFFFFFFFFFFF
    b ^= b >> 27
    v5 = (((0x94D049BB133111EB * a) & 0xFFFFFFFFFFFFFFFF) ^
          ((0x94D049BB133111EB * b) & 0xFFFFFFFFFFFFFFFF)) & 0xFFFFFFFFFFFFFFFF
    t = (v5 ^ (v5 >> 31)) & 0xFFFFFFFFFFFFFFFF
    v6 = (0xBF58476D1CE4E5B9 * (t ^ (t >> 30))) & 0xFFFFFFFFFFFFFFFF
    u = (v6 ^ (v6 >> 27)) & 0xFFFFFFFFFFFFFFFF
    v7 = (((321982955 * u) & 0xFFFFFFFFFFFFFFFF) ^
          (((0x94D049BB133111EB * u) & 0xFFFFFFFFFFFFFFFF) >> 31)) & 0xFFFFFFFFFFFFFFFF
    return (v7 & 0xFFFF) % n


def rand_fraction(seed, salt=0):
    """sub_1413F02F0(seed) -> [0,1)：同一个 64 位混合取低 16 位 / 65536。"""
    if not seed:
        return 0.0
    seed &= M32
    a = (0xBF58476D1CE4E5B9 * ((seed ^ (seed >> 30)) & M32)) & 0xFFFFFFFFFFFFFFFF
    a ^= a >> 27
    g = (salt % 1000) & 0xFFFFFFFFFFFFFFFF
    b = (0xBF58476D1CE4E5B9 * g) & 0xFFFFFFFFFFFFFFFF
    b ^= b >> 27
    v5 = (((0x94D049BB133111EB * a) & 0xFFFFFFFFFFFFFFFF) ^
          ((0x94D049BB133111EB * b) & 0xFFFFFFFFFFFFFFFF)) & 0xFFFFFFFFFFFFFFFF
    t = (v5 ^ (v5 >> 31)) & 0xFFFFFFFFFFFFFFFF
    v6 = (0xBF58476D1CE4E5B9 * (t ^ (t >> 30))) & 0xFFFFFFFFFFFFFFFF
    u = (v6 ^ (v6 >> 27)) & 0xFFFFFFFFFFFFFFFF
    v7 = (((321982955 * u) & 0xFFFFFFFFFFFFFFFF) ^
          (((0x94D049BB133111EB * u) & 0xFFFFFFFFFFFFFFFF) >> 31)) & 0xFFFFFFFFFFFFFFFF
    return (v7 & 0xFFFF) / 65536.0


def shuffle_rooms(rooms, level_seed, key='component'):
    """sub_1435F7860：把房间列表按「单比特分区」洗牌。

    每个房间的 key = RandFraction(GetSeed(房间) + 134123)（盐 = seed % 1000），
    bit = (key >= 0.5)。排序是「从末尾挑最后一个 bit=0 的元素换到末尾」的变体，
    等价于把 bit=1 的房间挤到前面、bit=0 的留在后面（同组内相对顺序会被打乱）。
    """
    salt = level_seed % 1000
    bits = {}
    for room in rooms:
        seed = room_component_seed(room) if key == 'component' else seed_of_object(
            room, crc32_fname(LEVEL_OBJECT))
        bits[room] = 1 if rand_fraction((seed + SHUFFLE_OFFSET) & M32, salt) >= 0.5 else 0
    out = list(rooms)
    end = len(out) - 1
    while end > 0:
        best = 0
        for j in range(1, end + 1):
            if bits[out[j]] == 0:      # 最后一个 bit=0 的元素
                best = j
        if best != end:
            out[best], out[end] = out[end], out[best]
        end -= 1
    return out, bits


def room_component_seed(room, level_name=LEVEL_OBJECT, component=ROOM_COMPONENT):
    """GetSeed(RBPuzzleRoomComponent_0) = |crc(组件) + |crc(关卡) + crc(房间)||。"""
    return seed_of_object(component, seed_of_object(room, crc32_fname(level_name)))


# ---------------------------------------------------------------------------
# 1) 选 4 间房（每区至少 MinimumPuzzleRoomsInSection=1 间）
# ---------------------------------------------------------------------------
def _section_keys(n, salt):
    pool = list(range(n))
    keys = []
    for _ in range(n):
        i = rand_seeded(SECTION_KEY_SEED, len(pool), salt) % len(pool)
        keys.append(pool.pop(i))
    return keys


def _rand_bool_key(key, salt):
    return rand_seeded((key + SIMILARITY_SEED) & M32, 2, salt) & 1


def _sort_sections(keys, salt):
    e = [{'id': i, 'cnt': 0, 'key': keys[i]} for i in range(len(keys))]
    for end in range(len(e) - 1, 0, -1):
        best = 0
        for j in range(1, end + 1):
            if e[best]['cnt'] == e[j]['cnt']:
                take = _rand_bool_key(e[best]['key'], salt)
            else:
                take = e[best]['cnt'] < e[j]['cnt']
            if take:
                best = j
        if best != end:
            e[best], e[end] = e[end], e[best]
    return [x['id'] for x in e]


def pick_rooms(level_seed, sections=None, want=PUZZLE_ROOM_COUNT, trace=False,
               section_order=None):
    """关卡种子 -> 本局 4 间密码房（按分区抽取顺序 = 密码位次）。

    section_order 可强制指定分区处理顺序；默认用 CHJ_MT01 已验证的排序器
    （注意：对 SR_Trial 它给出的顺序与实测不符，见 SR_TRIAL.md §6）。
    """
    sections = sections if sections is not None else SECTIONS
    salt = level_seed % 1000
    keys = _section_keys(len(sections), salt)
    order = list(section_order) if section_order is not None else _sort_sections(keys, salt)
    pools = {i: list(s) for i, s in enumerate(sections)}
    picked, remaining = [], want
    for sid in order:
        if remaining <= 0:
            break
        pool = pools[sid]
        if not pool:
            continue
        idx = rand_seeded(remaining + SECTION_PICK_OFFSET, len(pool), salt) % len(pool)
        room = pool.pop(idx)
        picked.append(room)
        if trace:
            print('    section=%d 剩余=%d idx=%d/%d -> %s'
                  % (sid, remaining, idx, len(pool) + 1, ROOM_LABEL[room]))
        remaining -= 1
    if trace:
        print('    keys=%s section_order=%s' % (keys, order))
    return picked, order


# ---------------------------------------------------------------------------
# 2) 4 位数字：共享 0..9 池，按「处理顺序」逐个房间抽
# ---------------------------------------------------------------------------
def assign_digits(level_seed, order, trace=False):
    """order = 房间处理顺序（= 贴花 OrderDecal 上的 1..4）。返回 [(room, digit)]。"""
    salt = level_seed % 1000
    pool = list(range(10))
    out = []
    for k, room in enumerate(order):
        comp = room_component_seed(room)
        idx = rand_seeded((comp + k + DIGIT_OFFSET) & M32, len(pool), salt)
        digit = pool.pop(idx)               # 保序删除（sub_143620E70 用 memmove）
        out.append((room, digit))
        if trace:
            print('    k=%d %-22s compSeed=%d seed=%d pool=%d idx=%d -> %d'
                  % (k, ROOM_LABEL[room], comp, (comp + k + DIGIT_OFFSET) & M32,
                     len(pool) + 1, idx, digit))
    return out


def password_of(pairs):
    return ''.join(str(d) for _r, d in pairs)


# ---------------------------------------------------------------------------
# 输出
# ---------------------------------------------------------------------------
def describe(level_seed, order=None, trace=False, section_order=None):
    """section_order = 分区处理顺序（可强制）；抽完房间后还要过一道洗牌才是位次顺序。"""
    rooms, used_sections = pick_rooms(level_seed, trace=trace,
                                      section_order=section_order)
    shuffled, bits = shuffle_rooms(rooms, level_seed)
    if trace:
        print('    洗牌前 = %s' % [ROOM_LABEL[r] for r in rooms])
        print('    洗牌 bit = %s' % {ROOM_LABEL[k]: v for k, v in bits.items()})
        print('    洗牌后 = %s' % [ROOM_LABEL[r] for r in shuffled])
    if order is None:
        order = shuffled                    # 位次顺序 = 洗牌后的容器数组顺序
    pairs = assign_digits(level_seed, order, trace=trace)
    return {
        'level': 'SR_Trial',
        'map': 'SuburbRiot/SuburbRiot_T08_B02',
        'seed': level_seed,
        'salt': level_seed % 1000,
        'sections': len(SECTIONS),
        'rooms': rooms,
        'rooms_shuffled': shuffled,
        'shuffle_bits': {ROOM_LABEL[k]: v for k, v in bits.items()},
        'section_order': used_sections,
        'section_order_source': 'arg' if section_order is not None else 'model',
        'order': order,
        'order_source': 'arg' if order != shuffled else 'pick+shuffle',
        'digits': [{'room': r, 'label': ROOM_LABEL[r], 'digit': d,
                    'position': order.index(r) + 1} for r, d in pairs],
        'password': password_of(pairs),
        'sample': SAMPLES.get(level_seed),
    }


def render(info):
    lines = ['SR_Trial  (SuburbRiot / SuburbRiot_T08_B02)  第2阶段 4 位密码',
             'seed = %d   salt = %d   分区抽取顺序 = %s'
             % (info['seed'], info['salt'], info['section_order'])]
    lines.append('  房间（1 间/分区，共 %d 间）:' % len(info['rooms']))
    for i, room in enumerate(info['rooms'], 1):
        lines.append('    %d. %-22s %s' % (i, ROOM_LABEL[room], room))
    lines.append('  数字（处理顺序 = 贴花 OrderDecal 上的位置）:')
    for item in info['digits']:
        lines.append('    第%d位 %-10s = %d' % (item['position'], item['label'], item['digit']))
    lines.append('  密码 = %s' % info['password'])
    if info['section_order_source'] == 'model':
        lines.append('  ! 分区处理顺序用的是 CHJ_MT01 的排序器；它在 SR_Trial 上与实测不符'
                     '（485485 实测 [3,1,0,2]）。请用 --section-order 指定，'
                     '或用贴花上的位置号校对。')
    sample = info['sample']
    if sample:
        lines.append('  实测：%s  (%s)'
                     % (sample['password'],
                        ' '.join('%s=%d' % (ROOM_LABEL[r], d)
                                 for r, (d, _p) in sample['rooms'].items())))
    return '\n'.join(lines)


def check():
    good = 0
    total = 0
    for seed, sample in sorted(SAMPLES.items()):
        total += 1
        # 1) 房间集合
        rooms_model, _sec_model = pick_rooms(seed)
        ok_set = sorted(rooms_model) == sorted(sample['rooms'])
        # 2) 位次顺序 → 数字（顺序本身由实测给出，链路见下）
        picked, _ = pick_rooms(seed, section_order=sample['sections'])
        shuffled, bits = shuffle_rooms(picked, seed)
        pairs = assign_digits(seed, sample['order'])
        ok_digits = password_of(pairs) == sample['password']
        # 3) 该顺序是否为唯一可行解：穷举 24 种
        import itertools
        hits = [p for p in itertools.permutations(sample['order'])
                if password_of(assign_digits(seed, list(p))) == sample['password']]
        ok = ok_set and ok_digits and len(hits) == 1
        good += 1 if ok else 0
        print('  seed %-7d 房间集合 %s  数字 %s vs %s  唯一顺序 %s  %s'
              % (seed, 'OK' if ok_set else 'MISMATCH',
                 password_of(pairs), sample['password'],
                 'YES' if len(hits) == 1 else '%d 解' % len(hits),
                 'PASS' if ok else 'FAIL'))
        print('       链路：抽房 %s → 洗牌后 %s ；实测位次顺序 %s  %s'
              % ([ROOM_LABEL[r] for r in picked],
                 [ROOM_LABEL[r] for r in shuffled],
                 [ROOM_LABEL[r] for r in sample['order']],
                 'OK' if shuffled == sample['order'] else '(不吻合，见 SR_TRIAL.md §4)'))
        print('       分区顺序(实测) = %s   分区顺序(模型) = %s'
              % (sample['sections'], _sec_model))
    print('自检：%d/%d 通过' % (good, total))
    return good == total


def main(argv=None):
    ap = argparse.ArgumentParser(description='SR_Trial 第 2 阶段（4 位密码）种子推理')
    ap.add_argument('seed', nargs='?', type=int)
    ap.add_argument('--order', help='房间处理顺序，如 Bedroom,Office,GameRoom,Garage')
    ap.add_argument('--section-order', help='分区处理顺序，如 3,1,0,2（决定房间顺序与位次）')
    ap.add_argument('--json', action='store_true')
    ap.add_argument('--trace', action='store_true')
    ap.add_argument('--sections', action='store_true')
    ap.add_argument('--check', action='store_true')
    args = ap.parse_args(argv)
    try:
        sys.stdout.reconfigure(encoding='utf-8')
    except Exception:
        pass

    if args.sections:
        for i, sec in enumerate(SECTIONS):
            print('[%d] %s' % (i, ', '.join('%s(%s)' % (ROOM_LABEL[r], r) for r in sec)))
        print('PuzzleRoomCount=%d  NumberOfNormalDecals=%d' % (PUZZLE_ROOM_COUNT, NORMAL_DECALS))
        return 0
    if args.check:
        return 0 if check() else 1
    if args.seed is None:
        ap.print_help()
        return 2

    order = None
    if args.order:
        order = []
        for part in args.order.split(','):
            part = part.strip()
            order.append(LABEL_ROOM.get(part, part))
    sec = None
    if args.section_order:
        sec = [int(x) for x in args.section_order.replace(' ', '').split(',') if x != '']
    info = describe(args.seed, order, trace=args.trace, section_order=sec)
    print(json.dumps(info, ensure_ascii=False, indent=2) if args.json else render(info))
    return 0


if __name__ == '__main__':
    sys.exit(main())
