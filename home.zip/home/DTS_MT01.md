# DTS_MT01（Downtown Riot Sewers）人偶目标：数据、模型与复现

> 玩法：人偶舞台。30 个启用人体模型中 1 个是真身（LargeObjectHandler），29 个是陷阱。
> 线索在电视上给出，玩家据此把真身搬回面包车。本文只保留**已验证事实**与**当前模型**；
> 历史试错过程已删除（git 历史可查）。

---

## 1. 线索结构（已验证）

| 线索 | 取值 | 来源 |
|---|---|---|
| 性别/body | **固定 Women** | 运行时 pose 变体；无区分度 |
| 字母+数字 | 武器编码 A1~B3 | 真身 Torso 的 `MannequinType`（武器枚举字节） |
| 房间 | **区域显示名**（如 IRISH PUB） | 真身 Torso 的 `RBRoomAssociationComponent`→`GetGameplayDisplayName` |

**武器码表**（`MannequinType` 枚举序 = 索引 0~5）：

| idx | 字母=idx//3 | 数字=idx%3+1 | 编码 | 武器 |
|---|---|---|---|---|
| 0 | A | 1 | A1 | Chainsaw |
| 1 | A | 2 | A2 | FaceDrill |
| 2 | A | 3 | A3 | HandDrill |
| 3 | B | 1 | B1 | Paddle |
| 4 | B | 2 | B2 | Scythe |
| 5 | B | 3 | B3 | Whip |

**区域（region）= 显示名分组**，一个区域含多个实际房间（如 IRISH PUB =
`RBRoom_Pub_Master` + `RBRoom_Pub_Slave01`）。要点：

- 每区域最多 6 种武器；**运行时启用集内 (区域, 武器) 唯一**（区域内同武器的人偶不重复出现）。
- 因此线索 (区域, 武器) → **唯一确定**目标人偶。
- 静态地图有 84 个人偶（15 个 (区域,武器) 格静态有 2~3 个重复，启用时被去重/丢弃，
  由 `ShouldDiscardOtherObjectiveActorForRandomization`（同武器+同房间族）保证）。

三条实测样本（判定基准）：

| 关卡种子 | 线索(区域, 武器) | 目标人偶（观测） | 在 30 抽位次 |
|---|---|---|---|
| 252252 | IRISH PUB, A1/Chainsaw | Chainsaw_BP_2 或 BP3_13（同区域同武器，观测记录 BP_2） | BP3_13 @16 |
| 61061 | GARAGE, B2/Scythe | Scythe_BP5_5 | @15 |
| 836836 | SPEAKEASY, B2/Scythe | Scythe_BP13_2 | @2 |
| 197197 | BANK VAULT, A3/HandDrill | （未记录编号） | — |

197197 的调频器观测（模型 2/3）：`[Child15_8, Child17_2, Child10_14]`。

---

## 2. 静态数据（查表）

- 人偶 setup 共 **84** 个（`DTR_MT01_ManneqinSetup_<武器>_BP*`），6 武器 × 14。
- **14 个区域**（括号内：武器种数 / 人偶数）：
  BANK VAULT(4/4)、CENTRALE(6/6)、ELECTRIC ROOM(6/6)、FIRE STATION(6/6)、
  GARAGE(6/15)、IRISH PUB(6/9)、LAUNDRY(6/8)、MOTEL(6/10)、OLD SUBWAY(5/5)、
  PHOTO BOOTH(4/4)、SNACK BAR(6/6)、SPEAKEASY(6/6)、
  RBRoom_StreetsPub_Master(1/1)、RBRoom_StreetsWorkerFashion(1/1)。
  静态重复集中在 GARAGE / IRISH PUB / LAUNDRY / MOTEL。
- 协调器实例（`DRS_MT01_GatherAndDeliver_Mannequin_ObjCoord_BP`）关键属性：
  `LargePickupActors=DTR_MT01_MannequinUpper_Base_BP_C`（Torso 类，候选=84 个躯干拾取物）、
  `DesiredCount=30`（每局启用 30 个）、`NumberOfTrappedPickups=29`（陷阱数）、
  `bSplitByObjectiveType=True`（按 `GetObjectiveTypeIndex=MannequinType` 分组）、
  `bUnlockAllLargePickupsOnStart=True`、`DistanceBetweenSameObjectives=0`。

---

## 3. 已锁定的随机机制

**原语**（`opp_seed/seedcore.py`，与 exe 反编译逐位一致）：

```
GetSeed(obj)  = |crc32_fname(name) + GetSeed(outer)|   （绝对值 32 位；链式）
rand_seeded(seed, n, salt) = (mix64(seed, salt) & 0xFFFF) % n     # salt=关卡种子%1000
rand_fraction(seed, salt)  = (mix64(seed, salt) & 0xFFFF) / 65536
```

**关键常量**（人偶协调器 `GetSeed = 0x1140E7D9`，与关卡种子无关）：

| 量 | 值 |
|---|---|
| crc("PersistentLevel") | 0x4C09CC22 |
| GetSeed(人偶协调器) | 0x1140E7D9 |
| 30 启用抽取基址 `\|crc("Large Objects")+GetSeed(coord)\|` | 0x90FB6FBF |
| 指定环常量（原生 `sub_14361C230` 族） | 243551 / 223551 / 951320 / 850321 / 253526 / 923495 / 264069 |

**「30 启用」抽取（已验证，3/3）**：池 = 84 人偶按名称升序，从 base 0x90FB6FBF 起
`idx = rand_seeded(base+k, 池剩余, salt)` swap-remove 连抽 30 个；3 样本真身全部落在抽中集
（位次 15/16/2）。

**真身注册与校验链（反编译确认）**：

```
指定环 vtable[297](coordinator, +3464, 1)  ← 人偶类 vtable 基址 0x1459A7300（激活=261）
AddObjectiveActor(actor, flag)   0x1433AA480：actor→RemainingObjectives(+3464)，预算+3480
交付校验 0x1437B8040：交付有效 ⇔ carried+168 ∈ +3464 且面板在互动清单
线索生成（BP，无随机）：全部派生自真身 torso 的 RoomAssociation / MannequinType
```

⇒ **「seed→真身」的最后缺口 = 原生指定环（vtable[297] 族）的选择规则**，
等价问题即「seed→(区域, 武器)」。

**同族先例（调频器面板；3 样本 3/3 后被第 4 样本打破）**：
`seed = |crc("Objective Actors") + GetSeed(DRS_MT01_Frequency_ObjCoord_BP2)| = 0x59B28CED`
池=19 面板，`rand_seeded(seed+k, 池剩余)` swap-remove 连抽 3。名称序+3-循环修正
在 252252/61061/836836 上 3/3，但 197197 只中 2/3（详见 §4）。

---

## 4. 第 4 样本（197197）裁决记录（2026-10-31）

**区域候选模型 S2 已被否决**：S2 预测 (ELECTRIC ROOM, Chainsaw)，实测 (BANK VAULT, HandDrill)。
（此前 3/3 是 ~8 万变体搜索的家族假阳性，符合预警。）「seed→区域」仍为未解问题。

**调频器池序问题（当前最大缺口）**：旧池（名称序+3-循环）对 197197 预测
`[Child17_2, Child12_11, Child10_14]`，实测 `[Child15_8, Child17_2, Child10_14]`——中 2/3。
更关键的是**已数学排除「静态池序 + 合理抽取形状」的全部可能**：

| 检验 | 结果 |
|---|---|
| 槽位矛盾（抽取种子 seed+k, k=0,1,2） | 4 样本要求 Child15_8 同时占两个槽 ⇒ 任何 19 名排列均不可行 |
| 形状网格：swap/顺序删除/独立抽 × 6 偏移组 × 6 盐函数（%1000/全值/0/%997/%991/%100）× 池 19/20 | **0 可解** |
| 动态排序 key 族（RandFraction/量化，18 常量×6 量化×2 方向×2 tie-break×前缀） | 无 ≥3/4 |
| 自然序（名称/JSON/名字表/导出号/坐标 x,y,z/长度/房间名） | 全 ≤2/4 |
| 丢弃重抽假设（min-distance） | 被距离数据推翻：252252 接受了相距仅 396 的一对，而 197197 被跳过的都在 1443+ |

唯一结构线索：旧池下 197197 的连抽流 =
`[17_2, 12_11, 10_14, 22, 9_26, 14_5, 4_2, 15_8]`，实测集合恰等于偏移 **(0, 2, 7)** 三抽
（中间 5 抽被跳过，机制不明）。

**裁决办法（三选一）**：
1. **复核 197197 记录**：当时 3 个面板里有没有 `Child12_11`（RBRoom22_7 / CENTRALE）？
   若实测其实含 12_11（或 15_8 是误记），旧模型立即 4/4，池序闭合；
2. 再补 1 条样本（最好带各面板房间名），5 样本可区分「观测误差」与「模型形状错」；
3. Frida hook `sub_1402B05C0`/`AddObjectiveActor` 抓一局抽取序列（一锤定音）。

### 4.1 距离重排假设的证明级否证（2026-10-31）

假设：抽取后若与已接受面板太近（`DistanceBetweenSameObjectives=1000`）则丢弃续抽。
**四种形态全部证伪（与池序无关的手工推演）**：

| 形态 | 否证 |
|---|---|
| 两两最小间距（点距/房间 AABB 间隙/房间中心距，任意 T） | `Child17_2`+`Child15_8` 在 252252 与 197197 **两局共存**，而两者点距仅 **396**、房间间隙 **100**——任何 T>396 的两两规则都会把第二抽丢掉 |
| 只对「上一个已接受」做距离检查（任意 T、任意度量） | 近邻集推演强制 `π[5]=Child10_14`（17_2/15_8 互为唯一近邻，二者都不可丢）；但 10_14 的槽位不在 836836 抽取流里 ⇒ 836836 永远收不到 10_14，矛盾。且 197197 的接受序要求 T≤1761，其内近邻集不变 ⇒ 全 T 域矛盾 |
| 对锚点（目标人偶/面包车/固定面板）距离合格性 | 0 解（197197 被跳过的反而更远） |
| 同 RBRoomGroup / 同显示区域 去重 | 252252 同时接受两个 Sewer 组面板（20_14/15_8）⇒ 否证 |

⇒ 若 197197 观测无误，剩下的只有：**动态池序**（key 函数未找到）或**非距离的重抽判据**。

---

## 5. 复现方式

```powershell
cd d:\workspace\outlast\release\home
python dts_mt01.py 836836            # 调频器 3 个 + 区域/武器/人偶预测 + 30 启用位次
python dts_mt01.py --samples         # 3 样本回归（调频器应 3/3）
python dts_mt01.py --regions         # 区域×武器矩阵（重复格标出）
python dts_mt01.py --mannequins      # 84 人偶（区域/武器/坐标/房间）
```

脚本输出中的「区域预测」即 §4 候选模型，标注为未验证；真身/陷阱判定以实测为准。

---

## 6. 关键文件

| 内容 | 路径 |
|---|---|
| 随机原语 | `opp_seed/seedcore.py` |
| 本关工具 | `release/home/dts_mt01.py` |
| 地图 JSON | `pak/OPP/Content/Maps_json/DowntownRiotSewers/DRS_MT01_B00.json` |
| MapSet/LD 蓝图 JSON | `pak/OPP/Content/MapSet/DowntownRiotSewers/Blueprints/Mannequins/`、`pak/OPP/Content/LD/Coordinators/LargeGatherDeliver/` |
| 线索文本表 | `pak/OPP/Content/LD/Objectives/BriefingTV/NarrativeScreen_DataTables/DTS1/TV_DTS_MT01_Clues_DT.json`（仅通用模板） |
| 前序阶段报告（只读） | `release/coop/DRS_MT01/DRS_MT01.md`、`drs_data.py` |
