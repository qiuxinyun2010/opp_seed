# -*- coding: utf-8 -*-
"""PSB_MT01 固化静态表 —— 由 tools/psb_gen.py 生成，勿手改。

数据源：pak/.../PSB_MT01_B00.json、PSB_MT01_B01.json、CorpseSearch_BP.json、
        opp_seed/ui/data/maps/PSB_MT01.json（房间 hull / 点位 → 房间）
"""

SECTORS = [
 {
  "key": "A",
  "kid": "KeyItemDestination_Device_Base_BP2",
  "tv": "Clue_TvChannel_LeftGate"
 },
 {
  "key": "B",
  "kid": "KeyItemDestination_Device_Base_BP3",
  "tv": "Clue_TvChannel_BP_6"
 },
 {
  "key": "C",
  "kid": "KeyItemDestination_Device_Base_BP_2",
  "tv": "Clue_TvChannel_RightGate"
 }
]

ZONES = [
 {
  "id": "A",
  "name_zh": "A 区 · 车库 / 轮胎库 / 后巷",
  "note_zh": "钥匙目的地 KeyItemDestination_Device_Base_BP2，线索电视 Clue_TvChannel_LeftGate（在体育馆）。15 具尸体：车库主厅/锅炉房/储藏/车间/办公室、轮胎库、后巷与后巷仓库、管道走廊 01。"
 },
 {
  "id": "B",
  "name_zh": "B 区 · 停尸房 / 维护区 / 管道北段",
  "note_zh": "钥匙目的地 KeyItemDestination_Device_Base_BP3，线索电视 Clue_TvChannel_BP_6（在体育馆）。10 具尸体：停尸房本体/楼梯/通道、发电机房、主楼梯、维修间、卫生间 4 间、管道走廊 02~05。"
 },
 {
  "id": "C",
  "name_zh": "C 区 · 靶场 / 档案 / 军械库",
  "note_zh": "钥匙目的地 KeyItemDestination_Device_Base_BP_2，线索电视 Clue_TvChannel_RightGate（在体育馆）。16 具尸体：靶场主厅与两条维护通道、档案室 3 号、军械库/军械车间/入口、施工区与施工通道、管道走廊 06、街道与街道入口。"
 }
]

# QuestItemClasses 顺序（release/coop/PSB_MT01/evidence/ADDR.md §1，非字母序）
QUEST_ITEM_CLASSES = ["Bunny", "Club", "Diamond", "Fire", "Heart", "Spade", "Crown", "Eye", "Moon", "Star"]

PATTERN_ZH = {"Bunny": "兔子", "Club": "梅花", "Diamond": "方块", "Fire": "火焰", "Heart": "红心", "Spade": "黑桃", "Crown": "王冠", "Eye": "眼睛", "Moon": "月亮", "Star": "五角星"}

# 图案 → 贴图（CluesMapping 的书写顺序，和 QuestItemClasses 顺序不同）
PATTERN_TEXTURE = {"Bunny": "Texture2D'cs_clue-03_M2'", "Club": "Texture2D'cs_clue-09_M'", "Diamond": "Texture2D'cs_clue-08_M'", "Fire": "Texture2D'cs_clue-06_M'", "Heart": "Texture2D'cs_clue-07_M'", "Spade": "Texture2D'cs_clue-10_M'", "Eye": "Texture2D'cs_clue-01_M'", "Star": "Texture2D'cs_clue-02_M'", "Crown": "Texture2D'cs_clue-04_M'", "Moon": "Texture2D'cs_clue-05_M'"}

# 41 具尸体：JSON(池)顺序 / 扇区 / 房间 id / 坐标
CORPSES = [
{
"i": 0,
"actor": "CorpseSearch_PS_Trial02_AgainstWall_BP2_5",
"sector": "A",
"room": 52,
"p": [
3459.1,
-1298.7,
0.1
],
"type": "AgainstWall"
},
{
"i": 1,
"actor": "CorpseSearch_PS_Trial02_AgainstWall_BP3_8",
"sector": "A",
"room": 17,
"p": [
1249.4,
905.8,
0.1
],
"type": "AgainstWall"
},
{
"i": 2,
"actor": "CorpseSearch_PS_Trial02_AgainstWall_BP4_11",
"sector": "A",
"room": 24,
"p": [
3041.7,
-2602.6,
0.1
],
"type": "AgainstWall"
},
{
"i": 3,
"actor": "CorpseSearch_PS_Trial02_AgainstWall_BP5_2",
"sector": "C",
"room": 49,
"p": [
-4414.5,
-2273.7,
0.1
],
"type": "AgainstWall"
},
{
"i": 4,
"actor": "CorpseSearch_PS_Trial02_AgainstWall_BP6_20",
"sector": "A",
"room": 16,
"p": [
1800.9,
312.1,
0.1
],
"type": "AgainstWall"
},
{
"i": 5,
"actor": "CorpseSearch_PS_Trial02_AgainstWall_BP7_23",
"sector": "C",
"room": 43,
"p": [
-3903.0,
-93.9,
1.7
],
"type": "AgainstWall"
},
{
"i": 6,
"actor": "CorpseSearch_PS_Trial02_AgainstWall_BP8_29",
"sector": "C",
"room": 5,
"p": [
-2642.1,
-2622.3,
0.1
],
"type": "AgainstWall"
},
{
"i": 7,
"actor": "CorpseSearch_PS_Trial02_AgainstWall_BP9_2",
"sector": "C",
"room": 14,
"p": [
-2237.6,
-3249.2,
-24.9
],
"type": "AgainstWall"
},
{
"i": 8,
"actor": "CorpseSearch_PS_Trial02_AgainstWall_BP_2",
"sector": "A",
"room": 18,
"p": [
2506.3,
-1737.1,
0.1
],
"type": "AgainstWall"
},
{
"i": 9,
"actor": "CorpseSearch_PS_Trial02_BP10_35",
"sector": "B",
"room": 31,
"p": [
-444.4,
612.2,
0.1
],
"type": "BP_C"
},
{
"i": 10,
"actor": "CorpseSearch_PS_Trial02_BP12_41",
"sector": "B",
"room": 35,
"p": [
-3102.6,
1797.1,
100.0
],
"type": "BP_C"
},
{
"i": 11,
"actor": "CorpseSearch_PS_Trial02_BP13_44",
"sector": "C",
"room": 1,
"p": [
-3170.1,
298.3,
0.1
],
"type": "BP_C"
},
{
"i": 12,
"actor": "CorpseSearch_PS_Trial02_BP15_50",
"sector": "C",
"room": 43,
"p": [
-3905.6,
-858.8,
0.1
],
"type": "BP_C"
},
{
"i": 13,
"actor": "CorpseSearch_PS_Trial02_BP19_62",
"sector": "C",
"room": 4,
"p": [
-2646.2,
1248.6,
0.1
],
"type": "BP_C"
},
{
"i": 14,
"actor": "CorpseSearch_PS_Trial02_BP20_65",
"sector": "C",
"room": 43,
"p": [
-2528.0,
-518.0,
0.1
],
"type": "BP_C"
},
{
"i": 15,
"actor": "CorpseSearch_PS_Trial02_BP2_20",
"sector": "A",
"room": 16,
"p": [
1910.8,
-161.7,
0.1
],
"type": "BP_C"
},
{
"i": 16,
"actor": "CorpseSearch_PS_Trial02_BP3_8",
"sector": "A",
"room": 22,
"p": [
2554.0,
-641.8,
0.1
],
"type": "BP_C"
},
{
"i": 17,
"actor": "CorpseSearch_PS_Trial02_BP4_11",
"sector": "A",
"room": 16,
"p": [
1947.6,
-408.8,
0.1
],
"type": "BP_C"
},
{
"i": 18,
"actor": "CorpseSearch_PS_Trial02_BP5_17",
"sector": "A",
"room": 52,
"p": [
2955.2,
-1795.0,
0.1
],
"type": "BP_C"
},
{
"i": 19,
"actor": "CorpseSearch_PS_Trial02_BP6_23",
"sector": "A",
"room": 16,
"p": [
2007.2,
1215.9,
0.1
],
"type": "BP_C"
},
{
"i": 20,
"actor": "CorpseSearch_PS_Trial02_BP7_2",
"sector": "C",
"room": 14,
"p": [
-2436.9,
-2409.2,
0.1
],
"type": "BP_C"
},
{
"i": 21,
"actor": "CorpseSearch_PS_Trial02_BP9_32",
"sector": "B",
"room": 35,
"p": [
-1805.5,
1864.9,
0.1
],
"type": "BP_C"
},
{
"i": 22,
"actor": "CorpseSearch_PS_Trial02_BP_2",
"sector": "A",
"room": 52,
"p": [
3153.3,
-1639.1,
0.1
],
"type": "BP_C"
},
{
"i": 23,
"actor": "CorpseSearch_PS_Trial02_Desk_BP2_2",
"sector": "B",
"room": 30,
"p": [
486.7,
2072.4,
0.1
],
"type": "Desk"
},
{
"i": 24,
"actor": "CorpseSearch_PS_Trial02_Desk_BP3_5",
"sector": "B",
"room": 32,
"p": [
-947.6,
2199.7,
0.1
],
"type": "Desk"
},
{
"i": 25,
"actor": "CorpseSearch_PS_Trial02_Desk_BP_5",
"sector": "B",
"room": 32,
"p": [
-690.0,
2551.0,
0.1
],
"type": "Desk"
},
{
"i": 26,
"actor": "CorpseSearch_PS_Trial02_OnChair_BP2_5",
"sector": "B",
"room": 25,
"p": [
-2286.0,
2399.2,
0.1
],
"type": "OnChair"
},
{
"i": 27,
"actor": "CorpseSearch_PS_Trial02_OnChair_BP3_8",
"sector": "C",
"room": 1,
"p": [
-3097.2,
711.2,
0.1
],
"type": "OnChair"
},
{
"i": 28,
"actor": "CorpseSearch_PS_Trial02_OnChair_BP4_11",
"sector": "C",
"room": 7,
"p": [
-3489.0,
-2961.3,
0.1
],
"type": "OnChair"
},
{
"i": 29,
"actor": "CorpseSearch_PS_Trial02_OnChair_BP5_14",
"sector": "C",
"room": 5,
"p": [
-3030.2,
-1835.5,
0.1
],
"type": "OnChair"
},
{
"i": 30,
"actor": "CorpseSearch_PS_Trial02_OnChair_BP7_23",
"sector": "C",
"room": 3,
"p": [
-4006.3,
540.3,
0.1
],
"type": "OnChair"
},
{
"i": 31,
"actor": "CorpseSearch_PS_Trial02_OnChair_BP8_5",
"sector": "C",
"room": 43,
"p": [
-2478.0,
14.9,
0.1
],
"type": "OnChair"
},
{
"i": 32,
"actor": "CorpseSearch_PS_Trial02_OnChair_BP_2",
"sector": "B",
"room": 32,
"p": [
-343.0,
2027.9,
0.1
],
"type": "OnChair"
},
{
"i": 33,
"actor": "CorpseSearch_PS_Trial02_WallThroat_BP2_5",
"sector": "A",
"room": 24,
"p": [
3402.4,
-3232.1,
0.1
],
"type": "WallThroat"
},
{
"i": 34,
"actor": "CorpseSearch_PS_Trial02_WallThroat_BP3_11",
"sector": "A",
"room": 16,
"p": [
1735.1,
1567.9,
0.1
],
"type": "WallThroat"
},
{
"i": 35,
"actor": "CorpseSearch_PS_Trial02_WallThroat_BP4_14",
"sector": "A",
"room": 17,
"p": [
1302.5,
81.2,
0.1
],
"type": "WallThroat"
},
{
"i": 36,
"actor": "CorpseSearch_PS_Trial02_WallThroat_BP5_17",
"sector": "B",
"room": 12,
"p": [
1116.2,
1478.1,
0.1
],
"type": "WallThroat"
},
{
"i": 37,
"actor": "CorpseSearch_PS_Trial02_WallThroat_BP7_26",
"sector": "B",
"room": 35,
"p": [
-1824.1,
2351.8,
0.1
],
"type": "WallThroat"
},
{
"i": 38,
"actor": "CorpseSearch_PS_Trial02_WallThroat_BP8_32",
"sector": "C",
"room": 43,
"p": [
-2999.5,
-549.0,
0.1
],
"type": "WallThroat"
},
{
"i": 39,
"actor": "CorpseSearch_PS_Trial02_WallThroat_BP9_35",
"sector": "C",
"room": 15,
"p": [
-882.2,
-2604.8,
0.1
],
"type": "WallThroat"
},
{
"i": 40,
"actor": "CorpseSearch_PS_Trial02_WallThroat_BP_2",
"sector": "A",
"room": 23,
"p": [
3468.1,
-243.9,
0.1
],
"type": "WallThroat"
}
]

ROOMS = {
"0": [
"RBRoom_Alley",
"小巷"
],
"1": [
"RBRoom_Archives01_Master",
"档案库01主区"
],
"2": [
"RBRoom_Archives01_Slave01",
"档案库01副区01"
],
"3": [
"RBRoom_Archives02",
"档案库02"
],
"4": [
"RBRoom_Archives03",
"档案库03"
],
"5": [
"RBRoom_armory",
"军械库"
],
"6": [
"RBRoom_ArmoryAccess",
"军械库通道"
],
"7": [
"RBRoom_ArmoryWOrkshop",
"军械库车间"
],
"8": [
"RBRoom_BackAlleyStore",
"后巷商店"
],
"9": [
"RBRoom_Bathroom",
"洗手间"
],
"10": [
"RBRoom_BathroomCorridor01_Master",
"洗手间走廊01主区"
],
"11": [
"RBRoom_BathroomCorridor01_Slave01",
"洗手间走廊01副区01"
],
"12": [
"RBRoom_BathroomCorridor02",
"洗手间走廊02"
],
"13": [
"RBRoom_BathroomLockers",
"洗手间储物柜区"
],
"14": [
"RBRoom_Construction",
"施工"
],
"15": [
"RBRoom_ConstructionCorridor",
"施工走廊"
],
"16": [
"RBRoom_GarageBoiler",
"车库锅炉房"
],
"17": [
"RBRoom_GarageBoilerCorridor",
"车库锅炉房走廊"
],
"18": [
"RBRoom_GarageMain_Master",
"车库主主区"
],
"19": [
"RBRoom_GarageMain_Slave01",
"车库主副区01"
],
"20": [
"RBRoom_GarageMain_Slave02",
"车库主副区02"
],
"21": [
"RBRoom_GarageOffice",
"车库办公室"
],
"22": [
"RBRoom_GarageStorage_Master",
"车库储藏室主区"
],
"23": [
"RBRoom_GarageStorage_Slave01",
"车库储藏室副区01"
],
"24": [
"RBRoom_GarageWorkshop",
"车库车间"
],
"25": [
"RBRoom_Generator",
"发电机"
],
"26": [
"RBRoom_Gym",
"体育馆"
],
"27": [
"RBRoom_GymAccess",
"体育馆通道"
],
"28": [
"RBRoom_GymAccessCorridor",
"体育馆通道走廊"
],
"29": [
"RBRoom_GymStorage",
"体育馆储藏室"
],
"30": [
"RBRoom_MainStairs",
"主楼梯"
],
"31": [
"RBRoom_Maintenance",
"维修间"
],
"32": [
"RBRoom_Morgue_Master",
"停尸房主区"
],
"33": [
"RBRoom_Morgue_Slave01",
"停尸房副区01"
],
"34": [
"RBRoom_MorgueAccess",
"停尸房通道"
],
"35": [
"RBRoom_MorgueStairs",
"停尸房楼梯"
],
"36": [
"RBRoom_PipesHallway01",
"管道区走廊01"
],
"37": [
"RBRoom_PipesHallway02",
"管道区走廊02"
],
"38": [
"RBRoom_PipesHallway03",
"管道区走廊03"
],
"39": [
"RBRoom_PipesHallway04_Master",
"管道区走廊04主区"
],
"40": [
"RBRoom_PipesHallway04_Slave01",
"管道区走廊04副区01"
],
"41": [
"RBRoom_PipesHallway05",
"管道区走廊05"
],
"42": [
"RBRoom_PipesHallway06",
"管道区走廊06"
],
"43": [
"RBRoom_ShootingRange",
"靶场"
],
"44": [
"RBRoom_ShootingRangeCorridor01",
"靶场走廊01"
],
"45": [
"RBRoom_ShootingRangeCorridor02",
"靶场走廊02"
],
"46": [
"RBRoom_ShootingRangeMaintenance_Master",
"靶场维修间主区"
],
"47": [
"RBRoom_ShootingRangeMaintenance_Slave01",
"靶场维修间副区01"
],
"48": [
"RBRoom_ShootingRangeMaintenance_Slave02",
"靶场维修间副区02"
],
"49": [
"RBRoom_ShootingRangeMaintenance_Slave03",
"靶场维修间副区03"
],
"50": [
"RBRoom_Street",
"街道"
],
"51": [
"RBRoom_StreetAccess",
"街道通道"
],
"52": [
"RBRoom_TireStorage",
"TireStorage"
]
}
