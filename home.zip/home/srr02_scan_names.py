# -*- coding: utf-8 -*-
"""SRR_MT02 图案抽取种子基全空间扫描 v3（多进程并行，逐 C 早退，~2 分钟）。

约束（test.txt 事实）：图案池 = PossibleClueNames（5/6 项，无过滤），第 k 抽
  seed = base_z + k，pos = (uint16)mix(seed, S) % n_k，交换删除。
H_A: base_z = (C + GetSeed(协调器)) & M32；H_B: base_z = C。

对每个 C 按约束选择性从高到低早退校验；16 进程并行，全扫约 2 分钟。
"""
import os
import sys
import time
import numpy as np
from multiprocessing import Pool

_HERE = os.path.dirname(os.path.abspath(__file__))
sys.path.insert(0, r'd:/workspace/outlast/opp_seed')
from seedcore import crc32_fname, seed_of_object, rand_seeded, M32  # noqa: E402

LEVEL_CRC = crc32_fname('PersistentLevel')
CS = {z: seed_of_object('SRR_MT02_OrderedClueFrequency_' + z, LEVEL_CRC)
      for z in ('RichDistrict', 'School', 'SasExit')}

# (zone, k, n, i, salt)：i 为交换删除池中的下标；顺序即校验顺序（先强后弱）
NAME_CONSTRAINTS = [
    ('RichDistrict', 0, 5, 2, 417), ('School', 0, 6, 5, 417),
    ('SasExit', 0, 6, 5, 417),
    ('RichDistrict', 1, 4, 0, 417), ('School', 1, 5, 1, 417),
    ('SasExit', 1, 5, 2, 417),
    ('RichDistrict', 2, 3, 2, 417), ('School', 2, 4, 0, 417),
    ('SasExit', 2, 4, 0, 417),
    ('RichDistrict', 3, 2, 1, 417),
    ('RichDistrict', 0, 5, 2, 737), ('School', 0, 6, 4, 737),
    ('SasExit', 0, 6, 2, 737),
    ('RichDistrict', 1, 4, 2, 737), ('School', 1, 5, 2, 737),
    ('SasExit', 1, 5, 1, 737),
    ('RichDistrict', 2, 3, 2, 737), ('School', 2, 4, 1, 737),
    ('SasExit', 2, 4, 3, 737),
    ('RichDistrict', 3, 2, 1, 737),
]
LEVEL = {417: 417417, 737: 737737}

M64 = (1 << 64) - 1
C1, C2, C3 = 0xBF58476D1CE4E5B9, 0x94D049BB133111EB, 321982955
BPART = {}
for _s in (417, 737):
    _g = _s % 1000
    _b = (C1 * _g) & M64
    _b ^= _b >> 27
    BPART[_s] = (C2 * _b) & M64

_MODE = 'HA'
_CONS = []


# 变体：offset_z 额外偏移（模拟「计数器先被调频器抽取消耗」）
# 注：交换删除与保序删除在这 20 条约束上给出的下标序列完全一致，无需变体。
ZONE_EXTRA = {'RichDistrict': 4, 'School': 6, 'SasExit': 6}


def _build(mode):
    """约束 → (delta, n, i, salt, bpart)。"""
    cons = []
    for (z, k, n, i, s) in NAME_CONSTRAINTS:
        if mode in ('HA', 'HJ', 'HJ2'):
            extra = 0
            if mode == 'HA':
                extra = CS[z]
            elif mode == 'HJ':
                extra = (CS[z] + ZONE_EXTRA[z]) & M32
            else:  # HJ2
                extra = ZONE_EXTRA[z]
            delta = (extra + k) & M32
        else:  # HB
            delta = k
        cons.append((delta, n, i, s, BPART[s]))
    return cons


def _init(mode):
    global _MODE, _CONS
    _MODE = mode
    _CONS = _build(mode)


def mix16(x, bpart):
    a = np.uint64(C1) * (x ^ (x >> np.uint64(30)))
    a ^= a >> np.uint64(27)
    v = (np.uint64(C2) * a) ^ np.uint64(bpart)
    t = v ^ (v >> np.uint64(31))
    w = np.uint64(C1) * (t ^ (t >> np.uint64(30)))
    u = w ^ (w >> np.uint64(27))
    v7 = (np.uint64(C3) * u) ^ ((np.uint64(C2) * u) >> np.uint64(31))
    return (v7 & np.uint64(0xFFFF)).astype(np.uint32)


def _scan_range(arg):
    lo, hi = arg
    keep = np.arange(lo, hi, dtype=np.uint64)
    CH = 1 << 20
    # 逐约束分块过滤（早退由约束排序带来的稀疏化近似，最终精确校验兜底）
    for (delta, n, i, s, bpart) in _CONS:
        out = []
        for p in range(0, keep.size, CH):
            part = keep[p:p + CH]
            x = (part + np.uint64(delta)) & np.uint64(0xFFFFFFFF)
            h16 = mix16(x, bpart)
            out.append(part[(h16 % np.uint32(n)) == np.uint32(i)])
        keep = np.concatenate(out) if out else keep[:0]
        if keep.size == 0:
            return []
    return [int(c) for c in keep]


def exact_check(c, mode):
    """用 seedcore 精确复算 20 条约束（与 _CONS 同一套 delta）。"""
    bad = []
    for (delta, n, i, s, _bp) in _CONS:
        if rand_seeded((c + delta) & M32, n, LEVEL[s]) != i:
            bad.append(delta)
    return bad


def run(mode):
    t0 = time.time()
    NW = 14
    span = 1 << 32
    step = span // (NW * 16)
    ranges = [(a, min(a + step, span)) for a in range(0, span, step)]
    found = []
    with Pool(NW, initializer=_init, initargs=(mode,)) as pool:
        for res in pool.imap_unordered(_scan_range, ranges):
            for c in res:
                bad = exact_check(c, mode)
                print('[%.0fs] C=0x%08X 失配=%s' % (time.time() - t0, c,
                      bad if bad else '无（20/20 全中！）'), flush=True)
                if not bad:
                    found.append(c)
    print('== %s 完成 %.0fs，精确全中: %s ==' % (mode, time.time() - t0,
          [hex(c) for c in found]))
    return found


if __name__ == '__main__':
    which = sys.argv[1] if len(sys.argv) > 1 else 'HA'
    run(which)
