# -*- coding: utf-8 -*-
"""TFS_MT03（玩具工厂 · 开启六个阀门）seed → 阀门点位。

与 release/coop/TFS_MT03/TFS_MT03.py 的区别：不再用 MAIN_SECOND 这个「每区换一条路径」
的黑箱，而是按 0x143803600 的真实结构实现，并把唯一还没定死的参数（61390 那一段抽
出来的 k 个阀门到底是「被排除」还是「被选中」）显式暴露出来。

真实结构（0x143803600，a1 = 单个 MT03_FirePump_ObjCoord_BP_SectionXX）：

    cs    = GetSeed(coordinator)                  # 每区一个协调器，NumberOfValveSections = 1
    k     = sub_1402BF7F0(MinimumValveInSection, cs + v79, count, 0)   # v79 = 0
    pool  = copy(Valves)                          # 候选原序，见 SECTIONS
    for i in 0..k-1:                              # 61390 段
        j    = RandSeeded(i + cs + 61390, pool.Num())
        cand = pool[j]
        if 候选可用: SetState(cand, 1)
        else:        cand 归到「置 0」那一批
        RemoveAtSwap(pool, j)                     # 0x140474270
    # pool 剩下的 + 上面那批 全部 SetState(0)
    valid = [i for i in 0..count-1
             if 分区已激活 and 有 ObjectiveActor 组件 and IsValid(valves[i])]
    pick  = RandSeeded(cs + 39135, valid.Num())
    主阀门 = valid[pick]

用法：
    python tfs_mt03.py 14014              # 六区：61390 预选 / 39135 全池 / 39135 余池
    python tfs_mt03.py 14014 --mode exclude   # 只输出「预选被排除」那一路的点位
    python tfs_mt03.py 14014 --mode include   # 只输出「预选被选中」那一路的点位
    python tfs_mt03.py 14014 --json
    python tfs_mt03.py --fit               # 14014 实测房间 vs 各 (k, mode) 组合
"""
import argparse
import json
import sys
import os

M32 = 0xFFFFFFFF
M64 = 0xFFFFFFFFFFFFFFFF

# 候选原序来自 TFS_LD_MT03_B00.json 的 ValveSectionGroupConfig[0].Sections[0].Valves
# （已逐区比对过，含 B2 的 07,01,02,03,04,5,05,06 和 B3 的 1,2,3,4,6,5 这些跳号）
SECTION_ORDER = ['B3', 'B2', 'B1', 'A3', 'A1', 'A2']
SECTIONS = {
    'A1': [('01', 'RBRoom_West_Storage'), ('02', 'RBRoom_West_Sorting'),
           ('03', 'RBRoom_West_Storage'), ('04', 'RBRoom_East_Painting'),
           ('05', 'RBRoom_East_Painting'), ('06', 'RBRoom_West_Sorting')],
    'A2': [('01', 'RBRoom_West_Processing'), ('02', 'RBRoom_West_Processing'),
           ('03', 'RBRoom_West_ForemansOffice_01'),
           ('04', 'RBRoom_West_ForemansOffice_02'),
           ('05', 'RBRoom_West_PuppetWorshop'),
           ('06', 'RBRoom_West_PuppetWorshop')],
    'A3': [('1', 'RBRoom_Ext_ReceivingDocks_Stairs_Slave_1'),
           ('2', 'RBRoom_Ext_ReceivingDocks'),
           ('3', 'RBRoom_ReceivingDocks_2ndFloor'),
           ('5', 'RBRoom_ReceivingDocks_OfficeBuilding'),
           ('6', 'RBRoom_ReceivingDocks_OfficeBuilding'),
           ('7', 'RBRoom_ReceivingDocks_OfficeBuilding_CenterRoom')],
    'B1': [('02', 'RBRoom_East_Electrical'), ('03', 'RBRoom_East_Electrical'),
           ('04', 'RBRoom_East_Construction'), ('08', 'RBRoom_East_Storage')],
    'B2': [('07', 'RBRoom_East_Laundry'), ('01', 'RBRoom_East_ToyStorage'),
           ('02', 'RBRoom_East_ToyStorage'), ('03', 'RBRoom_East_Bathroom_Master'),
           ('04', 'RBRoom_East_Bathroom_Slave'), ('5', 'RBRoom_East_Bathroom_Slave'),
           ('05', 'RBRoom_East_Bathroom_Master'), ('06', 'RBRoom_East_Laundry')],
    'B3': [('1', 'RBRoom_Ext_LoadingDocks_OfficeTrailer'),
           ('2', 'RBRoom_Ext_LoadingDocks_OfficeTrailer'),
           ('3', 'RBRoom_Ext_LoadingDocks_Shack_4'),
           ('4', 'RBRoom_Ext_LoadingDocks_Shack_4'),
           ('6', 'RBRoom_Ext_LoadingDocks_Storage'),
           ('5', 'RBRoom_Ext_LoadingDocks_Storage')],
}
VALVE_COORDS = {
    'MT03_TF_Gas_ValvePanel_BP_Section_A1_01': [-1595.0, 1435.0, 0.0],
    'MT03_TF_Gas_ValvePanel_BP_Section_A1_02': [-1581.73, 777.3, 0.0],
    'MT03_TF_Gas_ValvePanel_BP_Section_A1_03': [-780.0, 1365.0, 1.0],
    'MT03_TF_Gas_ValvePanel_BP_Section_A1_04': [-2192.99, -212.77, -21.98],
    'MT03_TF_Gas_ValvePanel_BP_Section_A1_05': [-2626.65, 38.5, -30.0],
    'MT03_TF_Gas_ValvePanel_BP_Section_A1_06': [-977.12, -437.46, 0.0],
    'MT03_TF_Gas_ValvePanel_BP_Section_A2_01': [-3422.62, 231.0, -25.0],
    'MT03_TF_Gas_ValvePanel_BP_Section_A2_02': [-3834.56, -238.99, -25.0],
    'MT03_TF_Gas_ValvePanel_BP_Section_A2_03': [-4851.94, 1525.07, -25.0],
    'MT03_TF_Gas_ValvePanel_BP_Section_A2_04': [-5040.0, 515.0, -25.0],
    'MT03_TF_Gas_ValvePanel_BP_Section_A2_05': [-5075.0, -1329.89, -25.0],
    'MT03_TF_Gas_ValvePanel_BP_Section_A2_06': [-4100.0, -1195.0, -25.0],
    'MT03_TF_Gas_ValvePanel_BP_Section_A3_1': [-1280.0, -2250.0, 150.0],
    'MT03_TF_Gas_ValvePanel_BP_Section_A3_2': [-2565.61, -1521.92, 315.0],
    'MT03_TF_Gas_ValvePanel_BP_Section_A3_3': [-2770.0, -1970.0, 300.0],
    'MT03_TF_Gas_ValvePanel_BP_Section_A3_5': [-3970.61, -2360.0, 250.0],
    'MT03_TF_Gas_ValvePanel_BP_Section_A3_6': [-3970.0, -3065.0, 250.0],
    'MT03_TF_Gas_ValvePanel_BP_Section_A3_7': [-3970.0, -2535.0, 250.0],
    'MT03_TF_Gas_ValvePanel_BP_Section_B1_02': [469.23, 4209.2, 0.0],
    'MT03_TF_Gas_ValvePanel_BP_Section_B1_03': [-40.0, 3890.0, 0.0],
    'MT03_TF_Gas_ValvePanel_BP_Section_B1_04': [-30.0, 2975.0, 0.0],
    'MT03_TF_Gas_ValvePanel_BP_Section_B1_08': [-480.0, 3230.0, 0.0],
    'MT03_TF_Gas_ValvePanel_BP_Section_B2_01': [-2486.1, 2784.16, 0.78],
    'MT03_TF_Gas_ValvePanel_BP_Section_B2_02': [-3280.0, 3015.0, 0.0],
    'MT03_TF_Gas_ValvePanel_BP_Section_B2_03': [-2025.0, 4665.0, -5.0],
    'MT03_TF_Gas_ValvePanel_BP_Section_B2_04': [-2825.0, 4705.0, -5.0],
    'MT03_TF_Gas_ValvePanel_BP_Section_B2_05': [-2885.15, 4572.04, -5.0],
    'MT03_TF_Gas_ValvePanel_BP_Section_B2_06': [-1395.0, 4780.0, 0.0],
    'MT03_TF_Gas_ValvePanel_BP_Section_B2_07': [-795.0, 3920.0, 0.78],
    'MT03_TF_Gas_ValvePanel_BP_Section_B2_5': [-3275.0, 4705.0, -5.0],
    'MT03_TF_Gas_ValvePanel_BP_Section_B3_1': [-2555.0, 5890.0, 98.0],
    'MT03_TF_Gas_ValvePanel_BP_Section_B3_2': [-2296.89, 6126.81, 98.0],
    'MT03_TF_Gas_ValvePanel_BP_Section_B3_3': [-680.0, 6775.0, 200.69],
    'MT03_TF_Gas_ValvePanel_BP_Section_B3_4': [-710.0, 7070.0, 200.69],
    'MT03_TF_Gas_ValvePanel_BP_Section_B3_5': [1435.0, 6635.0, 200.0],
    'MT03_TF_Gas_ValvePanel_BP_Section_B3_6': [1234.86, 7117.02, 200.0],
}

# test.txt 里 14014 只记录了房间（5 个区一个房间有 2 个候选阀门，所以只有房间级真值）
SAMPLE_14014_ROOM = {
    'B3': 'RBRoom_Ext_LoadingDocks_OfficeTrailer',
    'B2': 'RBRoom_East_Laundry',
    'B1': 'RBRoom_East_Construction',
    'A3': 'RBRoom_ReceivingDocks_OfficeBuilding',
    'A1': 'RBRoom_East_Painting',
    'A2': 'RBRoom_West_Processing',
}

_CRC_TAB = []
for _i in range(256):
    _c = _i
    for _ in range(8):
        _c = ((_c >> 1) ^ 0xEDB88320) if _c & 1 else _c >> 1
    _CRC_TAB.append(_c & M32)


def crc32_fname(name):
    crc = M32
    for ch in name:
        u = ord(ch) & 0xFFFF
        crc = _CRC_TAB[(crc ^ (u & 0xFF)) & 0xFF] ^ (crc >> 8)
        crc = _CRC_TAB[(crc ^ (u >> 8)) & 0xFF] ^ (crc >> 8)
        crc = _CRC_TAB[crc & 0xFF] ^ (crc >> 8)
        crc = _CRC_TAB[crc & 0xFF] ^ (crc >> 8)
    return (~crc) & M32


def seed_of_object(name, outer_seed=0):
    value = (crc32_fname(name) + outer_seed) & M32
    return value if value < 0x80000000 else (0x100000000 - value) & M32


def seed_chain(names):
    value = 0
    for name in names:
        value = seed_of_object(name, value)
    return value


def rand_seeded(seed, count, level_seed):
    """sub_1402D29E0：RandSeeded(seed, count)，盐 = 关卡种子 % 1000。"""
    if not count or not seed or not level_seed:
        return 0
    salt = level_seed % 1000
    a = (0xBF58476D1CE4E5B9 * ((seed ^ (seed >> 30)) & M64)) & M64
    a ^= a >> 27
    b = (0xBF58476D1CE4E5B9 * salt) & M64
    b ^= b >> 27
    v = ((0x94D049BB133111EB * a) & M64) ^ ((0x94D049BB133111EB * b) & M64)
    v ^= v >> 31
    v = (0xBF58476D1CE4E5B9 * (v ^ (v >> 30))) & M64
    v ^= v >> 27
    # IDA: (unsigned __int16)((unsigned __int16)sub_14270F020(seed,0) % count)
    return ((((321982955 * v) & M64) ^
             (((0x94D049BB133111EB * v) & M64) >> 31)) & 0xFFFF) % count


def swap_remove(items, index):
    items[index] = items[-1]
    items.pop()


def actor(section, index):
    return 'MT03_TF_Gas_ValvePanel_BP_Section_%s_%s' % (
        section, SECTIONS[section][index][0])


def room(section, index):
    return SECTIONS[section][index][1]


def preselect(cs, count, k, level_seed):
    """61390 段：抽 k 个，每个都是 RemoveAtSwap。"""
    pool = list(range(count))
    drawn = []
    for i in range(k):
        if not pool:
            break
        j = rand_seeded(i + cs + 61390, len(pool), level_seed)
        drawn.append(pool[j])
        swap_remove(pool, j)
    return drawn


def valid_list(cs, count, k, mode, level_seed):
    """39135 段抽之前的有效候选表（原序）。"""
    drawn = preselect(cs, count, k, level_seed) if k else []
    if mode == 'include':
        return sorted(drawn)
    return [i for i in range(count) if i not in drawn]


def predict(level_seed, k=1, mode='exclude'):
    out = []
    for section in SECTION_ORDER:
        cs = seed_chain(['PersistentLevel',
                         'MT03_FirePump_ObjCoord_BP_Section' + section])
        count = len(SECTIONS[section])
        drawn = preselect(cs, count, k, level_seed) if k else []
        valid = valid_list(cs, count, k, mode, level_seed)
        pick = rand_seeded(cs + 39135, len(valid), level_seed) if valid else -1
        idx = valid[pick] if pick >= 0 else -1
        item = {
            'section': section,
            'coordinator_seed': cs,
            'candidate_count': count,
            'preselected': [actor(section, i) for i in drawn],
            'preselected_rooms': [room(section, i) for i in drawn],
            'valid_indices': valid,
            'pick': pick,
            'valve_index': idx,
            'actor': actor(section, idx) if idx >= 0 else None,
            'room': room(section, idx) if idx >= 0 else None,
            'coordinates': VALVE_COORDS[actor(section, idx)] if idx >= 0 else None,
            'mode': mode, 'k': k,
        }
        out.append(item)
    return out


def fit(level_seed=14014):
    print('14014 实测房间 vs (k, mode) 组合（只列命中的）')
    for section in SECTION_ORDER:
        cs = seed_chain(['PersistentLevel',
                         'MT03_FirePump_ObjCoord_BP_Section' + section])
        count = len(SECTIONS[section])
        want = SAMPLE_14014_ROOM[section]
        print('\n%-3s n=%d 实测=%s' % (section, count, want))
        for k in range(0, count):
            for mode in ('exclude', 'include'):
                valid = valid_list(cs, count, k, mode, level_seed)
                if not valid:
                    continue
                p = rand_seeded(cs + 39135, len(valid), level_seed)
                if room(section, valid[p]) == want:
                    print('    k=%d %-7s valid=%-24s pick=%d -> %s'
                          % (k, mode, valid, p, actor(section, valid[p])))


def main():
    ap = argparse.ArgumentParser(
        description=__doc__, formatter_class=argparse.RawDescriptionHelpFormatter)
    ap.add_argument('seed', nargs='?', type=int)
    ap.add_argument('--k', type=int, default=1,
                    help='61390 段抽几个（MinimumValveInSection，默认 1）')
    ap.add_argument('--mode', default=None, choices=('exclude', 'include'),
                    help='预选出的阀门是被排除(默认)还是被选中')
    ap.add_argument('--json', action='store_true', dest='as_json')
    ap.add_argument('--fit', action='store_true', help='14014 拟合表')
    args = ap.parse_args()

    if args.fit:
        fit()
        return
    if args.seed is None:
        ap.print_help()
        return

    modes = (args.mode,) if args.mode else ('exclude', 'include')
    tables = [(m, predict(args.seed, args.k, m)) for m in modes]
    if args.as_json:
        print(json.dumps([t[1] for t in tables], ensure_ascii=False, indent=2))
        return

    print('TFS_MT03  seed=%d  k=%d' % (args.seed, args.k))
    for mode, rows in tables:
        print('\n--- 预选阀门被%s ---' % ('排除' if mode == 'exclude' else '选中'))
        for item in rows:
            print('  %-3s %-44s %-42s %s'
                  % (item['section'], item['actor'] or '(无有效候选)',
                     item['room'] or '', item['coordinates'] or ''))
            print('       预选=%s' % (', '.join(item['preselected']) or '无'))


if __name__ == '__main__':
    main()
