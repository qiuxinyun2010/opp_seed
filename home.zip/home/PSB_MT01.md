# PSB_MT01「警察局地下室 · 找钥匙把受试者送进粉碎机」

> 本轮（2026-10-30）在 `release/home/` 内的产物。上一轮的静态结论在
> `release/coop/PSB_MT01/`（只读参考）。
>
> **状态：Q1「seed → 每区钥匙图案」✅ 闭环（12/12 实测通过，全 2³² 唯一解）。**
> **Q2「图案落在哪一具尸体」🟡 算法已完全确定，还差一个未知量（候选组的初始顺序）。**

---

## 0. 一句话结论

```
一局要的东西 = 3 个扇区 × (1 张图案 + 1 具尸体)

Q1 ✅ seed → 3 张钥匙图案：
    B      = 0xCD055621             ← 全 2³² 扫描的唯一解
    组序   = A(3 具) → C(4 具) → B(3 具)，共 10 具
    图案   = pool[ RandSeeded(B + 223551 + V + j, |pool|, salt = S % 1000) ]
             抽走即 RemoveAt（保序）→ 10 具图案互不重复
    钥匙   = 该组**第 1 具**的图案（j == 0）
                                                        ✅ 12/12 实测
Q2 🟡 图案 → 尸体：
    尸体   = group[ RandSeeded(B + 243551 + V + j, |group|, salt) ]，同样保序删除
    group  = 该扇区的候选尸体（A 15 / B 10 / C 16）
    差的就是 **每个 group 的初始顺序**（见 §6）
```

`V` = 全局已抽计数，`j` = 组内序号；代码里两者都在自增，所以**盐是 `S_g + 2j`**
（`S_g` = 本组开始前已抽的总数：A 组 0,2,4；C 组 3,5,7,9；B 组 7,9,11）。

实测三条 seed 全部命中：

| seed | salt | A | B | C |
|---|---|---|---|---|
| 111111 | 111 | 五角星 Star | 兔子 Bunny | 方块 Diamond |
| 565565 | 565 | 红心 Heart | 梅花 Club | 眼睛 Eye |
| 378378 | 378 | 月亮 Moon | 火焰 Fire | 黑桃 Spade |

378378 还额外对上了「每区出现过的图案集合」（A=月亮/王冠/红心、B=火焰/方块/兔子、
C=黑桃/眼睛/梅花 + 一颗未记录的五角星）。

---

## 1. 直接可用

```powershell
cd d:\workspace\outlast\release\home

python psb_mt01.py 565565           # ★ 3 个区的钥匙图案 + 每区几具 / 各显示什么
python psb_mt01.py 417417 --json    # 机器可读
python psb_mt01.py --sectors        # 3 个扇区：锁位 / 线索电视 / 尸体数 / 区域
python psb_mt01.py --corpses        # 41 具尸体：池序号 / 扇区 / 房间 / 坐标
python psb_mt01.py --corpses A      # 只看 A 区
python psb_mt01.py --find 靶场       # 按房间名/尸体名模糊查候选
python psb_mt01.py --pool           # 10 个图案：池顺序 / 贴图 / 中文
python psb_mt01.py --known          # 三条实测样本回放
python psb_mt01.py --selftest       # 51/51（含 seed→图案 9/9 + 图案集合 3/3）
python tools\psb_model.py 378378    # 只算图案，打印抽取过程（j/V/图案）
python tools\psb_gen.py             # 重新生成 psb_mt01_static.py（读 pak + ui 数据）
```

Python API：

```python
import psb_mt01 as m
m.key_patterns(565565)      # {'A':'Heart','B':'Club','C':'Eye'}
m.patterns_of(565565)       # [('A',[(0,'Heart'),(1,'Crown'),(2,'Star')]), ('C',...), ('B',...)]
m.corpses_of('C')           # 16 具 C 区候选尸体（含房间 + 坐标）
m.room_of(m.S.CORPSES[7])   # 'RBRoom_Construction'
```

---

## 2. 静态结构（全部来自 pak，本机可复核）

### 2.1 三个扇区

| Sector | 钥匙锁位 `KeyItemDestination_Device_Base_*` | 线索电视 `Clue_TvChannel_*` | 候选尸体 | 区域 |
|---|---|---|---|---|
| A | `..._BP2` | `LeftGate` | 15 | 车库 / 轮胎库 / 后巷 |
| B | `..._BP3` | `BP_6` | 10 | 停尸房 / 维护区 / 管道北段 |
| C | `..._BP_2` | `RightGate` | 16 | 靶场 / 档案 / 军械库 |

- 顺序来源：`PSB_MT01_B00.json` 里协调器 `PSB_MT01_B01_CorpseSearch_3`
  （类 `PoliceStation_Trial2_QuestItemCoord_BP_C`）的 `ObjectiveActors` 数组，
  与 `FindKeyLineTexts` 的 `Sector A/B/C Key` 一一对应。
- 协调器配置（`PSB_MT01_B00.json` 实测，不是猜的）：
  `SpawnerActorsRandomizationSetup.DesiredCount = 10`（NormalLocalValue）、
  `bSplitByObjectiveType = true`；`PrimaryActorsRandomizationSetup` 全空。
  LD 默认里 `MinCount/MaxCount = 10/10`、`ItemSpawnerClass = CorpseSearch_BP_C`。

### 2.2 41 具尸体 = 候选池（一局只刷 10 具）

5 种姿势：地面 14 / 靠墙 9 / 墙喉 8 / 椅子 7 / 桌子 3。
每具尸体上写死 `SpecificObjectiveActorTarget`（它装的钥匙属于哪个扇区）：

| 扇区 | 候选数 | 一局实际出现 | 大致方位 |
|---|---|---|---|
| A | 15 | 3（1 真 + 2 假） | 东侧（X > 0） |
| B | 10 | 3（1 真 + 2 假） | 北侧（Y > 600） |
| C | 16 | **4**（1 真 + 3 假） | 西侧（X < −2000） |

`python psb_mt01.py --corpses` 全表；房间由 `opp_seed/ui/data/maps/PSB_MT01.json`
的 hull 判定，**已用实测 13/13 核对过**（`--selftest`）。

### 2.3 10 个图案（池顺序 = `QuestItemClasses`，**不是字母序**）

| # | 类 | 图案 | 中文 |
|---|---|---|---|
| 0 | `..._QuestItem_Bunny_BP` | Bunny | 兔子 |
| 1 | `..._QuestItem_Club_BP` | Club | 梅花 |
| 2 | `..._QuestItem_Diamond_BP` | Diamond | 方块 |
| 3 | `..._QuestItem_Fire_BP` | Fire | 火焰 |
| 4 | `..._QuestItem_Heart_BP` | Heart | 红心 |
| 5 | `..._QuestItem_Spade_BP` | Spade | 黑桃 |
| 6 | `..._QuestItem_Crown_BP` | Crown | 王冠 |
| 7 | `..._QuestItem_Eye_BP` | Eye | 眼睛 |
| 8 | `..._QuestItem_Moon_BP` | Moon | 月亮 |
| 9 | `..._QuestItem_Star_BP` | Star | 五角星 |

`..._QuestItem_Plain_BP`（无图案）不在池里。
贴图映射 `CluesMapping` 的书写顺序与池顺序不同，**不能拿 `CluesMapping` 的下标当池下标**。

---

## 3. 实测样本回放（`release/home/test.txt`）

### 3.1 seed 565565

| 扇区 | 图案 | 钥匙尸体 | 房间 |
|---|---|---|---|
| A | 红心 | `AgainstWall_BP3_8` | `RBRoom_GarageBoilerCorridor` |
| B | 梅花 | `BP10_35` | `RBRoom_Maintenance` |
| C | 眼睛 | `AgainstWall_BP9_2` | `RBRoom_Construction` |
| （干扰，记录为 C） | 方块 | `AgainstWall_BP5_2` | `RBRoom_ShootingRangeMaintenance_Slave03` |

⚠️ 模型把「方块」算到 **B 区**（B 的图案是 梅花/方块/兔子），而这具尸体在静态表里属于
C 区。两条路：要么玩家记录时把它归错了区，要么 `AgainstWall_BP5_2` 的
`SpecificObjectiveActorTarget` 其实指向 B 的 KID。已在 §6 列为待复核项。

### 3.2 seed 378378（完整样本：9 具 + 图案）

| 扇区 | 尸体 | 房间 | 图案 |
|---|---|---|---|
| A | `AgainstWall_BP2_5` | `RBRoom_TireStorage` | 红心 |
| A | `BP3_8` | `RBRoom_GarageStorage_Master` | 王冠 |
| A | `AgainstWall_BP_2` | `RBRoom_GarageMain_Master` | **月亮 ← 钥匙** |
| B | `Desk_BP_5` | `RBRoom_Morgue_Master` | 方块 |
| B | `WallThroat_BP7_26` | `RBRoom_MorgueStairs` | **火焰 ← 钥匙** |
| B | `Desk_BP2_2` | `RBRoom_MainStairs` | 兔子 |
| C | `BP7_2` | `RBRoom_Construction` | 眼睛 |
| C | `WallThroat_BP8_32` | `RBRoom_ShootingRange` | **黑桃 ← 钥匙** |
| C | `OnChair_BP3_8` | `RBRoom_Archives01_Master` | 梅花 |

模型算出的 C 区第 4 具是「五角星」，玩家没记到 —— 与「C 区 4 具」吻合。

---

## 4. 代码侧读数（REA → IDA）

| 用途 | 地址 | 备注 |
|---|---|---|
| 协调器随机化主函数 | `0x14361C230`（0xC0D） | ★ 本轮拿到完整逐行语义 |
| 通用引擎入口 | `0x1402AE7F0`（0x206） | 盐名 `L"Objective Actors"`（`0x14665E254`） |
| 分组 + 洗牌（写回种子） | `0x1402C30C0` | `&v143` 会被改写 |
| 图案抽取 | `0x14361CA7C` | `RandSeeded(v123+v71+v70, \|pool\|)` |
| 图案池删除 | `0x14361CA8D` | `TArray::RemoveAt(..., bKeepOrder=1)` |
| 尸体抽取 | `0x14361CA08` | `RandSeeded(v120+v71+v70, group.Num)` |
| 尸体删除 | `0x14361CA55` | `RemoveAt(..., bKeepOrder=1)` |
| `RandSeeded` / `GetSeed` / `crc32_fname` | `0x1402D29E0` / `0x140503B80` / `0x141CBDC30` | 同 `opp_seed/seedcore.py` |
| 「随机浮点」（洗牌用） | `0x1413F02F0` | `(RandSeeded 的 16 位值)/65536` |

### 4.1 `sub_14361C230` 的关键片段（本轮新读）

```c
v58 = GetSeed(coord);                                  // 0x14361C6B4
sub_14361CE40(Num(+6600), IntByDifficulty(+6848), &v145, v58 + 924519, &v142);
sub_14361CE40(Num(+6600), IntByDifficulty(+6648), &v141, v58 + 264069,  &v145);
pool1 = copy(coord+6616);        // QuestItemClasses（10）
pool2 = copy(coord+6632);
if (*(coord+7273) == 1)  sub_14361CFA0(...);            // 分支 B，本关不走
else if (Num(v144) > 0) {                               // ← 本关
    sub_1402C30C0(coord+1352, &v133, Num(+6600), &v134, &v143);   // 分组，写回 v143
    sub_1402AF770((uint*)(coord+6600), &v132);                    // 候选队列
    v70 = 0;                       // 全局已抽计数
    for (group : v134) {
        if (group.DesiredCount <= 0) { v131.Add(group); continue; }
        v71 = 0;                   // 组内序号
        do {
            entry      = ResultArray.Add();                 // coord+7256
            entry[0]   = v132.pop_front();                  // 候选队列 FIFO
            entry[8]   = v70;
            pick       = RandSeeded(v143+243551 + v71 + v70, group.Num);
            v80        = group[pick];
            if (!v80 || !IsA(v80, ...)) abort;
            RemoveAt(group, pick, 1, /*keepOrder=*/1);       // 0x14361CA55
            ki         = RandSeeded(v143+223551 + v71 + v70, pool1.Num);
            entry[16]  = entry[40] = pool1[ki];              // key + clue
            if (v71 ∈ v145) entry[56] = pool2[RandSeeded(v143+850321+v71, ...)];
            if (v71 ∈ v141) entry[32] = pool2[RandSeeded(v143+951320+v71, ...)];
            RemoveAt(pool1, ki, 1, /*keepOrder=*/1);         // 0x14361CA8D
            ++v70; ++v71;
        } while (v71 < group.DesiredCount);
    }
}
```

两条**关键的新事实**：

1. `v71 + v70` 两个都在自增 → 组内第 `j` 次抽取的盐是 `B + const + S_g + 2j`。
   之前几轮按 `S_g + j` 算，所以全部 0 命中。
2. `pool1` 每次抽完 `RemoveAt`，模数是**池的当前长度** → 10 具图案互不重复。
   这正好解释「C 区同时有眼睛和方块」。

### 4.2 `v143` 是怎么来的

`v143` 初值 = `GetSeed(coordinator)`，再以 `&v143` 传给 `sub_1402C30C0`（分组器）
—— 上一轮的证据说它被写成 `GetSeed + 组数`。本轮不再依赖这个猜测：
**直接把 `B = v143` 当未知量，用 3 条实测量在全 2³² 里反解。**

---

## 5. Q1 是怎么解出来的（反解而不是碰运气）

模型定下来之后，未知量只剩 **一个 32 位整数 `B`**，于是：

- 约束：3 条 seed × 3 个扇区 = 9 条「钥匙图案」事实；
  再加 378378 每区「出现过的图案集合」3 条。
- 结构假设只有两个小枚举：扇区 → 组的排列（3! = 6）、每组条目数
  （(3,3,3) / (3,3,4) / (3,4,3) / (4,3,3)）。
- 扫描器：`tools/psb_key_scan.c`（MSVC `/O2 /openmp`，16 线程 **82 s** 跑完 2³²）。
  先算 `(B+223551,10)` 三遍做淘汰（约 99.7% 直接淘汰），再对幸存者回算全部约束。

**结果：全 2³² 只命中 1 个**

```
HIT B=0xCD055621   order=A C B   cnt=3/4/3
```

按「每组 3~5 具、总数 ≤10」放宽到 27 种分配后仍是唯一解
（重建命令见 §7）。随机撞上的期望数量是几百个，所以这基本可以确定就是真值。

### 5.1 顺带确认的三件事

1. 每组**第 1 具**（`j == 0`）才是真钥匙，不是最后 1 具、也不是第 2 具
   （`psb_key_scan.c` 的 `keypos` 参数可以切，只有 0 命中）。
2. 一局总共 **10 具**（= `DesiredCount`），C 区 4 具、A/B 各 3 具。
   之前按「每区恰好 3 具」建模是错的 —— 玩家只是没记到第 10 具。
3. 图案分配与「尸体在哪」无关，只与 `B` 和 salt 有关 →
   **Q1 可以完全离线算，不需要知道尸体顺序。**

---

## 6. Q2 还差什么：候选组的初始顺序

尸体这一侧的模型同样已经确定：

```
尸体 = group[ RandSeeded(B + 243551 + V + j, |group|, salt) ]，保序删除
```

用它把「某具尸体显示了某图案」翻译成「该具尸体在候选组初始列表里的下标」，
两条 seed 一共得到 **7 条约束，且互相 0 冲突**：

| 扇区 | 初始下标 | 尸体 |
|---|---|---|
| A | 3 | `AgainstWall_BP2_5` |
| A | 4 | `AgainstWall_BP_2` |
| A | 12 | `AgainstWall_BP3_8` |
| B | 5 | `Desk_BP_5` |
| B | 7 | `AgainstWall_BP5_2` ← 见 §3.1 的存疑项 |
| C | 6 | `WallThroat_BP8_32` |
| C | 9 | `BP7_2` |

（复核脚本 `tools/psb_check.py`：组大小取 15/10/16 时 0 冲突。）

**差的那一块**：每个 group 的初始顺序**不是**关卡 JSON / 字典序
（`tools/psb_order.py` 已验证：7 条里只碰对 2 条）。它来自
`sub_14361C230` 开头那次 **`std::sort`（MSVC intro-sort）**，而它的比较器是

```c
sub_1413F02F0(GetSeed(actor)) >= 0.5      // 0x1413F02F0 = (RandSeeded 的 16 位值)/65536
```

两点要注意：

1. 这是个「伪随机比较器」（只看第一个参数），本质是**洗牌**，不是排序；
2. `sub_1413F02F0` 内部掺了 `dword_146E2E5C4 % 1000`
   —— **它随关卡 seed 变化**，所以这个顺序每局都不一样，必须真的把那段
   intro-sort 复刻出来才能算。

要闭合 Q2，按性价比排序：

1. **把 `0x14361C230` 第 164–384 行那段 intro-sort 原样翻译成 C/Python**，
   输入 = 41 具尸体的 level actor 顺序（就是静态表里的字典序），
   逐元素用 `GetSeed(尸体)` 比较。校验标准：上面 7 条约束全过。
   需要 `GetSeed(尸体)`，而 `GetSeed` 里有个
   `RBRandomSeedGeneratorInterface` 覆盖分支（`0x140503B80` 第 131–211 行），
   得先确认尸体类有没有实现它。
2. **再要 1~2 条完整样本**（10 具 + 图案 + 房间），把约束从 7 条推到 20 条以上；
   组大小 15/10/16 的话，约需 40 条才能定死全表，所以不如走第 1 条。
3. **Frida hook** `0x14361CA08`（尸体抽取）打印 `v143 / v70 / v71 / group.Num`，
   一局就能读出顺序（`release/coop/GUIDE.md` 有现成流程）。

房间 → 候选序号的换算：`python psb_mt01.py --find <房间名>`。

---

## 7. 环境与文件

| 项 | 结果 |
|---|---|
| REA | ✅ MCP server `rea` 在线 |
| REA → IDA | ✅ provider `ida`（`IDA MCP adapter` v1，mode=attached），upstream `ida-pro-mcp 1.30.0` |
| 目标 | `D:\workspace\outlast\TOTClient-Win64-Shipping.exe`，base `0x140000000`，sha256 `2cd37c88…a4192e` |
| 本轮新反编译 | `sub_14361C230`（650 行全量）、`sub_1402AE7F0`（全文）、`sub_1413F02F0`（全文）、`sub_140503B80`（全文） |
| 扫描器 | MSVC `cl.exe /O2 /openmp`（VS2022 Community），16 线程 |

重建 / 复核命令：

```powershell
cd d:\workspace\outlast\release\home
cmd.exe /c "tools\_build.bat"          # 编译 tools\psb_key_scan.c
tools\psb_key_scan.exe t               # 先自检：C 与 opp_seed/seedcore.py 逐位一致
tools\psb_key_scan.exe 0 1             # 全 2³² 扫描（约 82 s，唯一解 0xCD055621）
python tools\psb_model.py              # 12/12 自检
python tools\psb_model.py 378378       # 打印抽取过程
python tools\psb_check.py              # Q2：7 条约束 0 冲突
python tools\psb_order.py              # Q2：验证初始顺序 ≠ 字典序
```

| 路径 | 作用 |
|---|---|
| `psb_mt01.py` | ★ 交付脚本：seed → 3 区钥匙图案 + 每区图案清单 + 候选池（自检 51/51） |
| `psb_mt01_static.py` | 固化静态表（41 尸体 / 53 房间 / 3 扇区 / 图案池） |
| `tools/psb_model.py` | 图案模型（B、组序、抽取过程），`--selftest` 12/12 |
| `tools/psb_key_scan.c` | ★ 2³² 反解 `B` 的 OpenMP 扫描器（本次唯一解的出处） |
| `tools/_build.bat` | 编译 `psb_key_scan.c`（vcvars64 + cl.exe） |
| `tools/psb_corpses.py` | 尸体抽取下标 / 槽位约束推演 |
| `tools/psb_solve.py` | 组大小 × 顺序 的联合可行性搜索 |
| `tools/psb_check.py` | Q2 冲突检查（组大小 15/10/16） |
| `tools/psb_order.py` | 验证「初始顺序 ≠ 静态表字典序」 |
| `tools/psb_gen.py` | 从 pak + ui 数据重新生成静态表 |
| `tools/psb_scan.py` | 关卡 JSON 探查器（kinds / find / props / corpses / coord） |
| `tools/psb_fit3..fit10.py` | 上一轮的证伪记录（模型里 `S_g+j` 是错的，所以全部 0 命中） |

---

## 8. 已排除（省下一个人重走）

1. 盐不是 `S_g + j`，是 `S_g + 2j`（`v70` 和 `v71` 都自增）。
2. 不是「每区恰好 3 具」——是 3/4/3，共 10 具。
3. 「同区尸体都显示本区图案」——错，10 具图案互不重复。
4. 池顺序不是 `CluesMapping` 的顺序，也不是字母序；是 `QuestItemClasses`。
5. 盐名不是 `"Objective Actors"` 的 CRC 当基线（那是**另一条**通用随机化用的，
   在 `sub_1402AE7F0` 里，`base = crc32_fname("Objective Actors") + GetSeed(coord)`）。
6. 候选组的初始顺序不是关卡 JSON / 字典序（`psb_order.py` 证伪）。
7. 分支 B（`*(coord+7273)==1`）本关不走。
