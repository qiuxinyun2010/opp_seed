# RES_MT02：莉莉娅人偶的真宝石点位

> 关卡：水疗度假村（ResortSpa）·「焚毁莉莉娅的遗物 / Purchase Liliya's Relic」
> 目标：给定关卡种子 → 推出**真宝石挂在哪些人偶身上、什么宝石、坐标在哪**
> 依据：REA / IDA 反编译（`TOTClient-Win64-Shipping.exe`，base `0x140000000`）+ `RES_MT02_B00.json`
> 状态：**主轴段已闭环**（seed 176176 的 2 条实测全中）；**教学段类别已解、点位未解**（§6）

---

## 1. 一句话结论

**能推出主轴段的 26 颗真宝石（人偶 actor + 宝石类别 + 坐标），已用实测验证；教学段能推出「任意人偶这个 seed 下是什么颜色」（`--tuto`），但「哪 6 个人偶」还差上游那一步。**

```
主轴段 MT02_CollectingJewels_MainAuction
  2 个固定房（Building_Room3 / RestaurantLounge_Master）各 1 颗，恒为数组第 1 类 = 红宝石
  4 个 section 共 25 颗：房间按 RandFraction(GetSeed(room)+479582) 升序排好，依次轮流派发
      第 k 颗：房间内空闲人偶 RandSeeded(k+279412, N) 抽一个
              类别 = 类别桶[ RandRangeInt(k+823203, 0, len-1) ]，抽完 swap-remove
  类别桶 = 把 0.2/0.5/0.3 按 25 整数化 → 红 5 / 蓝 13 / 绿 8（合计 26，用 25）
```

对玩家最有用的三条性质：

1. **每个 seed 的类别配额是固定的**：分区 25 颗里蓝 13、绿 8、红 5，再加 2 颗固定红。
   所以「这一局蓝宝石最多」永远成立，seed 只改变分配顺序。
2. **房间集合由 seed 决定**：每个 section 的 7/9/4/5 个候选房间按 seed 键排序，
   取前 N 个（6/6/6/7）依次拿宝石。房间在**同一个 section 内不重复**，但跨 section 会重复
   （如 `Building_Room3` 固定房 1 颗 + section3 再来 2 颗）。
3. **宝石只可能在这 25 个房间里的人偶身上**，其余房间的人偶全是骷髅（假宝石）。

> 本关用到的通用方法（定位链 / 随机原语 / 坑表 / 关键函数）已提炼到 **`RE_METHOD.md`**，
> 新关卡直接照那套流程走；本文只留本关专属结论与证据。

---

## 2. 直接可用

```powershell
cd d:\workspace\outlast\release\home

python ..\..\opp_seed\seed.py RES_MT02 176176       # ★ 交付入口（等同下面的 res_mt02.py）
python ..\..\opp_seed\seed.py RES_MT02 69069 --tuto # 宝石点位 + 教学段 51 人偶类别图

python res_mt02.py 176176            # 全部真宝石点位（人偶 + 类别 + 坐标）
python res_mt02.py 176176 --trace    # 附带房间排序键与逐个抽取过程
python res_mt02.py 176176 --json --out r.json
python res_mt02.py --rooms 176176    # 4 个区的房间排序与命中的前 N 个
python res_mt02.py --pool            # 全部 318 个人偶（main / tutorial / base）
python res_mt02.py 69069 --tuto      # 教学段 51 个人偶的类别图（蓝/绿 + 序号 + 坐标）
python res_mt02.py --selftest        # 原语 + 配额 + 教学段类别 + 实测样本自检
python res_mt02_tuto_fit.py          # 教学段类别模型对两局 10 条实测的一致性检查
```

Python API：

```python
import sys; sys.path.insert(0, 'release/home')
import res_mt02 as m
r = m.predict(176176)
for it in r['items']:
    print(it['room'], it['gem'], it['spawner'], it['coordinates'])
```

坐标：`coordinates` = 宝石挂点（人偶根 + `ItemSpawnLocation`，已按 yaw 旋转），
`root` = 人偶容器 `SceneComp` 的根坐标。

---

## 3. REA / IDA 状态（本次实测）

| 项 | 值 |
|---|---|
| REA MCP | 可用（`list_documents` / `procedure_pseudo_code` 正常） |
| provider | `ida` / `IDA MCP adapter`，上游 `ida-pro-mcp 1.30.0`，`mode = attached` |
| 目标 | `TOTClient-Win64-Shipping.exe`，sha256 `2cd37c88…92e` |
| IDA 数据库 | base `0x140000000`，size `0x7625000` |

踩坑：`binary_overview` 第一次调用 `-32001` 超时（GUIDE §2.2 坑 1），
换 `list_documents` 即恢复；`resolve_containing_procedure` 这个 provider 不提供，
但 `procedure_pseudo_code` **可以直接喂函数内部地址**（会自动归到所在函数）。
全程没用 `read_bytes`。

---

## 4. 关卡结构：两个协调器，同一个关卡种子

`RES_MT02_B00.json` 里有两个 `BlacklightDetectionItemInteract_Coord_BP_C`：

| 协调器 | objective | 段 | 数量 | 类别分布 | 人偶类 |
|---|---|---|---|---|---|
| `MT02_CollectingJewels_Tuto` | Find gems to buy the first key | 教学段（Crypt / FinalKill / WineCellar 一带，z ≈ -400） | 6（`DesiredCount`） | 蓝 0.6 / 绿 0.4 | `RE_MannequinTrap_Tutorial_BP` |
| `MT02_CollectingJewels_MainAuction` | Purchase Liliya's Relic | 主轴段（度假村主体） | 2 固定 + 25 分区 | 红 0.2 / 蓝 0.5 / 绿 0.3 | `RE_MannequinTrap_Setup_BP` |

实测样本里 4 个 `RE_MannequinTrap_Tutorial_BP_*` 落在 `RBRoom_Crypt_*`，
2 个 `RE_MannequinTrap_Setup_BP*` 落在 section1 的拍卖厅 —— 正好对应这两段。

---

## 5. 主轴段算法（反编译直读，已验证）

### 5.1 主循环 `0x1433B49B0`

```text
# 1) 固定房（MandatoryRoomsSpawnData）—— 用自己的 counter，恒取 dist[0]
for m in MandatoryRoomsSpawnData:                       # Building_Room3, RestaurantLounge_Master
  for k in 0 .. IntByDifficulty(m.count)-1:             # Easy 没写 Override → 回落 Normal = 1
     sp = pick_spawner(m.room, counter + 820351)
     spawn_item(sp, dist[0].ItemClass)                  # ★ 恒为红宝石
     counter += 1

# 2) 类别桶：n_i = round_half_even(2 * d_i * total + 0.5) >> 1
total = Σ IntByDifficulty(section.count)                # 6+6+6+7 = 25
E = [i] * n_i                                           # 红5 蓝13 绿8 = 26 项

# 3) 每个 section —— counter 从 0 重新开始（★ 关键修正，见 5.4）
for sec in RandomRoomsData:
  n = IntByDifficulty(sec.count)
  key(r) = RandFraction(GetSeed(r) + 479582)
  rooms = sort_by_key(sec.RoomsInSection)               # float 升序
  k = 0
  while k < n:
      room = rooms[k % len(rooms)]                      # ★ 轮流，不是随机
      sp = pick_spawner(room, counter + 279412)
      if sp == 0:  k += 1; continue                     # 打 "No mannequins..."；counter 不前进
      r  = RandRangeInt(counter + 823203, 0, len(E)-1)
      ci = E[r]; swap_remove(E, r)
      spawn_item(sp, dist[ci].ItemClass)
      counter += 1; k += 1
```

### 5.2 `pick_spawner(room, seed)` `0x1433B58F0`

```text
arr = room.GetActorsByTag(15)          # 房间登记的人偶（跨子关卡）
filter_valid(arr, radius = 300.0)      # 剔掉不可用 / 已被占用
if arr.empty: return 0
return arr[ RandSeeded(seed, len(arr)) ]
```

脚本里 `arr` 的顺序用 `(level, name)` 近似关卡 actor 顺序 —— 本次 2/2 命中。

### 5.3 类别桶必须「四舍五入」而不是截断

`0x1433B4D72..0x1433B4D88` 是 `mulss → addss → addss 0.5 → cvtss2si → sar 1`。
`cvtss2si` 四舍五入到偶数：25 → 红 5 / 蓝 13 / 绿 8 = 26 ≥ 25。
按截断算是 5/12/7 = 24 < 25，游戏会打 `Random rooms distributions error` 并整段放弃，
所以四舍五入是唯一自洽的解读。

### 5.4 ★ 本次新修正：分区 counter 从 0 起，固定房不占位

`room_section_randomize.c` 里：

```c
/* line: 217 */  v135 = 0i64;                       /* 固定房循环：counter 从 0 */
/* line: 285 */  v135 = (unsigned int)(v135 + 1);   /* 固定房每颗 +1  → 结束时 v135 = 2 */
/* line: 386 */  v42 = 0i64;                        /* ★ 分区循环前重新置 0 */
/* line: 393 */  v135 = v42;                        /* ★ 分区 counter 从 0 开始 */
/* line: 765 */  v42 = v135;                        /* 每个 section 结束后带走（跨 section 连续） */
```

旧版 `release/coop/RES_MT02/RES_MT02.py` 让分区从 2 起算，**房间内人偶和类别全错**。
修正后 seed=176176 的 3 条事实（人偶 BP160 / 人偶 BP_295 / 类别 红+蓝）同时命中：

| 事实 | 预测（counter 从 0） | 预测（旧版，从 2） |
|---|---|---|
| `SilentAuction` 里的人偶 | `BP160` ✅ | `BP_159` ❌ |
| `West1F_SilentAuction_B` 里的人偶 | `BP_295` ✅ | `BP_292` ❌ |
| 这两颗的类别 | 红 + 蓝 ✅ | 绿 + 绿 ❌ |

### 5.5 常见误判（已排除）

1. ~~类别按 Distribution 独立加权抽~~ → 不是，先整数化成桶再 `RandRangeInt + swap-remove`
   （所以整局类别**计数固定**，只有分配顺序变）。
2. ~~section 内房间随机抽~~ → 不是，先按 seed 键排序再 `k % len(rooms)` 轮流。
3. ~~人偶是运行时生成的~~ → 不是，全是关卡里摆好的 `RE_MannequinTrap_Setup_BP` 容器，
   协调器只挑不生成。
4. ~~`RBRoom_UnderBalcony` 有人偶~~ → 导出数据里它 0 个可用人偶，抽到必然少一颗
   （seed=176176 的 section2 因此只有 5 颗，总数 26 而不是 27）。

---

## 6. 教学段：类别已解（✅），「哪 6 个」未解（🔴）

### 6.1 函数语义（`0x1433B5BC0`，本地 capstone 复核）

```text
v4 = GetSeed(协调器) = seed_of('MT02_CollectingJewels_Tuto') = 1753430342
RemoveAll(a1+0x3728, nullptr)                 # 0x141C9CE10 = TArray::RemoveAll
arr = copy(a1+0x3728)                         # ← 51 个 RE_MannequinTrap_Tutorial_BP_*（全量）
Sort(arr)                                     # 0x14018C680 = Introsort
                                              # 比较器 0x1402C6910 = actor 名字大小写折叠升序
v8 = 0
while (len(arr)):                             # len 随 RemoveAt 递减
   idx = RandSeeded(v4 + v8, len(arr))
   sp  = arr[idx]
   ci  = bAlternatePricesUniformly ? v8 % Num(dist) : RandSeeded(v8 + 438361, Num(dist))
   append(a1+0x36E0, {sp, dist[ci]})          # 每个人都记一笔
   if (!sub_143993600(sp)) RemoveAt(arr, idx, 1, 1)
   if (++v8 == wanted) break
```

三个关键点（此前都判错了）：

1. **`a1+0x3728` 是 51 个全量人偶，不是预选出的 6 个**。`v34 = *(a1+0x3730)` 既是数组长度
   也是循环上界，所以**每个人都拿到类别**；「哪 6 个有宝石」是另一套上游选择。
2. `v4` 来自 `GetSeed(协调器)`，即 `|crc32(名字) + crc32("PersistentLevel")|`，
   **与关卡种子无关**（两个 seed 共用同一个 v4）。关卡种子只进 `RandSeeded` 的全局 salt（`%1000`）。
3. `sub_143993600` 是 `IsA(Interface) + vtbl+0x220` 的**静态**判定（本地反汇编确认），
   即「是否移除」跨 seed 不变，不是随机。

因此：**某个人偶的颜色 = 它在「51 人排序后逐次抽取」排列里的奇偶**（偶 = Sapphire 蓝，奇 = Emerald 绿），
类别表顺序取协调器自己的 `distributions`（`RE_Sapphire_BP_C`, `RE_Emerald_BP_C`），不是关卡全局表。

### 6.2 实测验证（两局 10 条）

```
seed=176176   96 绿✓  106 蓝✓  111 蓝✓   139 绿✗（模型给蓝）
seed=069069   106 蓝✓ 115 蓝✓  84/86 绿✓  117 绿✓  109/91 绿✓  139 蓝✗（模型给绿）
=> 8/10
```

`res_mt02.py --selftest` 里只收无歧义的 8 条，全部通过。
`BP_139` 在两局里都**恰好与模型相反**（位置 36/17，各差一个奇偶），
且它和 `BP_106` 是两局都出现的名字（随机 6 选 51 时概率 ~2e-4），怀疑：
该点位上存在两个几乎重合的人偶（关卡里记录比实测少一个），或实测把邻居记成了 139。
暂按「单点异常」处理。

### 6.3 还缺的那一步：51 选 6

`SpawnerActorsRandomizationSetup(DesiredCount=6)` 的实现仍未定位
（`scan_disp.py 0x3728` 有 21 个候选函数；已确认 `+0x94 4/0x950` 两个虚函数分别做
「收集全部 spawner」与「按 +0x4570 列表开关 spawner」，选 6 的逻辑不在其中）。
已证伪的形态见 §6.4。

有了它才能给出「这局宝石在哪 6 个人偶上」；当前的可交付形式是**反过来用**：

```bash
python res_mt02.py <seed> --tuto      # 打印 51 个人偶的类别图
```

进游戏看到 6 个带宝石的人偶名字后，直接查表得颜色（并且应满足 3 蓝 3 绿）。

### 6.4 已证伪的「51 选 6」形态

| 试过的 | 结果 |
|---|---|
| 池 = 51，直接 `RandSeeded(v4+v, 51)` 抽 6（8 种 GetSeed 外层 × 2 种名字折叠） | 最多命中 2 条 |
| 池按名字排序 / 字典序 / 关卡 JSON 序 / 逆序 / 子关卡顺序 | 无 |
| 顺序抽 6（弹出 或 swap-remove），基种子 = `GetSeed(Coord) + {0,66066,279412,479582,820351,823203,438361,738368,61670}` × 8 种外层 | 无 |
| 固定 N 抽 6（不移除，12 种起始偏移） | 无 |
| `FRandomStream` LCG（`select_subset`） | 无 |
| 按 `RandFraction(GetSeed(spawner)+66066)` 排序 | 无 —— `66066` 属于 `ARBMinigameRoomsObjectiveCoordinator`（`0x1435DA9D0`） |
| 全 2^32 扫 `v4`（join：69069 的 6 集合 + 176176 的 4 个已知，含条件移除全组合） | 无（一次性 numpy 扫描脚本，结论已固化，脚本已清理） |

最省事的下一步数据：**同一局 6 个教学段人偶的完整名单**（凑齐 6 个），
以及**再一个 seed 的 6 个**，用于反查 upstream 的距离约束选择。

---

## 7. seed = 176176 的答案

主轴段 **26 颗**（2 固定 + 24 分区；section2 因 `RBRoom_UnderBalcony` 无人偶少 1 颗）。
含实测命中的 2 条（★）：

| 段 | 房间 | 宝石 | 人偶 actor | 挂点坐标 |
|---|---|---|---|---|
| 固定 | `RBRoom_Building_Room3` | 红 | `RE_MannequinTrap_Setup_BP_15` | (-139.2, -829.9, 369.2) |
| 固定 | `RBRoom_RestaurantLounge_Master` | 红 | `RE_MannequinTrap_Setup_BP_214` | (-977.1, -3279.3, 683.2) |
| s1 | `RBRoom_West1F_GameRoom` | 蓝 | `RE_MannequinTrap_Setup_BP_129` | (-2071.7, 4694.8, 219.2) |
| s1 | `RBRoom_West1F_Hub` | 蓝 | `RE_MannequinTrap_Setup_BP_141` | (-1913.9, 2769.7, 186.2) |
| s1 | `RBRoom_SilentAuction` | 红 ★ | `RE_MannequinTrap_Setup_BP160` | (-1546.0, 3060.0, 186.2) |
| s1 | `RBRoom_West1F_SilentAuction_B` | 蓝 ★ | `RE_MannequinTrap_Setup_BP_295` | (-1496.6, 2605.1, 186.2) |
| s1 | `RBRoom_LiveAuction` | 绿 | `RE_MannequinTrap_Setup_BP2` | (58.2, 2904.0, 187.6) |
| s1 | `RBRoom_West1F_Cloak_RewardRoom` | 红 | `RE_MannequinTrap_Setup_BP6_36` | (-835.1, 3602.6, 286.2) |
| s2 | `RBRoom_Exterior_3` | 绿 | `RE_MannequinTrap_Setup_BP_171` | (-763.9, 1046.5, 286.3) |
| s2 | `RBRoom_OutsideRestaurant_Master` | 红 | `RE_MannequinTrap_Setup_BP_118` | (-457.8, -1705.0, 369.3) |
| s2 | `RBRoom_OutsideGarage_Master` | 蓝 | `RE_MannequinTrap_Setup_BP_91` | (669.4, -2033.5, 369.3) |
| s2 | `RBRoom_FirePlace_Exterior` | 绿 | `RE_MannequinTrap_Setup_BP_232` | (-1205.1, -2069.4, 369.4) |
| s2 | `RBRoom_TunnelSpa` | 蓝 | `RE_MannequinTrap_Setup_BP_181` | (-2039.3, -1056.1, 318.9) |
| s3 | `RBRoom_Building_Room2` | 蓝 | `RE_MannequinTrap_Setup_BP19_108` | (1947.7, -30.3, 369.2) |
| s3 | `RBRoom_Building_Room3` | 红 | `RE_MannequinTrap_Setup_BP20_6` | (-54.7, -615.2, 369.2) |
| s3 | `RBRoom_Building_Room1` | 蓝 | `RE_MannequinTrap_Setup_BP17_122` | (1356.4, -824.4, 369.2) |
| s3 | `RBRoom_SaunaSpa` | 绿 | `RE_MannequinTrap_Setup_BP16_99` | (2323.8, -1313.3, 370.2) |
| s3 | `RBRoom_Building_Room2` | 蓝 | `RE_MannequinTrap_Setup_BP_174` | (1895.5, -411.3, 369.2) |
| s3 | `RBRoom_Building_Room3` | 蓝 | `RE_MannequinTrap_Setup_BP_21` | (-140.1, -156.7, 369.2) |
| s4 | `RBRoom_RestaurantLounge_Master` | 红 | `RE_MannequinTrap_Setup_BP24_143` | (-311.2, -3315.3, 684.2) |
| s4 | `RBRoom_WomenLocker_Master` | 绿 | `RE_MannequinTrap_Setup_BP30_12` | (-3353.8, -3513.5, 683.2) |
| s4 | `RBRoom_MenLocker_Master` | 绿 | `RE_MannequinTrap_Setup_BP_307` | (-3481.1, -2451.2, 683.2) |
| s4 | `RBRoom_Kitchen` | 蓝 | `RE_MannequinTrap_Setup_BP_322` | (512.7, -3791.1, 683.2) |
| s4 | `RBRoom_SpaHall_Master` | 蓝 | `RE_MannequinTrap_Setup_BP_247` | (-2830.0, -3184.3, 683.2) |
| s4 | `RBRoom_RestaurantLounge_Master` | 绿 | `RE_MannequinTrap_Setup_BP_316` | (-196.7, -3025.6, 683.2) |
| s4 | `RBRoom_WomenLocker_Master` | 蓝 | `RE_MannequinTrap_Setup_BP28_9` | (-3832.7, -3763.8, 683.2) |

教学段 6 颗：点位未解（§6.3）。已实测 4 颗 —— `Tutorial_BP_96` 绿 / `Tutorial_BP_139` 绿 /
`Tutorial_BP_106` 蓝 / `Tutorial_BP_111` 蓝；剩 1 蓝 + 1 绿未定位。
颜色本身不用等：`python res_mt02.py 176176 --tuto` 里已经给出全部 51 个人偶的颜色。

---

## 8. 文件索引

```text
release/home/
  RES_MT02.md                 本文
  res_mt02.py                 ★ 预测器 + CLI + --selftest
  res_mt02_pool.json          318 个人偶容器（main 233 / tutorial 51 / base 34，含房间与坐标）
  res_mt02_leveldata.json     关卡静态数据（协调器的固定房 / 4 个 section / 类别分布）
  res_mt02_tuto_fit.py        教学段类别模型的一致性检查（两局 10 条实测，8/10）
  res_mt02_176176.json        seed 176176 的机器可读结果
  ..\..\opp_seed\seed.py      交付入口：python seed.py RES_MT02 <seed> [--tuto]（数据在 opp_seed/data/res_mt02.json）
  RE_METHOD.md                可复用的逆向方法论 + 关键函数速查（本关提炼）
  tools/dis_va.py             capstone+pefile 裸反汇编（IDA provider 掉线时用）
```

数据来自 `release/coop/RES_MT02/` 的提取产物（未修改其它目录）。

## 9. 已知边界

1. 种子只通过 `seed % 1000` 进入公式：`S` 与 `S+1000` 结果完全一样。
2. 只有 Easy / 1P 有实测；normal/hard/insane 只是换了 `IntByDifficulty` 的档位，未实测。
3. 房间内「到底哪一个人偶」依赖 `arr` 的顺序，脚本用 `(level, name)` 近似关卡 actor 顺序。
   目前 2/2 命中，但样本少；如果某局对不上，优先怀疑这一条。
4. `RBRoom_UnderBalcony` 在导出数据里 0 个可用人偶，可能导致总数从 27 降为 26；
   若实际有人偶（房间多边形判定有误），section2 会多 1 颗。
5. 教学段：颜色已解（8/10 实测，`BP_139` 单点异常），点位（51 选 6）未解（§6）。
6. `GetSeed` 只由名字 CRC 决定，所以 `v4` 跨 seed 不变；关卡种子仅通过全局 salt（`%1000`）进入。
