# -*- coding: utf-8 -*-
"""SRR_MT01（郊区住宅区 · 撬开富豪宅的密码盘）seed 推理 → 3 个密码房 + 4 位密码。

游戏机制：5 栋豪宅各有一个密码盘位置，每局随机激活其中 3 栋 = 3 个密码房；
每栋密码房挑 4 个贴花位（4 间房各 1 张），4 个数字组成该房的 4 位密码。

已全部闭环（894894→4369/5623/9217、512512→6459/8612/3159、745745→1840/8726/8102）：
    选 3 栋：sub_1437E5100（RandomizeActorArray）：池=5 栋候选(H1..H5)，抽 3：
            idx_j = RandSeeded(groupSeed + j + 45151, |池|)，保序删除；
            groupSeed 构造见 draw_houses 注释（三样本唯一解，语义待第四样本确认）；
    房间集合：sub_14374E420 分区抽房（28042 偏移）；
    处理顺序：sub_14374E420 尾部容器 introsort（key = RandFraction(GetSeed(容器))>=0.5，
              n<=8 走选择排序：每轮「最后一个 frac<0.5」换到末尾），再逆序消费；
    数字公式：digit_k = pool[ RandSeeded(compSeed(room_k) + k + 7168, |pool|) ]，保序删除。

用法：
    python srr_mt01.py 894894                 # 本局 3 个密码房 + 4 位密码（唯一解）
    python srr_mt01.py 894894 --all           # 全部 5 栋候选（含未激活的 2 栋）
    python srr_mt01.py 894894 --trace         # 附带选房 / 抽房 / 逐位抽取过程
    python srr_mt01.py 894894 --json
    python srr_mt01.py --check                # 三样本自检（选房 + 密码精确匹配）
"""
import argparse
import json
import os
import sys

_HERE = os.path.dirname(os.path.abspath(__file__))     # release/home
_REL = os.path.dirname(_HERE)                          # release
_ROOT = os.path.dirname(_REL)                          # 工作区根
sys.dont_write_bytecode = True      # 不在 opp_seed / release 里留 .pyc
for _cand in (os.path.join(_ROOT, 'opp_seed'), os.path.join(_REL, 'seed')):
    if os.path.isdir(_cand) and _cand not in sys.path:
        sys.path.insert(0, _cand)
        break

from seedcore import (  # noqa: E402  依赖 opp_seed/seedcore.py 的随机原语
    M32, crc32_fname, rand_fraction, rand_seeded, seed_of_object,
)

LEVEL_OBJECT = 'PersistentLevel'
LEVEL_CRC = crc32_fname(LEVEL_OBJECT)

MAP_DIR = os.path.join(_ROOT, 'pak', 'OPP', 'Content', 'Maps_json',
                       'SuburbRiotResidential')
LEVEL_JSON = os.path.join(MAP_DIR, 'SRR_MT01_B00.json')
ROOMS_JSON = os.path.join(MAP_DIR, 'SRR_LD_Rooms.json')

PICK_OFFSET = 28042       # sub_14374E420: RandSeeded(剩余需求 + 28042, |该区房间|)
FILL_OFFSET = 28088       # 兜底补位（本关用不到）
DIGIT_OFFSET = 7168       # sub_143620E70: RandSeeded(seed + 7168, |pool|)
DRAW_OFFSET = 45151       # sub_1437E5100: RandSeeded(GetSeed(setup) + j + 45151, |池|)

# test.txt 实测样本（seed → {密码盘 actor: (所在房间或 None, 密码)}）
SAMPLES = {
    894894: {
        'MultiroomPuzzleKeypad_BP_2': ('RBRoom_Rich_House1_Salon', '4369'),
        'MultiroomPuzzleKeypad_BP3_5': ('RBRoom_Rich_House3_Salon', '5623'),
        'MultiroomPuzzleKeypad_BP4_8': ('RBRoom_Rich_House4_ConstrcutionRoom2', '9217'),
    },
    512512: {
        'MultiroomPuzzleKeypad_BP_2': (None, '6459'),
        'MultiroomPuzzleKeypad_BP4_8': (None, '8612'),
        'MultiroomPuzzleKeypad_BP5_11': (None, '3159'),
    },
    745745: {
        'MultiroomPuzzleKeypad_BP_2': (None, '1840'),
        'MultiroomPuzzleKeypad_BP3_5': (None, '8726'),
        'MultiroomPuzzleKeypad_BP5_11': (None, '8102'),
    },
}


# ---------------------------------------------------------------------------
# 静态数据
# ---------------------------------------------------------------------------
def _short_name(path):
    return (path or '').split('.')[-1]


def load_level(path=LEVEL_JSON):
    """→ ({coordinator: {...}}, {room: component_name})"""
    data = json.load(open(path, encoding='utf-8'))
    coords = {}
    for obj in data:
        if obj.get('Type') != 'MultiroomPuzzle_Coordinator_BP_C':
            continue
        props = obj.get('Properties', {})
        sections = []
        for sec in props.get('Sections') or []:
            sections.append({
                'rooms': [_short_name(r.get('SubPathString'))
                          for r in sec.get('RoomsInSection') or []],
                'min': (sec.get('MinimumPuzzleRoomsInSection') or {})
                       .get('DefaultValues', {}).get('NormalLocalValue', 1),
                'random_id': sec.get('randomID', 0),
            })
        coords[obj['Name']] = {
            'pad': _short_name((props.get('PasscodePadActor') or {}).get('SubPathString')),
            'count': (props.get('PuzzleRoomCount') or {})
                     .get('DefaultValues', {}).get('NormalLocalValue', 4),
            'sections': sections,
        }
    comps = {}
    for obj in json.load(open(ROOMS_JSON, encoding='utf-8')):
        if obj.get('Type') == 'RBPuzzleRoomComponent':
            owner = (obj.get('Outer', {}).get('ObjectName') or '').split('.')[-1].rstrip("'")
            comps[owner] = obj['Name']
    return coords, comps


def comp_seed(room, comps):
    """GetSeed(RBPuzzleRoomComponent) = |crc(组件名) + |crc(房间名) + crc(PersistentLevel)||"""
    component = comps.get(room, 'RBPuzzleRoomComponent_0')
    return seed_of_object(component, seed_of_object(room, LEVEL_CRC))


def draw_houses(seed):
    """本局 3 个密码房（sub_1437E5100 RandomizeActorArray，三样本 3/3）。

    池 = 5 栋候选 H1..H5（推车目标不参与），抽 3 个：
        idx_j = RandSeeded(groupSeed + j + 45151, |池|)，保序删除
    groupSeed = |crc('RBObjectiveCoordinatorGroup2') + |crc('MultiroomPuzzle_Coordinator_House1_BP')||
    （机制来自反编译；种子构造是三样本下 670+ 名字链构造中的唯一解，
     其 GetSeed 语义来源待第四样本进一步确认——见 SRR_MT01.md §6.1）
    返回抽中顺序的 tag 列表，如 ['H1', 'H3', 'H4']。
    """
    salt = seed % 1000
    group_seed = seed_of_object('RBObjectiveCoordinatorGroup2',
                                seed_of_object('MultiroomPuzzle_Coordinator_House1_BP', 0))
    pool = ['H1', 'H2', 'H3', 'H4', 'H5']
    out = []
    for j in range(3):
        idx = rand_seeded((group_seed + j + DRAW_OFFSET) & M32, len(pool), salt)
        out.append(pool.pop(idx))
    return out


# ---------------------------------------------------------------------------
# 1) 抽房（sub_14374E420 的 bUseDefinedSections 分支）
# ---------------------------------------------------------------------------
def pick_rooms(coordinator, salt, trace=False):
    sections = coordinator['sections']
    pools = [list(s['rooms']) for s in sections]
    picked, remaining = [], coordinator['count']
    for sid, section in enumerate(sections):
        for _ in range(max(0, min(section['min'], remaining))):
            pool = pools[sid]
            if not pool:
                break
            idx = rand_seeded((remaining + PICK_OFFSET) & M32, len(pool), salt)
            picked.append(pool.pop(idx))
            if trace:
                print('    sect%d 剩余=%d idx=%d/%d -> %s'
                      % (sid, remaining, idx, len(pool) + 1, picked[-1]))
            remaining -= 1
    for sid in range(len(sections)):           # 兜底补位（28088）
        while remaining > 0 and pools[sid]:
            idx = rand_seeded((remaining + FILL_OFFSET) & M32, len(pools[sid]), salt)
            picked.append(pools[sid].pop(idx))
            remaining -= 1
    return picked


# ---------------------------------------------------------------------------
# 2) 4 位数字（sub_1436FE410 / sub_143620E70）
# ---------------------------------------------------------------------------
def digits(order, comps, salt, trace=False):
    pool = list(range(10))
    out = []
    for k, room in enumerate(order):
        base = comp_seed(room, comps)
        seed = (base + k + DIGIT_OFFSET) & M32
        idx = rand_seeded(seed, len(pool), salt)
        digit = pool.pop(idx)                  # 保序删除（memmove）
        out.append(digit)
        if trace:
            print('    k=%d %-42s compSeed=%d seed=%d pool=%d idx=%d -> %d'
                  % (k, room, base, seed, len(pool) + 1, idx, digit))
    return ''.join(str(d) for d in out)


# ---------------------------------------------------------------------------
# 3) 处理顺序（已闭环）：sub_14374E420 尾部容器 introsort + 逆序消费
# ---------------------------------------------------------------------------
def _sel_sort_bit(items, bit_of):
    """sub_14374E420 LABEL_123 / sub_1435F7860 小范围（n<=8）选择排序的复刻。

    每轮把「最后一个 bit=0（frac<0.5）」换到区间末尾；全 1 则换首位。
    """
    out = list(items)
    end = len(out) - 1
    while end > 0:
        cand = 0
        for j in range(1, end + 1):
            if bit_of(out[j]) == 0:
                cand = j
        out[cand], out[end] = out[end], out[cand]
        end -= 1
    return out


def process_order(rooms, comps, salt):
    """4 个贴花位的处理顺序 = 容器 introsort（key=RandFraction(compSeed)>=0.5）的逆序。

    894894 的 3 栋实测密码各对应 24 种顺序中的唯一解，本规则 3/3 精确命中。
    """
    bits = {r: 1 if rand_fraction(comp_seed(r, comps), salt) >= 0.5 else 0
            for r in rooms}
    return list(reversed(_sel_sort_bit(rooms, lambda r: bits[r]))), bits


def resolve_rooms(token, all_rooms):
    """观测里的房间名 → 全名集合（先精确匹配，不行再按后缀匹配）。"""
    token = token.strip().split('.')[-1]
    exact = {r for r in all_rooms if r == token}
    if exact:
        return exact
    return {r for r in all_rooms if r.endswith(token)}


# ---------------------------------------------------------------------------
# 推理 / 输出
# ---------------------------------------------------------------------------
def predict(seed, trace=False, observed=None):
    coords, comps = load_level()
    salt = seed % 1000
    sample = SAMPLES.get(seed, {})
    all_rooms = sorted({r for c in coords.values()
                        for s in c['sections'] for r in s['rooms']})
    resolved = [(resolve_rooms(tok, all_rooms), digit)
                for tok, digit in (observed or [])]
    result = {'level': 'SRR_MT01', 'map': 'SuburbRiotResidential/SRR_MT01_B00',
              'seed': seed, 'salt': salt,
              'observed': [{'rooms': sorted(rs), 'digit': d} for rs, d in resolved],
              'selected': draw_houses(seed),
              'houses': []}
    for name in sorted(coords):
        coord = coords[name]
        tag = name.replace('MultiroomPuzzle_Coordinator_House', 'H').replace('_BP', '')
        if trace:
            print('  [%s] pad=%s%s' % (name, coord['pad'],
                                       '  <== 本局密码房' if tag in result['selected'] else ''))
        rooms = pick_rooms(coord, salt, trace=trace)
        order, bits = process_order(rooms, comps, salt)
        code = digits(order, comps, salt, trace=trace)
        entry = {
            'coordinator': name,
            'tag': tag,
            'pad': coord['pad'],
            'selected': tag in result['selected'],
            'rooms': rooms,
            'comp_seeds': {r: comp_seed(r, comps) for r in rooms},
            'bits': bits,
            'order': order,
            'code': code,
            'obs_conflict': None,
            'sample': None,
        }
        for rs, digit in resolved:
            hits = [i for i, r in enumerate(order) if r in rs]
            if hits and all(code[i] != str(digit) for i in hits):
                entry['obs_conflict'] = sorted(rs)[0]
        actual = sample.get(coord['pad'])
        if actual:
            entry['sample'] = {'room': actual[0], 'code': actual[1]}
        result['houses'].append(entry)
    return result


def render(result):
    lines = ['SRR_MT01  郊区住宅区 · 撬开富豪宅的密码盘',
             'seed = %d   salt = %d   本局密码房 = %s'
             % (result['seed'], result['salt'], ', '.join(result['selected']))]
    for entry in result['houses']:
        name = entry['tag']
        lines.append('')
        lines.append('[%s]%s 密码盘 %s'
                     % (name, '' if entry['selected'] else '（未激活）', entry['pad']))
        lines.append('  4 个贴花位（分区顺序，同一间房可出现 2 次 = 该房 2 张贴花）: %s'
                     % ', '.join(r.split('House')[-1] for r in entry['rooms']))
        dupes = sorted({r for r in entry['rooms'] if entry['rooms'].count(r) > 1})
        if dupes:
            lines.append('    ! 重复房间（2 张贴花）: %s'
                         % ', '.join(d.split('House')[-1] for d in dupes))
        lines.append('  处理顺序（容器排序逆序）: %s'
                     % ' -> '.join('%s(%d)' % (r.split('House')[-1], i)
                                   for i, r in enumerate(entry['order'])))
        lines.append('  密码 = %s' % entry['code'])
        sample = entry.get('sample')
        if sample:
            lines.append('  实测 %s —— %s'
                         % (sample['code'],
                            '命中 ✓' if sample['code'] == entry['code'] else '不匹配 ✗'))
        if entry.get('obs_conflict'):
            lines.append('  ! 观测（--digit）与预测冲突（%s），请复查输入' % entry['obs_conflict'])
    lines.append('')
    if all(e['selected'] for e in result['houses']):
        lines.append('以上即本局 3 个密码房（seed 完全决定，无需进图试错）。')
    else:
        lines.append('标「未激活」的 %d 栋不是本局密码房（--all 显示全部候选）。'
                     % sum(1 for e in result['houses'] if not e['selected']))
    return '\n'.join(lines)


def dump_data(coords, comps):
    for name in sorted(coords):
        coord = coords[name]
        print('%-42s pad=%-30s count=%d sections=%d'
              % (name, coord['pad'], coord['count'], len(coord['sections'])))
        for i, sec in enumerate(coord['sections']):
            print('    [%d] min=%d rooms=%s'
                  % (i, sec['min'],
                     ', '.join('%s(%s)' % (r, comps.get(r, '?')) for r in sec['rooms'])))


def check():
    good = total = 0
    for seed in sorted(SAMPLES):
        result = predict(seed)
        by_pad = {e['pad']: e for e in result['houses']}
        sample = SAMPLES[seed]
        want = {by_pad[p]['tag'] for p in sample if p in by_pad}
        drawn = set(result['selected'])
        total += 1
        sel_ok = want == drawn
        good += 1 if sel_ok else 0
        print('seed=%-7d 选房 %s == 实测 %s  %s'
              % (seed, ', '.join(sorted(drawn)), ', '.join(sorted(want)),
                 'OK' if sel_ok else 'MISS'))
        for pad in sorted(sample):
            room, code = sample[pad]
            entry = by_pad.get(pad)
            total += 1
            code_ok = bool(entry) and entry['code'] == code
            rooms_ok = room is None or (bool(entry) and room in entry['rooms'])
            good += 1 if (code_ok and rooms_ok) else 0
            print('  %-28s 房间 %-8s 密码 %s==%s %s'
                  % (pad, 'OK' if rooms_ok else 'MISMATCH',
                     entry['code'] if entry else '?', code,
                     'OK' if code_ok else 'MISS'))
    print('自检：%d/%d 通过（选房 + 房间集合 + 4 位密码精确命中）' % (good, total))
    return good == total


def main(argv=None):
    ap = argparse.ArgumentParser(description='SRR_MT01 密码房 / 4 位密码 seed 推理')
    ap.add_argument('seed', nargs='?', type=int)
    ap.add_argument('--data', action='store_true', help='打印协调器/分区/房间/组件名')
    ap.add_argument('--trace', action='store_true', help='打印抽房与逐位抽取过程')
    ap.add_argument('--json', action='store_true', help='输出 JSON')
    ap.add_argument('--check', action='store_true', help='三样本自检（选房 + 密码精确匹配）')
    ap.add_argument('--digit', action='append', default=[], metavar='房间=数字',
                    help='观测校验：某房间的贴花数字，如 House1_Salon=4（与预测比对）')
    ap.add_argument('--all', action='store_true', help='输出全部 5 栋候选（默认只输出选中的 3 栋密码房）')
    ap.add_argument('--houses', default='', metavar='H1,H3,H4',
                    help='手动指定输出哪几栋（覆盖抽签结果），如 H1,H3,H4')
    args = ap.parse_args(argv)
    try:
        sys.stdout.reconfigure(encoding='utf-8')
    except Exception:
        pass

    if args.data:
        coords, comps = load_level()
        dump_data(coords, comps)
        return 0
    if args.check:
        return 0 if check() else 1
    if args.seed is None:
        ap.print_help()
        return 2

    observed = []
    for item in args.digit:
        if '=' not in item:
            print('--digit 需要 房间=数字 形式：%s' % item, file=sys.stderr)
            return 2
        room, digit = item.rsplit('=', 1)
        observed.append((room.strip(), digit.strip()))

    result = predict(args.seed, trace=args.trace, observed=observed)
    if args.houses:
        want = {t.strip().upper().replace('HOUSE', 'H') for t in args.houses.split(',') if t.strip()}
        result['houses'] = [e for e in result['houses'] if e['tag'] in want]
    elif not args.all:
        result['houses'] = [e for e in result['houses'] if e['selected']]
    if args.json:
        print(json.dumps(result, ensure_ascii=False, indent=2))
    else:
        print(render(result))
    return 0


if __name__ == '__main__':
    sys.exit(main())
