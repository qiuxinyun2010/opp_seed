/*
 * PSB_MT01 抽取过程取证脚本（Frida / Windows x64）
 *
 * 目的：一次性把「每区 3 具尸体」和「图案」的抽取序列读出来，
 *      不再靠离线猜 base。跑一局就行。
 *
 * 抓三样东西：
 *   1) GetSeed(actor) 的返回值        —— 找到协调器那次的种子
 *   2) RandSeeded(seed, n) 的入参      —— 抽取序列本体（n 只会是 2..16）
 *   3) 两个关键调用点的现场（可选）     —— 见 onEnter 注释
 *
 * 用法（在游戏已经进入关卡、尸体刚刷完之前挂上）：
 *    frida -l hook_psb.js -f TOTClient-Win64-Shipping.exe --runtime=v8
 *   或对已运行进程：
 *    frida -l hook_psb.js TOTClient-Win64-Shipping.exe
 *   然后进一局 PSB_MT01，等尸体刷出来（约 3~10 秒），把控制台输出发我。
 *
 * 只想看关键行：把 VERBOSE 改成 false。
 */
'use strict';

const VERBOSE = true;          // false = 只打印和 223551 / 243551 相关的
const MAX_N = 64;              // 只记录模数 <= 64 的抽取（尸体 ≤41、图案 ≤10）

const MODULE = 'TOTClient-Win64-Shipping.exe';
const RVA_GETSEED = 0x503B80;   // GetSeed(actor, 0)
const RVA_RAND = 0x2D29E0;      // RandSeeded(seed, n)
const RVA_LOOP = 0x4361CA08;    // 尸体抽取：RandSeeded(v143+243551+v71+v70, 组内数)
const RVA_POOL = 0x4361CA7C;    // 图案抽取：RandSeeded(v143+223551+v71+v70, 池大小)

const mod = Process.getModuleByName(MODULE);
const base = mod.base;
console.log('[psb] module base = ' + base + '  size=0x' + mod.size.toString(16));

function u32(x) { return x.toUInt32 ? x.toUInt32() : (x >>> 0); }

// ---------------------------------------------------------------- GetSeed
Interceptor.attach(base.add(RVA_GETSEED), {
  onEnter(args) {
    this.obj = args[0];
    this.arg1 = args[1].toInt32();
  },
  onLeave(ret) {
    const v = u32(ret);
    if (VERBOSE) {
      console.log('GETSEED obj=' + this.obj + ' arg1=' + this.arg1 +
                  ' -> 0x' + v.toString(16));
    }
  }
});

// -------------------------------------------------------------- RandSeeded
let randCount = 0;
Interceptor.attach(base.add(RVA_RAND), {
  onEnter(args) {
    const seed = u32(args[0]);
    const n = args[1].toInt32();
    this.seed = seed;
    this.n = n;
    if (n <= 0 || n > MAX_N) return;
    randCount++;
    const d1 = (seed - 223551) >>> 0;   // 图案抽取的偏移
    const d2 = (seed - 243551) >>> 0;   // 尸体抽取的偏移
    const interesting = d1 < 0x10000000 || d2 < 0x10000000;
    if (!VERBOSE && !interesting) return;
    console.log('RAND  seed=0x' + seed.toString(16).padStart(8, '0') +
                '  n=' + n.toString().padStart(2) +
                '  seed-223551=0x' + d1.toString(16) +
                '  seed-243551=0x' + d2.toString(16));
  }
});

// --------------------------------------------------- 两个调用点的现场（可选）
// 这里只打印「调用前一瞬」的寄存器快照，用来确认 v143 / v71 / v70。
// 若游戏版本偏移变了会导致崩溃，先注释掉这一段跑一遍。
try {
  [['loop', RVA_LOOP, 243551], ['pool', RVA_POOL, 223551]].forEach(function (item) {
    const tag = item[0];
    Interceptor.attach(base.add(item[1]), {
      onEnter() {
        const ctx = this.context;
        console.log('SITE ' + tag +
                    ' rcx=0x' + ctx.rcx.toString(16) +
                    ' rdx=0x' + ctx.rdx.toString(16) +
                    ' r8=0x' + ctx.r8.toString(16) +
                    ' r9=0x' + ctx.r9.toString(16) +
                    ' eax=0x' + ctx.rax.toString(16) +
                    ' esi=0x' + ctx.rsi.toString(16) +
                    ' edi=0x' + ctx.rdi.toString(16));
      }
    });
  });
} catch (e) {
  console.log('[psb] 调用点 hook 失败（可忽略）：' + e);
}

console.log('[psb] hooks installed. 现在进 PSB_MT01 一局，等尸体刷出来。');
console.log('[psb] Ctrl-C 结束，把上面的 RAND/GETSEED 行发回来。');
